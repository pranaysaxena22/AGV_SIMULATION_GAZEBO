import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.gen_gazebo_world import convert_floor_to_gz, wrap_yaw


def test_node_conversion_contract():
    assert convert_floor_to_gz(3, 37) == (-27, 17, 0.2)
    assert convert_floor_to_gz(47, 3) == (17, -17, 0.2)


def test_heading_wrap_contract():
    assert wrap_yaw(math.radians(90)) == pytest.approx(math.pi / 2)


def test_charge_bay_lamps_spawn_in_two_states_per_bay():
    from scripts.gen_gazebo_world import charge_bay_markers

    layout = {
        "stations": [
            {"id": "H01", "role": "parking", "x": 3, "y": 37},
            {"id": "H02", "role": "parking", "x": 7, "y": 37},
            {"id": "W34", "role": "default", "x": 20, "y": 10},
        ]
    }

    world = charge_bay_markers(layout)
    assert "H01_lamp_idle" in world
    assert "H01_lamp_charging" in world
    assert "H02_lamp_idle" in world
    assert "H02_lamp_charging" in world
    assert "-50" in world


def test_agv_beacon_models_emit_all_states_for_all_agvs_hidden_by_default():
    from scripts.gen_gazebo_world import agv_beacon_markers

    world = agv_beacon_markers()
    expected_names = [
        "AGV01_beacon_idle",
        "AGV01_beacon_moving",
        "AGV01_beacon_loading",
        "AGV01_beacon_unloading",
        "AGV01_beacon_blocked",
        "AGV01_beacon_charging",
        "AGV01_beacon_depleted",
        "AGV02_beacon_idle",
        "AGV02_beacon_moving",
        "AGV02_beacon_loading",
        "AGV02_beacon_unloading",
        "AGV02_beacon_blocked",
        "AGV02_beacon_charging",
        "AGV02_beacon_depleted",
        "AGV03_beacon_idle",
        "AGV03_beacon_moving",
        "AGV03_beacon_loading",
        "AGV03_beacon_unloading",
        "AGV03_beacon_blocked",
        "AGV03_beacon_charging",
        "AGV03_beacon_depleted",
        "AGV04_beacon_idle",
        "AGV04_beacon_moving",
        "AGV04_beacon_loading",
        "AGV04_beacon_unloading",
        "AGV04_beacon_blocked",
        "AGV04_beacon_charging",
        "AGV04_beacon_depleted",
        "AGV05_beacon_idle",
        "AGV05_beacon_moving",
        "AGV05_beacon_loading",
        "AGV05_beacon_unloading",
        "AGV05_beacon_blocked",
        "AGV05_beacon_charging",
        "AGV05_beacon_depleted",
    ]
    for name in expected_names:
        assert name in world
    assert world.count("-50.0") >= 35


def test_payload_crate_models_are_hidden_by_default_and_per_agv():
    from scripts.gen_gazebo_world import payload_crate_markers

    world = payload_crate_markers()
    for agv_name in ["AGV01", "AGV02", "AGV03", "AGV04", "AGV05"]:
        assert f"{agv_name}_crate" in world
    assert world.count("-50.0") >= 5


def test_blocked_corridor_disc_models_cover_all_waypoints_hidden_by_default():
    from scripts.gen_gazebo_world import blocked_corridor_markers

    world = blocked_corridor_markers()
    assert "W11_blocked_disc" in world
    assert "W35_blocked_disc" in world
    assert "W46_blocked_disc" in world
    assert world.count("-50.0") >= 1
