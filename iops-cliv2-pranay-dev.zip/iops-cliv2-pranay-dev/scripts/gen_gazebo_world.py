from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LAYOUT = ROOT / "shared" / "layouts" / "poc-floor.json"
DEFAULT_OUTPUT = ROOT / "shared" / "gazebo" / "agv_floor.sdf"

ROLE_COLORS = {
    "inbound": "#8ecae6",
    "outbound": "#f4d35e",
    "dispatch_dock": "#84a98c",
    "parking": "#f4a261",
    "ict": "#bde0fe",
    "fct": "#90be6d",
    "xray": "#cdb4db",
    "aoi": "#ffafcc",
    "rework": "#ffc8dd",
    "smt_feeder": "#2a9d8f",
    "smt_pnp": "#e76f51",
    "paste_print": "#f9844a",
    "reflow": "#9d8189",
    "aoi_post_smt": "#e9c46a",
    "wip_buffer": "#adb5bd",
    "conformal_coat": "#5e548e",
    "depanel": "#ffb703",
    "final_assembly": "#577590",
    "packaging": "#c7f9cc",
    "default": "#8d99ae",
}

ZONE_COLORS = {
    "A": "#dfe7fd",
    "B": "#d9f2d9",
    "C": "#f8e9d6",
}

AGV_STARTS = {
    "AGV01": "H01",
    "AGV02": "H02",
    "AGV03": "H03",
    "AGV04": "W34",
    "AGV05": "W38",
}

AGV_COLORS = {
    "AGV01": "#e63946",
    "AGV02": "#f4a261",
    "AGV03": "#2a9d8f",
    "AGV04": "#457b9d",
    "AGV05": "#9d4edd",
}

AGV_BEACON_STATES = (
    "idle",
    "moving",
    "loading",
    "unloading",
    "blocked",
    "charging",
    "depleted",
)

AGV_BEACON_COLORS = {
    "idle": "0.694118 0.694118 0.694118",
    "moving": "0.180392 0.729412 0.298039",
    "loading": "0.180392 0.498039 0.929412",
    "unloading": "0.298039 0.635294 0.929412",
    "blocked": "0.929412 0.529412 0.180392",
    "charging": "0.929412 0.749020 0.180392",
    "depleted": "0.850980 0.180392 0.180392",
}


def convert_floor_to_gz(sim_x: float, sim_y: float, sim_z: float = 0.2) -> tuple[float, float, float]:
    return (float(sim_x) - 30.0, float(sim_y) - 20.0, float(sim_z))


def wrap_yaw(yaw: float) -> float:
    wrapped = (yaw + math.pi) % (2.0 * math.pi) - math.pi
    if wrapped <= -math.pi:
        wrapped += 2.0 * math.pi
    if wrapped > math.pi:
        wrapped -= 2.0 * math.pi
    return wrapped


def heading_to_yaw_deg(heading_degrees: float) -> float:
    return wrap_yaw(math.radians(float(heading_degrees)))


def load_layout(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def node_map(layout: dict[str, Any]) -> dict[str, dict[str, float]]:
    nodes: dict[str, dict[str, float]] = {}
    for station in layout.get("stations", []):
        nodes[station["id"]] = {"x": float(station["x"]), "y": float(station["y"])}
    for waypoint in layout.get("waypoints", []):
        nodes[waypoint["id"]] = {"x": float(waypoint["x"]), "y": float(waypoint["y"])}
    return nodes


def role_color(role: str | None) -> str:
    return ROLE_COLORS.get((role or "").strip(), ROLE_COLORS["default"])


def hex_to_sdf_rgba(color: str, alpha: float | None = None) -> str:
    hex_color = (color or "#000000").strip()
    if not hex_color.startswith("#"):
        raise ValueError(f"Unsupported color format: {color!r}")

    hex_value = hex_color[1:]
    if len(hex_value) == 3:
        hex_value = "".join(ch * 2 for ch in hex_value)
    if len(hex_value) == 6:
        r, g, b = (int(hex_value[i : i + 2], 16) for i in (0, 2, 4))
        a = 1.0 if alpha is None else float(alpha)
    elif len(hex_value) == 8:
        r, g, b = (int(hex_value[i : i + 2], 16) for i in (0, 2, 4))
        a = int(hex_value[6:8], 16) / 255.0 if alpha is None else float(alpha)
    else:
        raise ValueError(f"Unsupported color format: {color!r}")

    return " ".join(f"{channel / 255.0:.6f}" for channel in (r, g, b)) + f" {a:.6f}"


def zone_bounds(layout: dict[str, Any]) -> dict[str, tuple[float, float, float, float]]:
    bounds = layout.get("bounds", {"minX": 0, "minY": 0, "maxX": 60, "maxY": 40})
    min_x = float(bounds.get("minX", 0))
    max_x = float(bounds.get("maxX", 60))
    min_y = float(bounds.get("minY", 0))
    max_y = float(bounds.get("maxY", 40))
    zone_ranges = {
        "A": (min_x, max_x / 3.0, min_y, max_y),
        "B": (max_x / 3.0, 2.0 * max_x / 3.0, min_y, max_y),
        "C": (2.0 * max_x / 3.0, max_x, min_y, max_y),
    }
    return zone_ranges


def make_ground_plane() -> str:
    return """
    <model name="ground_plane">
      <static>true</static>
      <link name="ground_link">
        <visual name="ground_visual">
          <geometry><plane><normal>0 0 1</normal><size>120 80</size></plane></geometry>
          <material>
            <ambient>0.85 0.85 0.82 1</ambient>
            <diffuse>0.85 0.85 0.82 1</diffuse>
            <specular>0.1 0.1 0.1 1</specular>
          </material>
        </visual>
      </link>
    </model>
    """


def make_zone_tints(layout: dict[str, Any]) -> str:
    blocks: list[str] = []
    for zone, (min_x, max_x, min_y, max_y) in zone_bounds(layout).items():
        cx = (min_x + max_x) / 2.0
        cy = (min_y + max_y) / 2.0
        gz_x, gz_y, gz_z = convert_floor_to_gz(cx, cy)
        size_x = max_x - min_x
        size_y = max_y - min_y
        color = ZONE_COLORS.get(zone, "#eeeeee")
        rgba = hex_to_sdf_rgba(color, 0.24)
        blocks.append(
            f"""
    <model name=\"zone_{zone}\">
      <static>true</static>
      <pose>{gz_x} {gz_y} {gz_z - 0.02} 0 0 0</pose>
      <link name=\"zone_link\">
        <visual name=\"zone_visual\">
          <geometry><box><size>{size_x} {size_y} 0.02</size></box></geometry>
          <material>
            <ambient>{rgba}</ambient>
            <diffuse>{rgba}</diffuse>
            <specular>0.2 0.2 0.2 0.2</specular>
          </material>
        </visual>
      </link>
    </model>
            """.strip()
        )
    return "\n".join(blocks)


def edge_models(layout: dict[str, Any]) -> str:
    nodes = node_map(layout)
    blocks: list[str] = []
    for edge in layout.get("edges", []):
        src_id = edge.get("from")
        dst_id = edge.get("to")
        if src_id not in nodes or dst_id not in nodes:
            continue
        src = nodes[src_id]
        dst = nodes[dst_id]
        dx = float(dst["x"]) - float(src["x"])
        dy = float(dst["y"]) - float(src["y"])
        length = math.hypot(dx, dy)
        if length <= 0:
            continue
        cx = (float(src["x"]) + float(dst["x"])) / 2.0
        cy = (float(src["y"]) + float(dst["y"])) / 2.0
        gz_x, gz_y, gz_z = convert_floor_to_gz(cx, cy)
        yaw = wrap_yaw(math.atan2(dy, dx))
        blocks.append(
            f"""
    <model name=\"edge_{src_id}_{dst_id}\">
      <static>true</static>
      <pose>{gz_x} {gz_y} {gz_z + 0.03} 0 0 {yaw}</pose>
      <link name=\"lane_link\">
        <visual name=\"lane_visual\">
          <geometry><box><size>{length} 0.18 0.02</size></box></geometry>
          <material>
            <ambient>0.949020 0.949020 0.949020 1.000000</ambient>
            <diffuse>0.949020 0.949020 0.949020 1.000000</diffuse>
            <specular>0.2 0.2 0.2 1</specular>
          </material>
        </visual>
      </link>
    </model>
            """.strip()
        )
    return "\n".join(blocks)


def waypoint_models(layout: dict[str, Any]) -> str:
    blocks: list[str] = []
    for waypoint in layout.get("waypoints", []):
        node_id = waypoint["id"]
        x = float(waypoint["x"])
        y = float(waypoint["y"])
        gz_x, gz_y, gz_z = convert_floor_to_gz(x, y)
        blocks.append(
            f"""
    <model name=\"{node_id}\">
      <static>true</static>
      <pose>{gz_x} {gz_y} {gz_z + 0.02} 0 0 0</pose>
      <link name=\"waypoint_link\">
        <visual name=\"waypoint_visual\">
          <geometry><cylinder><radius>0.12</radius><length>0.05</length></cylinder></geometry>
          <material>
            <ambient>0.2 0.2 0.2 1</ambient>
            <diffuse>0.2 0.2 0.2 1</diffuse>
          </material>
        </visual>
      </link>
    </model>
            """.strip()
        )
    return "\n".join(blocks)


def station_models(layout: dict[str, Any]) -> str:
    blocks: list[str] = []
    for station in layout.get("stations", []):
        station_id = station["id"]
        x = float(station["x"])
        y = float(station["y"])
        gz_x, gz_y, gz_z = convert_floor_to_gz(x, y)
        role = station.get("role")
        color = role_color(role)
        size_x = 0.9
        size_y = 0.9
        if station_id.startswith("H"):
            size_x = size_y = 1.1
        rgba = hex_to_sdf_rgba(color)
        blocks.append(
            f"""
    <model name=\"{station_id}\">
      <static>true</static>
      <pose>{gz_x} {gz_y} {gz_z + 0.06} 0 0 0</pose>
      <link name=\"station_link\">
        <visual name=\"station_visual\">
          <geometry><box><size>{size_x} {size_y} 0.12</size></box></geometry>
          <material>
            <ambient>{rgba}</ambient>
            <diffuse>{rgba}</diffuse>
            <specular>0.2 0.2 0.2 1</specular>
          </material>
        </visual>
      </link>
    </model>
            """.strip()
        )
    return "\n".join(blocks)


def charge_bay_markers(layout: dict[str, Any]) -> str:
    blocks: list[str] = []
    for station in layout.get("stations", []):
        if station.get("role") != "parking":
            continue
        station_id = station["id"]
        x = float(station["x"])
        y = float(station["y"])
        gz_x, gz_y, gz_z = convert_floor_to_gz(x, y)

        for lamp_state, color in (("idle", "0.694118 0.694118 0.694118"), ("charging", "0.929412 0.749020 0.180392")):
            blocks.append(
                f"""
    <model name=\"{station_id}_lamp_{lamp_state}\">
      <static>true</static>
      <pose>{gz_x} {gz_y} {-50.0} 0 0 0</pose>
      <link name=\"{station_id}_lamp_{lamp_state}_link\">
        <visual name=\"{station_id}_lamp_{lamp_state}_visual\">
          <geometry><cylinder><radius>0.35</radius><length>0.08</length></cylinder></geometry>
          <material>
            <ambient>{color} 1.000000</ambient>
            <diffuse>{color} 1.000000</diffuse>
          </material>
        </visual>
      </link>
    </model>
                """.strip()
            )
    return "\n".join(blocks)


def payload_crate_markers(layout: dict[str, Any] | None = None) -> str:
    if layout is None:
        try:
            layout = load_layout(DEFAULT_LAYOUT)
        except Exception:
            layout = {}
    nodes = node_map(layout)
    blocks: list[str] = []
    for agv_name in (f"AGV{i:02d}" for i in range(1, 6)):
        node_id = AGV_STARTS.get(agv_name, "H01")
        x = float(nodes.get(node_id, {"x": 0.0, "y": 0.0})["x"])
        y = float(nodes.get(node_id, {"x": 0.0, "y": 0.0})["y"])
        gz_x, gz_y, _ = convert_floor_to_gz(x, y)
        blocks.append(
            f"""
    <model name="{agv_name}_crate">
      <static>true</static>
      <pose>{gz_x} {gz_y} -50.0 0 0 0</pose>
      <link name="{agv_name}_crate_link">
        <visual name="{agv_name}_crate_visual">
          <geometry><box><size>0.55 0.55 0.40</size></box></geometry>
          <material>
            <ambient>0.75 0.50 0.20 1.000000</ambient>
            <diffuse>0.75 0.50 0.20 1.000000</diffuse>
          </material>
        </visual>
      </link>
    </model>
                """.strip()
        )
    return "\n".join(blocks)


def blocked_corridor_markers(layout: dict[str, Any] | None = None) -> str:
    if layout is None:
        try:
            layout = load_layout(DEFAULT_LAYOUT)
        except Exception:
            layout = {}
    blocks: list[str] = []
    for waypoint in layout.get("waypoints", []):
        node_id = waypoint["id"]
        x = float(waypoint["x"])
        y = float(waypoint["y"])
        gz_x, gz_y, _ = convert_floor_to_gz(x, y)
        blocks.append(
            f"""
    <model name="{node_id}_blocked_disc">
      <static>true</static>
      <pose>{gz_x} {gz_y} -50.0 0 0 0</pose>
      <link name="{node_id}_blocked_disc_link">
        <visual name="{node_id}_blocked_disc_visual">
          <geometry><cylinder><radius>0.22</radius><length>0.06</length></cylinder></geometry>
          <material>
            <ambient>0.929412 0.529412 0.180392 1.000000</ambient>
            <diffuse>0.929412 0.529412 0.180392 1.000000</diffuse>
          </material>
        </visual>
      </link>
    </model>
                """.strip()
        )
    return "\n".join(blocks)


def agv_beacon_markers(layout: dict[str, Any] | None = None) -> str:
    if layout is None:
        try:
            layout = load_layout(DEFAULT_LAYOUT)
        except Exception:
            layout = {}
    nodes = node_map(layout)
    blocks: list[str] = []
    for agv_name in (f"AGV{i:02d}" for i in range(1, 6)):
        node_id = AGV_STARTS.get(agv_name, "H01")
        x = float(nodes.get(node_id, {"x": 0.0, "y": 0.0})["x"])
        y = float(nodes.get(node_id, {"x": 0.0, "y": 0.0})["y"])
        gz_x, gz_y, _ = convert_floor_to_gz(x, y)
        for state in AGV_BEACON_STATES:
            color = AGV_BEACON_COLORS.get(state, AGV_BEACON_COLORS["idle"])
            blocks.append(
                f"""
    <model name=\"{agv_name}_beacon_{state}\">
      <static>true</static>
      <pose>{gz_x} {gz_y} -50.0 0 0 0</pose>
      <link name=\"{agv_name}_beacon_{state}_link\">
        <visual name=\"{agv_name}_beacon_{state}_visual\">
          <geometry><cylinder><radius>0.18</radius><length>0.08</length></cylinder></geometry>
          <material>
            <ambient>{color} 1.000000</ambient>
            <diffuse>{color} 1.000000</diffuse>
          </material>
        </visual>
      </link>
    </model>
                """.strip()
            )
    return "\n".join(blocks)


def agv_models(layout: dict[str, Any]) -> str:
    nodes = node_map(layout)
    blocks: list[str] = []
    for i in range(1, 6):
        agv_name = f"AGV{i:02d}"
        node_id = AGV_STARTS[agv_name]
        x = float(nodes[node_id]["x"])
        y = float(nodes[node_id]["y"])
        gz_x, gz_y, gz_z = convert_floor_to_gz(x, y)
        color = AGV_COLORS[agv_name]
        rgba = hex_to_sdf_rgba(color)
        blocks.append(
            f"""
    <model name=\"{agv_name}\">
      <pose>{gz_x} {gz_y} {gz_z} 0 0 0</pose>
      <link name=\"chassis\">
        <kinematic>true</kinematic>
        <gravity>false</gravity>
        <inertial>
          <mass>120</mass>
          <inertia>
            <ixx>8</ixx><iyy>16</iyy><izz>20</izz>
            <ixy>0</ixy><ixz>0</ixz><iyz>0</iyz>
          </inertia>
        </inertial>
        <visual name=\"body\">
          <geometry><box><size>1.2 0.8 0.35</size></box></geometry>
          <material>
            <ambient>{rgba}</ambient>
            <diffuse>{rgba}</diffuse>
            <specular>0.2 0.2 0.2 1</specular>
          </material>
        </visual>
        <collision name=\"body\">
          <geometry><box><size>1.2 0.8 0.35</size></box></geometry>
        </collision>
      </link>
      <plugin filename=\"gz-sim-velocity-control-system\" name=\"gz::sim::systems::VelocityControl\">
        <topic>/model/{agv_name}/cmd_vel</topic>
      </plugin>
      <plugin filename=\"gz-sim-pose-publisher-system\" name=\"gz::sim::systems::PosePublisher\">
        <publish_model_pose>true</publish_model_pose>        <publish_link_pose>false</publish_link_pose>        <update_frequency>20</update_frequency>
      </plugin>
    </model>
            """.strip()
        )
    return "\n".join(blocks)


def generate_world(layout: dict[str, Any]) -> str:
    return f"""<sdf version=\"1.9\">
  <world name=\"agv_floor\">
    <physics name=\"10ms\" type=\"ignored\">
      <max_step_size>0.01</max_step_size>
      <real_time_factor>1.0</real_time_factor>
    </physics>
    <plugin filename=\"gz-sim-physics-system\" name=\"gz::sim::systems::Physics\"/>
    <plugin filename=\"gz-sim-user-commands-system\" name=\"gz::sim::systems::UserCommands\"/>
    <plugin filename=\"gz-sim-scene-broadcaster-system\" name=\"gz::sim::systems::SceneBroadcaster\"/>

    {make_ground_plane()}
    {make_zone_tints(layout)}
    {edge_models(layout)}
    {waypoint_models(layout)}
    {station_models(layout)}
    {charge_bay_markers(layout)}
    {payload_crate_markers(layout)}
    {blocked_corridor_markers(layout)}
    {agv_beacon_markers(layout)}
    {agv_models(layout)}
  </world>
</sdf>
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a floor SDF from the canonical layout.")
    parser.add_argument("--layout", type=Path, default=DEFAULT_LAYOUT, help="Path to the JSON layout file.")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Path to the generated SDF file.")
    args = parser.parse_args()

    layout = load_layout(args.layout)
    sdf = generate_world(layout)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(sdf, encoding="utf-8")
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
