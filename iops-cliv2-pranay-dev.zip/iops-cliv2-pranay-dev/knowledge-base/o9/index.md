---
title: "Knowledge Base"
description: "Deloitte curated reference documentation for LLM agents"
---

# Knowledge Base

> Deloitte curated reference documentation for LLM agents working with o9 implementations.

## LLM Reference

For AI/LLM consumption, use the aggregated content index:

- [llms.txt](llms.txt) - Index of all knowledge base sections

## Browse Sections

- [View all sections](sections/) - Browse available reference documentation

---

*This content is maintained separately and can be updated without rebuilding the container.*
