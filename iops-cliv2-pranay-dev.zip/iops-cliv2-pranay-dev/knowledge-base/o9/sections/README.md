# Knowledge Base Sections

This directory contains markdown reference files that are served directly to LLM agents.

## File Naming Convention

- Use **kebab-case**: `uat-prepack-config.md`, `best-practices.md`
- Keep names descriptive but concise
- Avoid special characters and spaces

## File Structure

Each markdown file should include:

1. **Frontmatter** (required):
   ```yaml
   ---
   title: "Section Title"
   description: "Brief description for LLM context"
   ---
   ```

2. **Content** in standard markdown format

## Updating Content

1. Edit or add `.md` files in this directory
2. Update `../llms.txt` to reference new sections
3. Changes are served immediately (no rebuild required)

## URL Pattern

Files are accessible at:
- Web: `http://{host}/o9/knowledge-base/sections/{filename}/`
- Raw MD: `http://{host}/o9/knowledge-base/sections/{filename}/?format=md`

## Example Entry in llms.txt

```text
- [Section Title](http://${HOST_NAME}/o9/knowledge-base/sections/section-name/?format=md): Brief description
```