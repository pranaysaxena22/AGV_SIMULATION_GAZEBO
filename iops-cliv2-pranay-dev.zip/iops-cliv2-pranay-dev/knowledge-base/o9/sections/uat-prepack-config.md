---
title: "UAT - Prepack Configuration"
description: "UAT test case for validating Prepack Configuration in o9 Supply Planning"
---

# UAT_SP_Prepack Configuration

**Description:** Prepack Configuration

**Action:** Always make sure to get the detailed answer by looking for section "To update the configuration of a measure" in your rag corpus "o9_corpus" as well as vendor technical documentation tool and append all the steps found from the search in following steps as well.

## Test Steps

**Step 1:** Login to o9 solutions WEB UI using the proper credentials
**Expected Results:** Planner is able to login to the WEB UI successfully

**Step 2:** Click on the 9 cubes icon (Workspace) at the top left. Navigate to the Master Data Workspace
**Expected Results:** "Master Data" Workspace is displayed

**Step 3:** Select the Master Data page group and choose the Item page. Select the Prepack Configuration tab at the top of the page. If the page does not load, select the three dots in the righthand corner and select Factory Setting
**Expected Results:** Prepack Configuration tab loads and displays correctly

**Step 4:** This page shows the Prepack Distribution Curve ratio for SKUs to support breaking down the Prepack LUM conversion factor.
**Expected Results:** Planner understands purpose of the Prepack Configuration page

**Step 5:** In the top pivot chart, filter to VN00000DBLKP0XK004, VN000EE3W00P0CX012, VN000D3HBKAP0FX006, and VN000D3HBKAP0CX012 under the "Prepack" column.
**Expected Results:** Planner filters to test data in Prepack Configuration table

**Step 6:** Use the chain link action button under the Actions column on the lefthand side of the pivot chart to send the prepack details down to the Prepack Configuration (Multiplier) pivot chart.
- For VN00000DBLKP0XK004: Prepack Distribution Curve Ratio is 4, prepack distribution is 1 across 4 SKUs
- For VN000EE3W00P0CX012: Prepack Distribution Curve Ratio is 12, prepack distribution sums to 12 across 5 SKUs
- For VN000D3HBKAP0CX012: Prepack Distribution Curve Ratio is 12, prepack distribution sums to 12 across 5 SKUs
- For VN000D3HBKAP0FX006: Prepack distribution is 6, prepack distribution sums to 6

**Expected Results:** Planner notes down and reviews the Prepack Distribution ratio that is used to break down prepacks to the LUM

**Step 7:** Now, select the Workspace icon and select the Vans SP workspace. Choose the Transactional Data page group and select the Sales Order page. If the page does not load, select the three dots in the righthand corner and select Factory Setting
**Expected Results:** Sales Order page loads and displays correctly

**Step 8:** In the pivot chart, filter to "VN00000DBLK, VN000EE3W00, and VN000D3HBKA" under Planning Item. Under Item Type, filter to "Prepack"
**Expected Results:** Planner sets up pivot chart with Prepack flag for test items

**Step 9:** Let's start with VN000D3HBKA. Under the "Item" column, filter to VN000D3HBKAP0CX012. Scroll to the right to review the SO Open Request Quantity and SO Open Request LUM Quantity fields. Review the example and confirm the LUM quantity matches the Conversion factor of 12 from the previous steps (ex: 5 SO Open Request converts to 60 LUM from multiplying by 12). After review is completed, select Filters at the top right of the chart and select "Clear Filters".
**Expected Results:** Planner validates LUM conversion of Prepack based on Distribution multiplier

**Step 10:** Now, let's review VN000EE3W00. Under the Item column, filter to "VN000EE3W00P0CX012". Scroll to the right to review the SO Open Request Quantity and SO Open Request LUM. Review the example and confirm the LUM quantity matches the Conversion factor of 12 from the previous steps (ex: 5 SO Open Request converts to 60 LUM from multiplying by 12)
**Expected Results:** Planner validates LUM conversion of Prepack based on Distribution multiplier

**Step 11:** Let's look at Purchase Orders next. Select the Purchase Order page from the Transactional Data page group. If the page does not load, select the three dots in the righthand corner and select Factory Setting
**Expected Results:** Planner navigates to and loads Purchase Orders page

**Step 12:** In the PO Request pivot chart, let's look at "VN00000DBLK". Filter to that Style Color under "Planning Item" and filter to "Prepack" under Item type. Under Item, filter to "VN00000DBLKP0XK004". Scroll to the right to review the Open PO quantity and the Open PO LUM Quantity. Review the example and confirm the LUM quantity matches the Conversion factor of 4 from the previous steps (ex: 16 PO Open Request converts to 64 LUM from multiplying by 4). After review is completed, select Filters at the top right of the chart and select "Clear Filters".
**Expected Results:** Planner validates LUM conversion of Prepack based on Distribution multiplier

**Step 13:** Let's look at Purchase Requisitions next. Select the Purchase Requisition page from the Transactional Data page group. If the page does not load, select the three dots in the righthand corner and select Factory Setting. Select the Layout button at the top right of the pivot chart. Remove the selection for Season and Select Planning Month. Select the Data tab and make sure Open PR LUM is added into the feed. Select Apply
**Expected Results:** Purchase Requisition page loads and displays correctly

**Step 14:** In the pivot chart, filter to VN000D3HBKAP0CX012 under Item. Filter to Prepack under Item Type. For M03-24, note down the LUM and Open PR Quantities across DC / Combinations. Divide the LUM Quantity by the Open PR Quantity for each example to validate the multiplier of 12 is applied correctly
**Expected Results:** Planner validates LUM conversion of Prepack based on Distribution multiplier

**Step 15:** Let's look at the inbound TPSN now. Select the TPSN & PLIR inputs page under the Transactional Data page group. If the page does not load, select the three dots in the righthand corner and select Factory Setting
**Expected Results:** TPSN page loads and displays correctly

**Step 16:** In the TPSN pivot chart, filter to "VN000D3HBKA" under Planning Item, filter to "Prepack" under Item Type, and VN000D3HBKAP0FX006 under Planning Item. Review the example and confirm the LUM quantity matches the Conversion factor of 6 from the previous steps (ex: 28 TPSN Input converts to 168 TPSN LUM from multiplying by 6). After review is completed, select Filters at the top right of the chart and select "Clear Filters".
**Expected Results:** Planner validates LUM conversion of Prepack based on Distribution multiplier

**Step 17:** Select the PLIR tab at the top of the page. In the Seasonal PLIR Input tab, let's look at the Prepack LUM for PLIR.
**Expected Results:** Planner loads PLIR tab

**Step 18:** In the pivot chart, filter to "VN00000DBLK under Planning Item. Filter to Prepack under Item Type. Filter to VN00000DBLKP0XK004 under Item. Review the example and confirm the LUM quantity matches the Conversion factor of 4 from the previous steps (ex: 11 TPSN Input converts to 44 TPSN LUM from multiplying by 4). After review is completed, select Filters at the top right of the chart and select "Clear Filters".
**Expected Results:** Prepack LUM validation complete

**Step 19:** The Prepack disaggregation supports capacity consumption at the Style Color level for prepacks. Now, let's follow that prepack breakdown after the solver run to see how the capacity consumption occurred
**Expected Results:** Planner understands purpose of the Prepack Disaggregation for capacity consumption

**Step 20:** Under the Vans SP workspace, select the Global Plan Review page group. Select the Global Vendor Buy Plan page.
**Expected Results:** Planner navigates to and loads Global Vendor Buy Plan page

**Step 21:** In the top pivot chart, filter to PLIR_PP_VN00000DBLKP0XK004, 1000904782_PP_VN000D3HBKAP0BC012, and 1000905202_PP_VN000EE3W00P0CX012 under the Demand ID column. Use the small chain link button under the Actions column on the left side to send all of the data down to the lower pivot charts
**Expected Results:** Planner sets up scope filters and sends data down to lower pivot charts

**Step 22:** Review the capacity consumption details in the middle pivot chart
**Expected Results:** Planner reviews capacity consumption details in the middle pivot chart

**Step 23:** Scroll to the bottom pivot chart. Under the Item Type column, validate all are Prepacks. Scroll to the right to see the PR Quantity and PR LUM quantity details. Review the LUM to PR Header conversion using the LUM multiplier factors noted down in Step 6. Validate the LUM disaggregation shows correctly based on those conversion factors
**Expected Results:** Planner validates Prepack disaggregation in o9 planned orders

**Step 24:** Now, let's follow a prepack to the Outbound PLIR page. Select the PLIRs page of the Global Plan Review page group. Select the DTC PLIR tab at the top of the page
**Expected Results:** Planner loads and navigates to PLIR page

**Step 25:** In the top pivot chart, filter to VN00000DBLK under the Planning Item column. In the bottom chart, filter to PLIR_PP_VN00000DBLKP0XK004 under Demand ID. Validate the Prepack quantity from the previous step is visible under Demand Quantity
**Expected Results:** Planner validates Prepack PLIR quantity for Outbound PLIR
