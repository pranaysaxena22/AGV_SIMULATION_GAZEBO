---
title: "UAT - Forecast Consumption & Canada/Mexico Demand"
description: "UAT test case for validating Forecast Consumption and Canada/Mexico Demand in o9"
---

# UAT_SP_Forecast Consumption & Canada and Mexico Demand

**Description:** Forecast Consumption & Canada and Mexico Demand

## Test Steps

**Step 1:** Login to o9 solutions WEB UI using the proper credentials
**Expected Results:** Planner is able to login to the WEB UI successfully

**Step 2:** Click on the 9 cubes icon (Workspace) at the top left. Navigate to the Netting and Prioritization
**Expected Results:** "Netting and Prioritization" Workspace is displayed

**Step 3:** Select the Forecast Netting Page group and select the Demand Inputs page. Select the Netting parameters tab at the top of the page
**Expected Results:** Planner navigates to and loads Netting Parameters page

**Step 4:** In this page, the planner can set the forward/backward months o9 can use to net the forecast against at the Style Color / Sales Org Channel level. For new items, they can only net forward. For carryover items, they can net forward and backwards. In the pivot chart, filter to VN00000DBLK. For CA_Wholesale, set the netting forward and backward months to 1 as this is a carryover item. Select save at the top of the screen after you input your months.
**Expected Results:** Planner inputs forward and backward netting values to validate netting parameters

**Step 5:** Select the Forecast Netting Page group and select the Demand Inputs page. Select the Orders tab at the top of the page.
**Expected Results:** Planner loads page and sets up pivot chart for test scenario

**Step 6:** The top pivot chart called "Sales Orders" shows the Style Color Order Details. Filter to "VN00000DBLK" under "Planning Item". Note down the Open Order of 55 for Canada Wholesale in M03-24. Now, filter to "VN000D3HBKA" and note down the order quantity of 156 for Mexico Wholesale in M03-24
**Expected Results:** Planner validates and notes down Canada Wholesale Demand and Mexico Wholesale Demand

**Step 7:** Now, select the Forecast tab at the top of the page. If the page does not load, select the three dots in the righthand corner and select Factory setting
**Expected Results:** Planner loads Forecast page

**Step 8:** In the pivot chart, filter to VN00000DBLK and VN000D3HBKA under the Planning Item column. Under Sales Org Channel, filter to MX Wholesale and CA Wholesale.
**Expected Results:** Planner filters to test data in pivot chart

**Step 9:** Note down the Consensus Forecast of 116 for VN00000DBLK in CA Wholesale for M03-24. Note down the Consensus Forecast of 417 for VN000D3HBKA in MX Wholesale for M03-24
**Expected Results:** Planner validates Consensus forecast availability and notes down example data

**Step 10:** Now, select the Netted Output page and select the Monthly Netted Output tab at the top of the page
**Expected Results:** Planner navigates to and loads Netted Output page

**Step 11:** In the pivot chart, filter to "VN00000DBLK" and "VN000D3HBKA" under Planning Item. Scroll to the right to M03-24. For VN00000DBLK at CA Wholesale, note down that the item is Make to Stock (MTS). Note down that the Netted Demand Quantity is 116. Select the arrow button at the top of that column to see the Netted Demand Details.
**Expected Results:** Planner reviews netted demand output for test data

**Step 12:** For this example, note down how the FCST_Order is showing as 55, which makes the open order from the previous step. Note down how the UBF is 61, which matches Consensus Forecast from the previous steps - the Orders.
**Expected Results:** Planner validates netted output

**Step 13:** Now, scroll to M03-24 for VN000D3HBKA at MX Wholesale. Note down how the item is MTS. Note down how the Netted Demand is 4552. Under the Demand Details columns to the right, note down how the FCST_ORDER is 156 and how the UBF is 4396, which matches Consensus Forecast from the previous steps - the Orders.
**Expected Results:** Planner validates netted output

**Step 14:** Across the Demand Details columns, note down how there is no longer "RTF"
**Expected Results:** Planner validates removal of RTF

**Step 15:** Now, select the Size Profile Page group and choose the Profiled Demand page. Select the Size Profile Setup tab at the top of the page. If the page does not load, select the three dots in the righthand corner and select Factory Setting
**Expected Results:** Planner navigates to and loads Profiled Demand page

**Step 16:** The top pivot chart shows the Size Profile by Class 1, where the Planner can see the system-generated size profile for the Class 1 and override the percentage if needed. In the bottom pivot chart, the planner can use the chain link action button to send Class 1 data down to the bottom chart to review the style color level size distribution.
**Expected Results:** Planner understands purpose of this page

**Step 17:** In the top pivot chart, filter to MN Pants under the Class 1 and filter to CA Wholesale under Sales Org Channel. Note down the Class 1 size profile distribution for these pants. Use the chain link action button to send the data down to the Style Color pivot chart. Under Planning Item in the bottom pivot chart, filter to "VN00000DBLK. Note down the Style Color Size Profile Recommendations.
**Expected Results:** Planner reviews size profile breakdowns and notes down test data

**Step 18:** Now, select the Forecast by Size tab at the top of the page. This page shows the UBF at the Style Color Size level based on the size profiles from the previous steps. Under Planning Item, filter to VN00000DBLK and filter to CA_Wholesale under Sales Org Channel. Remember back to the previous step where we noted down that the UBF for this Style Color / Sales Org Channel combination is 61 for M03-24. Sum the Forecast for this Style Color / Sales Org Channel combination and validate it matches the UBF input from the previous step
**Expected Results:** Planner validates the UBF distributed by size

**Step 19:** Now, take the o9-out SKU level forecasts for M03-24 and divide by 61 (the UBF total). This ensures we validate the % split by size we noted down from the previous steps. Ex: 16 divided by 61 is 26%, which matches the size profile percentage from the previous step
**Expected Results:** Planner validates the size profile distribution of the UBF

**Step 20:** Let's return to the Size Profile Recommendation tab at the top of the page so we can make overrides to the size profile and validate. Return to the bottom pivot called Size Profile by Style Color. Filter to VN00000DBLK under Planning Item and CA Wholesale under Sales Org Channel. Override the size profile % in the Override column to any value(s) that sum to 100%.
**Expected Results:** Planner overrides size profile breakdown

**Step 21:** Hit save at the top of the screen when you have overridden your changes. Select the "Apply to Forecast" button at the top of the pivot chart 2
**Expected Results:** Planner applies size profile breakdown changes to netted forecast

**Step 22:** Return to the Forecast by Size tab at the top of the page. Refresh your data using the o9 refresh button at the top of the page. In the pivot chart, filter to VN00000DBLK under Planning Item and CA Wholesale under Sales Org Channel. Validate the size profile override was applied correctly by reviewing the updated forecast distribution
**Expected Results:** Planner validates size profile override was applied to forecast
