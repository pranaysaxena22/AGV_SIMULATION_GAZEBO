---
title: "Opcenter - How to write Type Files"
description: "When writing Type files in UL format always remember to use following guidelines"
---

# GuidRef is always important and must always be added if referring to other parameter types

**Description:** Always add GuidRef after Guid annotation if it is refering to another parameter type in same UL file

**Example:** As you see the following example, @GuidRef(856b9add-e2ed-4217-9ff3-5d7959fc7a7e) in parameter type ToyotaAppU4DMExtApp_PalletOperationMapping which is refering to guid of ToyotaAppU4DMExtApp_PalletMapping. Always remember to do that.

```
[@Guid(c9d3e922-a8e1-44d2-9e76-b1391639112f)]
PARAMETERTYPE ToyotaAppU4DMExtApp_PalletOperationMapping
WITH
    [@Guid(92eb358d-a677-4c63-821b-3395940ebae8)]
    [@GuidRef(856b9add-e2ed-4217-9ff3-5d7959fc7a7e)]
    CellToPalletMapping AS list of TMNA.AppU4DM.ToyotaAppU4DMExtApp.TOPOMModel.Types.ToyotaAppU4DMExtApp_PalletMapping
    [Length = 255]
    [@Guid(7d2a6663-24fe-4274-a8bd-b84ac8787157)]
    EquipmentId AS string

[@Guid(856b9add-e2ed-4217-9ff3-5d7959fc7a7e)]
PARAMETERTYPE ToyotaAppU4DMExtApp_PalletMapping
WITH
    [Length = 255]
    [@Guid(93cb85e4-940d-4e66-addd-6e8d0bed8e6b)]
    SerialNumber AS string
```

# How to define the list parameter types

**Description:** If parameter type is of list type then you must define it as shown in example below

**Example:** Check the following example of CellToPalletMapping parameter.

```
[@Guid(c9d3e922-a8e1-44d2-9e76-b1391639112f)]
PARAMETERTYPE ToyotaAppU4DMExtApp_PalletOperationMapping
WITH
    [@Guid(92eb358d-a677-4c63-821b-3395940ebae8)]
    [@GuidRef(856b9add-e2ed-4217-9ff3-5d7959fc7a7e)]
    CellToPalletMapping AS list of TMNA.AppU4DM.ToyotaAppU4DMExtApp.TOPOMModel.Types.ToyotaAppU4DMExtApp_PalletMapping
    [Length = 255]
    [@Guid(7d2a6663-24fe-4274-a8bd-b84ac8787157)]
    EquipmentId AS string
```
