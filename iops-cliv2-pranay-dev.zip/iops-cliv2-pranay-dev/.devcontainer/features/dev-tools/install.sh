#!/usr/bin/env bash
set -e

# Development Tools Feature - System-level tool installations
# Runs as root during container build (no env var dependencies)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install pip packages with PEP 668 compatibility
# Handles externally-managed-environment on Ubuntu 24.04+ and similar systems
pip_install() {
    local pip_args=("$@")
    # Check if we need --break-system-packages flag (PEP 668 compliant systems)
    if python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" 2>/dev/null; then
        # Check if EXTERNALLY-MANAGED file exists (indicates PEP 668 enforcement)
        local stdlib_path=$(python3 -c "import sysconfig; print(sysconfig.get_path('stdlib'))" 2>/dev/null)
        if [ -f "${stdlib_path}/EXTERNALLY-MANAGED" ]; then
            pip_args+=("--break-system-packages")
        fi
    fi
    python3 -m pip install "${pip_args[@]}"
}

# Function to detect OS
detect_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [ -f /etc/os-release ]; then
        . /etc/os-release
        if [ "$ID" = "ubuntu" ]; then
            echo "ubuntu"
        else
            echo "linux-other"
        fi
    else
        echo "unknown"
    fi
}

# Function to get Ubuntu version
get_ubuntu_version() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [ "$ID" = "ubuntu" ]; then
            echo "$VERSION_ID"
        else
            echo "not-ubuntu"
        fi
    else
        echo "unknown"
    fi
}

# Function to get macOS version
get_macos_version() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        sw_vers -productVersion
    else
        echo "not-macos"
    fi
}

# Function to compare versions
version_compare() {
    if [ "$1" = "$2" ]; then
        return 0
    fi
    local IFS=.
    local i ver1=($1) ver2=($2)
    for ((i=${#ver1[@]}; i<${#ver2[@]}; i++)); do
        ver1[i]=0
    done
    for ((i=0; i<${#ver1[@]}; i++)); do
        if [[ -z ${ver2[i]} ]]; then
            ver2[i]=0
        fi
        if ((10#${ver1[i]} > 10#${ver2[i]})); then
            return 1
        fi
        if ((10#${ver1[i]} < 10#${ver2[i]})); then
            return 2
        fi
    done
    return 0
}

# Helper to run commands as the container user
run_as_user() {
    su "${_REMOTE_USER}" -s /bin/bash -c "$1"
}

# Helper to run npm/npx commands as the container user with NVM sourced
run_npm_as_user() {
    run_as_user '
        # Check common NVM locations
        for nvm_dir in "$HOME/.nvm" "/usr/local/share/nvm"; do
            if [ -f "$nvm_dir/nvm.sh" ]; then
                export NVM_DIR="$nvm_dir"
                unset npm_config_prefix
                unset NPM_CONFIG_PREFIX
                source "$NVM_DIR/nvm.sh" 2>/dev/null || true
                break
            fi
        done
        '"$1"
}

# Feature option
ENABLE_VOICE_MODE="${ENABLEVOICEMODE:-false}"

# ============================================================
# OS Detection & Validation
# ============================================================
log_info "Checking operating system..."
os_type=$(detect_os)

case "$os_type" in
    "ubuntu")
        ubuntu_version=$(get_ubuntu_version)
        version_compare "$ubuntu_version" "24.04"
        case $? in
            0|1) log_success "Ubuntu version $ubuntu_version meets requirements (>= 24.04)" ;;
            2)
                log_error "Ubuntu version $ubuntu_version is below required version 24.04"
                exit 1
                ;;
        esac
        ;;
    "macos")
        macos_version=$(get_macos_version)
        log_success "macOS version $macos_version detected"
        # Check if we have at least macOS 10.15 (Catalina)
        macos_major=$(echo "$macos_version" | cut -d'.' -f1)
        macos_minor=$(echo "$macos_version" | cut -d'.' -f2)
        if [ "$macos_major" -lt 10 ] || ([ "$macos_major" -eq 10 ] && [ "$macos_minor" -lt 15 ]); then
            log_error "macOS version $macos_version is below required version 10.15"
            exit 1
        fi
        ;;
    "linux-other")
        log_error "This script currently supports Ubuntu Linux and macOS. Other Linux distributions are not supported."
        exit 1
        ;;
    *)
        log_error "Unsupported operating system: $os_type"
        exit 1
        ;;
esac

# ============================================================
# Apt Update / Homebrew
# ============================================================
if [ "$os_type" = "ubuntu" ]; then
    # Remove deprecated Yarn repository with expired GPG key (causes apt update failures)
    if [ -f "/etc/apt/sources.list.d/yarn.list" ]; then
        log_info "Removing deprecated Yarn repository (expired GPG key)..."
        rm -f /etc/apt/sources.list.d/yarn.list
        rm -f /usr/share/keyrings/yarn-archive-keyring.gpg
    fi
    log_info "Updating package list..."
    apt-get update
elif [ "$os_type" = "macos" ]; then
    log_info "Checking Homebrew installation..."

    # Check if Homebrew exists but is not in PATH (run as user)
    if [ -f "/opt/homebrew/bin/brew" ]; then
        log_info "Found Homebrew at /opt/homebrew/bin/brew"
    elif [ -f "/usr/local/bin/brew" ]; then
        log_info "Found Homebrew at /usr/local/bin/brew"
    fi

    if ! run_as_user "command -v brew >/dev/null 2>&1"; then
        log_info "Installing Homebrew..."
        run_as_user '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'

        # Add Homebrew to PATH for Apple Silicon Macs
        if [[ $(uname -m) == "arm64" ]]; then
            run_as_user 'echo '"'"'eval "$(/opt/homebrew/bin/brew shellenv)"'"'"' >> ~/.bashrc'
        else
            run_as_user 'echo '"'"'eval "$(/usr/local/bin/brew shellenv)"'"'"' >> ~/.bashrc'
        fi

        log_success "Homebrew installed successfully"
    else
        log_success "Homebrew is already installed"

        # Clean up deprecated taps first
        log_info "Removing deprecated taps..."
        run_as_user "brew untap homebrew/homebrew-cask-versions 2>/dev/null || true"

        # Clean up any potential issues
        log_info "Cleaning up Homebrew..."
        run_as_user "brew cleanup || true"

        # Update Homebrew
        log_info "Updating Homebrew..."
        if run_as_user "brew update 2>/dev/null"; then
            log_success "Homebrew updated successfully"
        else
            log_warning "Homebrew update failed, continuing with existing packages..."
        fi

        # Try to fix any broken installations
        run_as_user 'if brew doctor 2>/dev/null | grep -q "broken\|unlinked\|symlinks"; then brew cleanup || true; fi'
    fi
fi

# ============================================================
# Git
# ============================================================
log_info "Checking Git installation..."
if command_exists git; then
    git_version=$(git --version | cut -d' ' -f3)
    log_success "Git is already installed (version $git_version)"
else
    log_info "Installing Git..."
    if [ "$os_type" = "ubuntu" ]; then
        apt-get install -y git
    elif [ "$os_type" = "macos" ]; then
        run_as_user "brew install git"
    fi
    log_success "Git installed successfully"
fi

# ============================================================
# Docker
# ============================================================
log_info "Checking Docker installation..."
if command_exists docker; then
    docker_version=$(docker --version | cut -d' ' -f3 | cut -d',' -f1)
    log_success "Docker is already installed (version $docker_version)"
else
    log_info "Installing Docker..."

    if [ "$os_type" = "ubuntu" ]; then
        # Install Docker dependencies
        apt-get install -y ca-certificates curl gnupg lsb-release

        # Add Docker's official GPG key
        mkdir -p /etc/apt/keyrings
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg

        # Set up Docker repository
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

        # Install Docker CE
        apt-get update
        apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
        apt-get install -y pandoc texlive-xetex texlive-fonts-recommended texlive-plain-generic

        # Add container user to docker group
        usermod -aG docker "${_REMOTE_USER}"

    elif [ "$os_type" = "macos" ]; then
        # Install Docker Desktop for macOS
        run_as_user "brew install --cask docker"

        log_warning "Docker Desktop for macOS has been installed."
        log_warning "Please start Docker Desktop from Applications folder before continuing."
    fi

    log_success "Docker installed successfully"
fi

# ============================================================
# Python
# ============================================================
log_info "Checking Python installation..."

# Upgrade Python via the pre-installed conda at /opt/conda (from ghcr.io/devcontainers/features/conda:1)
_upgrade_python_via_conda() {
    log_info "Upgrading Python via existing conda at /opt/conda..."

    if [ ! -x "/opt/conda/bin/conda" ]; then
        log_error "conda not found at /opt/conda/bin/conda — ensure ghcr.io/devcontainers/features/conda:1 is installed"
        exit 1
    fi

    # Create a Python 3.12 environment using the pre-installed conda
    if /opt/conda/bin/conda create -n python312 -y python=3.12; then
        log_success "Created Python 3.12 conda environment at /opt/conda/envs/python312"
    else
        log_warning "Could not create python312 env, trying base update"
        /opt/conda/bin/conda install -y python=3.12 || log_warning "Could not upgrade Python, continuing with existing version"
    fi
}

CONDA_DIR="/opt/conda"

# Check if conda python312 environment exists first
if [ -f "${CONDA_DIR}/envs/python312/bin/python3" ]; then
    python_version=$("${CONDA_DIR}/envs/python312/bin/python3" --version | cut -d' ' -f2)
    log_success "Python $python_version found in conda environment (meets requirements > 3.11)"
elif command_exists python3; then
    python_version=$(python3 --version | cut -d' ' -f2)
    python_major=$(echo "$python_version" | cut -d'.' -f1)
    python_minor=$(echo "$python_version" | cut -d'.' -f2)

    if [ "$python_major" -gt 3 ] || ([ "$python_major" -eq 3 ] && [ "$python_minor" -gt 11 ]); then
        log_success "Python $python_version meets requirements (> 3.11)"
    else
        log_warning "Python version $python_version is below required version 3.11"
        _upgrade_python_via_conda
    fi
else
    log_info "Python not found. Installing via conda..."
    _upgrade_python_via_conda
fi

# Ensure Python 3.12 is available for the rest of the script
if [ -f "${CONDA_DIR}/envs/python312/bin/python3" ]; then
    export PATH="${CONDA_DIR}/envs/python312/bin:$PATH"
fi

# ============================================================
# boto3
# ============================================================
log_info "Checking boto3 installation..."
if python3 -c "import boto3" 2>/dev/null; then
    boto3_version=$(python3 -c "import boto3; print(boto3.__version__)" 2>/dev/null)
    log_success "boto3 is already installed (version $boto3_version)"
else
    log_info "Installing boto3..."
    if run_as_user "$(declare -f pip_install); pip_install boto3"; then
        log_success "boto3 installed successfully"
    else
        log_error "Failed to install boto3"
        exit 1
    fi
fi

# ============================================================
# UV
# ============================================================
log_info "Checking UV installation..."
if command_exists uv || run_as_user "command -v uv >/dev/null 2>&1"; then
    log_success "UV is already installed"
else
    log_info "Installing UV..."
    run_as_user 'curl -LsSf https://astral.sh/uv/install.sh | sh'
    log_success "UV installed successfully"
fi

# ============================================================
# Node.js
# ============================================================
log_info "Checking Node.js installation..."

# Check NVM and Node.js availability
_check_node_as_user() {
    run_as_user '
        for nvm_dir in "$HOME/.nvm" "/usr/local/share/nvm"; do
            if [ -f "$nvm_dir/nvm.sh" ]; then
                export NVM_DIR="$nvm_dir"
                unset npm_config_prefix
                unset NPM_CONFIG_PREFIX
                source "$NVM_DIR/nvm.sh" 2>/dev/null || true
                break
            fi
        done
        if command -v node >/dev/null 2>&1; then
            node --version | cut -d"v" -f2
        else
            echo "none"
        fi
    '
}

_install_node_as_user() {
    run_as_user '
        for nvm_dir in "$HOME/.nvm" "/usr/local/share/nvm"; do
            if [ -f "$nvm_dir/nvm.sh" ]; then
                export NVM_DIR="$nvm_dir"
                unset npm_config_prefix
                unset NPM_CONFIG_PREFIX
                source "$NVM_DIR/nvm.sh" 2>/dev/null || true
                break
            fi
        done
        if command -v nvm >/dev/null 2>&1; then
            nvm install node
            nvm alias default node
            exit 0
        fi
        # Fallback: install via NodeSource if NVM not available
        exit 1
    '
}

node_version=$(_check_node_as_user)

if [ "$node_version" != "none" ]; then
    node_major=$(echo "$node_version" | cut -d'.' -f1)

    if [ "$node_major" -gt 20 ]; then
        log_success "Node.js version $node_version meets requirements (> 20)"
    else
        log_warning "Node.js version $node_version is below required version 20"
        log_info "Installing latest Node.js..."

        if _install_node_as_user; then
            log_success "Node.js installed successfully via NVM"
        elif [ "$os_type" = "ubuntu" ]; then
            curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
            apt-get install -y nodejs
            log_success "Node.js installed successfully"
        elif [ "$os_type" = "macos" ]; then
            run_as_user "brew reinstall node 2>/dev/null || brew install node"
            log_success "Node.js installed successfully"
        fi
    fi
else
    log_info "Installing Node.js..."

    if _install_node_as_user; then
        log_success "Node.js installed successfully via NVM"
    elif [ "$os_type" = "ubuntu" ]; then
        curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
        apt-get install -y nodejs
        log_success "Node.js installed successfully"
    elif [ "$os_type" = "macos" ]; then
        run_as_user "brew install node"
        log_success "Node.js installed successfully"
    fi
fi

# ============================================================
# Symlink node, npm, npx to /usr/local/bin
# ============================================================
log_info "Creating symlinks for node, npm, npx..."
_nvm_node_version=$(run_as_user '
    for nvm_dir in "$HOME/.nvm" "/usr/local/share/nvm"; do
        if [ -f "$nvm_dir/nvm.sh" ]; then
            export NVM_DIR="$nvm_dir"
            unset npm_config_prefix
            unset NPM_CONFIG_PREFIX
            source "$NVM_DIR/nvm.sh" 2>/dev/null || true
            break
        fi
    done
    if command -v nvm >/dev/null 2>&1; then
        nvm version
    fi
')
_nvm_dir=$(run_as_user '
    for nvm_dir in "$HOME/.nvm" "/usr/local/share/nvm"; do
        if [ -d "$nvm_dir" ]; then
            echo "$nvm_dir"
            break
        fi
    done
')

if [ -n "$_nvm_dir" ] && [ -n "$_nvm_node_version" ]; then
    _nvm_bin="${_nvm_dir}/versions/node/${_nvm_node_version}/bin"
    if [ -d "$_nvm_bin" ]; then
        for cmd in node npm npx; do
            if [ -f "$_nvm_bin/$cmd" ]; then
                ln -sf "$_nvm_bin/$cmd" "/usr/local/bin/$cmd"
                log_success "Symlinked /usr/local/bin/$cmd -> $_nvm_bin/$cmd"
            else
                log_warning "$cmd not found in $_nvm_bin"
            fi
        done
    else
        log_warning "NVM bin directory not found at $_nvm_bin, skipping symlinks"
    fi
else
    log_warning "Could not determine NVM directory or node version, skipping symlinks"
fi

# ============================================================
# npm/npx configuration
# ============================================================
# Verify npm is available
if ! command_exists npm && ! run_as_user "command -v npm >/dev/null 2>&1"; then
    log_error "npm is not available after Node.js installation"
    exit 1
fi

# # Verify npx is available (ships with npm but verify)
# if ! command_exists npx && ! run_as_user "command -v npx >/dev/null 2>&1"; then
#     log_warning "npx not found, installing..."
#     npm install -g npx
#     if command_exists npx; then
#         log_success "npx installed successfully"
#     else
#         log_error "npx is not available after installation attempt"
#         exit 1
#     fi
# fi

# Configure npm environment variables
log_info "Configuring npm environment variables..."
if [ "$os_type" = "ubuntu" ]; then
    export npm_config_target_platform="linux"
elif [ "$os_type" = "macos" ]; then
    export npm_config_target_platform="darwin"
fi
export npm_config_target_arch="$(uname -m)"
export npm_config_runtime="node"

# ============================================================
# Playwright chromium
# ============================================================
log_info "Installing Playwright chromium..."
run_npm_as_user 'npx -y playwright install chromium'
PLAYWRIGHT_BROWSERS_PATH=$(run_as_user 'echo "$HOME/.cache/ms-playwright"')
if [ -d "$PLAYWRIGHT_BROWSERS_PATH" ]; then
    run_npm_as_user 'npx -y playwright install-deps chromium' 2>/dev/null || \
    apt-get install -y \
        libglib2.0-0 libnss3 libnspr4 libdbus-1-3 libatk1.0-0 libatk-bridge2.0-0 \
        libcups2 libdrm2 libxkbcommon0 libatspi2.0-0 libxcomposite1 libxdamage1 \
        libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2t64 2>/dev/null || true
fi
log_success "Playwright chromium installed successfully"

# ============================================================
# backlog.md
# ============================================================
# log_info "Installing backlog.md..."
# if command_exists backlog || run_npm_as_user "command -v backlog >/dev/null 2>&1"; then
#     log_success "backlog.md is already installed"
# else
#     log_info "Installing backlog.md CLI tool..."
#     run_npm_as_user 'npm install -g backlog.md'
#     if run_npm_as_user "command -v backlog >/dev/null 2>&1"; then
#         log_success "backlog.md installed successfully"
#     else
#         log_error "Failed to install backlog.md"
#         exit 1
#     fi
# fi

# ============================================================
# npm global packages
# ============================================================
log_info "Installing npm global packages..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NPM_PACKAGES_FILE="${SCRIPT_DIR}/npm-global-packages.txt"

if [ -f "$NPM_PACKAGES_FILE" ]; then
    while IFS= read -r line || [ -n "$line" ]; do
        # Skip empty lines and comments
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

        # Extract package name (before @ or entire line if no @)
        package_spec="$line"
        package_name=$(echo "$package_spec" | sed 's/@[^@]*$//' | sed 's/^@//' | cut -d'@' -f1)

        # Check if package is already installed
        if run_npm_as_user "command -v $package_name >/dev/null 2>&1" || command_exists "$package_name"; then
            log_success "$package_name is already installed"
        else
            log_info "Installing $package_spec..."
            if run_npm_as_user "npm install -g $package_spec"; then
                log_success "$package_spec installed successfully"
            else
                log_warning "Failed to install $package_spec (continuing anyway)"
            fi
        fi
    done < "$NPM_PACKAGES_FILE"
else
    log_warning "npm-global-packages.txt not found at $NPM_PACKAGES_FILE, skipping npm global packages"
fi

# ============================================================
# Specify CLI
# ============================================================
log_info "Checking Specify CLI installation..."
if command_exists specify || run_as_user "command -v specify >/dev/null 2>&1"; then
    log_success "Specify CLI is already installed"
else
    log_info "Installing Specify CLI..."

    # Install specify-cli using uv tool (run as user since uv was installed for user)
    if run_as_user 'export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"; uv tool install specify-cli --force --from git+https://github.com/github/spec-kit.git'; then
        log_success "Specify CLI installed successfully"
    else
        log_error "Failed to install Specify CLI"
        exit 1
    fi
fi

# ============================================================
# Voice mode install (conditional, install only - not start)
# ============================================================
if [ "$ENABLE_VOICE_MODE" = "true" ]; then
    log_info "Installing Voice Mode dependencies (enabled via feature option)..."
    run_as_user 'export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"; uvx voice-mode-install -n; uvx openai; voicemode whisper install'
else
    log_info "Voice Mode installation skipped (not enabled in feature options)"
fi

# ============================================================
# markitdown + openpyxl
# ============================================================
log_info "Installing markitdown and openpyxl..."
run_as_user "$(declare -f pip_install); pip_install markitdown[pptx] openpyxl"
log_success "markitdown and openpyxl installed successfully"

log_success "Development tools feature installation completed!"
