/**
 * @packageDocumentation
 * IOPS Studio Installer
 *
 * Downloads the iops-studio .deb package from JFrog Artifactory
 * and installs it with all dependencies. Features animated spinners,
 * a download progress bar, and colored output using Bun's native APIs.
 *
 * @example
 * ```bash
 * bun run .devcontainer/scripts/install.ts
 * bun run .devcontainer/scripts/install.ts --version 2.0.0
 * bun run .devcontainer/scripts/install.ts --branch main --repo smaf-dist-scratch-local
 * IOPS_STUDIO_VERSION=2.0.0 bun run .devcontainer/scripts/install.ts
 * ```
 */

import { $ } from "bun";
import { mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { Buffer } from "node:buffer";

/* ── Color / TTY detection ─────────────────────────────────────────── */

const NO_COLOR = "NO_COLOR" in process.env && process.env.NO_COLOR !== "";
const FORCE_COLOR = "FORCE_COLOR" in process.env;
const COLOR_ENABLED = FORCE_COLOR || !NO_COLOR;
const IS_TTY = process.stderr.isTTY ?? false;

const RESET = COLOR_ENABLED ? "\x1b[0m" : "";
const BOLD = COLOR_ENABLED ? "\x1b[1m" : "";
const DIM_CODE = COLOR_ENABLED ? "\x1b[2m" : "";

function c(text: string, colorName: string): string {
  if (!COLOR_ENABLED) return text;
  const ansi = Bun.color(colorName, "ansi");
  return ansi ? `${ansi}${text}${RESET}` : text;
}

function bold(text: string): string {
  return BOLD ? `${BOLD}${text}${RESET}` : text;
}

function dim(text: string): string {
  return DIM_CODE ? `${DIM_CODE}${text}${RESET}` : text;
}

/* ── Spinner ───────────────────────────────────────────────────────── */

const SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
const SPINNER_INTERVAL = 80;
/**
 * Animated terminal spinner for long-running operations.
 *
 * @internal
 */
class Spinner {
  private frameIndex = 0;
  private timer: ReturnType<typeof setInterval> | null = null;
  private message = "";

  start(message: string): void {
    this.message = message;
    this.frameIndex = 0;
    if (IS_TTY && COLOR_ENABLED) {
      this.render();
      this.timer = setInterval(() => this.render(), SPINNER_INTERVAL);
    } else {
      process.stderr.write(`  - ${message}\n`);
    }
  }

  private render(): void {
    const frame = c(SPINNER_FRAMES[this.frameIndex % SPINNER_FRAMES.length], "#89B4FA");
    process.stderr.write(`\r\x1b[K  ${frame} ${this.message}`);
    this.frameIndex++;
  }
  /** Stops the spinner and prints a success message. */
  stop(successMessage: string): void {
    this.clear();
    process.stderr.write(`  ${c("✓", "#A6E3A1")} ${successMessage}\n`);
  }
  /** Stops the spinner and prints an error message. */
  fail(errorMessage: string): void {
    this.clear();
    process.stderr.write(`  ${c("✗", "#F38BA8")} ${c(errorMessage, "#F38BA8")}\n`);
  }

  private clear(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (IS_TTY && COLOR_ENABLED) {
      process.stderr.write("\r\x1b[K");
    }
  }
}

/**
 * Formats a byte count as a human-readable string (B / KB / MB).
 *
 * @param bytes - Raw byte count.
 * @returns Formatted string (e.g. `"4.2 MB"`).
 *
 * @internal
 */
function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function renderProgressBar(current: number, total: number, width = 30): void {
  const ratio = Math.min(current / total, 1);
  const percent = Math.floor(ratio * 100);
  const filled = Math.round(ratio * width);
  const empty = width - filled;

  const bar = c("█".repeat(filled), "#89B4FA") + dim("░".repeat(empty));
  const stats = `${percent}%  ${formatBytes(current)} / ${formatBytes(total)}`;

  process.stderr.write(`\r\x1b[K      ${bar}  ${stats}`);
}

function divider(): void {
  console.error(c("  ══════════════════════════════════════════", "#847ACE"));
}

/* ── CLI args + env config ─────────────────────────────────────────── */

interface CliArgs {
  help: boolean;
  version: string;
  branch: string;
  repo: string;
  url: string;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  let help = false;
  let version = "";
  let branch = "";
  let repo = "";
  let url = "";

  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--help" || args[i] === "-h" || args[i] === "help") {
      help = true;
    } else if (args[i] === "--version" && i + 1 < args.length) {
      version = args[++i];
    } else if (args[i] === "--branch" && i + 1 < args.length) {
      branch = args[++i];
    } else if (args[i] === "--repo" && i + 1 < args.length) {
      repo = args[++i];
    } else if (args[i] === "--url" && i + 1 < args.length) {
      url = args[++i];
    }
  }

  return {
    help,
    version: version || process.env.IOPS_STUDIO_VERSION || "1.0.5",
    branch:  branch  || process.env.IOPS_STUDIO_BRANCH  || "main",
    repo:    repo    || process.env.IOPS_STUDIO_REPO    || "smaf-dist-scratch-local",
    url:     url     || process.env.ARTIFACTORY_URL     || "https://artifacts.engineeringplatforms.deloitte.com/artifactory",
  };
}

/** npm scope configured for Artifactory registry. */
const NPM_SCOPE = "@smaf";
/** Artifactory npm registry URL for the scoped packages. */
const NPM_REGISTRY = "https://artifacts.engineeringplatforms.deloitte.com/artifactory/api/npm/smaf-npm-scratch/";

/**
 * Prints the ASCII art banner and version to stderr.
 *
 * @internal
 */
function printBanner(subtitle: string, version?: string): void {
  const versionStr = version ? ` v${version}` : "";
  const text = `${subtitle}${versionStr}`;

  const blockWidth = 7 + 3 + text.length;
  const leftPadNum = Math.floor((44 - blockWidth) / 2);
  const rightPadNum = Math.ceil((44 - blockWidth) / 2);

  const lp = " ".repeat(Math.max(0, leftPadNum));
  const rp = " ".repeat(Math.max(0, rightPadNum));
  const r13Gap = " ".repeat(Math.max(0, rightPadNum + 3 + text.length));

  const termWidth = process.stdout.columns || 80;
  const margin = " ".repeat(Math.max(0, Math.floor((termWidth - 46) / 2)));

  const bColor = "#5E8EDE";
  const vLine = c("┊", bColor);

  const lines = [
    "",
    `${margin}${c("╭" + "┄".repeat(44) + "╮", bColor)}`,
    `${margin}${vLine}        ${c("╦", "#4796E4")}${c("╔═╗", "#5E8EDE")}${c("╔═╗", "#7586D8")}${c("╔═╗", "#847ACE")}  ${c("╔═╗", "#9471B8")}${c("╔╦╗", "#A468A2")}${c("╦ ╦", "#B05F8C")}${c("╔╦╗", "#BC5876")}${c("╦", "#C3677F")}${c("╔═╗", "#C3677F")}        ${vLine}`,
    `${margin}${vLine}        ${c("║", "#4796E4")}${c("║ ║", "#5E8EDE")}${c("╠═╝", "#7586D8")}${c("╚═╗", "#847ACE")}  ${c("╚═╗", "#9471B8")}${c(" ║ ", "#A468A2")}${c("║ ║", "#B05F8C")}${c(" ║║", "#BC5876")}${c("║", "#C3677F")}${c("║ ║", "#C3677F")}        ${vLine}`,
    `${margin}${vLine}        ${c("╩", "#4796E4")}${c("╚═╝", "#5E8EDE")}${c("╩  ", "#7586D8")}${c("╚═╝", "#847ACE")}  ${c("╚═╝", "#9471B8")}${c(" ╩ ", "#A468A2")}${c("╚═╝", "#B05F8C")}${c("═╩╝", "#BC5876")}${c("╩", "#C3677F")}${c("╚═╝", "#C3677F")}        ${vLine}`,
    `${margin}${vLine}                                            ${vLine}`,
    `${margin}${vLine}${lp}${c(" ╭─┴─╮ ", "#7586D8")}${r13Gap}${vLine}`,
    `${margin}${vLine}${lp}${c("█│● ●│█", "#7586D8")}   ${c(subtitle, "#847ACE")}${version ? dim(versionStr) : ""}${rp}${vLine}`,
    `${margin}${vLine}${lp}${c(" ╰───╯ ", "#7586D8")}${r13Gap}${vLine}`,
    `${margin}${c("╰" + "┄".repeat(44) + "╯", bColor)}`,
    "",
  ];
  for (const line of lines) {
    console.error(line);
  }
}

/**
 * Prints a numbered step header to stderr.
 *
 * @param step - Current step number.
 * @param total - Total number of steps.
 * @param message - Step description.
 *
 * @internal
 */
function stepHeader(step: number, total: number, message: string): void {
  console.error(`\n  ${c("●", "#89B4FA")} ${dim(`Step ${step}/${total}`)}  ${bold(message)}`);
}

/**
 * Validates that Artifactory credentials are present in the environment.
 * Exits the process with a help message if either is missing.
 *
 * @returns The validated `user` and `pass` pair.
 *
 * @internal
 */
function validateCredentials(): { user: string; pass: string } {
  const user = process.env.ARTIFACTORY_USER;
  const pass = process.env.ARTIFACTORY_PASS;

  if (!user || !pass) {
    console.error("");
    console.error(`  ${c("✗", "#F38BA8")} ${c("ARTIFACTORY_USER and ARTIFACTORY_PASS are required.", "#F38BA8")}`);
    console.error("");
    console.error(`  ${dim("Set them via environment variables (e.g. Codespaces secrets) or run:")}`);
    console.error(`  ${c("ARTIFACTORY_USER=user ARTIFACTORY_PASS=pass bun run .devcontainer/scripts/install.ts", "#89DCEB")}`);
    console.error("");
    process.exit(1);
  }

  return { user, pass };
}

/**
 * Executes `fn` inside an auto-cleaned temporary directory.
 *
 * @typeParam T - Return type of the callback.
 * @param fn - Callback receiving the temporary directory path.
 * @returns The value returned by `fn`.
 *
 * @internal
 */
async function withTempDir<T>(fn: (dir: string) => Promise<T>): Promise<T> {
  const dir = await mkdtemp(join(tmpdir(), "iops-studio-"));
  try {
    return await fn(dir);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

/**
 * Downloads the `.deb` package from Artifactory to a temporary directory.
 *
 * @remarks
 * Streams to disk with a progress bar when `content-length` is available;
 * falls back to a buffered download with a spinner otherwise.
 *
 * @param tmpDir - Temporary directory to write the file into.
 * @param user - Artifactory username.
 * @param pass - Artifactory password or token.
 * @returns Absolute path to the downloaded `.deb` file.
 *
 * @throws {@link Error}
 * Thrown if the HTTP response is not OK or the body is empty.
 *
 * @internal
 */
async function downloadDeb(
  tmpDir: string,
  user: string,
  pass: string,
  downloadUrl: string,
  debFile: string,
): Promise<string> {
  const destPath = join(tmpDir, debFile);
  const credentials = Buffer.from(`${user}:${pass}`).toString("base64");

  const response = await fetch(downloadUrl, {
    headers: { Authorization: `Basic ${credentials}` },
    redirect: "follow",
  });

  if (!response.ok) {
    throw new Error(`Download failed (HTTP ${response.status}): ${downloadUrl}`);
  }

  const contentLength = Number(response.headers.get("content-length") ?? 0);
  const body = response.body;

  if (!body) {
    throw new Error("Empty response body");
  }

  if (contentLength > 0) {
    const writer = Bun.file(destPath).writer();
    let received = 0;
    const reader = body.getReader();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      writer.write(value);
      received += value.length;
      renderProgressBar(received, contentLength);
    }

    await writer.end();
    process.stderr.write("\n");
  } else {
    const spinner = new Spinner();
    spinner.start(`Downloading ${debFile}...`);
    const buffer = await response.arrayBuffer();
    await Bun.write(destPath, buffer);
    spinner.stop(`Downloaded ${debFile}`);
  }

  return destPath;
}

/**
 * Runs `apt-get update` to refresh package lists.
 *
 * @throws {@link Error}
 * Thrown if the update command fails.
 *
 * @internal
 */
async function updatePackageLists(): Promise<void> {
  const spinner = new Spinner();
  spinner.start("Updating package lists...");
  try {
    await $`sudo apt-get update -qq`.quiet();
    spinner.stop("Package lists updated");
  } catch {
    spinner.fail("Failed to update package lists");
    throw new Error("apt-get update failed");
  }
}

/**
 * Installs the `.deb` package via `apt-get install`.
 *
 * @param debPath - Absolute path to the `.deb` file.
 *
 * @throws {@link Error}
 * Thrown if the install command fails.
 *
 * @internal
 */
async function installDeb(debPath: string, version: string): Promise<void> {
  const spinner = new Spinner();
  spinner.start(`Installing iops-studio v${version}...`);
  try {
    await $`sudo -E apt-get install -y ${debPath}`.quiet();
    spinner.stop(`iops-studio v${version} installed`);
  } catch {
    spinner.fail("Installation failed");
    throw new Error("apt-get install failed");
  }
}

/**
 * Configures npm to use the Artifactory registry for {@link NPM_SCOPE}.
 *
 * @param user - Artifactory username.
 * @param pass - Artifactory password or token.
 *
 * @throws {@link Error}
 * Thrown if `npm config set` fails.
 *
 * @internal
 */
async function configureNpm(user: string, pass: string): Promise<void> {
  const spinner = new Spinner();
  spinner.start(`Configuring npm registry for ${NPM_SCOPE}...`);
  try {
    await $`npm config set ${NPM_SCOPE}:registry ${NPM_REGISTRY}`;

    const registryUrl = NPM_REGISTRY.replace(/^https?:/, "");
    const authToken = Buffer.from(`${user}:${pass}`).toString("base64");
    const authKey = `${registryUrl}:_auth`;

    await $`npm config set ${authKey} ${authToken}`;

    spinner.stop(`npm configured for ${NPM_SCOPE}`);
  } catch (error) {
    spinner.fail("npm configuration failed");
    console.error(`  ${dim("Error:")} ${error instanceof Error ? error.message : String(error)}`);
    throw new Error("npm config failed");
  }
}

/**
 * Prints the post-install success banner with next-step instructions.
 *
 * @internal
 */
function printSuccess(version: string): void {
  console.error("");
  divider();
  console.error(`  ${c("✓", "#A6E3A1")} ${bold("iops-studio")} ${c("v" + version, "#89B4FA")} ${bold("installed successfully")}`);
  divider();
  console.error("");
  console.error(`  ${bold("npm configured for:")} ${c(NPM_SCOPE, "#89DCEB")}`);
  console.error(`  ${dim("Registry:")} ${NPM_REGISTRY}`);
  console.error("");
  console.error(`  ${bold("Monitor setup progress:")}`);
  console.error(`  ${c("tail -f /var/log/iops-studio/setup.log", "#89DCEB")}`);
  console.error("");
  console.error(`  ${bold("Once setup completes, manage services with:")}`);
  console.error(`  ${c("iops-studio start", "#89DCEB")}    ${dim("# start all services")}`);
  console.error(`  ${c("iops-studio stop", "#89DCEB")}     ${dim("# stop all services")}`);
  console.error(`  ${c("iops-studio status", "#89DCEB")}   ${dim("# show service status")}`);
  console.error(`  ${c("iops-studio verify", "#89DCEB")}   ${dim("# run health checks")}`);
  console.error("");
}

function showUsage(): void {
  printBanner("Installer");
  console.error(`  ${bold("Usage:")}`);
  console.error(`  ${c("bun run .devcontainer/scripts/install.ts", "#89DCEB")}`);
  console.error(`  ${c("bun run .devcontainer/scripts/install.ts --version 2.0.0", "#89DCEB")}`);
  console.error(`  ${c("bun run .devcontainer/scripts/install.ts --branch main", "#89DCEB")}`);
  console.error(`  ${c("bun run .devcontainer/scripts/install.ts --help", "#89DCEB")}`);
  console.error("");
  console.error(`  ${bold("Options:")}`);
  console.error(`  ${c("--version <ver>", "#89DCEB")}   ${dim("# package version (env: IOPS_STUDIO_VERSION, default: 1.0.3)")}`);
  console.error(`  ${c("--branch <name>", "#89DCEB")}   ${dim("# distribution branch (env: IOPS_STUDIO_BRANCH, default: main)")}`);
  console.error(`  ${c("--repo <name>", "#89DCEB")}     ${dim("# artifactory repo (env: IOPS_STUDIO_REPO, default: smaf-dist-scratch-local)")}`);
  console.error(`  ${c("--url <url>", "#89DCEB")}       ${dim("# artifactory base URL (env: ARTIFACTORY_URL)")}`);
  console.error(`  ${c("--help", "#89DCEB")}            ${dim("# show this help")}`);
  console.error("");
  console.error(`  ${bold("Environment:")}`);
  console.error(`  ${c("ARTIFACTORY_USER", "#89DCEB")}  ${dim("# required")}`);
  console.error(`  ${c("ARTIFACTORY_PASS", "#89DCEB")}  ${dim("# required")}`);
  console.error("");
}

async function main(): Promise<void> {
  const args = parseArgs();

  if (args.help) {
    showUsage();
    return;
  }

  const version = args.version;
  const debFile = `iops-studio_${version}_amd64.deb`;
  const downloadUrl = `${args.url}/${args.repo}/iops/iops-studio-deb/${args.branch}/${version}/${debFile}`;

  printBanner("Installer", version);

  const { user, pass } = validateCredentials();

  await withTempDir(async (tmpDir) => {
    stepHeader(1, 4, `Downloading iops-studio v${version}`);
    const debPath = await downloadDeb(tmpDir, user, pass, downloadUrl, debFile);
    const stat = Bun.file(debPath);
    console.error(`  ${c("✓", "#A6E3A1")} Downloaded ${c(debFile, "#89DCEB")} ${dim("(" + formatBytes(stat.size) + ")")}`);

    stepHeader(2, 4, "Updating package lists");
    await updatePackageLists();

    stepHeader(3, 4, "Installing package");
    await installDeb(debPath, version);
  });

  stepHeader(4, 4, "Configuring npm registry");
  await configureNpm(user, pass);

  printSuccess(version);
}

try {
  await main();
} catch (error) {
  console.error("");
  console.error(`  ${c("✗", "#F38BA8")} ${c(error instanceof Error ? error.message : String(error), "#F38BA8")}`);
  console.error("");
  process.exit(1);
}
