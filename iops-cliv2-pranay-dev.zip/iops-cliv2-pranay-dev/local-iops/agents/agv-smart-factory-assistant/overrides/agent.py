"""Aio Agent module."""

import os
import json
import asyncio
import logging
from uuid import uuid4
from typing import Any, Dict, AsyncIterable, Literal, Optional
from pydantic import BaseModel

from a2a.types import (
    GetTaskResponse,
    SendMessageResponse,
    SendStreamingMessageResponse,
)

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.types import Checkpointer

from config import agent_config
from skills.a2a_skill import get_skills_from_config
from tools.mcp import get_tools_from_config
from aio_agent.workflow import create_workflow_graph

TOOLS = agent_config.get_tool_agent_messages()

logger = logging.getLogger(__name__)


def get_short_tool_descr(names):
    """Get a short description for the given tool names.

    Args:
        names (str or list): Tool name(s).

    Returns:
        str: Short description of the tool(s).
    """
    if isinstance(names, str):
        names = [names]
    if not isinstance(names, list):
        return ""

    return ", ".join([TOOLS[name] for name in names if name in TOOLS])


class ResponseFormat(BaseModel):
    """Response format model for agent responses."""

    status: Literal["input_required", "completed", "error"]  # = "input_required"
    message: str


class AioAgent:
    """Aio Agent.

    This agent provides to the test tools.
    """

    ID = agent_config.id  # "aio_agent"

    NAME = agent_config.name  # "Aio Agent"

    DESCRIPTION = agent_config.description

    MODEL = agent_config.model  # "gpt-4o-2024-11-20"

    TEMPERATURE = agent_config.temperature  # 0.1

    SYSTEM_PROMPT = agent_config.prompt

    SYSTEM_INSTRUCTION = agent_config.system_instruction

    STRUCTURED_RESPONSE_INSTRUCTION = agent_config.structured_response_instruction

    def __init__(self):
        """Initialize the AioAgent and its tools."""
        # Alert Info Tool
        self.tools = get_tools_from_config()

        # Skill Tools
        skill_tools = get_skills_from_config()
        self.skill_names = [skill.name for skill in skill_tools or []]
        if skill_tools:
            self.tools = self.tools or []
            self.tools.extend(skill_tools)

        # Initialize graph attribute
        self.graph = None

    def compile_graph(self, checkpointer: Checkpointer):
        """Compile the workflow graph for the agent.

        Args:
            checkpointer (Checkpointer): The checkpointer to use for the workflow graph.
        """
        # Create graph
        self.graph = create_workflow_graph(
            model=self.MODEL,
            temperature=self.TEMPERATURE,
            system_prompt=self.SYSTEM_PROMPT,
            system_instructions=self.SYSTEM_INSTRUCTION,
            tools=self.tools,
            response_format=ResponseFormat,
            structured_response_instructions=self.STRUCTURED_RESPONSE_INSTRUCTION,
            checkpointer=checkpointer,
        )

    def _format_existing_messages(self, state_messages):
        """Format existing messages for comparison.

        Args:
            state_messages (list): Current state messages.

        Returns:
            list: Formatted messages.
        """
        if not state_messages:
            return []
        return [message.type + ": " + str(message.content) for message in state_messages]

    def _determine_role(self, record_type):
        """Determine the role based on record type.

        Args:
            record_type (str): The type of the record.

        Returns:
            str: The determined role.
        """
        if record_type == "human":
            return "user"
        elif record_type == "ai":
            return "assistant"
        return record_type

    def _should_skip_record(self, rec, inputs):
        """Check if a history record should be skipped.

        Args:
            rec (dict): History record.
            inputs (dict): Input messages.

        Returns:
            bool: True if record should be skipped.
        """
        return rec["type"] == "human" and rec["content"] == inputs["messages"][0]["content"]

    def _process_history_records(self, inputs, history, existing_messages):
        """Process history records and add them to inputs.

        Args:
            inputs (dict): The input messages.
            history (list): The message history.
            existing_messages (list): Formatted existing messages.
        """
        for rec in history:
            message_key = rec["type"] + ": " + str(rec["content"])
            if message_key not in existing_messages:
                if self._should_skip_record(rec, inputs):
                    continue

                role = self._determine_role(rec["type"])
                inputs["messages"].append({"role": role, "content": rec["content"]})

    async def _check_history(self, inputs, history, config):
        """Check and update the input messages with history.

        Args:
            inputs (dict): The input messages.
            history (list): The message history.
            config (dict): The configuration.

        Returns:
            dict: Updated input messages.
        """
        current_state = await self.graph.aget_state(config)
        logger.info(f"=== Initial State ===:\n{type(current_state)}\n{current_state}")

        state_messages = current_state.values.get("messages", [])
        existing_messages = self._format_existing_messages(state_messages)

        if history:
            self._process_history_records(inputs, history, existing_messages)

        # Move first message to end and remove from beginning
        inputs["messages"].append(inputs["messages"][0])
        inputs["messages"] = inputs["messages"][1:]

        logger.info(f"Inputs with history:\n{inputs}")

        return inputs

    async def invoke(self, query, history, session_id) -> str:
        """Invoke the agent with a query and history.

        Args:
            query (str): The user query.
            history (list): The message history.
            session_id (str): The session ID.

        Returns:
            str: The agent's response.
        """
        inputs = {
            "messages": [{"role": "user", "content": query}],
            "structured_response": None,
        }
        config = {"configurable": {"thread_id": f"{self.ID}_{session_id}"}}

        logger.info(f"=== Inputs ===\n{inputs}, config: {config}, history: {history}")

        inputs = await self._check_history(inputs, history, config)

        result = await self.graph.ainvoke(inputs, config)
        logger.info(f"{result}")

        response = await self.get_agent_response(
            result.get("messages"),
            result.get("structured_response"),
        )
        logger.info(f"=== Result === {response}")

        return response

    def _is_duplicate_message(self, message, message_ids):
        """Check if a message is a duplicate.

        Args:
            message: The message to check.
            message_ids (list): List of existing message IDs.

        Returns:
            bool: True if message is duplicate.
        """
        message_id = message.type + ":" + message.id
        return message_id in message_ids

    def _process_ai_message_with_tools(self, message):
        """Process AI message with tool calls.

        Args:
            message (AIMessage): The AI message with tool calls.

        Returns:
            dict: Response for AI message with tools.
        """
        tool_names = [
            tool_call["name"]
            for tool_call in message.tool_calls
            if tool_call["name"] not in self.skill_names
        ]
        tool_descr = get_short_tool_descr(tool_names)
        content = f"Looking up the {tool_descr}..." if tool_descr else None
        return {
            "is_task_complete": False,
            "require_user_input": False,
            "content": content,
        }

    def _process_tool_message_data(self, message):
        """Process tool message data and prepare response.

        Args:
            message (ToolMessage): The tool message.

        Returns:
            dict or None: Response data or None if no data to yield.
        """
        data = message.content
        if isinstance(data, list):
            data = data[0]
        try:
            data = json.loads(message.content)
        except Exception:
            data = message.content

        if isinstance(data, str):
            return {
                "is_task_complete": False,
                "require_user_input": False,
                "content": data,
            }
        else:
            if not isinstance(data, dict) or data.get("type", None) is None:
                data = {
                    "type": message.name,
                    message.name: data,
                }

            return {
                "is_task_complete": False,
                "require_user_input": False,
                "data": data,
                "metadata": {
                    "type": "ui",
                    "component": "alert",
                    "id": str(uuid4()),
                },
            }

    async def _process_tool_message(self, message):
        """Process tool message and yield appropriate responses.

        Args:
            message (ToolMessage): The tool message to process.

        Yields:
            dict: Response items for tool message.
        """
        tool_descr = get_short_tool_descr(message.name)
        content = f"Processing the {tool_descr}..." if tool_descr else None
        yield {
            "is_task_complete": False,
            "require_user_input": False,
            "content": content,
        }

        if message.status == "success":
            data_response = self._process_tool_message_data(message)
            if data_response:
                yield data_response

    def _process_ui_message(self, message):
        """Process UI message.

        Args:
            message (dict): The UI message.

        Returns:
            dict or None: Response for UI message or None if not UI type.
        """
        if message.get("type") == "ui":
            return {
                "is_task_complete": False,
                "require_user_input": False,
                "data": message,
            }
        return None

    def _create_response_dict(self, content=None, data=None):
        """Create a standardized response dictionary."""
        response = {
            "is_task_complete": False,
            "require_user_input": False,
        }
        if content is not None:
            response["content"] = content
        if data is not None:
            response["data"] = data
        return response

    def _handle_custom_stream_mode(self, item, prev_str_item):
        """Handle custom stream mode items."""
        if isinstance(
            item,
            (SendStreamingMessageResponse | SendMessageResponse | GetTaskResponse),
        ):
            logger.info("Transfer A2A skill agent response...")
            return {"streaming_response": item}, prev_str_item
        if isinstance(item, str):
            if item != prev_str_item:
                # Don't send duplicated messages
                return self._create_response_dict(content=item), item
            return None, prev_str_item
        return self._create_response_dict(data=item), prev_str_item

    async def stream(
        self,
        query,
        history,
        task_id,
        session_id,
        jwt_token: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> AsyncIterable[Dict[str, Any]]:
        """Stream the agent's response for a query and history.

        Args:
            query (str): The user query.
            history (list): The message history.
            task_id (str): The task ID.
            session_id (str): The session ID.
            jwt_token (Optional[str]): JWT authentication token for downstream calls.
            api_key (Optional[str]): API key for downstream calls.

        Yields:
            Dict[str, Any]: Streamed response items.
        """
        inputs = {
            "messages": [{"role": "user", "content": query}],
            "task_id": task_id,
            "session_id": session_id,
            "structured_response": None,
            "jwt_token": jwt_token,
            "api_key": api_key,
        }
        config = {"configurable": {"thread_id": f"{self.ID}_{session_id}"}}

        logger.info(f"=== Inputs ===\n{inputs}, config: {config}, history: {history}")

        inputs = await self._check_history(inputs, history, config)

        message_ids = []
        complete_content = True
        messages = []
        structured_response = None
        prev_str_item = ""

        async for stream_mode, item in self.graph.astream(
            inputs, config, stream_mode=["custom", "values"]
        ):  # , debug=True):
            if stream_mode == "custom":
                response, prev_str_item = self._handle_custom_stream_mode(item, prev_str_item)
                if response:
                    yield response
                await asyncio.sleep(0.01)
                continue

            prev_str_item = ""
            message = item["messages"][-1]
            message_id = message.type + ":" + message.id
            messages = item["messages"]
            structured_response = item.get("structured_response")

            if self._is_duplicate_message(message, message_ids):
                logger.info(f"Duplicated: {type(message)} - {message_id}")
                await asyncio.sleep(0.01)
                continue

            message_ids.append(message_id)
            logger.info(f"Task: id={task_id}, Message: {type(message)} - {message_id}\n{message}")

            if (
                isinstance(message, AIMessage)
                and message.tool_calls
                and len(message.tool_calls) > 0
            ):
                tool_names = [
                    tool_call["name"]
                    for tool_call in message.tool_calls
                    if tool_call["name"] not in self.skill_names
                ]
                if tool_names:
                    complete_content = False
                    yield self._process_ai_message_with_tools(message)
            elif isinstance(message, ToolMessage) and message.name not in self.skill_names:
                complete_content = False
                async for response in self._process_tool_message(message):
                    yield response
            elif isinstance(message, dict):
                ui_response = self._process_ui_message(message)
                if ui_response:
                    yield ui_response

            await asyncio.sleep(0.01)

        response = await self.get_agent_response(messages, structured_response, complete_content)
        logger.info(f"=== Result ===\n{response}")

        yield response

    async def get_agent_response(self, messages, structured_response, complete_content=True):
        """Get the agent's response based on the current state.

        Args:
            messages (list): The list of messages.
            structured_response (ResponseFormat): The structured response.
            complete_content (bool): Whether to return complete content.

        Returns:
            dict: The agent's response.
        """
        last_ai_content = ""
        try:
            for m in reversed(messages or []):
                if isinstance(m, AIMessage) and not getattr(m, "tool_calls", None):
                    c = m.content
                    if isinstance(c, str) and c.strip():
                        last_ai_content = c
                        break
        except Exception:
            last_ai_content = ""

        if structured_response and isinstance(structured_response, ResponseFormat):
            if structured_response.status == "input_required":
                if last_ai_content:
                    return {
                        "is_task_complete": True,
                        "require_user_input": False,
                        "content": last_ai_content,
                    }
                return {
                    "is_task_complete": False,
                    "require_user_input": True,
                    "content": structured_response.message,
                }
            if structured_response.status == "error":
                return {
                    "is_task_complete": False,
                    "require_user_input": True,
                    "content": structured_response.message,
                }
            if structured_response.status == "completed":
                content = last_ai_content or messages[-1].content or structured_response.message
                return {
                    "is_task_complete": True,
                    "require_user_input": False,
                    "content": content,
                }

        logger.info("Something went wrong")

        return {
            "is_task_complete": False,
            "require_user_input": True,
            "content": "We are unable to process your request at the moment. Please try again.",
        }

    SUPPORTED_CONTENT_TYPES = ["text", "text/plain", "data"]
