"""Tiny Redis pub/sub -> WebSocket fan-out for the AGV demo UI.

PSUBSCRIBEs to agv:*/task:*/trip:*/traffic:*/scenario:* and pushes
every message as ``{"channel": "...", "data": {...}}`` to all connected
WebSocket clients. No request/response protocol; clients just listen.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from typing import Set

import redis.asyncio as redis
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

log = logging.getLogger("agv-stream-bridge")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "") or None
MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017")
PATTERNS = [p.strip() for p in os.getenv(
    "CHANNEL_PATTERNS", "agv:*,task:*,trip:*,traffic:*,scenario:*"
).split(",") if p.strip()]

clients: Set[WebSocket] = set()
clients_lock = asyncio.Lock()


async def _broadcast(msg: dict) -> None:
    payload = json.dumps(msg)
    async with clients_lock:
        targets = list(clients)
    dead = []
    for ws in targets:
        try:
            await ws.send_text(payload)
        except Exception:
            dead.append(ws)
    if dead:
        async with clients_lock:
            for ws in dead:
                clients.discard(ws)


async def _subscribe_loop(stop_event: asyncio.Event) -> None:
    while not stop_event.is_set():
        try:
            client = redis.Redis(
                host=REDIS_HOST,
                port=REDIS_PORT,
                password=REDIS_PASSWORD,
                decode_responses=True,
            )
            pubsub = client.pubsub()
            await pubsub.psubscribe(*PATTERNS)
            log.info("subscribed to %s", PATTERNS)
            async for msg in pubsub.listen():
                if msg.get("type") not in ("pmessage", "message"):
                    continue
                channel = msg.get("channel")
                raw = msg.get("data")
                try:
                    data = json.loads(raw) if isinstance(raw, str) else raw
                except Exception:
                    data = raw
                await _broadcast({"channel": channel, "data": data})
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("subscribe loop crashed (%s); retrying in 2s", e)
            await asyncio.sleep(2)


@asynccontextmanager
async def lifespan(app: FastAPI):
    stop_event = asyncio.Event()
    task = asyncio.create_task(_subscribe_loop(stop_event))
    try:
        yield
    finally:
        stop_event.set()
        task.cancel()
        try:
            await task
        except Exception:
            pass


app = FastAPI(lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health() -> dict:
    return {"ok": True, "clients": len(clients), "patterns": PATTERNS}


QUALITY_STAGES = {"aoi_post_smt", "ict", "fct"}


def _zone_for(station_id: str | None) -> str:
    if not station_id:
        return "unknown"
    try:
        n = int(station_id.lstrip("Ss"))
    except Exception:
        return "unknown"
    if n <= 10:
        return "A"
    if n <= 20:
        return "B"
    return "C"


def _aggregate_stats(completed_docs: list[dict], assigned_docs: list[dict]) -> dict:
    """Reproduce the per-event roll-up done in the UI's onTripCompleted /
    onTaskAssigned reducers, but from persisted task documents.
    """
    stats = {
        "boards_total": 0,
        "boards_by_product": {},
        "cycle_time_sum_s": 0.0,
        "cycle_time_count": 0,
        "cycle_time_by_stage_sum_s": {},
        "cycle_time_by_stage_count": {},
        "reworks": 0,
        "passes": 0,
        "sla_hits_by_priority": {"low": 0, "normal": 0, "high": 0},
        "sla_total_by_priority": {"low": 0, "normal": 0, "high": 0},
        "wip_by_zone": {},
    }
    for d in completed_docs:
        units = d.get("units") or 1
        stats["boards_total"] += units
        prod = d.get("product_id")
        if prod:
            stats["boards_by_product"][prod] = stats["boards_by_product"].get(prod, 0) + units
        ct_created = d.get("created_ts") or 0
        ct_done = d.get("completed_ts") or 0
        cycle = max(0, ct_done - ct_created)
        stats["cycle_time_sum_s"] += cycle
        stats["cycle_time_count"] += 1
        stage = d.get("stage_to") or "unknown"
        stats["cycle_time_by_stage_sum_s"][stage] = stats["cycle_time_by_stage_sum_s"].get(stage, 0) + cycle
        stats["cycle_time_by_stage_count"][stage] = stats["cycle_time_by_stage_count"].get(stage, 0) + 1
        if stage == "rework":
            stats["reworks"] += 1
        elif stage in QUALITY_STAGES:
            stats["passes"] += 1
        pri = d.get("priority") or "normal"
        if pri in stats["sla_total_by_priority"]:
            stats["sla_total_by_priority"][pri] += 1
            sla = d.get("sla")
            if sla and ct_done <= sla:
                stats["sla_hits_by_priority"][pri] += 1
    # WIP = currently-assigned tasks grouped by destination zone.
    for a in assigned_docs:
        z = _zone_for(a.get("drop"))
        stats["wip_by_zone"][z] = stats["wip_by_zone"].get(z, 0) + 1
    return stats


@app.get("/tasks/snapshot")
async def tasks_snapshot() -> dict:
    """Return all pending + assigned + recent completed tasks from Mongo,
    plus aggregated PCB stats, so a freshly-loaded UI can rehydrate its
    task queue and KPI bar without waiting for new pub/sub events.
    """
    try:
        from pymongo import MongoClient
    except ImportError:
        return {
            "ok": False, "error": "pymongo not installed",
            "pending": [], "assigned": [], "completed": [], "stats": None,
        }
    try:
        cli = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
        col = cli["agv_poc"]["agv_tasks"]
        pending = list(col.find({"status": "pending"}, {"_id": 0}))
        assigned = list(col.find({"status": "assigned"}, {"_id": 0}))
        completed = list(
            col.find({"status": "completed"}, {"_id": 0})
               .sort("completed_ts", -1)
               .limit(200)
        )
        # Roll up KPIs from ALL completed (not just last 20) so the bar is accurate.
        all_completed = list(col.find({"status": "completed"}, {"_id": 0}))
        stats = _aggregate_stats(all_completed, assigned)
        return {
            "ok": True,
            "pending": pending,
            "assigned": assigned,
            "completed": completed,
            "stats": stats,
        }
    except Exception as e:
        log.warning("tasks/snapshot failed: %s", e)
        return {
            "ok": False, "error": str(e),
            "pending": [], "assigned": [], "completed": [], "stats": None,
        }


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket) -> None:
    await ws.accept()
    async with clients_lock:
        clients.add(ws)
    log.info("client connected (%d total)", len(clients))
    try:
        while True:
            # We don't expect inbound messages, but draining keeps the
            # socket alive and lets us detect disconnects promptly.
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.debug("ws recv ended: %s", e)
    finally:
        async with clients_lock:
            clients.discard(ws)
        log.info("client disconnected (%d remain)", len(clients))
