"""AGV Tool Server — exposes 8 AGV/PCB control tools over HTTP.

Each tool publishes a `chatbot:*` command to Redis (consumed by the simulator's
CommandBridge) and waits briefly for a `chatbot:reply` correlated by request_id.
Read-only tools (fleet status, task queue, batch history) read directly from
Redis snapshots / Mongo.
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from typing import Any, Optional

import redis
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

log = logging.getLogger("agv-tools")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD") or None
REPLY_TIMEOUT_S = float(os.getenv("REPLY_TIMEOUT_S", "2.0"))

app = FastAPI(title="agv-tool-server", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_client: Optional[redis.Redis] = None


def client() -> redis.Redis:
    global _client
    if _client is None:
        _client = redis.Redis(
            host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD,
            decode_responses=True,
        )
    return _client


def _call(channel: str, payload: dict[str, Any], wait_reply: bool = True) -> dict[str, Any]:
    rid = uuid.uuid4().hex[:10]
    body = {**payload, "request_id": rid}
    if wait_reply:
        ps = client().pubsub(ignore_subscribe_messages=True)
        ps.subscribe("chatbot:reply")
        # drain initial subscribe ack
        ps.get_message(timeout=0.1)
    client().publish(channel, json.dumps(body))
    if not wait_reply:
        return {"ok": True, "request_id": rid}
    deadline = time.time() + REPLY_TIMEOUT_S
    try:
        while time.time() < deadline:
            msg = ps.get_message(timeout=max(0.05, deadline - time.time()))
            if msg and msg.get("type") == "message":
                try:
                    data = json.loads(msg["data"])
                    if data.get("request_id") == rid:
                        return data
                except Exception:
                    continue
        return {"ok": False, "error": "timeout", "request_id": rid}
    finally:
        try:
            ps.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Tool request / response models
# ---------------------------------------------------------------------------
class CreateTaskReq(BaseModel):
    product: str = "pcb_consumer"
    units: int = 1
    priority: Optional[str] = None
    pickup_role: Optional[str] = None
    drop_role: Optional[str] = None


class SendToReq(BaseModel):
    agv_id: str
    station_id_or_role: str
    intent: Optional[str] = None
    units: Optional[int] = None
    expected_units: Optional[int] = None
    force: Optional[bool] = None


class MultiDropDrop(BaseModel):
    station: str
    units: int = 1


class MultiDropTripReq(BaseModel):
    agv_id: str
    pickup: str
    drops: list[MultiDropDrop]
    product: str = "pcb_consumer"
    priority: Optional[str] = None
    units_per_drop: int = 1
    force: Optional[bool] = None


class MultiPairPair(BaseModel):
    pickup: str
    drop: str
    units: int = 1


class MultiPairTripReq(BaseModel):
    agv_id: str
    pairs: list[MultiPairPair]
    product: str = "pcb_consumer"
    priority: Optional[str] = None
    force: Optional[bool] = None


class AgvIdReq(BaseModel):
    agv_id: str


class BatchReq(BaseModel):
    batch_id: str


class CancelTripReq(BaseModel):
    trip_id: Optional[str] = None
    agv_id: Optional[str] = None


class RerouteReq(BaseModel):
    agv_id: str
    station_id_or_role: str
    force: bool = False


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------
@app.get("/")
def root() -> dict:
    return {"service": "agv-tool-server", "ok": True}


EXPORTS_DIR = "/app/exports"
os.makedirs(EXPORTS_DIR, exist_ok=True)


@app.get("/exports/{filename}")
def download_export(filename: str):
    from fastapi.responses import FileResponse
    from fastapi import HTTPException
    if "/" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="invalid filename")
    path = os.path.join(EXPORTS_DIR, filename)
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail="not found")
    media = "text/csv" if filename.endswith(".csv") else "application/octet-stream"
    return FileResponse(path, media_type=media, filename=filename)


@app.get("/health")
def health() -> dict:
    try:
        client().ping()
        return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


@app.post("/tools/create_pcb_task")
def create_pcb_task(req: CreateTaskReq) -> dict:
    return _call("chatbot:create_task", req.model_dump(exclude_none=True))


@app.post("/tools/send_agv_to")
def send_agv_to(req: SendToReq) -> dict:
    return _call("chatbot:send_to", req.model_dump(exclude_none=True))


@app.post("/tools/multi_drop_trip")
def multi_drop_trip(req: MultiDropTripReq) -> dict:
    return _call("chatbot:multi_drop_trip", req.model_dump(exclude_none=True))


@app.post("/tools/multi_pair_trip")
def multi_pair_trip(req: MultiPairTripReq) -> dict:
    return _call("chatbot:multi_pair_trip", req.model_dump(exclude_none=True))


@app.post("/tools/recall_agv")
def recall_agv(req: AgvIdReq) -> dict:
    return _call("chatbot:recall_agv", req.model_dump())


@app.post("/tools/pause_agv")
def pause_agv(req: AgvIdReq) -> dict:
    return _call("chatbot:pause_agv", req.model_dump())


@app.post("/tools/resume_agv")
def resume_agv(req: AgvIdReq) -> dict:
    return _call("chatbot:resume_agv", req.model_dump())


@app.post("/tools/unblock_agv")
def unblock_agv(req: AgvIdReq) -> dict:
    return _call("chatbot:unblock_agv", req.model_dump())


@app.get("/tools/get_fleet_status")
def get_fleet_status() -> dict:
    return _call("chatbot:query", {"kind": "fleet"})


@app.get("/tools/get_task_queue")
def get_task_queue() -> dict:
    return _call("chatbot:query", {"kind": "tasks"})


@app.get("/tools/get_task_counts")
def get_task_counts() -> dict:
    return _call("chatbot:query", {"kind": "counts"})


@app.get("/tools/get_batch_history")
def get_batch_history(batch_id: str) -> dict:
    return _call("chatbot:query", {"kind": "batch", "batch_id": batch_id})


class AnalyzeDispatchReq(BaseModel):
    agv_id: Optional[str] = None
    pickup: Optional[str] = None
    drops: Optional[list[Any]] = None
    target: Optional[str] = None


@app.post("/tools/analyze_dispatch")
def analyze_dispatch(req: AnalyzeDispatchReq) -> dict:
    return _call("chatbot:analyze_dispatch", req.model_dump(exclude_none=True))


@app.post("/tools/emergency_stop")
def emergency_stop(req: AgvIdReq) -> dict:
    return _call("chatbot:emergency_stop", req.model_dump())


@app.post("/tools/cancel_trip")
def cancel_trip(req: CancelTripReq) -> dict:
    return _call("chatbot:cancel_trip", req.model_dump(exclude_none=True))


@app.post("/tools/reroute")
def reroute(req: RerouteReq) -> dict:
    return _call("chatbot:reroute", req.model_dump())


@app.get("/tools/list_interrupted_tasks")
def list_interrupted_tasks() -> dict:
    return _call("chatbot:list_interrupted", {})


@app.post("/tools/complete_interrupted_task")
def complete_interrupted_task(req: AgvIdReq) -> dict:
    return _call("chatbot:complete_interrupted", req.model_dump())


class RecallLowBatteryReq(BaseModel):
    count: int = 3
    threshold: float | None = None


@app.post("/tools/recall_low_battery")
def recall_low_battery(req: RecallLowBatteryReq) -> dict:
    return _call("chatbot:recall_low_battery", req.model_dump(exclude_none=True))


class CancelPendingTaskReq(BaseModel):
    task_id: Optional[str] = None
    task_ids: Optional[list[str]] = None
    all: bool = False


@app.post("/tools/cancel_pending_task")
def cancel_pending_task(req: CancelPendingTaskReq) -> dict:
    return _call("chatbot:cancel_pending_task", req.model_dump(exclude_none=True))


@app.get("/tools/list_pending_tasks")
def list_pending_tasks() -> dict:
    return _call("chatbot:list_pending_tasks", {})
