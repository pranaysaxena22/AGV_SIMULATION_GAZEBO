"""Pure velocity-command math for the AGV Gazebo bridge.

No ROS 2 / Gazebo dependencies — safe to import and test standalone.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path


def _find_repo_root(start: Path) -> Path:
    for parent in start.parents:
        if (parent / "scripts" / "gen_gazebo_world.py").exists():
            return parent
    raise ImportError("could not locate scripts/gen_gazebo_world.py above " + str(start))


_REPO_ROOT = _find_repo_root(Path(__file__).resolve())
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from scripts.gen_gazebo_world import convert_floor_to_gz  # noqa: E402  (reused, not reimplemented)

__all__ = [
    "compute_tracking_error_meters",
    "compute_velocity_command",
    "wrap_angle",
    "convert_floor_to_gz",
]


def compute_tracking_error_meters(
    target_x: float,
    target_y: float,
    actual_x: float,
    actual_y: float,
) -> float:
    """Return the 2D target/actual tracking error in meters."""
    ex = target_x - actual_x
    ey = target_y - actual_y
    return math.hypot(ex, ey)


def wrap_angle(angle: float) -> float:
    """Wrap an angle (radians) to (-pi, pi]."""
    wrapped = (angle + math.pi) % (2.0 * math.pi) - math.pi
    if wrapped <= -math.pi:
        wrapped += 2.0 * math.pi
    return wrapped


def compute_velocity_command(
    target_x: float,
    target_y: float,
    actual_x: float,
    actual_y: float,
    actual_yaw: float,
    Kp: float = 1.6,
    Kw: float = 2.5,
    v_max: float = 2.0,
    w_max: float = 1.5,
    target_speed: float = 0.0,
) -> tuple[float, float]:
    """Proportional go-to-point controller with optional feedforward target speed."""
    distance = compute_tracking_error_meters(target_x, target_y, actual_x, actual_y)
    if abs(target_speed) < 1e-9 and distance <= 0.05:
        return (0.0, 0.0)

    ex = target_x - actual_x
    ey = target_y - actual_y
    v = max(0.0, min(Kp * distance + target_speed, v_max))
    yaw_desired = math.atan2(ey, ex)
    heading_error = wrap_angle(yaw_desired - actual_yaw)
    omega = max(-w_max, min(Kw * heading_error, w_max))
    return (v, omega)
