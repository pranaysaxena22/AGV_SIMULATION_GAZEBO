from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import rclpy
from geometry_msgs.msg import Pose, PoseStamped, Twist
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

import redis.asyncio as redis

from .bridge_math import (
    compute_tracking_error_meters,
    compute_velocity_command,
    convert_floor_to_gz,
)

log = logging.getLogger("agv_gazebo_bridge")

DEFAULT_AGV_IDS = tuple(f"AGV{i:02d}" for i in range(1, 6))
DEFAULT_CHANNELS = ("agv:telemetry",)
AGV_BEACON_STATES = (
    "idle",
    "moving",
    "loading",
    "unloading",
    "blocked",
    "charging",
    "depleted",
)


@dataclass
class TargetState:
    x: float
    y: float
    heading: float
    ts: float
    speed: float = 0.0


@dataclass
class ActualState:
    x: float
    y: float
    yaw: float
    ts: float


def _parse_agv_ids(raw: str | None) -> tuple[str, ...]:
    if not raw:
        return DEFAULT_AGV_IDS
    agv_ids = tuple(part.strip() for part in raw.split(",") if part.strip())
    return agv_ids or DEFAULT_AGV_IDS


def _coerce_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _yaw_from_quaternion(x: float, y: float, z: float, w: float) -> float:
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return math.atan2(siny_cosp, cosy_cosp)


class AgvGazeboBridgeNode(Node):
    def __init__(self) -> None:
        super().__init__("agv_gazebo_bridge")
        self._lock = threading.Lock()
        self._targets: dict[str, TargetState] = {}
        self._actual: dict[str, ActualState] = {}
        self._last_tracking_log: dict[str, float] = {}
        self._startup_pose_synced: set[str] = set()
        self._agv_charge_lamps: dict[str, str] = {}
        self._agv_beacon_states: dict[str, str] = {}
        self._last_agv_beacon_update: dict[str, float] = {}
        self._last_agv_nodes: dict[str, str] = {}
        self._last_agv_states: dict[str, str] = {}
        self._agv_payload_counts: dict[str, int] = {}
        self._agv_blocked_nodes: dict[str, str | None] = {}
        self._active_blocked_nodes: set[str] = set()
        self._charge_bay_positions = {
            "H01": (26.0, 10.0),
            "H02": (37.0, 10.0),
            "H03": (47.0, 10.0),
        }
        self._waypoint_positions = self._load_waypoint_positions()
        self._agv_ids = _parse_agv_ids(os.getenv("AGV_IDS"))
        self._publish_hz = max(0.1, _coerce_float(os.getenv("PUBLISH_HZ"), 10.0))
        self._redis_host = os.getenv("REDIS_HOST", "localhost")
        self._redis_port = int(_coerce_float(os.getenv("REDIS_PORT"), 6379))
        self._redis_password = os.getenv("REDIS_PASSWORD", "") or None
        self._pose_topic_suffix = os.getenv("POSE_TOPIC_SUFFIX", "/pose")
        self._pose_topic_type = os.getenv("POSE_TOPIC_TYPE", "pose").strip().lower()
        self._redis_patterns = [p.strip() for p in os.getenv(
            "CHANNEL_PATTERNS", ",".join(DEFAULT_CHANNELS)
        ).split(",") if p.strip()]

        self._cmd_publishers = {
            agv_id: self.create_publisher(Twist, f"/model/{agv_id}/cmd_vel", 10)
            for agv_id in self._agv_ids
        }
        self._pose_subscriptions = self._create_pose_subscriptions()
        self._command_timer = self.create_timer(1.0 / self._publish_hz, self._publish_commands)

        self._redis_stop = threading.Event()
        self._redis_thread = threading.Thread(
            target=self._run_redis_loop,
            name="agv-gazebo-bridge-redis",
            daemon=True,
        )
        self._redis_thread.start()

        self.get_logger().info(
            f"bridge ready for {', '.join(self._agv_ids)}; publishing cmd_vel at {self._publish_hz:.1f} Hz"
        )

    def _create_pose_subscriptions(self) -> list[Any]:
        subscriptions: list[Any] = []
        for agv_id in self._agv_ids:
            topic = f"/model/{agv_id}{self._pose_topic_suffix}"
            if self._pose_topic_type == "pose_stamped":
                subscriptions.append(
                    self.create_subscription(
                        PoseStamped,
                        topic,
                        self._make_pose_stamped_callback(agv_id),
                        10,
                    )
                )
            else:
                subscriptions.append(
                    self.create_subscription(
                        Pose,
                        topic,
                        self._make_pose_callback(agv_id),
                        10,
                    )
                )
            self.get_logger().info(f"subscribed to pose feedback: {topic} ({self._pose_topic_type})")
        return subscriptions

    def _make_pose_callback(self, agv_id: str):
        def _callback(msg: Pose) -> None:
            self._store_actual(
                agv_id,
                msg.position.x,
                msg.position.y,
                _yaw_from_quaternion(
                    msg.orientation.x,
                    msg.orientation.y,
                    msg.orientation.z,
                    msg.orientation.w,
                ),
            )

        return _callback

    def _make_pose_stamped_callback(self, agv_id: str):
        def _callback(msg: PoseStamped) -> None:
            pose = msg.pose
            self._store_actual(
                agv_id,
                pose.position.x,
                pose.position.y,
                _yaw_from_quaternion(
                    pose.orientation.x,
                    pose.orientation.y,
                    pose.orientation.z,
                    pose.orientation.w,
                ),
            )

        return _callback

    def _store_actual(self, agv_id: str, x: float, y: float, yaw: float) -> None:
        with self._lock:
            prior = self._actual.get(agv_id)
            if x == 0.0 and y == 0.0 and yaw == 0.0:
                if prior is None:
                    self._actual[agv_id] = ActualState(x=x, y=y, yaw=yaw, ts=time.time())
                else:
                    last_warn = self._last_tracking_log.get(f"{agv_id}:zero_pose", 0.0)
                    now = time.monotonic()
                    if now - last_warn >= 2.0:
                        self.get_logger().warning(
                            f"{agv_id} ignoring all-zero pose update; keeping last known-good actual pose"
                        )
                        self._last_tracking_log[f"{agv_id}:zero_pose"] = now
                return
            self._actual[agv_id] = ActualState(x=x, y=y, yaw=yaw, ts=time.time())

    def _run_redis_loop(self) -> None:
        try:
            asyncio.run(self._subscribe_loop())
        except Exception as exc:
            log.exception("redis loop terminated: %s", exc)

    async def _subscribe_loop(self) -> None:
        while not self._redis_stop.is_set():
            client: redis.Redis | None = None
            pubsub = None
            try:
                client = redis.Redis(
                    host=self._redis_host,
                    port=self._redis_port,
                    password=self._redis_password,
                    decode_responses=True,
                )
                pubsub = client.pubsub()
                await pubsub.psubscribe(*self._redis_patterns)
                self.get_logger().info(f"subscribed to redis patterns: {self._redis_patterns}")

                while not self._redis_stop.is_set():
                    msg = await pubsub.get_message(ignore_subscribe_messages=False, timeout=1.0)
                    if msg is None or msg.get("type") not in ("pmessage", "message"):
                        continue
                    channel = msg.get("channel")
                    raw = msg.get("data")
                    try:
                        data = json.loads(raw) if isinstance(raw, str) else raw
                    except Exception:
                        data = raw
                    if channel == "agv:telemetry" and isinstance(data, dict):
                        self._on_telemetry(data)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.get_logger().warning(f"subscribe loop crashed ({exc}); retrying in 2s")
                await asyncio.sleep(2)
            finally:
                if pubsub is not None:
                    try:
                        await pubsub.aclose()
                    except Exception:
                        pass
                if client is not None:
                    try:
                        await client.aclose()
                    except Exception:
                        pass

    def _set_pose_vector(self, agv_id: str, target: TargetState) -> None:
        if shutil.which("gz") is None:
            self.get_logger().warning(
                f"{agv_id} startup pose sync skipped: Gazebo CLI not found on PATH"
            )
            return

        world_name = os.getenv("GZ_WORLD", "agv_floor")
        yaw = target.heading
        sl = math.sin(yaw / 2.0)
        cl = math.cos(yaw / 2.0)
        req = (
            f'pose {{ name: "{agv_id}" position {{ x: {target.x:.6f} y: {target.y:.6f} z: 0.0 }} '
            f'orientation {{ x: 0.0 y: 0.0 z: {sl:.6f} w: {cl:.6f} }} }}'
        )
        cmd = [
            "gz",
            "service",
            "-s",
            f"/world/{world_name}/set_pose_vector",
            "--reqtype",
            "gz.msgs.Pose_V",
            "--reptype",
            "gz.msgs.Boolean",
            "--timeout",
            "2000",
            "--req",
            req,
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=5)
            self.get_logger().info(
                f"{agv_id} startup pose sync: snapped to ({target.x:.3f}, {target.y:.3f})"
            )
        except Exception as exc:  # pragma: no cover - depends on Gazebo runtime
            self.get_logger().warning(f"{agv_id} startup pose sync failed: {exc}")

    def _set_model_pose(self, model_name: str, x: float, y: float, z: float = 0.0, yaw: float = 0.0) -> None:
        if shutil.which("gz") is None:
            return

        world_name = os.getenv("GZ_WORLD", "agv_floor")
        sl = math.sin(yaw / 2.0)
        cl = math.cos(yaw / 2.0)
        req = (
            f'pose {{ name: "{model_name}" position {{ x: {x:.6f} y: {y:.6f} z: {z:.6f} }} '
            f'orientation {{ x: 0.0 y: 0.0 z: {sl:.6f} w: {cl:.6f} }} }}'
        )
        cmd = [
            "gz",
            "service",
            "-s",
            f"/world/{world_name}/set_pose_vector",
            "--reqtype",
            "gz.msgs.Pose_V",
            "--reptype",
            "gz.msgs.Boolean",
            "--timeout",
            "2000",
            "--req",
            req,
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=5)
        except Exception:  # pragma: no cover - depends on Gazebo runtime
            pass

    def _load_waypoint_positions(self) -> dict[str, tuple[float, float]]:
        layout_path = Path(__file__).resolve().parents[5] / "shared" / "layouts" / "poc-floor.json"
        try:
            with layout_path.open("r", encoding="utf-8") as fh:
                layout = json.load(fh)
        except Exception:
            return {}
        result: dict[str, tuple[float, float]] = {}
        for waypoint in layout.get("waypoints", []):
            node_id = str(waypoint.get("id", "")).strip()
            if node_id:
                result[node_id] = (float(waypoint.get("x", 0.0)), float(waypoint.get("y", 0.0)))
        return result

    def _set_charge_lamp_state_for_bay(self, bay_id: str, desired_state: str) -> None:
        bay_x, bay_y = self._charge_bay_positions[bay_id]
        gx, gy, _ = convert_floor_to_gz(bay_x, bay_y)
        lamp_names = (f"{bay_id}_lamp_idle", f"{bay_id}_lamp_charging")

        for lamp_name in lamp_names:
            z = 0.15 if lamp_name.endswith(f"{desired_state}") else -50.0
            self._set_model_pose(lamp_name, gx, gy, z, 0.0)

        self._agv_charge_lamps[bay_id] = desired_state

    def _set_agv_crate_state_for_agv(self, agv_id: str, payload_count: int, x: float, y: float) -> None:
        crate_name = f"{agv_id}_crate"
        gx, gy, gz = convert_floor_to_gz(x, y)
        z = gz + 0.35 if payload_count > 0 else -50.0
        self._set_model_pose(crate_name, gx, gy, z, 0.0)
        self._agv_payload_counts[agv_id] = payload_count

    def _sync_agv_crate_state(self, payload: dict[str, Any]) -> None:
        agv_id = str(payload.get("agv_id", "")).strip()
        if not agv_id:
            return
        payload_count = int(payload.get("payload_count") or 0)
        x = _coerce_float(payload.get("x"), 0.0)
        y = _coerce_float(payload.get("y"), 0.0)
        previous_count = self._agv_payload_counts.get(agv_id)
        if previous_count != payload_count:
            self._set_agv_crate_state_for_agv(agv_id, payload_count, x, y)
        else:
            self._agv_payload_counts[agv_id] = payload_count

    def _set_blocked_corridor_disc_state(self, node_id: str, is_active: bool) -> None:
        if not node_id:
            return
        x, y = self._waypoint_positions.get(node_id, (0.0, 0.0))
        gx, gy, gz = convert_floor_to_gz(x, y)
        disc_name = f"{node_id}_blocked_disc"
        z = gz + 0.12 if is_active else -50.0
        self._set_model_pose(disc_name, gx, gy, z, 0.0)

    def _sync_blocked_corridor_state(self, payload: dict[str, Any]) -> None:
        agv_id = str(payload.get("agv_id", "")).strip()
        if not agv_id:
            return
        blocked_at_node = str(payload.get("blocked_at_node") or "").strip() or None
        previous_node = self._agv_blocked_nodes.get(agv_id)
        if previous_node == blocked_at_node:
            return
        self._agv_blocked_nodes[agv_id] = blocked_at_node
        if previous_node and previous_node in self._waypoint_positions:
            self._set_blocked_corridor_disc_state(previous_node, False)
        if blocked_at_node and blocked_at_node in self._waypoint_positions:
            self._set_blocked_corridor_disc_state(blocked_at_node, True)

    def _sync_charge_lamp_state(self, payload: dict[str, Any]) -> None:
        agv_id = str(payload.get("agv_id", "")).strip()
        current_node = str(payload.get("current_node", "")).strip()
        state = str(payload.get("state", "")).strip().lower()

        if agv_id:
            self._last_agv_nodes[agv_id] = current_node
            self._last_agv_states[agv_id] = state

        occupied_bays: dict[str, str] = {}
        for tracked_agv_id, tracked_node in self._last_agv_nodes.items():
            tracked_node = str(tracked_node).strip()
            if tracked_node not in self._charge_bay_positions:
                continue
            occupied_bays[tracked_node] = str(self._last_agv_states.get(tracked_agv_id, "idle")).strip().lower() or "idle"

        for bay_id in self._charge_bay_positions:
            desired_state = occupied_bays.get(bay_id, "idle")
            if desired_state not in {"idle", "charging"}:
                desired_state = "idle"

            if self._agv_charge_lamps.get(bay_id) != desired_state:
                self._set_charge_lamp_state_for_bay(bay_id, desired_state)

    def _set_agv_beacon_state_for_agv(self, agv_id: str, desired_state: str, x: float, y: float) -> None:
        if desired_state not in AGV_BEACON_STATES:
            desired_state = "idle"
        gx, gy, gz = convert_floor_to_gz(x, y)
        for beacon_state in AGV_BEACON_STATES:
            beacon_name = f"{agv_id}_beacon_{beacon_state}"
            z = gz + 1.0 if beacon_state == desired_state else -50.0
            self._set_model_pose(beacon_name, gx, gy, z, 0.0)
        self._agv_beacon_states[agv_id] = desired_state

    def _sync_agv_beacon_state(self, payload: dict[str, Any]) -> None:
        agv_id = str(payload.get("agv_id", "")).strip()
        if not agv_id:
            return

        state = str(payload.get("state", "")).strip().lower()
        if state not in AGV_BEACON_STATES:
            state = "idle"

        previous_state = self._agv_beacon_states.get(agv_id)
        if previous_state != state:
            x = _coerce_float(payload.get("x"), 0.0)
            y = _coerce_float(payload.get("y"), 0.0)
            self._set_agv_beacon_state_for_agv(agv_id, state, x, y)

        self._agv_beacon_states[agv_id] = state
        self._last_agv_beacon_update[agv_id] = time.monotonic()

    def _on_telemetry(self, payload: dict[str, Any]) -> None:
        agv_id = payload.get("agv_id")
        if agv_id not in self._cmd_publishers:
            return
        target_x, target_y, _ = convert_floor_to_gz(
            _coerce_float(payload.get("x")),
            _coerce_float(payload.get("y")),
        )
        target = TargetState(
            x=target_x,
            y=target_y,
            heading=_coerce_float(payload.get("heading")),
            ts=_coerce_float(payload.get("ts"), time.time()),
            speed=_coerce_float(payload.get("speed"), 0.0),
        )

        self._sync_charge_lamp_state(payload)
        self._sync_agv_beacon_state(payload)
        self._sync_agv_crate_state(payload)
        self._sync_blocked_corridor_state(payload)

        should_sync = False
        with self._lock:
            self._targets[agv_id] = target
            if agv_id not in self._startup_pose_synced:
                self._startup_pose_synced.add(agv_id)
                should_sync = True
                target_snapshot = TargetState(
                    x=target.x,
                    y=target.y,
                    heading=target.heading,
                    ts=target.ts,
                    speed=target.speed,
                )
            else:
                target_snapshot = None

        if should_sync and target_snapshot is not None:
            self._set_pose_vector(agv_id, target_snapshot)

    def _publish_commands(self) -> None:
        with self._lock:
            targets = dict(self._targets)
            actual = dict(self._actual)
            last_tracking_log = dict(self._last_tracking_log)

        now = time.monotonic()

        for agv_id, publisher in self._cmd_publishers.items():
            twist = Twist()
            target = targets.get(agv_id)
            pose = actual.get(agv_id)
            if target is not None and pose is not None:
                error_meters = compute_tracking_error_meters(
                    target_x=target.x,
                    target_y=target.y,
                    actual_x=pose.x,
                    actual_y=pose.y,
                )
                last_log_at = last_tracking_log.get(agv_id, -math.inf)
                if now - last_log_at >= 2.0:
                    self.get_logger().info(f"{agv_id} tracking error: {error_meters:.2f}m")
                    with self._lock:
                        self._last_tracking_log[agv_id] = now

                target_speed = target.speed
                linear_x, angular_z = compute_velocity_command(
                    target_x=target.x,
                    target_y=target.y,
                    actual_x=pose.x,
                    actual_y=pose.y,
                    actual_yaw=pose.yaw,
                    target_speed=target_speed,
                )
                twist.linear.x = linear_x
                twist.angular.z = angular_z

                if agv_id in {"AGV01", "AGV03", "AGV04"}:
                    self.get_logger().info(
                        f"{agv_id} DEBUG target=({target.x:.2f},{target.y:.2f}) "
                        f"actual=({pose.x:.2f},{pose.y:.2f},yaw={pose.yaw:.2f}) "
                        f"cmd=(v={linear_x:.2f},omega={angular_z:.2f})"
                    )
            publisher.publish(twist)

    def destroy_node(self) -> bool:
        self._redis_stop.set()
        return super().destroy_node()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    rclpy.init()
    node = AgvGazeboBridgeNode()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()