#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
SIMULATOR_DIR="${REPO_ROOT}/local-iops/agents/agv-simulator"
STREAM_BRIDGE_DIR="${REPO_ROOT}/local-iops/agents/agv-stream-bridge"
LOG_DIR="${SCRIPT_DIR}/logs"
BRIDGE_LOG="${LOG_DIR}/bridge.log"
SIMULATOR_LOG="${LOG_DIR}/simulator.log"
GUI_LOG="${LOG_DIR}/gui.log"
STREAM_BRIDGE_LOG="${LOG_DIR}/stream_bridge.log"

BRIDGE_PID=""
SIMULATOR_PID=""
GUI_PID=""
STREAM_BRIDGE_PID=""

cleanup_children() {
  local pid
  for pid in "${BRIDGE_PID}" "${SIMULATOR_PID}" "${GUI_PID}" "${STREAM_BRIDGE_PID}"; do
    if [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null; then
      echo "Stopping process group for PID ${pid}"
      kill -INT -- "-${pid}" 2>/dev/null || kill -INT "${pid}" 2>/dev/null || true
    fi
  done

  sleep 2

  for pid in "${BRIDGE_PID}" "${SIMULATOR_PID}" "${GUI_PID}" "${STREAM_BRIDGE_PID}"; do
    if [[ -n "${pid}" ]] && kill -0 "${pid}" 2>/dev/null; then
      echo "Force-killing process group for PID ${pid}"
      kill -KILL -- "-${pid}" 2>/dev/null || kill -KILL "${pid}" 2>/dev/null || true
    fi
  done

  echo "All managed processes stopped."
}

handle_signal() {
  local sig="$1"
  echo "Received ${sig}; shutting down managed processes..."
  cleanup_children
  exit 130
}

trap 'handle_signal SIGINT' INT
trap 'handle_signal SIGTERM' TERM

mkdir -p "${LOG_DIR}"
: > "${BRIDGE_LOG}"
: > "${SIMULATOR_LOG}"
: > "${GUI_LOG}"
: > "${STREAM_BRIDGE_LOG}"

# Ensure every run starts from a clean slate, even if a previous session left
# orphaned Gazebo bridge, simulator, or stream bridge processes behind.
pkill -f "parameter_bridge|agv_gazebo_bridge.node|agv_simulator.main|gz sim.*agv_floor.sdf|uvicorn app:app.*--port 8000" || true
sleep 2

wait_for_redis() {
  local attempts=0
  while (( attempts < 30 )); do
    if pixi run redis-cli ping 2>/dev/null | grep -q '^PONG$'; then
      echo "Redis is ready."
      return 0
    fi
    echo "Waiting for Redis to respond to PING (${attempts}/30)..."
    sleep 1
    attempts=$((attempts + 1))
  done

  echo "Redis did not respond with PONG within 30s." >&2
  return 1
}

# Step 1: ensure Redis is running
echo "[1/2] Starting Redis..."
pixi run redis-server --daemonize yes
wait_for_redis

# Step 2: start stream bridge early once Redis is ready; it does not require Gazebo or the simulator.
echo "[2/4] Starting agv-stream-bridge in background..."
setsid bash -lc "cd \"${STREAM_BRIDGE_DIR}\" && REDIS_HOST=localhost REDIS_PORT=6379 pixi run uvicorn app:app --host 0.0.0.0 --port 8000" > "${STREAM_BRIDGE_LOG}" 2>&1 &
STREAM_BRIDGE_PID=$!
echo "Stream bridge PID: ${STREAM_BRIDGE_PID}"

echo "Waiting for stream bridge startup confirmation in ${STREAM_BRIDGE_LOG}..."
start_deadline=$((SECONDS + 30))
while ! grep -q "Uvicorn running on http://0.0.0.0:8000" "${STREAM_BRIDGE_LOG}"; do
  if (( SECONDS >= start_deadline )); then
    echo "Timed out after 30s waiting for stream bridge startup confirmation." >&2
    cleanup_children
    exit 1
  fi

  if ! kill -0 "${STREAM_BRIDGE_PID}" 2>/dev/null; then
    echo "Stream bridge process exited before startup confirmation." >&2
    cleanup_children
    exit 1
  fi

  sleep 1
  echo "Still waiting for stream bridge startup..."
done

echo "Stream bridge startup confirmed."

# Step 3: start bridge stack
echo "[3/4] Starting bridge stack in background..."
setsid bash "${SCRIPT_DIR}/run_local.sh" > "${BRIDGE_LOG}" 2>&1 &
BRIDGE_PID=$!
echo "Bridge PID: ${BRIDGE_PID}"

# Wait until run_local.sh logs startup confirmation, rather than guessing
echo "Waiting for bridge startup confirmation in ${BRIDGE_LOG}..."
start_deadline=$((SECONDS + 30))
while ! grep -q "All processes started" "${BRIDGE_LOG}"; do
  if (( SECONDS >= start_deadline )); then
    echo "Timed out after 30s waiting for bridge startup confirmation." >&2
    cleanup_children
    exit 1
  fi

  if ! kill -0 "${BRIDGE_PID}" 2>/dev/null; then
    echo "Bridge process exited before startup confirmation." >&2
    cleanup_children
    exit 1
  fi

  sleep 1
  echo "Still waiting for bridge startup..."
done

echo "Bridge startup confirmed."

# Step 4: start the simulator in the repo's simulator folder
echo "[4/4] Starting AGV simulator..."
setsid bash -lc "cd \"${SIMULATOR_DIR}\" && REDIS_HOST=localhost REDIS_PORT=6379 LAYOUT_PATH=\"${REPO_ROOT}/shared/layouts/poc-floor.json\" PERSISTENCE=0 RUNTIME_S=0 PYTHONPATH=src pixi run python -m agv_simulator.main" > "${SIMULATOR_LOG}" 2>&1 &
SIMULATOR_PID=$!
echo "Simulator PID: ${SIMULATOR_PID}"

# Step 5: start Gazebo GUI process
echo "Starting Gazebo GUI..."
setsid bash -lc "cd \"${REPO_ROOT}\" && pixi run gz sim -g" > "${GUI_LOG}" 2>&1 &
GUI_PID=$!
echo "Gazebo GUI PID: ${GUI_PID}"

for pid in "${BRIDGE_PID}" "${SIMULATOR_PID}" "${GUI_PID}" "${STREAM_BRIDGE_PID}"; do
  if ! kill -0 "${pid}" 2>/dev/null; then
    echo "Expected process ${pid} is not alive after startup." >&2
    cleanup_children
    exit 1
  fi
done

echo "All managed processes are alive."
echo "All processes started. Gazebo, parameter_bridge, agv_gazebo_bridge.node, agv_simulator.main, and agv-stream-bridge are running. Open http://localhost:8000/ws to view the live WebSocket feed."

echo "Following bridge log (Ctrl+C to stop everything)..."
tail -f "${BRIDGE_LOG}"
