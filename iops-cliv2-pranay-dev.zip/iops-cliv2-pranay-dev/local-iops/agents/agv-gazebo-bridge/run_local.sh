#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
WORLD_FILE="${REPO_ROOT}/shared/gazebo/agv_floor.sdf"
BRIDGE_CONFIG="${SCRIPT_DIR}/bridge_config.yaml"
NODE_SRC="${SCRIPT_DIR}/src"

cleanup() {
  local exit_code=$?
  if [[ -n "${NODE_PID:-}" ]]; then
    kill "${NODE_PID}" 2>/dev/null || true
  fi
  if [[ -n "${BRIDGE_PID:-}" ]]; then
    kill "${BRIDGE_PID}" 2>/dev/null || true
  fi
  if [[ -n "${GAZEBO_PID:-}" ]]; then
    kill "${GAZEBO_PID}" 2>/dev/null || true
  fi
  wait 2>/dev/null || true
  exit "$exit_code"
}
trap cleanup EXIT INT TERM

echo "[1/3] Starting Gazebo headless with ${WORLD_FILE}"
if [[ ! -f "${WORLD_FILE}" ]]; then
  echo "World file not found: ${WORLD_FILE}" >&2
  exit 1
fi
pixi run gz sim -r -s "${WORLD_FILE}" &
GAZEBO_PID=$!
sleep 2
if ! kill -0 "${GAZEBO_PID}" 2>/dev/null; then
  echo "Gazebo failed to stay running" >&2
  exit 1
fi

echo "[2/3] Starting ros_gz_bridge parameter_bridge with ${BRIDGE_CONFIG}"
if ! pixi run ros2 pkg prefix ros_gz_bridge >/dev/null 2>&1; then
  echo "ros_gz_bridge is not installed in the current Pixi environment" >&2
  echo "Add the ros_gz_bridge package before running this script." >&2
  exit 1
fi
pixi run ros2 run ros_gz_bridge parameter_bridge --ros-args -p config_file:="${BRIDGE_CONFIG}" &
BRIDGE_PID=$!
sleep 2
if ! kill -0 "${BRIDGE_PID}" 2>/dev/null; then
  echo "ros_gz_bridge failed to stay running" >&2
  exit 1
fi

echo "[3/3] Starting agv_gazebo_bridge.node"
cd "${REPO_ROOT}"
PYTHONPATH="${NODE_SRC}${PYTHONPATH:+:${PYTHONPATH}}" pixi run python -m agv_gazebo_bridge.node &
NODE_PID=$!
sleep 2
if ! kill -0 "${NODE_PID}" 2>/dev/null; then
  echo "agv_gazebo_bridge.node failed to stay running" >&2
  exit 1
fi

echo "All processes started. Press Ctrl+C to stop Gazebo, ros_gz_bridge, and agv_gazebo_bridge.node."
wait "${GAZEBO_PID}" "${BRIDGE_PID}" "${NODE_PID}"