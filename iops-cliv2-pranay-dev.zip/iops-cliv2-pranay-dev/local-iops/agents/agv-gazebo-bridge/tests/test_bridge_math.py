"""Pure-math tests for the AGV Gazebo bridge controller — no ROS 2 / Gazebo required."""
import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))

from agv_gazebo_bridge.bridge_math import (
    compute_tracking_error_meters,
    compute_velocity_command,
    wrap_angle,
)


def test_tracking_error_matches_distance_between_target_and_actual():
    error = compute_tracking_error_meters(target_x=3.0, target_y=4.0, actual_x=0.0, actual_y=0.0)
    assert error == pytest.approx(5.0, abs=1e-9)


def test_target_ahead_same_heading_drives_straight():
    v, omega = compute_velocity_command(
        target_x=5.0, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
    )
    assert omega == pytest.approx(0.0, abs=1e-9)
    assert v > 0.0


def test_target_requiring_90_degree_turn_saturates_omega():
    # Facing +x (yaw=0), target is straight ahead in +y -> 90 deg left turn.
    v, omega = compute_velocity_command(
        target_x=0.0, target_y=5.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
    )
    w_max = 1.5
    # Kw * (pi/2) = 2.5 * 1.5708 ~= 3.93, well past w_max -> clamps exactly to it.
    assert omega == pytest.approx(w_max, abs=1e-9)


def test_within_tolerance_holds_position():
    v, omega = compute_velocity_command(
        target_x=2.03, target_y=3.02, actual_x=2.0, actual_y=3.0, actual_yaw=0.0,
    )
    assert (v, omega) == (0.0, 0.0)


def test_target_speed_feedforward_increases_linear_velocity():
    pure_p_v, _ = compute_velocity_command(
        target_x=1.0, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
        target_speed=0.0,
    )
    v, omega = compute_velocity_command(
        target_x=1.0, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
        target_speed=1.5,
    )
    assert v > pure_p_v
    assert v == pytest.approx(2.0, abs=1e-9)
    assert omega == pytest.approx(0.0, abs=1e-9)

    small_distance_v, _ = compute_velocity_command(
        target_x=0.02, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
        target_speed=1.5,
    )
    assert 1.0 < small_distance_v < 1.6


def test_dead_zone_still_holds_with_target_speed_zero():
    v, omega = compute_velocity_command(
        target_x=0.04, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
        target_speed=0.0,
    )
    assert (v, omega) == (0.0, 0.0)


def test_exactly_at_tolerance_boundary_holds_position():
    v, omega = compute_velocity_command(
        target_x=0.05, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
    )
    assert (v, omega) == (0.0, 0.0)


def test_far_target_clamps_v_at_v_max():
    v_max = 2.0
    v, omega = compute_velocity_command(
        target_x=10_000.0, target_y=0.0, actual_x=0.0, actual_y=0.0, actual_yaw=0.0,
    )
    assert v == pytest.approx(v_max, abs=1e-9)
    assert v <= v_max


def test_wrap_angle_brings_multiples_of_pi_back_in_range():
    wrapped = wrap_angle(3 * math.pi)
    assert wrapped != pytest.approx(3 * math.pi)
    assert abs(wrapped) == pytest.approx(math.pi, abs=1e-9)


@pytest.mark.parametrize("angle", [0.0, math.pi, -math.pi, 0.99 * math.pi, -0.99 * math.pi,
                                    5 * math.pi, -5 * math.pi, 100.0])
def test_wrap_angle_always_in_range(angle):
    wrapped = wrap_angle(angle)
    assert -math.pi < wrapped <= math.pi
