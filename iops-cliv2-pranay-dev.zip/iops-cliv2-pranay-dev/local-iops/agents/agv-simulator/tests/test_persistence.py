"""Day-2: persistence worker mirrors Redis events into a Mongo-like store.

Uses fakeredis for pub/sub and patches MongoClient with mongomock.
"""
from __future__ import annotations

import json
import time
from unittest import mock

import fakeredis
import mongomock
import pytest

from agv_simulator.config import Config
from agv_simulator.persistence import (
    COL_STATE,
    COL_TELEMETRY,
    DB_NAME,
    PersistenceWorker,
)
from agv_simulator.telemetry import CHANNEL_STATE, CHANNEL_TELEMETRY


@pytest.fixture
def fake_pubsub():
    return fakeredis.FakeRedis(decode_responses=True)


@pytest.fixture
def mongo():
    return mongomock.MongoClient()


def test_state_events_persist(fake_pubsub, mongo):
    cfg = Config()
    with mock.patch("agv_simulator.persistence.MongoClient", return_value=mongo, create=True):
        worker = PersistenceWorker(cfg, redis_client=fake_pubsub)
        # Bypass real connect path; install our mock collections directly.
        worker._mongo_col_telemetry = mongo[DB_NAME][COL_TELEMETRY]
        worker._mongo_col_state = mongo[DB_NAME][COL_STATE]
        # Start only the listener thread; do not start the 1 Hz sampler.
        import threading

        worker._thread = threading.Thread(target=worker._run, daemon=True)
        worker._thread.start()
        time.sleep(0.1)

        for i in range(3):
            fake_pubsub.publish(
                CHANNEL_STATE,
                json.dumps(
                    {
                        "agv_id": "AGV01",
                        "state": "moving",
                        "ts": time.time() + i,
                    }
                ),
            )
        time.sleep(0.3)
        worker.stop()

        assert mongo[DB_NAME][COL_STATE].count_documents({}) == 3


def test_telemetry_sampled_at_1hz(fake_pubsub, mongo):
    cfg = Config()
    worker = PersistenceWorker(cfg, redis_client=fake_pubsub)
    worker._mongo_col_telemetry = mongo[DB_NAME][COL_TELEMETRY]
    worker._mongo_col_state = mongo[DB_NAME][COL_STATE]

    # Push 10 telemetry messages for one AGV; sampler should keep latest.
    for i in range(10):
        worker._on_telemetry({"agv_id": "AGV01", "x": float(i), "y": 0.0})
    # Push a few for AGV02.
    for i in range(5):
        worker._on_telemetry({"agv_id": "AGV02", "x": 0.0, "y": float(i)})

    # Manually run one sampler iteration's flush.
    with worker._latest_lock:
        batch = list(worker._latest_per_agv.values())
        worker._latest_per_agv.clear()
    worker._mongo_col_telemetry.insert_many(
        [dict(b, sampled_at=time.time()) for b in batch]
    )

    docs = list(mongo[DB_NAME][COL_TELEMETRY].find({}))
    # One sample per AGV, not 10 + 5.
    assert len(docs) == 2
    by_id = {d["agv_id"]: d for d in docs}
    assert by_id["AGV01"]["x"] == 9.0  # latest x for AGV01
    assert by_id["AGV02"]["y"] == 4.0
