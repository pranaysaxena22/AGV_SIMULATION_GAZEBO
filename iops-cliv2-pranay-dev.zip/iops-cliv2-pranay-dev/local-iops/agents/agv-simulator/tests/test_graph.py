"""Validation + loader + routing tests for poc-floor.json."""
import json
import math
import sys
from collections import defaultdict, deque
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[4]
LAYOUT_PATH = ROOT / "shared" / "layouts" / "poc-floor.json"
sys.path.insert(0, str(ROOT / "local-iops" / "agents" / "agv-simulator" / "src"))

from agv_simulator.graph import load_floor  # noqa: E402
from agv_simulator.routing import precompute_all_pairs  # noqa: E402


# ---------- raw JSON validation ----------

@pytest.fixture(scope="module")
def layout():
    return json.loads(LAYOUT_PATH.read_text())


@pytest.fixture(scope="module")
def raw_graph(layout):
    stations = {s["id"]: s for s in layout["stations"]}
    waypoints = {w["id"]: w for w in layout["waypoints"]}
    nodes = {**stations, **waypoints}
    adj = defaultdict(set)
    for e in layout["edges"]:
        adj[e["from"]].add(e["to"])
        adj[e["to"]].add(e["from"])
    return stations, waypoints, nodes, adj


def test_station_count(raw_graph):
    stations, *_ = raw_graph
    assert len(stations) == 33


def test_no_id_collision(raw_graph):
    stations, waypoints, *_ = raw_graph
    assert not (set(stations) & set(waypoints))


def test_zone_balance(raw_graph):
    stations, *_ = raw_graph
    counts = {"A": 0, "B": 0, "C": 0}
    for s in stations.values():
        counts[s["zone"]] += 1
    assert counts == {"A": 10, "B": 12, "C": 11}


def test_nodes_within_bounds(layout, raw_graph):
    *_, nodes, _ = raw_graph
    b = layout["bounds"]
    for nid, n in nodes.items():
        assert b["minX"] <= n["x"] <= b["maxX"], nid
        assert b["minY"] <= n["y"] <= b["maxY"], nid


def test_edges_reference_known_nodes(raw_graph, layout):
    *_, nodes, _ = raw_graph
    for e in layout["edges"]:
        assert e["from"] in nodes
        assert e["to"] in nodes


def test_no_floating_nodes(raw_graph):
    *_, nodes, adj = raw_graph
    floating = [nid for nid in nodes if nid not in adj]
    assert not floating, f"floating nodes: {floating}"


def test_all_stations_reachable_from_s01(raw_graph):
    stations, _, _, adj = raw_graph
    seen, q = set(), deque(["S01"])
    while q:
        u = q.popleft()
        if u in seen:
            continue
        seen.add(u)
        q.extend(adj[u])
    unreached = [s for s in stations if s not in seen]
    assert not unreached, f"unreachable from S01: {unreached}"


def test_edges_have_positive_length(raw_graph, layout):
    *_, nodes, _ = raw_graph
    for e in layout["edges"]:
        a, c = nodes[e["from"]], nodes[e["to"]]
        d = math.hypot(a["x"] - c["x"], a["y"] - c["y"])
        assert d > 0, f"zero-length edge {e}"
        assert d <= 15, f"edge too long ({d:.1f}m): {e}"


# ---------- graph.load_floor ----------

@pytest.fixture(scope="module")
def loaded():
    return load_floor(LAYOUT_PATH)


def test_layout_loads(loaded):
    g, coords = loaded
    assert g is not None
    assert coords is not None


def test_loader_returns_30_plus_nodes(loaded):
    g, _ = loaded
    assert g.number_of_nodes() >= 30
    stations = [n for n, d in g.nodes(data=True) if d["kind"] == "station"]
    assert len(stations) == 33


def test_loader_assigns_euclidean_weights(loaded):
    g, coords = loaded
    for u, v, d in g.edges(data=True):
        ax, ay = coords[u]
        bx, by = coords[v]
        expected = math.hypot(ax - bx, ay - by)
        assert d["weight"] == pytest.approx(expected)


def test_loader_validates_reachability_to_every_station(loaded):
    import networkx as nx
    g, _ = loaded
    stations = [n for n, d in g.nodes(data=True) if d["kind"] == "station"]
    for s in stations:
        assert nx.has_path(g, "S01", s), f"no path S01 -> {s}"


# ---------- routing.precompute_all_pairs ----------

@pytest.fixture(scope="module")
def routing(loaded):
    g, _ = loaded
    return precompute_all_pairs(g)


def test_shortest_path_s01_to_s30_starts_and_ends_correctly(routing):
    path = routing.shortest_path("S01", "S30")
    assert isinstance(path, list)
    assert len(path) >= 2
    assert path[0] == "S01"
    assert path[-1] == "S30"


def test_distance_symmetric(routing):
    assert routing.distance("S01", "S30") == pytest.approx(routing.distance("S30", "S01"))


def test_distance_matches_path_total(routing):
    path = routing.shortest_path("S05", "S22")
    assert routing.distance("S05", "S22") == pytest.approx(routing.total_distance(path))


def test_path_uses_only_real_edges(routing, loaded):
    g, _ = loaded
    path = routing.shortest_path("S01", "S30")
    for a, b in zip(path, path[1:]):
        assert g.has_edge(a, b), f"path uses non-existent edge {a}-{b}"
