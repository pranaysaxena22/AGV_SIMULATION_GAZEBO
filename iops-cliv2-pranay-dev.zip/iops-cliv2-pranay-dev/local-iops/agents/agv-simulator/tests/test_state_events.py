"""Day-2: state-change callback fires on every transition."""
from __future__ import annotations

from pathlib import Path

import simpy

from agv_simulator.agv import AGV, Stop, Trip
from agv_simulator.config import Config
from agv_simulator.graph import load_floor
from agv_simulator.routing import precompute_all_pairs

LAYOUT = str(Path(__file__).resolve().parents[4] / "shared" / "layouts" / "poc-floor.json")


def test_state_change_callback_fires_on_every_transition():
    cfg = Config()
    g, coords = load_floor(LAYOUT)
    routing = precompute_all_pairs(g)
    env = simpy.Environment()

    transitions: list[str] = []

    def cb(agv: AGV) -> None:
        transitions.append(agv.state)

    agv = AGV(
        agv_id="AGV01",
        start_node="S01",
        env=env,
        cfg=cfg,
        routing=routing,
        coords=coords,
        on_state_change=cb,
    )
    env.process(agv.run())
    agv.submit(Trip(trip_id="t1", stops=[Stop("S03", op="pickup")]))
    env.run(until=30)

    # Expect: idle (initial set on first loop iteration is a no-op since it's
    # already idle by default), moving, loading, idle (back to idle for next
    # cmd_queue.get).  We must see at least: moving, loading, idle (post).
    assert "moving" in transitions
    assert "loading" in transitions
    # Last transition observed should be back to idle as the AGV waits for
    # the next trip.
    assert transitions[-1] == "idle"


def test_no_callback_when_state_unchanged():
    """Setting the same state twice should not double-fire."""
    cfg = Config()
    g, coords = load_floor(LAYOUT)
    routing = precompute_all_pairs(g)
    env = simpy.Environment()

    fires: list[str] = []
    agv = AGV(
        agv_id="AGV01",
        start_node="S01",
        env=env,
        cfg=cfg,
        routing=routing,
        coords=coords,
        on_state_change=lambda a: fires.append(a.state),
    )
    agv.state = "idle"  # already idle -> no fire
    agv.state = "moving"
    agv.state = "moving"  # same -> no fire
    agv.state = "idle"
    assert fires == ["moving", "idle"]
