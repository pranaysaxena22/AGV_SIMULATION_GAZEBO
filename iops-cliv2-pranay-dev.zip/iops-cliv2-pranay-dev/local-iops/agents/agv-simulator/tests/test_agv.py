"""AGV state machine + telemetry publisher tests."""
import json
import sys
from pathlib import Path

import fakeredis
import pytest
import simpy

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "local-iops" / "agents" / "agv-simulator" / "src"))

from agv_simulator.agv import AGV, Stop, Trip
from agv_simulator.config import Config
from agv_simulator.fleet import build_fleet, telemetry_ticker
from agv_simulator.graph import load_floor
from agv_simulator.routing import precompute_all_pairs
from agv_simulator.telemetry import CHANNEL_TELEMETRY, TelemetryPublisher

LAYOUT_PATH = ROOT / "shared" / "layouts" / "poc-floor.json"


@pytest.fixture(scope="module")
def loaded():
    g, coords = load_floor(LAYOUT_PATH)
    return g, coords, precompute_all_pairs(g)


def make_cfg() -> Config:
    return Config()


def test_agv_starts_idle_at_start_node(loaded):
    g, coords, routing = loaded
    env = simpy.Environment()
    agv = AGV("AGV01", "S01", env, make_cfg(), routing, coords)
    assert agv.state == "idle"
    assert (agv.x, agv.y) == coords["S01"]
    assert agv.current_node == "S01"


def test_agv_completes_trip_and_returns_to_idle(loaded):
    g, coords, routing = loaded
    env = simpy.Environment()
    agv = AGV("AGV01", "S01", env, make_cfg(), routing, coords)
    env.process(agv.run())
    agv.submit(Trip("t1", [Stop("S03", "pickup"), Stop("S10", "drop")]))
    env.run(until=200)
    assert agv.state == "idle"
    assert agv.current_node == "S10"
    assert (agv.x, agv.y) == coords["S10"]
    assert agv.payload_count == 0


def test_state_transitions_visit_loading_and_unloading(loaded):
    g, coords, routing = loaded
    env = simpy.Environment()
    agv = AGV("AGV01", "S01", env, make_cfg(), routing, coords)
    env.process(agv.run())
    seen: set[str] = set()

    def watcher():
        while len(seen) < 4 and env.now < 200:
            seen.add(agv.state)
            yield env.timeout(0.1)

    env.process(watcher())
    agv.submit(Trip("t1", [Stop("S03", "pickup"), Stop("S10", "drop")]))
    env.run(until=200)
    assert {"idle", "moving", "loading", "unloading"} <= seen


def test_payload_count_tracks_pickups_and_drops(loaded):
    g, coords, routing = loaded
    env = simpy.Environment()
    agv = AGV("AGV01", "S01", env, make_cfg(), routing, coords)
    env.process(agv.run())
    agv.submit(Trip("t1", [Stop("S03", "pickup"), Stop("S05", "pickup")]))
    env.run(until=120)
    assert agv.payload_count == 2


def test_telemetry_publisher_emits_to_channel(loaded):
    g, coords, routing = loaded
    env = simpy.Environment()
    cfg = make_cfg()
    fleet = build_fleet(env, cfg, routing, coords, count=1)
    fake = fakeredis.FakeRedis(decode_responses=True)
    sub = fake.pubsub()
    sub.subscribe(CHANNEL_TELEMETRY)
    sub.get_message(timeout=0.1)  # drop subscribe ack

    publisher = TelemetryPublisher(cfg, client=fake)
    env.process(telemetry_ticker(env, cfg, fleet, publisher))
    fleet.agvs[0].submit(Trip("t1", [Stop("S03", "pickup")]))
    env.run(until=15)

    msgs = []
    while True:
        m = sub.get_message(timeout=0.05)
        if m is None:
            break
        if m["type"] == "message":
            msgs.append(json.loads(m["data"]))
    assert len(msgs) > 50, f"expected steady telemetry, got {len(msgs)}"
    last = msgs[-1]
    assert {"agv_id", "x", "y", "state", "trip_id", "ts"} <= set(last.keys())
    assert last["agv_id"] == "AGV01"
