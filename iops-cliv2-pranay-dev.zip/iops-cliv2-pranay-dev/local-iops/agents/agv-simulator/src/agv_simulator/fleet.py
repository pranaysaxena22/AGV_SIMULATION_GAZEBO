"""Fleet builder + telemetry ticker.

Day 2 default: 5 AGVs at S01/S07/S13/S19/S25. ``build_fleet`` reads
``count`` from config so 1-AGV smoke runs still work.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

import networkx as nx
import simpy

from .agv import AGV
from .config import Config
from .routing import RoutingTable
from .telemetry import TelemetryPublisher
from .traffic import TrafficManager

PARKING_BAYS = ["H01", "H02", "H03"]
DEFAULT_START_NODES = ["H01", "H02", "H03", "W34", "W38"]


@dataclass
class Fleet:
    agvs: list[AGV]

    def by_id(self, agv_id: str) -> AGV:
        return next(a for a in self.agvs if a.agv_id == agv_id)


def build_fleet(
    env: simpy.Environment,
    cfg: Config,
    routing: RoutingTable,
    coords: dict[str, tuple[float, float]],
    count: int = 5,
    traffic: Optional[TrafficManager] = None,
    graph: Optional[nx.Graph] = None,
    on_state_change: Optional[Callable[[AGV], None]] = None,
    on_stop_done: Optional[Callable[[AGV, str, str], None]] = None,
    on_trip_complete: Optional[Callable[[AGV, str, dict], None]] = None,
    on_trip_interrupted: Optional[Callable[[AGV, str, object], None]] = None,
) -> Fleet:
    starts = DEFAULT_START_NODES[:count]
    agvs: list[AGV] = []
    for i, node in enumerate(starts, 1):
        agv = AGV(
            agv_id=f"AGV{i:02d}",
            start_node=node,
            env=env,
            cfg=cfg,
            routing=routing,
            coords=coords,
            capacity=cfg.agv_capacity,
            traffic=traffic,
            graph=graph,
            on_state_change=on_state_change,
            on_stop_done=on_stop_done,
            on_trip_complete=on_trip_complete,
            on_trip_interrupted=on_trip_interrupted,
        )
        env.process(agv.run())
        agvs.append(agv)
    return Fleet(agvs=agvs)


def telemetry_ticker(
    env: simpy.Environment, cfg: Config, fleet: Fleet, publisher: TelemetryPublisher
):
    """Publish every AGV's snapshot once per tick."""
    while True:
        for agv in fleet.agvs:
            try:
                publisher.publish(agv)
            except Exception:
                pass
        yield env.timeout(cfg.tick_period)


def battery_ticker(env: simpy.Environment, cfg: Config, fleet: Fleet):
    """Drain battery while moving/idle; charge while parked on H01/H02/H03.

    Runs every cfg.tick_period; rates are %/second.
    """
    while True:
        dt = cfg.tick_period
        for agv in fleet.agvs:
            try:
                # Clear stale "moving"/"blocked" state when the AGV is parked
                # on a bay with no active trip — keeps the UI from showing
                # "moving" while it's actually sitting on H01/H02/H03.
                if (
                    agv.current_node in ("H01", "H02", "H03")
                    and agv.trip_id is None
                    and agv.state in ("moving", "blocked")
                ):
                    agv.state = "idle"
                if agv.is_on_charging_bay():
                    if agv.battery_pct < 100.0:
                        agv.battery_pct = min(100.0, agv.battery_pct + cfg.battery_charge_rate * dt)
                        # Reflect a "charging" pseudo-state when actively charging.
                        if agv.state == "idle" and agv.battery_pct < 100.0:
                            agv.state = "charging"
                    elif agv.state == "charging":
                        agv.state = "idle"
                else:
                    # Off-bay: clear any leftover "charging" state — the AGV
                    # should never appear as charging away from H01/H02/H03.
                    if agv.state == "charging":
                        agv.state = "idle"
                    if agv.state in ("moving", "blocked"):
                        rate = cfg.battery_drain_moving
                    elif agv.state == "depleted":
                        rate = 0.0  # frozen — does not drain further
                    else:
                        rate = cfg.battery_drain_idle
                    agv.battery_pct = max(0.0, agv.battery_pct - rate * dt)
                    # Trip into depleted state when battery hits 20% or lower.
                    # The AGV freezes in place and refuses normal trips until
                    # recalled to a charging bay (which clears the flag).
                    if (
                        agv.battery_pct <= cfg.battery_depleted_threshold
                        and agv.state not in ("depleted", "charging")
                        and not getattr(agv, "_recall_to_charge", False)
                    ):
                        # Abort any in-flight trip so the remaining stops are
                        # converted to an interrupted/pending trip; the AGV
                        # then freezes in place until recalled to a bay.
                        if agv.trip_id is not None:
                            agv._abort = True
                            run_proc = getattr(agv, "_run_proc", None)
                            if run_proc is not None and run_proc.is_alive:
                                try:
                                    run_proc.interrupt()
                                except Exception:
                                    pass
                        agv.state = "depleted"
            except Exception:
                pass
        yield env.timeout(dt)
