"""Runtime configuration loaded from environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


_REPO_ROOT = Path(__file__).resolve().parents[5]
_DEFAULT_LAYOUT_PATH = _REPO_ROOT / "shared" / "layouts" / "poc-floor.json"


@dataclass(frozen=True)
class Config:
    redis_host: str = os.getenv("REDIS_HOST", "localhost")
    redis_port: int = int(os.getenv("REDIS_PORT", "6379"))
    redis_password: str = os.getenv("REDIS_PASSWORD", "") or ""
    mongo_uri: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    layout_path: str = os.getenv(
        "LAYOUT_PATH",
        str(_DEFAULT_LAYOUT_PATH),
    )
    tick_hz: float = float(os.getenv("TICK_HZ", "10"))
    agv_speed: float = float(os.getenv("AGV_SPEED", "1.5"))      # m/s
    load_seconds: float = float(os.getenv("LOAD_SECONDS", "3"))
    runtime_s: float = float(os.getenv("RUNTIME_S", "30"))       # 0 = run forever
    fleet_size: int = int(os.getenv("FLEET_SIZE", "5"))
    persistence_enabled: bool = os.getenv("PERSISTENCE", "1") not in ("0", "false", "False")
    deadlock_timeout: float = float(os.getenv("DEADLOCK_TIMEOUT", "1.5"))
    agv_capacity: int = int(os.getenv("AGV_CAPACITY", "50"))
    bundle_radius: float = float(os.getenv("BUNDLE_RADIUS", "15.0"))  # max meters between bundled stops
    battery_drain_moving: float = float(os.getenv("BATTERY_DRAIN_MOVING", "0.4"))   # %/sec while moving
    battery_drain_idle: float = float(os.getenv("BATTERY_DRAIN_IDLE", "0.08"))      # %/sec while idle (off-bay)
    battery_charge_rate: float = float(os.getenv("BATTERY_CHARGE_RATE", "5.0"))     # %/sec at H01/H02/H03
    battery_min_dispatch: float = float(os.getenv("BATTERY_MIN_DISPATCH", "20.0"))  # min % to accept new task (matches depleted threshold)
    battery_depleted_threshold: float = float(os.getenv("BATTERY_DEPLETED", "20.0"))  # AGV freezes in place at/below this %
    auto_recall_threshold: float = float(os.getenv("AUTO_RECALL_THRESHOLD", "30.0"))  # auto-recall idle/depleted AGVs at/below this %
    auto_recall_interval_s: float = float(os.getenv("AUTO_RECALL_INTERVAL_S", "5.0"))  # how often the auto-recall sweep runs
    charge_resume_threshold: float = float(os.getenv("CHARGE_RESUME_THRESHOLD", "80.0"))  # battery % required to resume queued tasks after charging
    idle_park_timeout_s: float = float(os.getenv("IDLE_PARK_TIMEOUT_S", "10.0"))  # seconds idle before auto-parking to nearest bay
    batch_window_s: float = float(os.getenv("BATCH_WINDOW_S", "3.0"))  # seconds to accumulate tasks before dispatching (enables bundling)

    @property
    def tick_period(self) -> float:
        return 1.0 / self.tick_hz
