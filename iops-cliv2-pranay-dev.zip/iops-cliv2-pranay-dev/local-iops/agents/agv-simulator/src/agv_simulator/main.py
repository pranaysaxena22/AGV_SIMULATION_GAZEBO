"""Entrypoint: builds the realtime SimPy environment and runs the fleet."""
from __future__ import annotations

import argparse
import logging
import random
import sys
import time

import simpy.rt

from .agv import AGV, PARKING_BAYS, Stop, Trip
from .command_bridge import CommandBridge
from .config import Config
from .dispatcher_smart import SmartDispatcher
from .fleet import battery_ticker, build_fleet, telemetry_ticker
from .graph import load_floor
from .persistence import PersistenceWorker
from .routing import precompute_all_pairs
from .scenarios import get_scenario, get_seed
from .tasks import TaskGenerator
from .telemetry import (
    CHANNEL_TRIP_COMPLETED,
    CHANNEL_TRIP_INTERRUPTED,
    CHANNEL_TRIP_STOP_DONE,
    TelemetryPublisher,
)
from .traffic import TrafficManager

log = logging.getLogger("agv-simulator")


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    parser = argparse.ArgumentParser(prog="agv-sim")
    parser.add_argument("--count", type=int, default=None, help="number of AGVs (default: cfg.fleet_size)")
    parser.add_argument("--runtime", type=float, default=None, help="seconds; overrides RUNTIME_S")
    parser.add_argument("--scenario", type=str, default=None, help="normal | rush_hour")
    parser.add_argument("--no-persistence", action="store_true", help="disable Mongo writer")
    args = parser.parse_args(argv)

    cfg = Config()
    scenario = get_scenario(args.scenario)
    seed = get_seed()
    rng = random.Random(seed)
    log.info("scenario=%s lambda=%.2f seed=%d", scenario.name, scenario.lam, seed)

    runtime_s = (
        args.runtime
        if args.runtime is not None
        else (scenario.duration_s if scenario.duration_s > 0 else cfg.runtime_s)
    )
    fleet_size = args.count if args.count is not None else cfg.fleet_size

    g, coords = load_floor(cfg.layout_path)
    if scenario.blocked_edge:
        a, b = scenario.blocked_edge
        if g.has_edge(a, b):
            g.remove_edge(a, b)
            log.info("scenario blocked aisle: removed edge %s-%s", a, b)
        else:
            log.warning("scenario blocked aisle: edge %s-%s not in graph", a, b)
    routing = precompute_all_pairs(g)
    log.info("loaded floor: %d nodes, %d edges", g.number_of_nodes(), g.number_of_edges())

    env = simpy.rt.RealtimeEnvironment(factor=1.0, strict=False)
    publisher = TelemetryPublisher(cfg)

    traffic = TrafficManager(
        env,
        deadlock_timeout=cfg.deadlock_timeout,
        on_blocked=publisher.publish_event,
        on_resumed=publisher.publish_event,
    )

    def _on_state_change(agv) -> None:
        try:
            publisher.publish_state(agv)
        except Exception:
            pass

    # Late-bound dispatcher reference for trip-complete callback.
    dispatcher_ref: dict[str, SmartDispatcher] = {}

    def _on_stop_done(agv: AGV, trip_id: str, station_id: str, op: str) -> None:
        try:
            publisher.publish_event(
                CHANNEL_TRIP_STOP_DONE,
                {"trip_id": trip_id, "agv_id": agv.agv_id, "station_id": station_id, "op": op, "ts": time.time()},
            )
        except Exception:
            pass
        if op == "drop":
            d = dispatcher_ref.get("d")
            if d is not None:
                tasks = d.tasks_by_trip.get(trip_id) or []
                remaining = [t for t in tasks if t.drop != station_id]
                if remaining:
                    d.tasks_by_trip[trip_id] = remaining
                else:
                    d.tasks_by_trip.pop(trip_id, None)

    def _on_trip_complete(agv: AGV, trip_id: str, kpis: dict, stops: list) -> None:
        d = dispatcher_ref.get("d")
        tasks = d.all_tasks_by_trip.pop(trip_id, []) if d else []
        if d:
            d.tasks_by_trip.pop(trip_id, None)
        try:
            mat = tasks[0].material_type if tasks else None
            payload = {
                "trip_id": trip_id,
                "agv_id": agv.agv_id,
                "kpis": kpis,
                "task_ids": [t.task_id for t in tasks],
                "bundled": len(tasks),
                "material_type": mat,
                "stops": [
                    {"station_id": s.station_id, "op": s.op, "units": s.units}
                    for s in stops
                ],
                "ts": time.time(),
            }
            publisher.publish_event(CHANNEL_TRIP_COMPLETED, payload)
        except Exception:
            pass

    def _on_trip_interrupted(agv: AGV, trip_id: str, remaining_trip) -> None:
        d = dispatcher_ref.get("d")
        tasks = list(d.tasks_by_trip.get(trip_id, []) or d.all_tasks_by_trip.get(trip_id, [])) if d else []
        try:
            payload = {
                "trip_id": trip_id,
                "agv_id": agv.agv_id,
                "task_ids": [t.task_id for t in tasks],
                "remaining_stops": [
                    {"station_id": s.station_id, "op": s.op, "units": s.units}
                    for s in remaining_trip.stops
                ],
                "payload_count": agv.payload_count,
                "ts": time.time(),
            }
            publisher.publish_event(CHANNEL_TRIP_INTERRUPTED, payload)
        except Exception:
            pass

    fleet = build_fleet(
        env, cfg, routing, coords, count=fleet_size,
        traffic=traffic, graph=g,
        on_state_change=_on_state_change,
        on_stop_done=_on_stop_done,
        on_trip_complete=_on_trip_complete,
        on_trip_interrupted=_on_trip_interrupted,
    )
    # Priority function for deadlock resolution: AGVs carrying payload or
    # actively on a task outrank empty / parking-bound AGVs. Higher = wins.
    _fleet_by_id = {a.agv_id: a for a in fleet.agvs}
    def _priority_for(agv_id: str) -> int:
        a = _fleet_by_id.get(agv_id)
        if a is None:
            return 0
        score = 0
        if getattr(a, "payload_count", 0) > 0:
            score += 10
        if getattr(a, "current_trip", None) is not None:
            score += 5
        if getattr(a, "current_node", None) in PARKING_BAYS:
            score -= 3
        return score
    traffic._priority_fn = _priority_for

    env.process(telemetry_ticker(env, cfg, fleet, publisher))
    env.process(battery_ticker(env, cfg, fleet))

    persistence: PersistenceWorker | None = None
    if cfg.persistence_enabled and not args.no_persistence:
        persistence = PersistenceWorker(cfg)
        persistence.start()
        log.info("persistence worker started")

    station_ids = sorted(n for n in coords if n.startswith("S"))

    stations_by_role: dict[str, list[str]] = {}
    for sid in station_ids:
        attrs = g.nodes[sid]
        role = attrs.get("role")
        if role:
            stations_by_role.setdefault(role, []).append(sid)
    if stations_by_role:
        log.info("station roles loaded: %s", sorted(stations_by_role.keys()))

    dispatcher = SmartDispatcher(env, publisher, fleet.agvs, coords, routing, cfg)
    dispatcher._stations_by_role = stations_by_role
    dispatcher_ref["d"] = dispatcher
    env.process(dispatcher.run())

    import os as _os
    if _os.getenv("DISABLE_TASK_GENERATOR", "0") in ("1", "true", "True"):
        log.info("task generator disabled (DISABLE_TASK_GENERATOR=1) — chatbot only")
    else:
        generator = TaskGenerator(
            env=env,
            publisher=publisher,
            stations=station_ids,
            lam=scenario.lam,
            rng=rng,
            on_task=dispatcher.submit,
            stations_by_role=stations_by_role,
            product_mix=list(scenario.product_mix) if scenario.product_mix else None,
            failure_rate=scenario.failure_rate,
            disabled_role=scenario.disabled_role,
            starved_roles=scenario.starved_roles,
        )
        env.process(generator.run())

    bridge = CommandBridge(
        cfg=cfg,
        fleet=fleet.agvs,
        stations_by_role=stations_by_role,
        submit_task=dispatcher.submit,
        publisher=publisher,
        routing=routing,
        coords=coords,
        graph=g,
        dispatcher=dispatcher,
    )
    bridge.start()

    # Wire eviction callback: when an AGV's destination is held by an
    # empty parked/idle peer, ask the bridge to evict the peer off it.
    def _on_eviction_request(requester: AGV, blocked_node: str) -> None:
        try:
            bridge.evict_holder(requester, blocked_node)
        except Exception as exc:
            log.warning("eviction request failed: %s", exc)
    for a in fleet.agvs:
        a.on_eviction_request = _on_eviction_request

    # Reservation provider: union of planned-path nodes for every higher-
    # priority peer (one carrying payload / on a real task). Lets a lower-
    # priority AGV (e.g. an idle one heading to a parking bay) plan a route
    # that stays OUT of corridors the busy AGV needs, instead of marching
    # into them and then unwinding via deadlock detection.
    def _reservations_for(asking: AGV) -> set[str]:
        my_p = _priority_for(asking.agv_id)
        out: set[str] = set()
        for peer in fleet.agvs:
            if peer.agv_id == asking.agv_id:
                continue
            if _priority_for(peer.agv_id) <= my_p:
                continue
            try:
                out.update(peer.planned_path_nodes())
            except Exception:
                pass
        return out
    for a in fleet.agvs:
        a.reservation_provider = _reservations_for

    log.info("running for %.1fs at %.1f Hz with %d AGVs", runtime_s, cfg.tick_hz, fleet_size)
    try:
        if runtime_s > 0:
            env.run(until=runtime_s)
        else:
            env.run()
    except KeyboardInterrupt:
        log.info("interrupted")
    finally:
        bridge.stop()
        if persistence is not None:
            persistence.stop()
        publisher.close()
    log.info("done")
    return 0


if __name__ == "__main__":
    sys.exit(main())
