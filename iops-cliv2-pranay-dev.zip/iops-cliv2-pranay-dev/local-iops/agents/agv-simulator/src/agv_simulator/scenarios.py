"""Scenario configuration loader (PCB-realistic).

Each scenario tunes the task generator + traffic model. Selected via
`SCENARIO` env var or `--scenario` CLI flag.

PCB-realistic flags
-------------------
- `failure_rate`           — fraction of AOI/ICT boards diverted to rework.
- `product_mix`            — override (product_id, weight) list.
- `disabled_role`          — role temporarily out-of-service (e.g. reflow).
- `starved_roles`          — replenishment to these roles is paused.
- `blocked_edge`           — (node_a, node_b) marked as blocked aisle.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class Scenario:
    name: str
    lam: float                                    # Poisson arrival rate (tasks/sec)
    duration_s: float                             # 0 = run forever
    failure_rate: float = 0.05                    # board failure at AOI/ICT
    product_mix: Optional[tuple[tuple[str, float], ...]] = None
    disabled_role: Optional[str] = None           # e.g. "reflow"
    starved_roles: tuple[str, ...] = field(default_factory=tuple)
    blocked_edge: Optional[tuple[str, str]] = None


SCENARIOS: dict[str, Scenario] = {
    "normal": Scenario(
        name="normal", lam=0.2, duration_s=0.0,
    ),
    "rush_hour": Scenario(
        name="rush_hour", lam=1.0, duration_s=0.0,
    ),
    "reflow_downtime": Scenario(
        name="reflow_downtime", lam=0.6, duration_s=0.0,
        disabled_role="reflow",
    ),
    "blocked_aisle": Scenario(
        name="blocked_aisle", lam=0.5, duration_s=0.0,
        blocked_edge=("WP3", "WP4"),
    ),
    "quality_spike": Scenario(
        name="quality_spike", lam=0.5, duration_s=0.0,
        failure_rate=0.30,
    ),
    "material_starvation": Scenario(
        name="material_starvation", lam=0.5, duration_s=0.0,
        starved_roles=("smt_feeder", "paste_print"),
    ),
    "automotive_rush_reflow_down": Scenario(
        name="automotive_rush_reflow_down", lam=1.0, duration_s=0.0,
        product_mix=(("pcb_automotive", 0.7), ("pcb_industrial", 0.2), ("pcb_consumer", 0.1)),
        disabled_role="reflow",
        failure_rate=0.10,
    ),
}


def get_scenario(name: str | None = None) -> Scenario:
    key = (name or os.getenv("SCENARIO", "normal")).lower()
    return SCENARIOS.get(key, SCENARIOS["normal"])


def get_seed() -> int:
    return int(os.getenv("RANDOM_SEED", "42"))
