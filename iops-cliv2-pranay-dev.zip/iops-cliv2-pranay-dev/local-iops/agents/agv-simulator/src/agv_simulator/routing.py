"""All-pairs shortest path precomputation.

For ~54 nodes the all-pairs Dijkstra runs in microseconds and gives O(1)
lookups during the simulation tick.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import networkx as nx


@dataclass(frozen=True)
class RoutingTable:
    paths: dict[str, dict[str, list[str]]]
    lengths: dict[str, dict[str, float]]

    def shortest_path(self, src: str, dst: str) -> list[str]:
        try:
            return self.paths[src][dst]
        except KeyError as e:
            raise KeyError(f"no path {src}->{dst}") from e

    def distance(self, src: str, dst: str) -> float:
        try:
            return self.lengths[src][dst]
        except KeyError as e:
            raise KeyError(f"no distance {src}->{dst}") from e

    def total_distance(self, route: Iterable[str]) -> float:
        nodes = list(route)
        return sum(self.distance(a, b) for a, b in zip(nodes, nodes[1:]))


def precompute_all_pairs(g: nx.Graph) -> RoutingTable:
    """Run all-pairs Dijkstra and bundle path + length lookups."""
    paths = dict(nx.all_pairs_dijkstra_path(g, weight="weight"))
    lengths = dict(nx.all_pairs_dijkstra_path_length(g, weight="weight"))
    return RoutingTable(paths=paths, lengths=lengths)
