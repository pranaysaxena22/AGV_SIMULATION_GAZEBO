"""Redis command bridge: turns chatbot:* commands into simulator actions.

Channels (subscribe):
  chatbot:create_task   {product, units?, priority?, pickup_role?, drop_role?}
  chatbot:send_to       {agv_id, station_id_or_role}
  chatbot:recall_agv    {agv_id}
  chatbot:pause_agv     {agv_id}
  chatbot:resume_agv    {agv_id}
  chatbot:query         {request_id, kind: fleet|tasks|batch, batch_id?}

Replies (publish):
  chatbot:reply         {request_id, ok, data?, error?}
"""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from typing import Callable, Optional

import networkx as nx
import redis

from .agv import AGV, Stop, Trip
from .config import Config
from .routing import RoutingTable
from .telemetry import (
    CHANNEL_TASK_ASSIGNED,
    CHANNEL_TASK_CANCELLED,
    CHANNEL_TASK_CREATED,
    CHANNEL_TRIP_COMPLETED,
    CHANNEL_TRIP_REQUESTED,
    CHANNEL_TRIP_RESUMED,
    TelemetryPublisher,
)
from .tasks import (
    PRODUCT_PRIORITY,
    PRODUCT_ROUTES,
    SLA_BY_PRIORITY,
    Task,
    _material_for_stage,
)

log = logging.getLogger("agv-simulator.bridge")

CHANNELS = (
    "chatbot:create_task",
    "chatbot:multi_drop_trip",
    "chatbot:multi_pair_trip",
    "chatbot:send_to",
    "chatbot:recall_agv",
    "chatbot:pause_agv",
    "chatbot:resume_agv",
    "chatbot:query",
    "chatbot:analyze_dispatch",
    "chatbot:emergency_stop",
    "chatbot:cancel_trip",
    "chatbot:reroute",
    "chatbot:complete_interrupted",
    "chatbot:list_interrupted",
    "chatbot:recall_low_battery",
    "chatbot:cancel_pending_task",
    "chatbot:list_pending_tasks",
    "chatbot:unblock_agv",
)
REPLY_CHANNEL = "chatbot:reply"


class CommandBridge:
    def __init__(
        self,
        cfg: Config,
        fleet: list[AGV],
        stations_by_role: dict[str, list[str]],
        submit_task: Callable[[Task], None],
        publisher: Optional[TelemetryPublisher] = None,
        routing: Optional[RoutingTable] = None,
        coords: Optional[dict[str, tuple[float, float]]] = None,
        graph: Optional[nx.Graph] = None,
        client: Optional[redis.Redis] = None,
        dispatcher=None,
    ) -> None:
        self.cfg = cfg
        self.fleet = fleet
        self.stations_by_role = stations_by_role
        self.submit_task = submit_task
        self.publisher = publisher
        self.routing = routing
        self.coords = coords or {}
        self.graph = graph
        self.dispatcher = dispatcher
        self.client = client or redis.Redis(
            host=cfg.redis_host,
            port=cfg.redis_port,
            password=cfg.redis_password or None,
            decode_responses=True,
        )
        self._paused: set[str] = set()
        self._evicted_at: dict[str, float] = {}
        self._thread: Optional[threading.Thread] = None
        self._auto_recall_thread: Optional[threading.Thread] = None
        self._charge_resume_thread: Optional[threading.Thread] = None
        # Tasks queued because their target AGV was below auto_recall_threshold.
        # Each entry: {"agv_id": str, "channel": str, "payload": dict, "ts": float, "summary": str}
        self._charge_pending: list[dict] = []
        self._charge_pending_lock = threading.Lock()
        self._stop = threading.Event()
        # Short-lived claims set when a trip is submitted to an AGV before its
        # current_trip is observed. Closes the race window where two back-to-back
        # chatbot tasks would both target the same idle AGV. Entry value is a
        # monotonic timestamp; cleared when the AGV's current_trip is set or
        # after _CLAIM_TTL_S elapses.
        self._claims: dict[str, float] = {}
        self._claims_lock = threading.Lock()
        # Running totals fed by trip:completed / task:created so chatbot can
        # answer "how many tasks are completed/pending/in-transit" without
        # hallucinating. completed counts distinct task_ids actually finished.
        self._completed_task_ids: set[str] = set()
        self._completed_trip_ids: set[str] = set()
        self._completed_lock = threading.Lock()
        self._stats_thread: Optional[threading.Thread] = None
        self._mongo_tasks = None
        try:
            from pymongo import MongoClient
            mc = MongoClient(cfg.mongo_uri, serverSelectionTimeoutMS=1500)
            self._mongo_tasks = mc["agv_poc"]["agv_tasks"]
        except Exception as exc:
            log.info("command bridge mongo init skipped: %s", exc)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, name="cmd-bridge", daemon=True)
        self._thread.start()
        log.info("command bridge subscribed: %s", ", ".join(CHANNELS))
        self._auto_recall_thread = threading.Thread(
            target=self._auto_recall_loop, name="auto-recall", daemon=True
        )
        self._auto_recall_thread.start()
        log.info(
            "auto-recall enabled: threshold=%.1f%% interval=%.1fs",
            self.cfg.auto_recall_threshold, self.cfg.auto_recall_interval_s,
        )
        self._charge_resume_thread = threading.Thread(
            target=self._charge_resume_loop, name="charge-resume", daemon=True
        )
        self._charge_resume_thread.start()
        log.info(
            "charge-resume watcher enabled: resume at >=%.1f%% battery",
            self.cfg.charge_resume_threshold,
        )
        self._stats_thread = threading.Thread(
            target=self._stats_loop, name="cmd-bridge-stats", daemon=True
        )
        self._stats_thread.start()

    def _stats_loop(self) -> None:
        """Listen on trip:completed and accumulate distinct completed task_ids
        so the chatbot can report scheduler counts accurately."""
        try:
            ps = self.client.pubsub(ignore_subscribe_messages=True)
            ps.subscribe("trip:completed")
        except Exception as exc:
            log.warning("stats loop subscribe failed: %s", exc)
            return
        for msg in ps.listen():
            if self._stop.is_set():
                break
            if msg.get("type") != "message":
                continue
            try:
                data = json.loads(msg["data"])
            except Exception:
                continue
            ids: list[str] = []
            if isinstance(data.get("task_ids"), list):
                ids.extend([t for t in data["task_ids"] if t])
            if data.get("task_id"):
                ids.append(data["task_id"])
            trip_id = data.get("trip_id")
            # Skip synthetic park/eviction trips so they don't inflate the
            # completed total — the UI also excludes pure relocations.
            if isinstance(trip_id, str) and trip_id.startswith(("TR-PARK", "TR-EVICT")):
                continue
            with self._completed_lock:
                if ids:
                    self._completed_task_ids.update(ids)
                if trip_id:
                    self._completed_trip_ids.add(trip_id)

    def _charge_resume_loop(self) -> None:
        """When an AGV that has tasks queued behind a charging hold reaches
        the resume threshold, replay those commands."""
        resume_pct = self.cfg.charge_resume_threshold
        interval = max(1.0, self.cfg.auto_recall_interval_s)
        while not self._stop.is_set():
            if self._stop.wait(interval):
                break
            try:
                with self._charge_pending_lock:
                    pending = list(self._charge_pending)
                if not pending:
                    continue
                ready: list[dict] = []
                still_waiting: list[dict] = []
                for entry in pending:
                    agv = self._agv_by_id(entry["agv_id"])
                    if agv is None:
                        still_waiting.append(entry)
                        continue
                    if agv.battery_pct >= resume_pct and agv.state in ("idle", "charging"):
                        ready.append(entry)
                    else:
                        still_waiting.append(entry)
                if ready:
                    with self._charge_pending_lock:
                        # Replace queue with the still-waiting subset.
                        self._charge_pending = still_waiting
                    for entry in ready:
                        log.info(
                            "charge-resume: %s reached %.1f%% — replaying queued %s",
                            entry["agv_id"],
                            self._agv_by_id(entry["agv_id"]).battery_pct if self._agv_by_id(entry["agv_id"]) else 0.0,
                            entry["channel"],
                        )
                        try:
                            self._handle(entry["channel"], entry["payload"])
                        except Exception as exc:
                            log.warning("charge-resume replay failed: %s", exc)
            except Exception as exc:
                log.warning("charge-resume loop error: %s", exc)

    def _auto_recall_loop(self) -> None:
        """Periodically recall idle/depleted AGVs at or below the auto-recall
        threshold to charging bays. Also parks idle AGVs that have been idle
        longer than idle_park_timeout_s."""
        import time as _time

        bays = {"H01", "H02", "H03"}
        park_zones = {"H01", "H02", "H03", "W34", "W38"}
        threshold = self.cfg.auto_recall_threshold
        idle_timeout = self.cfg.idle_park_timeout_s
        interval = max(1.0, self.cfg.auto_recall_interval_s)
        while not self._stop.is_set():
            if self._stop.wait(interval):
                break
            try:
                # Low-battery recall (existing behavior)
                low_battery = [
                    a for a in self.fleet
                    if a.current_node not in bays
                    and a.state in ("idle", "depleted")
                    and not self.is_paused(a.agv_id)
                    and (a.battery_pct <= threshold or a.state == "depleted")
                ]
                if low_battery:
                    ids = [f"{a.agv_id}({a.battery_pct:.0f}%)" for a in low_battery]
                    log.info("auto-recall sweep: %d low-battery candidate(s) %s", len(low_battery), ", ".join(ids))
                    self._cmd_recall_low_battery({
                        "count": len(low_battery),
                        "threshold": threshold,
                    })

                # Idle-park: recall AGVs idle longer than timeout
                now = _time.time()
                # Backfill idle_since for any AGV that's idle but missing the
                # timestamp (e.g. trip aborted via estop where the state
                # transition didn't reset the marker). Without this, an AGV
                # stranded mid-aisle after an abort never auto-parks.
                for a in self.fleet:
                    if (a.state == "idle"
                            and a.idle_since is None
                            and getattr(a, "current_trip", None) is None
                            and not list(a.cmd_queue.items)):
                        a.idle_since = now
                def _on_park_trip(a) -> bool:
                    t = getattr(a, "current_trip", None)
                    if t and t.trip_id and str(t.trip_id).startswith(("TR-PARK", "TR-EVICT")):
                        return True
                    try:
                        for q in list(a.cmd_queue.items):
                            tid = getattr(q, "trip_id", "")
                            if tid and str(tid).startswith(("TR-PARK", "TR-EVICT")):
                                return True
                    except Exception:
                        pass
                    return False
                EVICT_COOLDOWN_S = 30.0
                idle_park = [
                    a for a in self.fleet
                    if a.current_node not in park_zones
                    and a.state == "idle"
                    and not self.is_paused(a.agv_id)
                    and a.idle_since is not None
                    and (now - a.idle_since) > idle_timeout
                    and a not in low_battery
                    and not _on_park_trip(a)
                    and getattr(a, "current_trip", None) is None
                    and not list(a.cmd_queue.items)
                    and (now - self._evicted_at.get(a.agv_id, 0)) > EVICT_COOLDOWN_S
                ]
                if idle_park:
                    ids = [f"{a.agv_id}(idle {now - a.idle_since:.0f}s)" for a in idle_park]
                    log.info("auto-park sweep: %d idle candidate(s) %s", len(idle_park), ", ".join(ids))
                    self._recall_idle_to_bay(idle_park)

                # Home-bay eviction safety net: if AGV-X is heading toward
                # its home bay and AGV-Y (non-owner) is squatting on it,
                # evict AGV-Y to a different free bay/staging spot. This
                # breaks the home-bay deadlock where the rightful owner
                # would otherwise block waiting on a peer's idle position.
                self._evict_home_bay_squatters()
            except Exception as exc:
                log.warning("auto-recall sweep error: %s", exc)

    def stop(self) -> None:
        self._stop.set()

    def is_paused(self, agv_id: str) -> bool:
        return agv_id in self._paused

    def _run(self) -> None:
        pubsub = self.client.pubsub(ignore_subscribe_messages=True)
        pubsub.subscribe(*CHANNELS)
        for msg in pubsub.listen():
            if self._stop.is_set():
                break
            try:
                self._handle(msg["channel"], json.loads(msg["data"]))
            except Exception as exc:
                log.warning("command bridge error on %s: %s", msg.get("channel"), exc)

    def _handle(self, channel: str, payload: dict) -> None:
        if channel == "chatbot:create_task":
            self._cmd_create_task(payload)
        elif channel == "chatbot:multi_drop_trip":
            self._cmd_multi_drop_trip(payload)
        elif channel == "chatbot:multi_pair_trip":
            self._cmd_multi_pair_trip(payload)
        elif channel == "chatbot:send_to":
            self._cmd_send_to(payload)
        elif channel == "chatbot:recall_agv":
            self._cmd_recall(payload)
        elif channel == "chatbot:pause_agv":
            self._paused.add(payload.get("agv_id", ""))
            self._reply(payload.get("request_id"), True, {"paused": payload.get("agv_id")})
        elif channel == "chatbot:resume_agv":
            self._cmd_resume(payload)
        elif channel == "chatbot:query":
            self._cmd_query(payload)
        elif channel == "chatbot:analyze_dispatch":
            self._cmd_analyze_dispatch(payload)
        elif channel == "chatbot:emergency_stop":
            self._cmd_emergency_stop(payload)
        elif channel == "chatbot:cancel_trip":
            self._cmd_cancel_trip(payload)
        elif channel == "chatbot:reroute":
            self._cmd_reroute(payload)
        elif channel == "chatbot:complete_interrupted":
            self._cmd_complete_interrupted(payload)
        elif channel == "chatbot:list_interrupted":
            self._cmd_list_interrupted(payload)
        elif channel == "chatbot:recall_low_battery":
            self._cmd_recall_low_battery(payload)
        elif channel == "chatbot:cancel_pending_task":
            self._cmd_cancel_pending_task(payload)
        elif channel == "chatbot:list_pending_tasks":
            self._cmd_list_pending_tasks(payload)
        elif channel == "chatbot:unblock_agv":
            self._cmd_unblock_agv(payload)

    def _resolve_station(self, station_or_role: str) -> Optional[str]:
        if station_or_role in self.stations_by_role:
            stations = self.stations_by_role.get(station_or_role) or []
            return stations[0] if stations else None
        return station_or_role  # treat as raw station id

    def _nearest_non_bay_node(self, agv: AGV) -> Optional[str]:
        """Pick a graph-adjacent non-bay node for evicting `agv` from a bay."""
        bays = {"H01", "H02", "H03"}
        node = agv.current_node
        if node is None or self.graph is None:
            return None
        try:
            neighbours = list(self.graph.neighbors(node))
        except Exception:
            return None
        candidates = [n for n in neighbours if n not in bays]
        if not candidates:
            return None
        # Pick the first non-bay neighbour not currently occupied by another AGV.
        occupied = {a.current_node for a in self.fleet if a.agv_id != agv.agv_id}
        for n in candidates:
            if n not in occupied:
                return n
        return candidates[0]

    def _agv_by_id(self, agv_id: str) -> Optional[AGV]:
        for a in self.fleet:
            if a.agv_id == agv_id:
                return a
        return None

    def _busy_preempt_error(self, agv: AGV, p: dict) -> Optional[str]:
        """Return an error message if the AGV is mid-trip and the caller did
        not pass force=true. Used to refuse silent priority-overrides that
        hijack an AGV already working on a task.
        """
        if bool(p.get("force") or p.get("override") or p.get("force_override")):
            return None
        queued = len(list(agv.cmd_queue.items))
        if agv.current_trip is None and queued == 0:
            return None
        if agv.current_trip is None and queued > 0:
            return (
                f"{agv.agv_id} already has {queued} queued trip(s). "
                "Pick another AGV or resend with force=true to override."
            )
        if agv.state in ("idle", "charging", "parked", "depleted") and queued == 0:
            return None
        try:
            remaining = [
                f"{s.op}@{s.station_id}"
                for s in agv.current_trip.stops[agv.current_stop_idx:]
            ] if agv.current_trip else []
        except Exception:
            remaining = []
        return (
            f"{agv.agv_id} is busy on trip {agv.trip_id} "
            f"(state={agv.state}, payload={agv.payload_count}, "
            f"remaining stops: {', '.join(remaining) or 'n/a'}). "
            "Refusing to preempt — pick another AGV, or resend with "
            "force=true to interrupt the current trip."
        )

    _CLAIM_TTL_S: float = 5.0

    def _claim_agv(self, agv_id: str) -> None:
        import time as _t
        with self._claims_lock:
            self._claims[agv_id] = _t.monotonic()

    def _release_claim(self, agv_id: str) -> None:
        with self._claims_lock:
            self._claims.pop(agv_id, None)

    def _active_claims(self) -> set[str]:
        import time as _t
        now = _t.monotonic()
        active: set[str] = set()
        stale: list[str] = []
        with self._claims_lock:
            for aid, ts in self._claims.items():
                if now - ts > self._CLAIM_TTL_S:
                    stale.append(aid)
                else:
                    active.add(aid)
            for aid in stale:
                self._claims.pop(aid, None)
        # Drop claims for AGVs whose current_trip is now set — claim served its purpose.
        for a in self.fleet:
            if a.agv_id in active and a.current_trip is not None:
                self._release_claim(a.agv_id)
                active.discard(a.agv_id)
        return active

    def _pick_best_agv(self, pickup: str, num_drops: int) -> Optional[AGV]:
        """Pick the lowest-cost idle AGV with enough capacity for `num_drops`.

        Cost = distance(current_node -> pickup) + congestion penalty if the
        candidate's current node is on another AGV's planned route.
        """
        # Exclude AGVs already reserved by pending tasks in the dispatcher
        # queue so chatbot tasks don't claim an AGV the seed pipeline has
        # already promised to a queued row.
        reserved_ids: set[str] = set()
        if self.dispatcher is not None:
            try:
                for t in self.dispatcher.pending:
                    rid = getattr(t, "reserved_agv_id", None)
                    if rid:
                        reserved_ids.add(rid)
            except Exception:
                pass
            # Also exclude AGVs already targeted by an outstanding chatbot trip
            # (provisional/deferred or freshly submitted). The chatbot stamps
            # `reserved_agv_id` on tasks it stores in `all_tasks_by_trip`.
            try:
                active_trip_ids = {a.trip_id for a in self.fleet if a.trip_id}
                for tid, tasks in self.dispatcher.all_tasks_by_trip.items():
                    for t in tasks:
                        rid = getattr(t, "reserved_agv_id", None)
                        if not rid:
                            continue
                        # Only count trips that haven't completed yet — a trip
                        # is "outstanding" if it's the AGV's current trip OR
                        # has not yet been started (no AGV runs it).
                        if tid in active_trip_ids or not any(
                            a.trip_id == tid for a in self.fleet
                        ):
                            reserved_ids.add(rid)
            except Exception:
                pass
        # AGVs with any queued/in-flight work — block them outright so a new
        # chatbot trip never coalesces on top of an existing assignment.
        for a in self.fleet:
            if a.current_trip is not None or list(a.cmd_queue.items):
                reserved_ids.add(a.agv_id)
        claimed_ids = self._active_claims()
        candidates = [
            a for a in self.fleet
            if a.state in ("idle", "charging", "parked")
            and not self.is_paused(a.agv_id)
            and a.battery_pct > self.cfg.auto_recall_threshold
            and a.agv_id not in reserved_ids
            and a.agv_id not in claimed_ids
            and not list(a.cmd_queue.items)
            and a.current_trip is None
            and a.payload_count == 0
            and a.interrupted_trip is None
            and not a.interrupted_trips
        ]
        if not candidates:
            return None

        # Build set of nodes other AGVs are currently committed to (origin/dest
        # form a coarse path proxy without re-running shortest_path).
        committed: set[str] = set()
        for a in self.fleet:
            if a.state in ("moving", "blocked"):
                if a.origin_node:
                    committed.add(a.origin_node)
                if a.dest_node:
                    committed.add(a.dest_node)

        def _cost(a: AGV) -> float:
            d = 0.0
            if self.routing is not None:
                try:
                    d = self.routing.distance(a.current_node, pickup)
                except KeyError:
                    d = float("inf")
            penalty = 5.0 if a.current_node in committed else 0.0
            return d + penalty

        return min(candidates, key=_cost)

    # ------------------------------------------------------------------
    def _cmd_create_task(self, p: dict) -> None:
        product = p.get("product") or "pcb_consumer"
        route = PRODUCT_ROUTES.get(product) or PRODUCT_ROUTES["pcb_consumer"]
        pickup_role = p.get("pickup_role") or route[0]
        drop_role = p.get("drop_role") or route[1]
        pickup = self._resolve_station(pickup_role)
        drop = self._resolve_station(drop_role)
        if not pickup or not drop:
            self._reply(p.get("request_id"), False, error=f"no stations for {pickup_role}->{drop_role}")
            return
        priority = p.get("priority") or PRODUCT_PRIORITY.get(product, "normal")
        units = int(p.get("units") or 1)
        if units > 50:
            self._reply(p.get("request_id"), False, error=f"units={units} exceeds AGV max payload capacity of 50")
            return
        now = time.time()
        task = Task(
            task_id=f"T-{uuid.uuid4().hex[:8]}",
            pickup=pickup,
            drop=drop,
            priority=priority,
            sla=now + SLA_BY_PRIORITY.get(priority, 180.0),
            created_ts=now,
            product_id=product,
            batch_id=f"B-CHAT-{uuid.uuid4().hex[:5]}",
            stage_from=pickup_role,
            stage_to=drop_role,
            units=units,
            material_type=_material_for_stage(pickup_role, drop_role),
        )
        self.submit_task(task)
        if self.publisher is not None:
            try:
                self.publisher.publish_event(CHANNEL_TASK_CREATED, task.to_event())
            except Exception as exc:
                log.warning("publish task:created failed: %s", exc)
        log.info("chatbot create_task: %s %s->%s units=%d pri=%s", product, pickup, drop, units, priority)
        self._reply(p.get("request_id"), True, {"task_id": task.task_id, "batch_id": task.batch_id, "pickup": pickup, "drop": drop})

    # ------------------------------------------------------------------
    def _cmd_multi_drop_trip(self, p: dict) -> None:
        """Build a single multi-stop trip: 1 pickup -> N drops, dispatched
        directly to a chosen AGV. Drop order is greedily optimised by
        precomputed Dijkstra distance from the pickup, then nearest-neighbour.
        Emits one task:created + task:assigned per drop so the queue UI
        reflects the bundle.
        """
        agv_id = p.get("agv_id", "")
        pickup_in = p.get("pickup") or p.get("pickup_role") or ""
        pickup = self._resolve_station(pickup_in)
        drops_in = p.get("drops") or []
        if not pickup or not drops_in:
            self._reply(p.get("request_id"), False, error="pickup and drops are required")
            return

        # Auto-select best idle AGV: lowest cost = distance(curr->pickup) +
        # penalty if AGV's current node sits on any other AGV's planned path.
        # Honor _pinned_agv_id from deferred retries so the AGV reported in
        # the queued reply matches the AGV that actually executes.
        pinned = p.get("_pinned_agv_id")
        if pinned:
            agv = self._agv_by_id(pinned)
            if not agv:
                self._reply(p.get("request_id"), False, error=f"agv {pinned} not found")
                return
            agv_id = pinned
        elif not agv_id or agv_id.lower() == "auto":
            agv = self._pick_best_agv(pickup, len(drops_in))
            if not agv:
                self._reply(
                    p.get("request_id"), False,
                    error="no idle AGV with capacity available — all are busy or full",
                )
                return
            agv_id = agv.agv_id
        else:
            agv = self._agv_by_id(agv_id)
            if not agv:
                self._reply(p.get("request_id"), False, error=f"agv {agv_id} not found")
                return
            err = self._battery_gate(agv)
            if err:
                self._reply(p.get("request_id"), False, error=err)
                return
            busy_err = self._busy_preempt_error(agv, p)
            if busy_err:
                self._reply(p.get("request_id"), False, error=busy_err)
                return

        # Charge-first gate: if the AGV is at or below the auto-recall
        # threshold, defer this trip until it has charged. Skip on deferred
        # retries to avoid double-queueing.
        if not p.get("_deferred") and not p.get("_charge_resumed") and self._needs_charge_first(agv):
            payload_replay = dict(p)
            payload_replay["_charge_resumed"] = True
            summary = (
                f"{agv.agv_id} battery is {agv.battery_pct:.1f}% — needs to charge first. "
                f"Trip queued; will start automatically once {agv.agv_id} reaches "
                f"{self.cfg.charge_resume_threshold:.0f}%."
            )
            data = self._queue_until_charged(agv, "chatbot:multi_drop_trip", payload_replay, summary)
            self._reply(p.get("request_id"), True, data)
            return

        # Normalise drops: each entry can be "S05" or {"station": "S05", "units": 25}.
        norm_drops: list[dict] = []
        for d in drops_in:
            if isinstance(d, str):
                norm_drops.append({"station": self._resolve_station(d), "units": int(p.get("units_per_drop") or 25)})
            elif isinstance(d, dict):
                station = self._resolve_station(d.get("station") or d.get("station_id") or "")
                norm_drops.append({"station": station, "units": int(d.get("units") or p.get("units_per_drop") or 25)})

        norm_drops = [d for d in norm_drops if d["station"]]
        if not norm_drops:
            self._reply(p.get("request_id"), False, error="no resolvable drop stations")
            return

        # Hard guard: refuse if another AGV is currently parked on, or
        # heading toward, any of our destination stations.
        # Station overlap is never allowed — force has no effect here.
        if True:
            dest_set = {pickup} | {d["station"] for d in norm_drops}
            # On a deferred retry, evict any idle-empty AGV still parked on
            # one of our destinations BEFORE re-checking collisions.
            if p.get("_deferred"):
                evicted = self._evict_idle_blockers(agv, dest_set)
                if evicted:
                    log.info("deferred retry evicted: %s", "; ".join(evicted))
                    # Give the evictee a beat to start moving so the
                    # collision recheck sees its new dest_node.
                    time.sleep(0.5)
            collision = self._station_collisions(agv, dest_set)
            if collision:
                # On retry: don't re-publish provisional rows; just reschedule.
                if p.get("_deferred"):
                    attempt = int(p.get("_defer_attempt") or 1)
                    MAX_ATTEMPTS = 30
                    if attempt >= MAX_ATTEMPTS:
                        log.warning(
                            "multi_drop_trip exceeded %d retry attempts; giving up: %s",
                            MAX_ATTEMPTS, "; ".join(collision),
                        )
                        return
                    delay = min(15.0, max(2.0, self._estimate_clear_seconds(agv, dest_set)))
                    next_payload = dict(p)
                    next_payload["_defer_attempt"] = attempt + 1
                    next_payload["_pinned_agv_id"] = agv.agv_id
                    self._schedule_retry(delay, "chatbot:multi_drop_trip", next_payload)
                    log.info(
                        "multi_drop_trip retry %d/%d in %.1fs due to: %s",
                        attempt + 1, MAX_ATTEMPTS, delay, "; ".join(collision),
                    )
                    return
                # Auto-defer (first attempt): publish provisional rows, pin AGV.
                delay = self._estimate_clear_seconds(agv, dest_set)
                product = p.get("product") or "pcb_consumer"
                priority = p.get("priority") or PRODUCT_PRIORITY.get(product, "normal")
                now = time.time()
                batch_id = f"B-CHAT-{uuid.uuid4().hex[:5]}"
                provisional_task_ids: list[str] = []
                provisional_tasks: list[Task] = []
                # Pre-allocate a provisional trip_id so the UI groups the N
                # provisional task:created events into ONE pending row.
                provisional_trip_id = f"TR-MULTI-{uuid.uuid4().hex[:6]}"
                for d in norm_drops:
                    tid = f"T-{uuid.uuid4().hex[:8]}"
                    provisional_task_ids.append(tid)
                    pt = Task(
                        task_id=tid,
                        pickup=pickup,
                        drop=d["station"],
                        priority=priority,
                        sla=now + SLA_BY_PRIORITY.get(priority, 180.0),
                        created_ts=now,
                        product_id=product,
                        batch_id=batch_id,
                        units=int(d["units"]),
                        trip_id=provisional_trip_id,
                    )
                    setattr(pt, "reserved_agv_id", agv.agv_id)
                    provisional_tasks.append(pt)
                if self.publisher is not None:
                    for t in provisional_tasks:
                        try:
                            self.publisher.publish_event(CHANNEL_TASK_CREATED, t.to_event())
                        except Exception as exc:
                            log.warning("publish provisional task:created failed: %s", exc)
                    # Publish a provisional trip:requested so the UI's
                    # tripsByAgv map is populated and the pending row can
                    # surface the chosen AGV (same as in-transit card).
                    try:
                        total_units = sum(d.get("units", 0) for d in norm_drops)
                        self.publisher.publish_event(
                            CHANNEL_TRIP_REQUESTED,
                            {
                                "trip_id": provisional_trip_id,
                                "agv_id": agv.agv_id,
                                "stops": [
                                    {
                                        "station_id": pickup,
                                        "x": self.coords.get(pickup, (0, 0))[0],
                                        "y": self.coords.get(pickup, (0, 0))[1],
                                        "op": "pickup",
                                        "units": total_units,
                                    },
                                    *[
                                        {
                                            "station_id": d["station"],
                                            "x": self.coords.get(d["station"], (0, 0))[0],
                                            "y": self.coords.get(d["station"], (0, 0))[1],
                                            "op": "drop",
                                            "units": d.get("units", 0),
                                        }
                                        for d in norm_drops
                                    ],
                                ],
                                "bundled_tasks": len(provisional_tasks),
                                "ts": now,
                                "provisional": True,
                            },
                        )
                    except Exception as exc:
                        log.warning("publish provisional trip:requested failed: %s", exc)
                # Pin the AGV across deferred retries so the AGV reported in
                # the queued reply matches the AGV that actually executes.
                deferred = dict(p)
                deferred["_deferred"] = True
                deferred["_pinned_agv_id"] = agv.agv_id
                deferred["_provisional_task_ids"] = provisional_task_ids
                deferred["_provisional_batch_id"] = batch_id
                deferred["_provisional_trip_id"] = provisional_trip_id
                deferred["_defer_attempt"] = 1
                self._schedule_retry(delay, "chatbot:multi_drop_trip", deferred)
                self._reply(
                    p.get("request_id"), True,
                    {
                        "deferred": True,
                        "delay_s": round(delay, 1),
                        "reason": "; ".join(collision),
                        "agv_id": agv.agv_id,
                        "pickup": pickup,
                        "drops": [d["station"] for d in norm_drops],
                        "task_ids": provisional_task_ids,
                    },
                )
                log.info(
                    "deferring multi_drop_trip pinned to %s (%d tasks, est %.1fs to clear): %s",
                    agv.agv_id, len(provisional_tasks), delay, "; ".join(collision),
                )
                return


        # Greedy ordering: nearest-neighbour starting from pickup, using
        # precomputed Dijkstra all-pairs lengths when available.
        ordered: list[dict] = []
        cursor = pickup
        remaining_drops = list(norm_drops)
        while remaining_drops:
            def _dist(d: dict) -> float:
                if self.routing is None:
                    return 0.0
                try:
                    return self.routing.distance(cursor, d["station"])
                except KeyError:
                    return float("inf")
            nxt = min(remaining_drops, key=_dist)
            ordered.append(nxt)
            cursor = nxt["station"]
            remaining_drops.remove(nxt)

        # Build trip: 1 pickup stop (total units), then N drop stops with
        # per-drop units so payload_count reflects actual cargo. Reuse the
        # provisional trip_id from the defer step (if any) so UI rows that
        # were keyed by that trip_id are promoted in place rather than
        # duplicated.
        trip_id = p.get("_provisional_trip_id") or f"TR-MULTI-{uuid.uuid4().hex[:6]}"
        total_units = sum(int(d["units"]) for d in ordered)
        stops: list[Stop] = [Stop(station_id=pickup, op="pickup", units=total_units)]
        for d in ordered:
            stops.append(Stop(station_id=d["station"], op="drop", units=int(d["units"])))
        trip = Trip(trip_id=trip_id, stops=stops)

        # Synthesize one Task per drop so the UI queue can show pending->assigned.
        product = p.get("product") or "pcb_consumer"
        priority = p.get("priority") or PRODUCT_PRIORITY.get(product, "normal")
        now = time.time()
        batch_id = f"B-CHAT-{uuid.uuid4().hex[:5]}"
        tasks: list[Task] = []
        # Reuse provisional task_ids from the defer step so the UI's pending
        # rows are promoted in place (avoid duplicate phantom rows).
        provisional_ids = list(p.get("_provisional_task_ids") or [])
        provisional_batch = p.get("_provisional_batch_id")
        if provisional_batch:
            batch_id = provisional_batch
        # Map drop station -> provisional task_id (best-effort, by index of
        # original drops_in order).
        provisional_by_idx = {
            i: provisional_ids[i] for i in range(min(len(provisional_ids), len(drops_in)))
        }
        # Build a mapping from drop station -> provisional id using the
        # original drops_in order (norm_drops follows that order).
        station_to_provisional: dict[str, str] = {}
        for i, d in enumerate(norm_drops):
            tid = provisional_by_idx.get(i)
            if tid and d.get("station"):
                station_to_provisional.setdefault(d["station"], tid)
        for d in ordered:
            tid = station_to_provisional.pop(d["station"], None) or f"T-{uuid.uuid4().hex[:8]}"
            t = Task(
                task_id=tid,
                pickup=pickup,
                drop=d["station"],
                priority=priority,
                sla=now + SLA_BY_PRIORITY.get(priority, 180.0),
                created_ts=now,
                product_id=product,
                batch_id=batch_id,
                stage_from=None,
                stage_to=None,
                units=int(d["units"]),
                material_type=None,
                assigned_ts=now,
                trip_id=trip_id,
            )
            tasks.append(t)

        # Register tasks with the dispatcher so trip:interrupted events
        # carry the correct task_ids for UI rendering.
        if self.dispatcher is not None:
            try:
                self.dispatcher.tasks_by_trip[trip_id] = tasks
                self.dispatcher.all_tasks_by_trip[trip_id] = list(tasks)
            except Exception:
                pass

        # Dispatch on the chosen AGV. If the AGV is already busy (or has a
        # queued trip), append FIFO so the new trip waits for the current
        # one to finish; only preempt when the AGV is truly idle.
        self._claim_agv(agv.agv_id)
        if agv.current_trip is not None or list(agv.cmd_queue.items):
            agv.submit(trip)
        else:
            agv.submit_priority(trip)

        # Emit telemetry: one task:created + task:assigned per drop, plus
        # a bundled trip:requested so the trip overlay renders correctly.
        if self.publisher is not None:
            try:
                # task:created first so the UI has the task rows. Skip if
                # provisional events were already published at defer time.
                if not provisional_ids:
                    for t in tasks:
                        self.publisher.publish_event(CHANNEL_TASK_CREATED, t.to_event())
                # trip:requested BEFORE task:assigned so the UI's
                # tripsByAgv mapping is populated when assigned arrives
                # — otherwise assigned tasks render as "unknown AGV, 0 stops".
                self.publisher.publish_event(
                    CHANNEL_TRIP_REQUESTED,
                    {
                        "trip_id": trip_id,
                        "agv_id": agv.agv_id,
                        "stops": [
                            {
                                "station_id": s.station_id,
                                "x": self.coords.get(s.station_id, (0, 0))[0],
                                "y": self.coords.get(s.station_id, (0, 0))[1],
                                "op": s.op,
                                "units": s.units,
                            }
                            for s in stops
                        ],
                        "bundled_tasks": len(tasks),
                        "ts": now,
                    },
                )
                for t in tasks:
                    self.publisher.publish_event(
                        CHANNEL_TASK_ASSIGNED,
                        {"task_id": t.task_id, "trip_id": trip_id, "ts": now},
                    )
            except Exception as exc:
                log.warning("publish multi-drop telemetry failed: %s", exc)

        log.info(
            "chatbot multi_drop_trip: %s pickup=%s drops=%s trip=%s",
            agv.agv_id, pickup, [d["station"] for d in ordered], trip_id,
        )
        self._reply(
            p.get("request_id"),
            True,
            {
                "agv_id": agv.agv_id,
                "trip_id": trip_id,
                "pickup": pickup,
                "drops": [d["station"] for d in ordered],
                "task_ids": [t.task_id for t in tasks],
                "batch_id": batch_id,
            },
        )

    def _cmd_multi_pair_trip(self, p: dict) -> None:
        """Build a single multi-pickup, multi-drop trip for ONE AGV.

        Accepts `pairs = [{pickup, drop, units}, ...]`. The simulator orders
        all pickup and drop stops smartly: greedy nearest-neighbour from the
        AGV's current node, but a drop is only eligible AFTER its matching
        pickup has been visited. Total units across all pairs must stay
        within capacity (≤ 50).
        """
        agv_id = p.get("agv_id", "")
        pairs_in = p.get("pairs") or []
        if not pairs_in:
            self._reply(p.get("request_id"), False, error="pairs are required")
            return

        # Normalise pairs.
        pairs: list[dict] = []
        for i, pr in enumerate(pairs_in):
            if not isinstance(pr, dict):
                continue
            pu = self._resolve_station(pr.get("pickup") or pr.get("pickup_station") or "")
            dr = self._resolve_station(pr.get("drop") or pr.get("drop_station") or "")
            units = int(pr.get("units") or p.get("units_per_drop") or 1)
            if not pu or not dr:
                self._reply(p.get("request_id"), False, error=f"pair {i+1}: pickup and drop required")
                return
            pairs.append({"pickup": pu, "drop": dr, "units": units, "idx": i})

        total_units = sum(pr["units"] for pr in pairs)

        # Pick AGV (auto or named). On deferred retries we MUST keep the
        # AGV pinned from the first attempt — otherwise the user sees one
        # AGV in the "queued" reply and a different one when the trip
        # auto-promotes, breaking the UI's pending-row AGV badge.
        pinned = p.get("_pinned_agv_id")
        if pinned:
            agv = self._agv_by_id(pinned)
            if not agv:
                self._reply(p.get("request_id"), False, error=f"agv {pinned} not found")
                return
            agv_id = pinned
        elif not agv_id or agv_id.lower() == "auto":
            # Use first pair's pickup as the heuristic anchor for selection.
            agv = self._pick_best_agv(pairs[0]["pickup"], len(pairs))
            if not agv:
                self._reply(
                    p.get("request_id"), False,
                    error="no idle AGV with capacity available — all are busy or full",
                )
                return
            agv_id = agv.agv_id
        else:
            agv = self._agv_by_id(agv_id)
            if not agv:
                self._reply(p.get("request_id"), False, error=f"agv {agv_id} not found")
                return
            err = self._battery_gate(agv)
            if err:
                self._reply(p.get("request_id"), False, error=err)
                return
            busy_err = self._busy_preempt_error(agv, p)
            if busy_err:
                self._reply(p.get("request_id"), False, error=busy_err)
                return

        # Capacity: total units ≤ AGV payload capacity (50).
        cap = getattr(agv, "capacity", 50) or 50
        # capacity is in DROPS, not units, in this codebase — but the LLM
        # treats the 50 limit as units. Use 50 as a hard unit ceiling.
        if total_units > 50:
            self._reply(
                p.get("request_id"), False,
                error=f"Total units ({total_units}) exceeds AGV max payload capacity of 50.",
            )
            return
        if len(pairs) > cap:
            self._reply(
                p.get("request_id"), False,
                error=f"{agv_id} can handle at most {cap} pairs per trip.",
            )
            return

        # Charge-first gate.
        if not p.get("_deferred") and not p.get("_charge_resumed") and self._needs_charge_first(agv):
            payload_replay = dict(p)
            payload_replay["_charge_resumed"] = True
            summary = (
                f"{agv.agv_id} battery is {agv.battery_pct:.1f}% — needs to charge first. "
                f"Trip queued; will start automatically once {agv.agv_id} reaches "
                f"{self.cfg.charge_resume_threshold:.0f}%."
            )
            data = self._queue_until_charged(agv, "chatbot:multi_pair_trip", payload_replay, summary)
            self._reply(p.get("request_id"), True, data)
            return

        # Station collisions across all stops.
        all_stations = {pr["pickup"] for pr in pairs} | {pr["drop"] for pr in pairs}
        if p.get("_deferred"):
            evicted = self._evict_idle_blockers(agv, all_stations)
            if evicted:
                log.info("multi_pair_trip deferred retry evicted: %s", "; ".join(evicted))
                time.sleep(0.5)
        collision = self._station_collisions(agv, all_stations)
        if collision:
            if not p.get("_deferred"):
                delay = self._estimate_clear_seconds(agv, all_stations)
                deferred = dict(p)
                deferred["_deferred"] = True
                deferred["_pinned_agv_id"] = agv.agv_id
                # Publish provisional task:created events (parity with
                # multi_drop_trip) so the deferred trip surfaces in the UI
                # Pending queue immediately and can be auto-promoted in
                # place when the retry succeeds.
                product = p.get("product") or "pcb_consumer"
                priority = p.get("priority") or PRODUCT_PRIORITY.get(product, "normal")
                now = time.time()
                batch_id = f"B-CHAT-{uuid.uuid4().hex[:5]}"
                provisional_trip_id = f"TR-PAIR-{uuid.uuid4().hex[:6]}"
                provisional_task_ids: list[str] = []
                provisional_tasks: list[Task] = []
                for pr in pairs:
                    tid = f"T-{uuid.uuid4().hex[:8]}"
                    provisional_task_ids.append(tid)
                    pt = Task(
                        task_id=tid,
                        pickup=pr["pickup"],
                        drop=pr["drop"],
                        priority=priority,
                        sla=now + SLA_BY_PRIORITY.get(priority, 180.0),
                        created_ts=now,
                        product_id=product,
                        batch_id=batch_id,
                        units=int(pr.get("units") or 1),
                        trip_id=provisional_trip_id,
                    )
                    setattr(pt, "reserved_agv_id", agv.agv_id)
                    provisional_tasks.append(pt)
                deferred["_provisional_task_ids"] = provisional_task_ids
                deferred["_provisional_batch_id"] = batch_id
                deferred["_provisional_trip_id"] = provisional_trip_id
                deferred["_defer_attempt"] = 1
                if self.publisher is not None:
                    for t in provisional_tasks:
                        try:
                            self.publisher.publish_event(CHANNEL_TASK_CREATED, t.to_event())
                        except Exception as exc:
                            log.warning("publish provisional multi_pair task:created failed: %s", exc)
                    # Compute planned stop order (nearest-neighbor) and publish
                    # provisional trip:requested so UI shows the actual sequence.
                    prov_stops = self._compute_pair_order(agv.current_node, pairs)
                    try:
                        self.publisher.publish_event(
                            CHANNEL_TRIP_REQUESTED,
                            {
                                "trip_id": provisional_trip_id,
                                "agv_id": agv.agv_id,
                                "stops": [
                                    {
                                        "station_id": s["station"],
                                        "x": self.coords.get(s["station"], (0, 0))[0],
                                        "y": self.coords.get(s["station"], (0, 0))[1],
                                        "op": s["step"],
                                    }
                                    for s in prov_stops
                                ],
                                "bundled_tasks": len(pairs),
                                "ts": now,
                                "provisional": True,
                            },
                        )
                    except Exception as exc:
                        log.warning("publish provisional trip:requested failed: %s", exc)
                self._schedule_retry(delay, "chatbot:multi_pair_trip", deferred)
                self._reply(
                    p.get("request_id"), True,
                    {
                        "deferred": True,
                        "delay_s": round(delay, 1),
                        "reason": "; ".join(collision),
                        "agv_id": agv.agv_id,
                        "pairs": pairs,
                        "task_ids": provisional_task_ids,
                    },
                )
                return
            # Still colliding on a deferred retry — keep retrying with capped
            # backoff so the trip auto-dispatches as soon as the blocker
            # clears. Only interrupted trips require manual user action.
            attempt = int(p.get("_defer_attempt") or 1)
            MAX_ATTEMPTS = 30
            if attempt >= MAX_ATTEMPTS:
                log.warning(
                    "multi_pair_trip exceeded %d retry attempts; giving up: %s",
                    MAX_ATTEMPTS, "; ".join(collision),
                )
                return
            delay = min(15.0, max(2.0, self._estimate_clear_seconds(agv, all_stations)))
            next_payload = dict(p)
            next_payload["_defer_attempt"] = attempt + 1
            next_payload["_pinned_agv_id"] = agv.agv_id
            self._schedule_retry(delay, "chatbot:multi_pair_trip", next_payload)
            log.info(
                "multi_pair_trip retry %d/%d in %.1fs due to: %s",
                attempt + 1, MAX_ATTEMPTS, delay, "; ".join(collision),
            )
            return

        # Smart ordering: greedy nearest-neighbour over an open set where a
        # drop is only added once its pickup has been visited. This lets
        # natural pickup→pickup→drop→drop sequences emerge when the two
        # pickups are nearer to each other than to the drops.
        def _dist(a: str, b: str) -> float:
            if self.routing is None or a == b:
                return 0.0
            try:
                return self.routing.distance(a, b)
            except KeyError:
                return float("inf")

        ordered_stops: list[Stop] = []
        cursor = agv.current_node or pairs[0]["pickup"]
        visited_pickups: set[int] = set()
        delivered_drops: set[int] = set()
        running_load = 0
        # Track ordered pairs for telemetry.
        pair_order: list[dict] = []
        while len(visited_pickups) < len(pairs) or len(delivered_drops) < len(pairs):
            candidates: list[tuple[float, str, int, str]] = []  # (dist, kind, pair_idx, station)
            for j, pr in enumerate(pairs):
                if j not in visited_pickups:
                    # Pickup eligible if it doesn't exceed capacity.
                    if running_load + pr["units"] <= 50:
                        candidates.append((_dist(cursor, pr["pickup"]), "pickup", j, pr["pickup"]))
                elif j not in delivered_drops:
                    candidates.append((_dist(cursor, pr["drop"]), "drop", j, pr["drop"]))
            if not candidates:
                # Must drop something to free capacity before more pickups.
                for j, pr in enumerate(pairs):
                    if j in visited_pickups and j not in delivered_drops:
                        candidates.append((_dist(cursor, pr["drop"]), "drop", j, pr["drop"]))
                if not candidates:
                    break
            candidates.sort(key=lambda c: c[0])
            d, kind, j, st = candidates[0]
            pr = pairs[j]
            if kind == "pickup":
                ordered_stops.append(Stop(station_id=st, op="pickup", units=pr["units"]))
                visited_pickups.add(j)
                running_load += pr["units"]
                pair_order.append({"step": "pickup", "pair": j + 1, "station": st, "units": pr["units"]})
            else:
                ordered_stops.append(Stop(station_id=st, op="drop", units=pr["units"]))
                delivered_drops.add(j)
                running_load -= pr["units"]
                pair_order.append({"step": "drop", "pair": j + 1, "station": st, "units": pr["units"]})
            cursor = st

        # Build trip + synthesise tasks (one per pair, like multi_drop_trip).
        # Reuse provisional trip_id / task_ids if this came from a deferred
        # retry so UI Pending rows promote in place (no duplicates).
        trip_id = p.get("_provisional_trip_id") or f"TR-PAIR-{uuid.uuid4().hex[:6]}"
        trip = Trip(trip_id=trip_id, stops=ordered_stops)
        product = p.get("product") or "pcb_consumer"
        priority = p.get("priority") or PRODUCT_PRIORITY.get(product, "normal")
        now = time.time()
        provisional_batch = p.get("_provisional_batch_id")
        batch_id = provisional_batch or f"B-CHAT-{uuid.uuid4().hex[:5]}"
        provisional_ids = list(p.get("_provisional_task_ids") or [])
        tasks: list[Task] = []
        for i, pr in enumerate(pairs):
            tid = provisional_ids[i] if i < len(provisional_ids) else f"T-{uuid.uuid4().hex[:8]}"
            t = Task(
                task_id=tid,
                pickup=pr["pickup"],
                drop=pr["drop"],
                priority=priority,
                sla=now + SLA_BY_PRIORITY.get(priority, 180.0),
                created_ts=now,
                product_id=product,
                batch_id=batch_id,
                stage_from=None,
                stage_to=None,
                units=pr["units"],
                material_type=None,
                assigned_ts=now,
                trip_id=trip_id,
            )
            tasks.append(t)

        if self.dispatcher is not None:
            try:
                self.dispatcher.tasks_by_trip[trip_id] = tasks
                self.dispatcher.all_tasks_by_trip[trip_id] = list(tasks)
            except Exception:
                pass

        self._claim_agv(agv.agv_id)
        if agv.current_trip is not None or list(agv.cmd_queue.items):
            agv.submit(trip)
        else:
            agv.submit_priority(trip)

        if self.publisher is not None:
            try:
                # Skip task:created republish when promoting provisional rows
                # — events were already published at defer time.
                if not provisional_ids:
                    for t in tasks:
                        self.publisher.publish_event(CHANNEL_TASK_CREATED, t.to_event())
                self.publisher.publish_event(
                    CHANNEL_TRIP_REQUESTED,
                    {
                        "trip_id": trip_id,
                        "agv_id": agv.agv_id,
                        "stops": [
                            {
                                "station_id": s.station_id,
                                "x": self.coords.get(s.station_id, (0, 0))[0],
                                "y": self.coords.get(s.station_id, (0, 0))[1],
                                "op": s.op,
                            }
                            for s in ordered_stops
                        ],
                        "bundled_tasks": len(tasks),
                        "ts": now,
                    },
                )
                for t in tasks:
                    self.publisher.publish_event(
                        CHANNEL_TASK_ASSIGNED,
                        {"task_id": t.task_id, "trip_id": trip_id, "ts": now},
                    )
            except Exception as exc:
                log.warning("publish multi_pair telemetry failed: %s", exc)

        log.info(
            "chatbot multi_pair_trip: %s order=%s trip=%s",
            agv.agv_id, [(s.op, s.station_id) for s in ordered_stops], trip_id,
        )
        self._reply(
            p.get("request_id"),
            True,
            {
                "agv_id": agv.agv_id,
                "trip_id": trip_id,
                "stop_order": pair_order,
                "task_ids": [t.task_id for t in tasks],
                "batch_id": batch_id,
                "total_units": total_units,
            },
        )

    def _cmd_send_to(self, p: dict) -> None:
        agv_id = p.get("agv_id", "")
        target = self._resolve_station(p.get("station_id_or_role", ""))
        agv = self._agv_by_id(agv_id)
        if not agv or not target:
            self._reply(p.get("request_id"), False, error="agv or target not found")
            return
        # Battery gate — non-charging-bay destinations require >=80% battery.
        if target not in ("H01", "H02", "H03"):
            err = self._battery_gate(agv)
            if err:
                self._reply(p.get("request_id"), False, error=err)
                return
            # Charge-first gate — defer until charged for non-bay targets.
            if not p.get("_deferred") and not p.get("_charge_resumed") and self._needs_charge_first(agv):
                payload_replay = dict(p)
                payload_replay["_charge_resumed"] = True
                summary = (
                    f"{agv.agv_id} battery is {agv.battery_pct:.1f}% — needs to charge first. "
                    f"Move to {target} queued; will start automatically once {agv.agv_id} "
                    f"reaches {self.cfg.charge_resume_threshold:.0f}%."
                )
                data = self._queue_until_charged(agv, "chatbot:send_to", payload_replay, summary)
                self._reply(p.get("request_id"), True, data)
                return
        # Station overlap is never allowed — auto-defer until clear.
        if True:
            if p.get("_deferred"):
                evicted = self._evict_idle_blockers(agv, {target})
                if evicted:
                    log.info("deferred retry evicted: %s", "; ".join(evicted))
                    time.sleep(0.5)
            collision = self._station_collisions(agv, {target})
            if collision:
                if not p.get("_deferred"):
                    delay = self._estimate_clear_seconds(agv, {target})
                    deferred = dict(p)
                    deferred["_deferred"] = True
                    deferred["_defer_attempt"] = 1
                    self._schedule_retry(delay, "chatbot:send_to", deferred)
                    self._reply(
                        p.get("request_id"), True,
                        {
                            "deferred": True,
                            "delay_s": round(delay, 1),
                            "reason": "; ".join(collision),
                            "agv_id": agv_id,
                            "target": target,
                        },
                    )
                    log.info(
                        "deferring send_to for %.1fs due to: %s",
                        delay, "; ".join(collision),
                    )
                    return
                # Keep retrying until the blocker clears (capped). Only
                # interrupted trips require manual user action.
                attempt = int(p.get("_defer_attempt") or 1)
                MAX_ATTEMPTS = 30
                if attempt >= MAX_ATTEMPTS:
                    log.warning(
                        "send_to exceeded %d retry attempts; giving up: %s",
                        MAX_ATTEMPTS, "; ".join(collision),
                    )
                    return
                delay = min(15.0, max(2.0, self._estimate_clear_seconds(agv, {target})))
                next_payload = dict(p)
                next_payload["_defer_attempt"] = attempt + 1
                self._schedule_retry(delay, "chatbot:send_to", next_payload)
                log.info(
                    "send_to retry %d/%d in %.1fs due to: %s",
                    attempt + 1, MAX_ATTEMPTS, delay, "; ".join(collision),
                )
                return
        intent = (p.get("intent") or "relocate").lower()
        units = int(p.get("units") or p.get("expected_units") or 0)
        busy_err = self._busy_preempt_error(agv, p)
        if busy_err:
            self._reply(p.get("request_id"), False, error=busy_err)
            return
        trip_id = f"TR-CHAT-{uuid.uuid4().hex[:6]}"
        if intent == "load" and units > 0:
            stops = [Stop(station_id=target, op="pickup", units=units)]
        elif intent == "unload" and units > 0:
            stops = [Stop(station_id=target, op="drop", units=units)]
        else:
            stops = [Stop(station_id=target, op="move")]
        trip = Trip(trip_id=trip_id, stops=stops)

        task_id = None
        if intent in ("load", "unload") and units > 0:
            now = time.time()
            priority = p.get("priority") or "normal"
            task = Task(
                task_id=f"T-{uuid.uuid4().hex[:8]}",
                pickup=target if intent == "load" else (agv.current_node or target),
                drop=target if intent == "unload" else "",
                priority=priority,
                sla=now + SLA_BY_PRIORITY.get(priority, 180.0),
                created_ts=now,
                product_id=p.get("product") or "pcb_consumer",
                batch_id=f"B-CHAT-{uuid.uuid4().hex[:5]}",
                stage_from=None,
                stage_to=None,
                units=units,
                material_type=None,
                assigned_ts=now,
                trip_id=trip_id,
            )
            task_id = task.task_id
            if self.dispatcher is not None:
                try:
                    self.dispatcher.tasks_by_trip[trip_id] = [task]
                    self.dispatcher.all_tasks_by_trip[trip_id] = [task]
                except Exception:
                    pass
            if self.publisher is not None:
                try:
                    self.publisher.publish_event(CHANNEL_TASK_CREATED, task.to_event())
                except Exception as exc:
                    log.warning("publish task:created (send_to) failed: %s", exc)

        self._claim_agv(agv.agv_id)
        if agv.current_trip is not None or list(agv.cmd_queue.items):
            agv.submit(trip)
        else:
            agv.submit_priority(trip)

        if self.publisher is not None and task_id is not None:
            try:
                self.publisher.publish_event(
                    CHANNEL_TRIP_REQUESTED,
                    {
                        "trip_id": trip_id,
                        "agv_id": agv.agv_id,
                        "stops": [
                            {
                                "station_id": s.station_id,
                                "x": self.coords.get(s.station_id, (0, 0))[0],
                                "y": self.coords.get(s.station_id, (0, 0))[1],
                                "op": s.op,
                                "units": getattr(s, "units", 0),
                            }
                            for s in stops
                        ],
                        "bundled_tasks": 1,
                        "ts": time.time(),
                    },
                )
                self.publisher.publish_event(
                    CHANNEL_TASK_ASSIGNED,
                    {"task_id": task_id, "trip_id": trip_id, "ts": time.time()},
                )
            except Exception as exc:
                log.warning("publish trip:requested/task:assigned (send_to) failed: %s", exc)

        log.info("chatbot send_to: %s -> %s (%s) intent=%s units=%d queued as %s (priority)",
                 agv_id, target, p.get("station_id_or_role"), intent, units, trip_id)
        self._reply(p.get("request_id"), True,
                    {"agv_id": agv_id, "target": target, "trip_id": trip_id,
                     "intent": intent, "units": units, "task_id": task_id})

    def _cmd_recall(self, p: dict) -> None:
        agv_id = p.get("agv_id", "")
        agv = self._agv_by_id(agv_id)
        if not agv:
            self._reply(p.get("request_id"), False, error="agv not found")
            return
        # Refuse to recall an AGV that is carrying payload — the units are
        # physically loaded on it and recalling would abandon the trip.
        # The user must let it finish (or pause + manually unload) first.
        # Exception: depleted AGVs (battery <= threshold) are allowed to be
        # recalled even with payload — cargo stays on the AGV until charged.
        is_depleted = (
            agv.state == "depleted"
            or agv.battery_pct <= self.cfg.battery_depleted_threshold
        )
        if agv.payload_count > 0 and not bool(p.get("force")) and not is_depleted:
            self._reply(
                p.get("request_id"), False,
                error=(
                    f"Cannot recall {agv_id} — it is currently carrying "
                    f"{agv.payload_count} unit(s). Recalling would abandon "
                    f"the loaded cargo. Let it finish its current trip, or "
                    f"pause it and dispatch another AGV to a different task."
                ),
            )
            return
        # Pooled charging bays — pick the nearest free bay (any-AGV-any-bay).
        pooled = ["H01", "H02", "H03"]
        free = [c for c in pooled if not self._station_collisions(agv, {c})]
        depot: Optional[str] = None
        def _dist(node: str) -> float:
            if self.routing is None or not agv.current_node:
                return float("inf")
            try:
                return self.routing.distance(agv.current_node, node)
            except Exception:
                return float("inf")
        if free:
            depot = min(free, key=_dist)
        evicted: Optional[str] = None
        if not depot:
            # All bays occupied — try to evict an occupant that is healthier
            # than the recall target (battery-priority swap). Prefer the
            # NEAREST bay; only evict an occupant whose battery is strictly
            # higher than the requesting AGV's.
            occupants: list[tuple[str, AGV]] = []
            for bay in sorted(pooled, key=_dist):
                for other in self.fleet:
                    if other.agv_id == agv.agv_id:
                        continue
                    if other.current_node == bay and other.state in ("idle", "charging"):
                        occupants.append((bay, other))
                        break
            # Walk bays in nearest-first order; evict the first occupant whose
            # battery exceeds the recall target's.
            for bay, other in occupants:
                if other.battery_pct > agv.battery_pct:
                    # Evict: send the occupant to the nearest non-bay neighbour
                    # so the bay frees up. The simulator treats this as a
                    # normal priority trip; the freed bay will be assigned to
                    # the requesting AGV below.
                    neighbour = self._nearest_non_bay_node(other)
                    if neighbour is None:
                        continue
                    evict_trip = Trip(
                        trip_id=f"TR-EVICT-{uuid.uuid4().hex[:6]}",
                        stops=[Stop(station_id=neighbour, op="move")],
                    )
                    other.submit_priority(evict_trip)
                    log.info(
                        "chatbot recall: evicting %s (%.1f%%) from %s -> %s to free bay for %s (%.1f%%)",
                        other.agv_id, other.battery_pct, bay, neighbour,
                        agv.agv_id, agv.battery_pct,
                    )
                    depot = bay
                    evicted = other.agv_id
                    break
        if not depot:
            self._reply(
                p.get("request_id"), False,
                error=(
                    "Cannot recall — all charging bays (H01–H03) are occupied "
                    "and no occupant has higher battery than the requested AGV."
                ),
            )
            return
        # Pre-clear the recall path: any AGV idling on a node along the
        # planned route is asked to step aside so the depleted AGV does not
        # have to negotiate corridor contention while moving on low battery.
        cleared: list[str] = []
        try:
            path = agv.routing.shortest_path(agv.current_node, depot) if agv.routing else None
        except Exception:
            path = None
        if path:
            blockers = [
                other for other in self.fleet
                if other.agv_id != agv.agv_id
                and other.current_node in path
                and other.state in ("idle", "charging")
            ]
            for other in blockers:
                neighbour = self._nearest_non_bay_node(other)
                # Avoid pushing a blocker onto another path node — pick a
                # neighbour that is NOT on the planned recall path.
                if neighbour is None or neighbour in path:
                    if other.graph is None:
                        continue
                    try:
                        nbs = list(other.graph.neighbors(other.current_node))
                    except Exception:
                        nbs = []
                    occupied = {a.current_node for a in self.fleet if a.agv_id != other.agv_id}
                    off_path = [n for n in nbs if n not in path and n not in {"H01","H02","H03"} and n not in occupied]
                    neighbour = off_path[0] if off_path else None
                if neighbour is None:
                    continue
                clear_trip = Trip(
                    trip_id=f"TR-CLEAR-{uuid.uuid4().hex[:6]}",
                    stops=[Stop(station_id=neighbour, op="move")],
                )
                other.submit_priority(clear_trip)
                cleared.append(other.agv_id)
                log.info(
                    "chatbot recall: clearing %s from %s -> %s on path of %s",
                    other.agv_id, other.current_node, neighbour, agv.agv_id,
                )
        trip = Trip(trip_id=f"TR-RECALL-{uuid.uuid4().hex[:6]}", stops=[Stop(station_id=depot, op="move")])
        agv._recall_to_charge = True  # bypass depleted-state gate
        agv.submit_priority(trip)
        self._publish_recall_trip(agv, trip)
        log.info("chatbot recall: %s -> %s as %s", agv_id, depot, trip.trip_id)
        self._reply(
            p.get("request_id"), True,
            {"agv_id": agv_id, "recalled_to": depot, "evicted": evicted, "cleared": cleared},
        )

    def _publish_recall_trip(self, agv: AGV, trip: Trip) -> None:
        """Emit trip:requested for a recall/charge trip so the UI renders it
        as an in-transit trip (not as a pending task row).
        """
        if self.publisher is None:
            return
        try:
            self.publisher.publish_event(
                CHANNEL_TRIP_REQUESTED,
                {
                    "trip_id": trip.trip_id,
                    "agv_id": agv.agv_id,
                    "stops": [
                        {
                            "station_id": s.station_id,
                            "x": self.coords.get(s.station_id, (0, 0))[0],
                            "y": self.coords.get(s.station_id, (0, 0))[1],
                            "op": s.op,
                        }
                        for s in trip.stops
                    ],
                    "bundled_tasks": 0,
                    "kind": "recall",
                    "ts": time.time(),
                },
            )
        except Exception as exc:
            log.warning("publish recall trip:requested failed: %s", exc)

    def _cmd_query(self, p: dict) -> None:
        kind = p.get("kind") or "fleet"
        if kind == "fleet":
            data = [a.snapshot() for a in self.fleet]
        elif kind == "tasks":
            # Build a live view of in-transit work directly from AGV state so
            # the chatbot can reason about who is busy without depending on
            # Mongo. Each entry has agv_id, trip_id, current_node, dest_node,
            # state, payload, and the remaining stops.
            in_transit = []
            for a in self.fleet:
                if a.trip_id is None and a.state in ("idle", "parked", "charging"):
                    continue
                trip = getattr(a, "current_trip", None)
                remaining = []
                if trip is not None:
                    for s in trip.stops[a.current_stop_idx:]:
                        remaining.append({
                            "station_id": s.station_id, "op": s.op,
                            "units": s.units,
                        })
                in_transit.append({
                    "agv_id": a.agv_id,
                    "trip_id": a.trip_id,
                    "state": a.state,
                    "current_node": a.current_node,
                    "dest_node": a.dest_node,
                    "payload_count": a.payload_count,
                    "remaining_stops": remaining,
                })
            interrupted = []
            for a in self.fleet:
                if a.interrupted_trip is None:
                    continue
                tid = a.interrupted_trip.trip_id
                has_tasks = (
                    self.dispatcher is not None
                    and bool(self.dispatcher.all_tasks_by_trip.get(tid))
                )
                if not has_tasks:
                    continue
                interrupted.append({
                    "agv_id": a.agv_id,
                    "trip_id": tid,
                    "remaining_stops": [
                        {"station_id": s.station_id, "op": s.op, "units": s.units}
                        for s in a.interrupted_trip.stops
                    ],
                    "payload_count": a.payload_count,
                })
            pending = []
            if self.dispatcher is not None:
                for t in list(self.dispatcher.pending):
                    pending.append({
                        "task_id": t.task_id,
                        "pickup": t.pickup,
                        "drop": t.drop,
                        "priority": t.priority,
                        "units": getattr(t, "units", 1),
                        "batch_id": getattr(t, "batch_id", None),
                    })
            data = {
                "paused": sorted(self._paused),
                "in_transit": in_transit,
                "interrupted": interrupted,
                "pending": pending,
            }
        elif kind == "counts":
            data = self._task_counts_snapshot()
        else:
            data = {"info": "not implemented for this query kind"}
        self._reply(p.get("request_id"), True, data)

    def _task_counts_snapshot(self) -> dict:
        """Return counts that mirror the UI Task Scheduler sections (one row
        per trip_id / batch_id group, not raw task count)."""
        pending_n = 0
        in_transit_n = 0
        interrupted_n = 0
        if self.dispatcher is not None:
            # Pending: group by trip_id, fall back to b:<batch_id>, else each
            # task counts standalone — same rule as TaskSchedulerPanel.
            seen_pending: set[str] = set()
            for t in list(self.dispatcher.pending):
                tid = getattr(t, "trip_id", None)
                bid = getattr(t, "batch_id", None)
                key = tid or (f"b:{bid}" if bid else f"t:{t.task_id}")
                if key in seen_pending:
                    continue
                seen_pending.add(key)
                pending_n += 1
            # In-transit: one row per active trip_id; interrupted trips split.
            interrupted_trip_ids: set[str] = set()
            for a in self.fleet:
                it = getattr(a, "interrupted_trip", None)
                if it is not None and it.trip_id:
                    interrupted_trip_ids.add(it.trip_id)
            for trip_id in self.dispatcher.all_tasks_by_trip.keys():
                if trip_id in interrupted_trip_ids:
                    interrupted_n += 1
                else:
                    in_transit_n += 1
        # Completed: source of truth is Mongo (survives restarts and matches
        # what persistence writes for the UI's snapshot).
        completed_n = 0
        if self._mongo_tasks is not None:
            try:
                completed_n = self._mongo_tasks.count_documents({"status": "completed"})
            except Exception as exc:
                log.debug("mongo completed count failed: %s", exc)
                with self._completed_lock:
                    completed_n = len(self._completed_trip_ids)
        else:
            with self._completed_lock:
                completed_n = len(self._completed_trip_ids)
        return {
            "pending": pending_n,
            "in_transit": in_transit_n,
            "interrupted": interrupted_n,
            "completed": completed_n,
            "total": pending_n + in_transit_n + interrupted_n + completed_n,
        }

    def _compute_pair_order(self, start_node: str, pairs: list[dict]) -> list[dict]:
        """Greedy nearest-neighbor ordering for multi-pair stops."""
        def _dist(a: str, b: str) -> float:
            if a == b:
                return 0.0
            try:
                return self.routing.distance(a, b)
            except (KeyError, Exception):
                return float("inf")

        result: list[dict] = []
        cursor = start_node
        visited_pickups: set[int] = set()
        delivered_drops: set[int] = set()
        running_load = 0
        while len(visited_pickups) < len(pairs) or len(delivered_drops) < len(pairs):
            candidates: list[tuple[float, str, int, str]] = []
            for j, pr in enumerate(pairs):
                if j not in visited_pickups:
                    if running_load + int(pr.get("units") or 1) <= 50:
                        candidates.append((_dist(cursor, pr["pickup"]), "pickup", j, pr["pickup"]))
                elif j not in delivered_drops:
                    candidates.append((_dist(cursor, pr["drop"]), "drop", j, pr["drop"]))
            if not candidates:
                for j, pr in enumerate(pairs):
                    if j in visited_pickups and j not in delivered_drops:
                        candidates.append((_dist(cursor, pr["drop"]), "drop", j, pr["drop"]))
                if not candidates:
                    break
            candidates.sort(key=lambda c: c[0])
            _, kind, j, st = candidates[0]
            pr = pairs[j]
            units = int(pr.get("units") or 1)
            if kind == "pickup":
                visited_pickups.add(j)
                running_load += units
            else:
                delivered_drops.add(j)
                running_load -= units
            result.append({"step": kind, "pair": j + 1, "station": st, "units": units})
            cursor = st
        return result

    def _estimate_clear_seconds(self, chosen: AGV, dest_set: set[str]) -> float:
        """Estimate seconds until every conflicting AGV vacates dest_set.

        Conflicting = parked-idle on dest, or moving toward dest. For moving
        AGVs we use straight-line dist(current->dest)/speed + load_seconds.
        For idle AGVs sitting on dest we assume they will move within
        load_seconds (their step-aside). Returns max across conflicts.
        """
        speed = max(0.1, self.cfg.agv_speed)
        load_s = float(self.cfg.load_seconds)
        worst = 0.0
        for other in self.fleet:
            if other.agv_id == chosen.agv_id:
                continue
            # Collect the remaining route the other AGV will walk.
            route: list[str] = [other.current_node]
            if other.dest_node and other.dest_node != other.current_node:
                route.append(other.dest_node)
            trip = getattr(other, "current_trip", None)
            if trip is not None:
                for s in trip.stops[other.current_stop_idx + 1:]:
                    if s.station_id:
                        route.append(s.station_id)
            try:
                for queued in list(other.cmd_queue.items):
                    for s in getattr(queued, "stops", []) or []:
                        if s.station_id:
                            route.append(s.station_id)
            except Exception:
                pass
            eta = 0.0
            cleared = False
            cursor = route[0]
            for nxt in route[1:]:
                if self.routing is not None:
                    try:
                        d = self.routing.distance(cursor, nxt)
                    except KeyError:
                        d = 0.0
                else:
                    d = 0.0
                eta += d / speed + load_s
                cursor = nxt
                if nxt in dest_set:
                    cleared = True
                    eta += load_s  # service time before it leaves
                    break
            if other.current_node in dest_set and other.state == "idle":
                eta = max(eta, load_s * 2)
                cleared = True
            if cleared:
                worst = max(worst, eta)
        return worst + 1.0

    def _cmd_unblock_agv(self, p: dict) -> None:
        """Clear whatever is preventing this AGV from moving WITHOUT
        cancelling its trip. Handles three cases:
          1. Soft-paused (e.g. via pause_agv) → resume it.
          2. State == "blocked" with an active trip → call evict_holder on
             the node it's waiting for, releasing stale locks / shoving
             parked peers off the corridor.
          3. Genuinely stuck (no obvious blocker) → reply with a note so
             the chat can offer a different fix.
        Never cancels the AGV's current trip.
        """
        agv_id = (p.get("agv_id") or "").strip()
        agv = self._agv_by_id(agv_id)
        if agv is None:
            self._reply(p.get("request_id"), False, error=f"unknown AGV {agv_id!r}")
            return
        actions: list[str] = []
        if agv_id in self._paused:
            self._paused.discard(agv_id)
            actions.append("resumed (was paused)")
        blocked_node = None
        traffic = getattr(agv, "traffic", None)
        if traffic is not None:
            try:
                waiting = traffic._waiting_for.get(agv_id)
                if waiting:
                    blocked_node = waiting
            except Exception:
                blocked_node = None
        if blocked_node is None and agv.state == "blocked":
            try:
                path = agv.planned_path_nodes()
                for n in path:
                    if traffic is not None and traffic.is_held(n) and traffic.holder(n) != agv_id:
                        blocked_node = n
                        break
            except Exception:
                pass
        if blocked_node is not None:
            try:
                self.evict_holder(agv, blocked_node)
                actions.append(f"evicted holder of {blocked_node}")
            except Exception as exc:
                log.warning("unblock_agv: evict_holder failed: %s", exc)
        if not actions:
            actions.append("no blocker detected; trip preserved")
        self._reply(p.get("request_id"), True, {
            "agv_id": agv_id,
            "actions": actions,
            "trip_id": agv.trip_id,
            "state": agv.state,
        })

    def evict_holder(self, requester: AGV, blocked_node: str) -> None:
        """Public entry: evict any idle/parked/empty peer sitting on the
        requester's planned corridor — not just the one on `blocked_node`.
        Helps when multiple parked AGVs straddle the corridor and clearing
        only the immediate blocker would just stall again at the next one.
        """
        # Stale-lock cleanup: if a traffic lock claims a holder that is not
        # physically on the node (e.g. a prior trip didn't release cleanly),
        # force-release it so the requester can acquire.
        try:
            traffic = requester.traffic
            if traffic is not None:
                holder_id = traffic.holder(blocked_node)
                if holder_id and holder_id != requester.agv_id:
                    holder_agv = self._agv_by_id(holder_id)
                    if holder_agv is None or holder_agv.current_node != blocked_node:
                        traffic._locks[blocked_node] = None
                        log.info(
                            "evict_holder: stale lock on %s (claimed by %s, not present) — released",
                            blocked_node, holder_id,
                        )
        except Exception as exc:
            log.warning("stale-lock cleanup failed for %s: %s", blocked_node, exc)
        try:
            corridor = set(requester.planned_path_nodes())
        except Exception:
            corridor = set()
        corridor.add(blocked_node)
        # Nodes currently occupied by an empty peer on the corridor.
        # We include peers that are currently on a "soft" trip (TR-PARK /
        # TR-EVICT) because those trips exist only to relocate idle AGVs
        # and MUST yield to real work — cancel theirs and bump them aside.
        evict_set: set[str] = set()
        soft_holders: list = []
        for a in self.fleet:
            if a.agv_id == requester.agv_id:
                continue
            if a.current_node not in corridor:
                continue
            soft_trip = False
            t = getattr(a, "current_trip", None)
            if t and str(getattr(t, "trip_id", "")).startswith(("TR-PARK", "TR-EVICT")):
                soft_trip = True
            # Never evict a peer that is actively executing a real trip — even
            # if it's momentarily on an idle/blocked tick between segments.
            # Only soft (TR-PARK/TR-EVICT) trips or stationary loaded peers
            # may be displaced.
            if t is not None and not soft_trip and a.payload_count == 0:
                continue
            # Loaded peer: only eligible if currently stationary (blocked)
            # — we'll one-hop step-aside and their original trip auto-resumes.
            loaded_stationary = a.payload_count > 0 and a.state == "blocked"
            if a.payload_count > 0 and not loaded_stationary:
                continue
            if a.state in ("idle", "parked", "charging") or soft_trip or loaded_stationary:
                evict_set.add(a.current_node)
                if soft_trip:
                    soft_holders.append(a)
        # Cancel in-flight soft trips so the evict trip we're about to submit
        # actually runs instead of being queued behind them.
        for sh in soft_holders:
            try:
                # Drop any queued items first.
                sh.cmd_queue.items = [
                    t for t in sh.cmd_queue.items
                    if not str(getattr(t, "trip_id", "")).startswith(("TR-PARK", "TR-EVICT"))
                ]
                # Interrupt the in-flight soft trip.
                sh._estop_requested = True
                sh.speed = 0.0
                log.info("evict: cancelled soft trip on %s to free corridor", sh.agv_id)
            except Exception as exc:
                log.warning("evict: could not cancel soft trip on %s: %s", sh.agv_id, exc)
        if not evict_set:
            log.info(
                "evict_holder for %s on %s: no idle/empty peer on corridor",
                requester.agv_id, blocked_node,
            )
            return
        notes = self._evict_idle_blockers(requester, evict_set)
        if notes:
            log.info(
                "on-demand eviction for %s (corridor nodes %s): %s",
                requester.agv_id, sorted(evict_set), "; ".join(notes),
            )
        else:
            log.info(
                "evict_holder for %s: candidates on %s but no clear neighbour found",
                requester.agv_id, sorted(evict_set),
            )

    def _graph_holder(self, node: str) -> Optional[str]:
        # Lookup via traffic locks if available on any AGV.
        for a in self.fleet:
            t = a.traffic
            if t is not None:
                h = t.holder(node)
                if h:
                    return h
                break
        return None

    def _evict_idle_blockers(self, chosen: AGV, dest_set: set[str]) -> list[str]:
        """For each other AGV that is idle-and-empty parked on a station in
        dest_set, send it on a low-priority `move` to a free neighbour so the
        deferred dispatch can claim the destination. Returns a list of
        eviction notes for telemetry/logging."""
        notes: list[str] = []
        if self.graph is None:
            return notes
        # The requester's full planned corridor — we must NOT relocate the
        # evicted peer onto another node it needs to traverse.
        try:
            requester_path = set(chosen.planned_path_nodes())
        except Exception:
            requester_path = set()
        for other in self.fleet:
            if other.agv_id == chosen.agv_id:
                continue
            if other.current_node not in dest_set:
                continue
            soft_trip = False
            t = getattr(other, "current_trip", None)
            if t and str(getattr(t, "trip_id", "")).startswith(("TR-PARK", "TR-EVICT")):
                soft_trip = True
            # Loaded blockers: ONLY nudge if they're currently stationary
            # (blocked/waiting) AND we can return them via a one-hop step-aside.
            # Once the requester clears, the blocker resumes its original trip.
            loaded_stationary = (
                other.payload_count > 0
                and other.state == "blocked"
            )
            if other.payload_count > 0 and not loaded_stationary:
                # Loaded and actively moving — don't disturb.
                continue
            if (other.payload_count == 0
                    and other.state not in ("idle", "parked", "charging")
                    and not soft_trip):
                continue
            # Pick a free neighbour that is NOT in dest_set, not on the
            # requester's planned corridor, and not occupied. Prefer
            # neighbours farthest off the requester's path.
            occupied = {a.current_node for a in self.fleet if a.agv_id != other.agv_id}
            target = None
            try:
                neighbours = list(self.graph.neighbors(other.current_node))
            except Exception:
                neighbours = []
            ranked = []
            for nb in neighbours:
                if nb in dest_set or nb in occupied:
                    continue
                # Penalty: how many of nb's own neighbours are on requester's path
                try:
                    overlap = sum(1 for n in self.graph.neighbors(nb) if n in requester_path)
                except Exception:
                    overlap = 0
                on_path = 1 if nb in requester_path else 0
                ranked.append((on_path, overlap, nb))
            ranked.sort()
            if ranked:
                target = ranked[0][2]
            # Helper: full eviction PATH must not cross requester's planned
            # path or current node, otherwise the evictee will block the
            # requester from the OTHER side (head-on deadlock — exactly the
            # S01/S04 case where AGV01 evicted S03→H01 sits on W13 which is
            # on AGV04's S03-bound corridor).
            requester_now = chosen.current_node
            def _path_safe(dst: str) -> bool:
                if self.routing is None:
                    return True
                try:
                    p = self.routing.shortest_path(other.current_node, dst) or []
                except Exception:
                    return False
                for n in p[1:]:
                    if n == requester_now or n in requester_path:
                        return False
                return True
            if target and not _path_safe(target):
                target = None  # neighbour found, but corridor unsafe
            if not target:
                # Try start_node, but only if its PATH is also safe.
                if (other.start_node and other.start_node not in dest_set
                        and other.start_node not in occupied
                        and other.start_node not in requester_path
                        and _path_safe(other.start_node)):
                    target = other.start_node
            if not target:
                log.info("eviction: no safe target for %s off %s — leaving in place",
                         other.agv_id, other.current_node)
                continue
            trip = Trip(
                trip_id=f"TR-EVICT-{uuid.uuid4().hex[:6]}",
                stops=[Stop(station_id=target, op="move")],
            )
            other.submit_priority(trip)
            self._evicted_at[other.agv_id] = time.time()
            notes.append(f"{other.agv_id}: {other.current_node} → {target}")
            log.info("eviction: moving %s off %s to %s for deferred dispatch",
                     other.agv_id, other.current_node, target)
        return notes

    def _schedule_retry(self, delay_s: float, channel: str, payload: dict) -> None:
        """Re-handle `payload` on `channel` after `delay_s` seconds."""
        def _fire():
            try:
                self._handle(channel, payload)
            except Exception as exc:
                log.warning("deferred retry failed: %s", exc)
        t = threading.Timer(max(0.5, delay_s), _fire)
        t.daemon = True
        t.start()

    def _planned_stations(self, agv: AGV) -> list[str]:
        """Every station this AGV will visit: current dest + remaining stops
        of its current trip + all stops of any queued trips. Used so the
        analyzer can see future destinations, not just the next segment."""
        out: list[str] = []
        if agv.dest_node:
            out.append(agv.dest_node)
        trip = getattr(agv, "current_trip", None)
        if trip is not None:
            for s in trip.stops[agv.current_stop_idx + 1:]:
                if s.station_id:
                    out.append(s.station_id)
        try:
            for queued in list(agv.cmd_queue.items):
                for s in getattr(queued, "stops", []) or []:
                    if s.station_id:
                        out.append(s.station_id)
        except Exception:
            pass
        return out

    def _station_collisions(self, chosen: AGV, dest_set: set[str]) -> list[str]:
        """Return human-readable collision notes if any other AGV is already
        parked on, heading to, or has a future planned stop at a destination
        station — including remaining stops of an in-flight multi-drop trip."""
        out: list[str] = []
        for other in self.fleet:
            if other.agv_id == chosen.agv_id:
                continue
            # An evicted peer that has a TR-EVICT-/TR-PARK- priority trip
            # queued or in-flight is actively leaving the dest station —
            # don't flag it as a collision (otherwise the deferred retry
            # spins forever between eviction and re-check, since
            # current_node only updates after the AGV physically advances).
            evicting = False
            try:
                t = getattr(other, "current_trip", None)
                if t and str(getattr(t, "trip_id", "")).startswith(("TR-EVICT", "TR-PARK")):
                    evicting = True
                if not evicting:
                    for queued in list(getattr(other, "cmd_queue", None).items if getattr(other, "cmd_queue", None) else []):
                        if str(getattr(queued, "trip_id", "")).startswith(("TR-EVICT", "TR-PARK")):
                            evicting = True
                            break
            except Exception:
                pass
            if evicting:
                continue
            if other.current_node in dest_set and other.state in ("idle", "parked", "charging"):
                out.append(f"{other.agv_id} is parked on {other.current_node}")
                continue
            if other.dest_node in dest_set and other.state in ("moving", "blocked"):
                out.append(f"{other.agv_id} is heading to {other.dest_node}")
                continue
            # Future stops: AGV is mid-trip and a later stop overlaps a dest.
            future = self._planned_stations(other)
            overlap = [s for s in future if s in dest_set]
            if overlap:
                out.append(
                    f"{other.agv_id} has {overlap[0]} as a planned stop in its current trip"
                )
        return out

    def _cmd_analyze_dispatch(self, p: dict) -> None:
        """Pre-flight feasibility analysis for a candidate dispatch.

        Inputs (any of):
          agv_id (or "auto"), pickup, drops=[{station,units}|"S05"], target

        Returns a structured report covering:
          - chosen AGV (if auto) and rationale
          - per-segment conflict warnings (other AGV holds or planned-for it)
          - leaf-node parking warning (drop station with single corridor link)
          - deadlock-risk pairs (another AGV idle on our pickup/drop)
          - recommendation: dispatch | wait | reprioritise
        """
        target = p.get("target")
        pickup_in = p.get("pickup") or p.get("pickup_role")
        drops_in = p.get("drops") or []
        agv_id = p.get("agv_id") or "auto"

        # Build the route the proposed trip would traverse.
        stations: list[str] = []
        if pickup_in:
            pk = self._resolve_station(pickup_in)
            if pk:
                stations.append(pk)
        for d in drops_in:
            if isinstance(d, str):
                s = self._resolve_station(d)
            elif isinstance(d, dict):
                s = self._resolve_station(d.get("station") or d.get("station_id") or "")
            else:
                s = None
            if s:
                stations.append(s)
        if target and not stations:
            t = self._resolve_station(target)
            if t:
                stations.append(t)

        # Choose AGV.
        chosen: Optional[AGV] = None
        rationale = ""
        if agv_id and agv_id.lower() != "auto":
            chosen = self._agv_by_id(agv_id)
            if chosen:
                rationale = f"User-specified {chosen.agv_id}."
        else:
            num_drops = max(1, len(drops_in))
            chosen = self._pick_best_agv(stations[0] if stations else "", num_drops)
            if chosen:
                rationale = (
                    f"Auto-selected {chosen.agv_id}: idle, capacity ok, "
                    f"lowest distance to pickup with no corridor conflict."
                )

        warnings: list[str] = []
        deadlock_risks: list[str] = []
        conflicts: list[str] = []
        station_collisions: list[str] = []  # hard-block: 2 AGVs same station

        # Path the candidate AGV would walk.
        path: list[str] = []
        if chosen and stations and self.routing is not None:
            cursor = chosen.current_node
            for s in stations:
                try:
                    seg = self.routing.shortest_path(cursor, s)
                    if path and seg and seg[0] == path[-1]:
                        path.extend(seg[1:])
                    else:
                        path.extend(seg)
                    cursor = s
                except Exception:
                    warnings.append(f"No route from {cursor} to {s}.")

        # Identify destination stations (the actual stops, not corridor waypoints).
        destination_set = set(stations)

        # Precompute each peer's full planned corridor (every node on their
        # active/queued trips, not just stop stations). Used to flag
        # corridor-overlap for bundled multi-drop trips at planning time.
        peer_corridors: dict[str, set[str]] = {}
        for a in self.fleet:
            if chosen and a.agv_id == chosen.agv_id:
                continue
            corridor: set[str] = set()
            try:
                corridor.update(a.planned_path_nodes() or [])
            except Exception:
                pass
            # Also expand each queued trip's stops into corridor waypoints so
            # we see bundled-trip overlaps before they start moving.
            try:
                cursor = a.current_node or a.start_node
                stops_iter = list(self._planned_stations(a))
                if self.routing is not None and cursor:
                    for s in stops_iter:
                        try:
                            seg = self.routing.shortest_path(cursor, s)
                            corridor.update(seg or [])
                            cursor = s
                        except Exception:
                            continue
            except Exception:
                pass
            if corridor:
                peer_corridors[a.agv_id] = corridor

        reported_corridor_overlap: set[str] = set()

        # Per-node conflict scan: who's parked there, who's heading there?
        for n in path:
            for a in self.fleet:
                if chosen and a.agv_id == chosen.agv_id:
                    continue
                if a.current_node == n and a.state == "idle":
                    # If the occupant is sitting on one of OUR destination
                    # stations, this is a station-occupancy collision — the
                    # planned drop/unload would overlap. Treat as a confirm
                    # risk, not a casual step-aside.
                    if n in destination_set:
                        station_collisions.append(
                            f"{a.agv_id} is already parked on destination {n} — two AGVs cannot share a station."
                        )
                        continue
                    # leaf check — does n have only one neighbour?
                    deg = -1
                    if self.graph is not None:
                        try:
                            deg = len(list(self.graph.neighbors(n)))
                        except Exception:
                            deg = -1
                    if deg == 1:
                        deadlock_risks.append(
                            f"{a.agv_id} is idle on {n} (leaf node — only one corridor link). "
                            f"If {chosen.agv_id if chosen else 'the AGV'} arrives before {a.agv_id} steps aside, "
                            f"a temporary standoff is likely."
                        )
                    else:
                        conflicts.append(f"{a.agv_id} is parked on {n}; will need to step aside.")
                elif a.dest_node == n and a.state in ("moving", "blocked"):
                    if n in destination_set:
                        station_collisions.append(
                            f"{a.agv_id} is also heading to destination {n} — both AGVs would arrive at the same station."
                        )
                    else:
                        conflicts.append(f"{a.agv_id} is also heading to {n} — corridor contention possible.")
                elif n in destination_set and n in self._planned_stations(a):
                    station_collisions.append(
                        f"{a.agv_id} has {n} as a future stop in its current trip — destinations overlap."
                    )
                else:
                    # Corridor-overlap: bundled multi-drop trips often hit
                    # peer corridors mid-route. Flag once per (peer,node).
                    corridor = peer_corridors.get(a.agv_id)
                    if corridor and n in corridor:
                        key = f"{a.agv_id}:{n}"
                        if key not in reported_corridor_overlap:
                            reported_corridor_overlap.add(key)
                            conflicts.append(
                                f"{a.agv_id}'s planned path passes through {n} — bundled-trip corridor overlap."
                            )

        # ---- Forecast: time-to-arrival per node along OUR path, and check
        # whether any other moving AGV is forecast to occupy the same node
        # in an overlapping window. Uses straight-line edge distance / speed.
        forecast_collisions: list[str] = []
        if chosen and path and self.coords:
            speed = max(0.1, self.cfg.agv_speed)

            def _eta_along(p: list[str]) -> list[tuple[str, float]]:
                etas: list[tuple[str, float]] = []
                t = 0.0
                for i in range(len(p) - 1):
                    a, b = p[i], p[i + 1]
                    dist: Optional[float] = None
                    if self.graph is not None:
                        try:
                            dist = float(self.graph[a][b].get("weight", 0.0)) or None
                        except Exception:
                            dist = None
                    if dist is None:
                        ax, ay = self.coords.get(a, (0.0, 0.0))
                        bx, by = self.coords.get(b, (0.0, 0.0))
                        dist = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
                    t += dist / speed
                    etas.append((b, t))
                return etas

            our_etas = _eta_along(path)
            our_eta_by_node = {n: t for n, t in our_etas}

            for other in self.fleet:
                if other.agv_id == chosen.agv_id:
                    continue
                if other.state not in ("moving", "blocked") or not other.dest_node:
                    continue
                try:
                    other_path = self.routing.shortest_path(other.current_node, other.dest_node)
                except Exception:
                    continue
                other_etas = _eta_along(other_path)
                # Look for shared nodes with overlapping arrival windows
                # (within ±2 s, the typical service/turn time).
                for n, ot in other_etas:
                    ourT = our_eta_by_node.get(n)
                    if ourT is None:
                        continue
                    if abs(ourT - ot) <= 2.0:
                        forecast_collisions.append(
                            f"{chosen.agv_id} reaches {n} at ~{ourT:.1f}s, "
                            f"{other.agv_id} reaches it at ~{ot:.1f}s — "
                            f"corridor contention forecast."
                        )
                        break  # one note per other AGV is enough


        # Recommendation.
        if not chosen:
            recommendation = "block"
            summary = "No AGV available — all busy or capacity-constrained."
        elif station_collisions:
            recommendation = "defer"
            eta = 0.0
            if chosen:
                eta = self._estimate_clear_seconds(chosen, set(stations))
            summary = (
                "Station collision detected. "
                + " ".join(station_collisions)
                + f" The dispatch will auto-start in ~{eta:.0f}s once the conflicting AGV clears. "
                "Confirm to queue the deferred dispatch."
            )
        elif warnings:
            recommendation = "block"
            summary = "Cannot dispatch as proposed."
        elif deadlock_risks:
            recommendation = "confirm"
            summary = (
                "Dispatch is feasible but standoff risk is non-trivial. "
                "Ask the user whether to (a) proceed anyway (the auto step-aside will resolve it), "
                "(b) reprioritise — pause the conflicting AGV's idle hold and recall it first, "
                "or (c) pick a different AGV."
            )
        elif forecast_collisions:
            recommendation = "confirm"
            summary = (
                "Forecast: another AGV is predicted to reach a shared node at ~the same time. "
                + " ".join(forecast_collisions)
                + " Ask the user whether to proceed (auto-reroute will resolve), "
                "stagger by pausing the other AGV briefly, or pick a different AGV."
            )
        elif conflicts:
            recommendation = "proceed_with_note"
            summary = "Dispatch is feasible. Minor corridor contention noted; auto-rerouting will handle it."
        else:
            recommendation = "proceed"
            summary = "No conflicts detected. Safe to dispatch."

        self._reply(
            p.get("request_id"),
            True,
            {
                "chosen_agv": chosen.agv_id if chosen else None,
                "rationale": rationale,
                "planned_path": path,
                "fleet_snapshot": [a.snapshot() for a in self.fleet],
                "warnings": warnings + station_collisions,
                "station_collisions": station_collisions,
                "conflicts": conflicts,
                "deadlock_risks": deadlock_risks,
                "forecast_collisions": forecast_collisions,
                "eta_clear_seconds": (
                    round(self._estimate_clear_seconds(chosen, set(stations)), 1)
                    if chosen and (station_collisions or forecast_collisions) else 0
                ),
                "recommendation": recommendation,
                "summary": summary,
            },
        )

    def _cmd_emergency_stop(self, p: dict) -> None:
        """Hard stop: interrupt the current trip and pause the AGV.

        Mid-trip the AGV is interrupted; cargo (if any) is held on board.
        The AGV is added to the paused set so dispatcher won't pick it.
        Use resume_agv to release.
        """
        agv_id = p.get("agv_id", "")
        agv = self._agv_by_id(agv_id)
        if not agv:
            self._reply(p.get("request_id"), False, error="agv not found")
            return
        self._paused.add(agv_id)
        was_running = agv.trip_id
        # Set the flag the simulation polls each tick — race-free across the
        # bridge thread / SimPy thread boundary. The AGV will snap to the
        # closer endpoint of the current segment and abort the trip.
        agv._estop_requested = True
        agv.speed = 0.0
        log.warning(
            "ESTOP set: %s state=%s trip=%s pos=(%.2f,%.2f) node=%s",
            agv_id, agv.state, agv.trip_id, agv.x, agv.y, agv.current_node,
        )
        # Drain any queued trips so they don't auto-fire on resume.
        cancelled = list(agv.cmd_queue.items)
        agv.cmd_queue.items.clear()
        log.info("chatbot estop: %s (was on %s, drained %d queued)",
                 agv_id, was_running, len(cancelled))
        # Compute remaining stops from the current trip (abort hasn't fired
        # yet in SimPy, so interrupted_trip is not set — read from current_trip).
        remaining_stops = []
        if agv.current_trip and agv.current_stop_idx is not None:
            remaining_stops = [
                {"station_id": s.station_id, "op": s.op, "units": s.units}
                for s in agv.current_trip.stops[agv.current_stop_idx:]
            ]
        self._reply(
            p.get("request_id"), True,
            {
                "agv_id": agv_id,
                "stopped_trip": was_running,
                "queued_trips_cancelled": len(cancelled),
                "payload_held": agv.payload_count,
                "has_interrupted_trip": bool(was_running),
                "remaining_stops": remaining_stops,
                "remaining_stops_count": len(remaining_stops),
            },
        )

    def _cmd_resume(self, p: dict) -> None:
        """Resume a paused AGV. If it has an interrupted trip (from emergency
        stop), re-submit the remaining stops so the AGV continues where it
        left off."""
        agv_id = p.get("agv_id", "")
        agv = self._agv_by_id(agv_id)
        if not agv:
            self._reply(p.get("request_id"), False, error="agv not found")
            return
        self._paused.discard(agv_id)
        agv._estop_requested = False
        resumed_trip = None
        remaining_stops = 0
        all_trips: list = []
        if agv.interrupted_trip is not None:
            all_trips.append(agv.interrupted_trip)
        all_trips.extend(agv.interrupted_trips)
        agv.interrupted_trip = None
        agv.interrupted_trips = []
        if all_trips:
            for trip in all_trips:
                agv.submit_priority(trip)
            resumed_trip = all_trips[0].trip_id
            remaining_stops = sum(len(t.stops) for t in all_trips)
            log.info("chatbot resume: %s resuming %d trip(s), first=%s total_stops=%d",
                     agv_id, len(all_trips), resumed_trip, remaining_stops)
            if self.publisher is not None:
                try:
                    for idx, trip in enumerate(all_trips):
                        self.publisher.publish_event(
                            CHANNEL_TRIP_RESUMED,
                            {
                                "trip_id": trip.trip_id,
                                "agv_id": agv_id,
                                "is_active": idx == 0,
                                "stops": [
                                    {
                                        "station_id": s.station_id,
                                        "x": self.coords.get(s.station_id, (0, 0))[0],
                                        "y": self.coords.get(s.station_id, (0, 0))[1],
                                        "op": s.op,
                                    }
                                    for s in trip.stops
                                ],
                                "ts": time.time(),
                            },
                        )
                except Exception as exc:
                    log.warning("publish trip:resumed failed: %s", exc)
        else:
            log.info("chatbot resume: %s (no interrupted trip to resume)", agv_id)
        self._reply(
            p.get("request_id"), True,
            {
                "resumed": agv_id,
                "resumed_trip": resumed_trip,
                "remaining_stops": remaining_stops,
            },
        )

    def _cmd_list_interrupted(self, p: dict) -> None:
        """Return all AGVs that have an interrupted trip pending resume.
        Only includes trips backed by real tasks (not simple relocations)."""
        out = []
        for a in self.fleet:
            all_interrupted = []
            if a.interrupted_trip is not None:
                all_interrupted.append(a.interrupted_trip)
            all_interrupted.extend(a.interrupted_trips)
            for trip in all_interrupted:
                trip_id = trip.trip_id
                has_tasks = (
                    self.dispatcher is not None
                    and bool(self.dispatcher.all_tasks_by_trip.get(trip_id))
                )
                if not has_tasks:
                    continue
                out.append({
                    "agv_id": a.agv_id,
                    "trip_id": trip_id,
                    "remaining_stops": [
                        {"station_id": s.station_id, "op": s.op, "units": s.units}
                        for s in trip.stops
                    ],
                    "payload_count": a.payload_count,
                    "current_node": a.current_node,
                    "paused": a.agv_id in self._paused,
                })
        self._reply(p.get("request_id"), True, {"interrupted": out})

    def _cmd_complete_interrupted(self, p: dict) -> None:
        """Discard an AGV's interrupted trip and clear its bundled tasks.

        Publishes a synthetic trip:completed (with aborted=true) so the UI
        moves the row out of pending into completed.
        """
        agv_id = p.get("agv_id", "")
        agv = self._agv_by_id(agv_id)
        if not agv:
            self._reply(p.get("request_id"), False, error="agv not found")
            return
        if agv.interrupted_trip is None:
            self._reply(p.get("request_id"), False, error="no interrupted trip")
            return
        # Gather all interrupted trips for this AGV.
        all_interrupted = [agv.interrupted_trip]
        all_interrupted.extend(agv.interrupted_trips)
        agv.interrupted_trip = None
        agv.interrupted_trips = []
        agv._estop_requested = False
        held = agv.payload_count
        agv.payload_count = 0
        trip_ids = []
        if self.publisher is not None:
            for trip in all_interrupted:
                trip_ids.append(trip.trip_id)
                try:
                    self.publisher.publish_event(
                        CHANNEL_TRIP_COMPLETED,
                        {
                            "trip_id": trip.trip_id,
                            "agv_id": agv_id,
                            "kpis": {"distance": 0, "duration": 0, "stops": 0, "aborted": True},
                            "task_ids": [],
                            "bundled": 0,
                            "ts": time.time(),
                        },
                    )
                except Exception as exc:
                    log.warning("publish synthetic trip:completed failed: %s", exc)
        log.info("chatbot complete_interrupted: %s trips=%s payload_dropped=%d",
                 agv_id, trip_ids, held)
        self._reply(p.get("request_id"), True, {
            "agv_id": agv_id, "trip_ids": trip_ids, "payload_dropped": held,
        })

    def _cmd_cancel_trip(self, p: dict) -> None:
        """Cancel a queued or in-flight trip by trip_id (or agv_id+current).

        - If trip is queued (not yet started) → drop it from cmd_queue.
        - If it's the active trip → interrupt; AGV returns to idle in place.
        Pending tasks bundled into the trip are NOT auto-resubmitted.
        """
        trip_id = p.get("trip_id", "")
        agv_id = p.get("agv_id", "")
        target_agv: Optional[AGV] = None
        location = "queue"
        if agv_id:
            target_agv = self._agv_by_id(agv_id)
        if target_agv is None and trip_id:
            for a in self.fleet:
                if a.trip_id == trip_id or any(getattr(t, "trip_id", None) == trip_id for t in a.cmd_queue.items):
                    target_agv = a
                    break
        if target_agv is None:
            self._reply(p.get("request_id"), False, error="trip/agv not found")
            return
        # Drop queued trip first.
        before = len(target_agv.cmd_queue.items)
        target_agv.cmd_queue.items = [
            t for t in target_agv.cmd_queue.items
            if not (trip_id and getattr(t, "trip_id", None) == trip_id)
        ]
        dropped = before - len(target_agv.cmd_queue.items)
        # Interrupt active trip if matched (or no trip_id supplied).
        active_cancelled = False
        if (not trip_id or target_agv.trip_id == trip_id) and target_agv.state != "idle":
            target_agv._estop_requested = True
            target_agv.speed = 0.0
            active_cancelled = True
            location = "active"
        log.info("chatbot cancel_trip: agv=%s trip=%s dropped=%d active_cancelled=%s",
                 target_agv.agv_id, trip_id or target_agv.trip_id, dropped, active_cancelled)
        self._reply(
            p.get("request_id"), True,
            {
                "agv_id": target_agv.agv_id,
                "trip_id": trip_id or target_agv.trip_id,
                "queued_dropped": dropped,
                "active_cancelled": active_cancelled,
                "where": location,
            },
        )

    def _cmd_reroute(self, p: dict) -> None:
        """Change destination of an AGV mid-flight (cancel current + send_to).

        If carrying payload, requires force=true (cargo will be diverted).
        """
        agv_id = p.get("agv_id", "")
        target = self._resolve_station(p.get("station_id_or_role", ""))
        agv = self._agv_by_id(agv_id)
        if not agv or not target:
            self._reply(p.get("request_id"), False, error="agv or target not found")
            return
        if agv.payload_count > 0 and not bool(p.get("force")):
            self._reply(
                p.get("request_id"), False,
                error=(
                    f"{agv_id} is carrying {agv.payload_count} unit(s). "
                    f"Reroute would divert loaded cargo. Pass force=true to override."
                ),
            )
            return
        collision = self._station_collisions(agv, {target})
        if collision:
            self._reply(
                p.get("request_id"), False,
                error="Cannot reroute — destination not clear: " + "; ".join(collision),
            )
            return
        # Drain queue so the new destination becomes the only goal.
        agv.cmd_queue.items.clear()
        trip = Trip(trip_id=f"TR-CHAT-{uuid.uuid4().hex[:6]}", stops=[Stop(station_id=target, op="move")])
        agv.submit_priority(trip)
        log.info("chatbot reroute: %s -> %s as %s", agv_id, target, trip.trip_id)
        self._reply(
            p.get("request_id"), True,
            {"agv_id": agv_id, "rerouted_to": target, "trip_id": trip.trip_id},
        )

    def _battery_gate(self, agv: AGV) -> Optional[str]:
        """Return None if AGV is fit to dispatch; otherwise an error message."""
        threshold = self.cfg.battery_min_dispatch
        if agv.battery_pct < threshold:
            return (
                f"{agv.agv_id} battery is {agv.battery_pct:.1f}% (below {threshold:.0f}% minimum). "
                f"Recall it to a charging bay (H01/H02/H03) before dispatching new work."
            )
        return None

    def _needs_charge_first(self, agv: AGV) -> bool:
        """True when the AGV is at/below the auto-recall threshold; new work
        should be queued behind a charging cycle rather than dispatched now."""
        return agv.battery_pct <= self.cfg.auto_recall_threshold

    def _queue_until_charged(self, agv: AGV, channel: str, payload: dict, summary: str) -> dict:
        """Queue `payload` to be replayed on `channel` once `agv` reaches the
        charge-resume threshold. Returns a reply-dict the caller can send back."""
        # Strip request_id so the replayed command doesn't reply twice.
        sanitized = {k: v for k, v in payload.items() if k != "request_id"}
        with self._charge_pending_lock:
            self._charge_pending.append({
                "agv_id": agv.agv_id,
                "channel": channel,
                "payload": sanitized,
                "ts": time.time(),
                "summary": summary,
            })
        log.info(
            "charge-pending: queued %s for %s (battery %.1f%%, resume at >=%.1f%%)",
            channel, agv.agv_id, agv.battery_pct, self.cfg.charge_resume_threshold,
        )
        return {
            "queued_until_charged": True,
            "agv_id": agv.agv_id,
            "battery_pct": round(agv.battery_pct, 1),
            "resume_at_pct": self.cfg.charge_resume_threshold,
            "summary": summary,
        }

    def _evict_home_bay_squatters(self) -> None:
        """If an AGV is heading to its home bay and a non-owner peer is
        parked on that bay, redirect the squatter to a different free
        bay/staging spot before the owner arrives. Prevents home-bay
        deadlock when the rightful owner would otherwise block.
        """
        all_bays = ["H01", "H02", "H03"]
        staging = ["W34", "W38"]
        park_nodes = set(all_bays + staging)

        # Build owner map and find inbound owners.
        for owner in self.fleet:
            home = getattr(owner, "start_node", None)
            if home not in park_nodes:
                continue
            if owner.current_node == home:
                continue
            # Is owner currently routed home? Check current trip's last stop
            # OR any TR-PARK trip in queue targeting home.
            heading_home = False
            t = getattr(owner, "current_trip", None)
            if t and t.stops and t.stops[-1].station_id == home:
                heading_home = True
            if not heading_home:
                try:
                    for q in list(owner.cmd_queue.items):
                        if getattr(q, "stops", None) and q.stops[-1].station_id == home:
                            heading_home = True
                            break
                except Exception:
                    pass
            if not heading_home:
                continue

            # Is a non-owner squatting on home?
            squatter = next(
                (a for a in self.fleet
                 if a.agv_id != owner.agv_id
                 and a.current_node == home
                 and a.state in ("idle", "parked", "charging")
                 and getattr(a, "current_trip", None) is None
                 and not list(a.cmd_queue.items)
                 and not self.is_paused(a.agv_id)),
                None,
            )
            if squatter is None:
                continue

            # Pick an alternative bay/staging for the squatter.
            occupied = {a.current_node for a in self.fleet if a.current_node in park_nodes}
            occupied.add(home)  # owner is en route, treat as taken
            home_bays_owned = {
                getattr(a, "start_node", None): a.agv_id
                for a in self.fleet if getattr(a, "start_node", None) in park_nodes
            }
            # Prefer squatter's own home if free.
            squatter_home = getattr(squatter, "start_node", None)
            target = None
            if squatter_home and squatter_home in park_nodes and squatter_home not in occupied:
                target = squatter_home
            else:
                # Prefer staging waypoints to avoid stealing another bay.
                for n in staging + all_bays:
                    if n in occupied:
                        continue
                    bay_owner = home_bays_owned.get(n)
                    if bay_owner and bay_owner != squatter.agv_id:
                        continue
                    target = n
                    break
            if target is None:
                log.info("evict-home-bay: no free spot for squatter %s on %s", squatter.agv_id, home)
                continue

            log.info(
                "evict-home-bay: %s squatting on %s (owner %s inbound) -> moving to %s",
                squatter.agv_id, home, owner.agv_id, target,
            )
            trip = Trip(
                trip_id=f"TR-EVICT-{uuid.uuid4().hex[:6]}",
                stops=[Stop(station_id=target, op="move")],
            )
            squatter.submit_priority(trip)
            self._publish_recall_trip(squatter, trip)
            self._evicted_at[squatter.agv_id] = time.time()

    def _recall_idle_to_bay(self, agvs: list) -> None:
        """Park idle AGVs at the LEAST-OBSTRUCTING free charging bay or
        staging waypoint. We score every available depot by how much its
        path crosses higher-priority peers' planned corridors, and pick
        the depot with the smallest overlap (ties broken by distance).
        This keeps idle AGVs from parking on top of a busy peer's route.
        """
        all_bays = ["H01", "H02", "H03"]
        staging_nodes = ["W34", "W38"]
        park_nodes = all_bays + staging_nodes
        occupied: set = {a.current_node for a in self.fleet if a.current_node in park_nodes}
        in_flight: set = set()
        for a in self.fleet:
            if hasattr(a, "current_trip") and a.current_trip and a.current_trip.stops:
                final_stop = a.current_trip.stops[-1].station_id
                if final_stop in park_nodes:
                    in_flight.add(final_stop)
        claimed = occupied | in_flight
        used: set = set()

        # Reservations = union of busy peers' full planned paths.
        # Home-bay return corridors are no longer reserved — AGVs are
        # not bound to a specific bay, so the "return path to start_node"
        # concept does not apply to auto-park anymore.
        def _busy_reservations(skip_id: str) -> set[str]:
            out: set[str] = set()
            for peer in self.fleet:
                if peer.agv_id == skip_id:
                    continue
                # Currently-planned path for busy peers.
                if getattr(peer, "payload_count", 0) > 0 or \
                        getattr(peer, "current_trip", None) is not None:
                    try:
                        out.update(peer.planned_path_nodes())
                    except Exception:
                        pass
            return out

        for agv in agvs:
            # No fixed home bay — the candidate pool is the full set of
            # parking/staging nodes minus those occupied or reserved by
            # another AGV in this sweep. Charging bays are preferred over
            # staging waypoints when both are free (so low-battery AGVs
            # still get a charge), but no AGV "owns" any specific bay.
            avail_bays = [
                b for b in all_bays
                if b not in claimed and b not in used
            ]
            avail_staging = [
                s for s in staging_nodes
                if s not in claimed and s not in used
            ]
            avail = avail_bays or avail_staging
            if not avail:
                log.info(
                    "auto-park: %s no free bay (claimed=%s, used=%s)",
                    agv.agv_id, sorted(claimed), sorted(used),
                )
                continue
            reservations = _busy_reservations(agv.agv_id)
            idle_seconds = max(0.0, time.time() - (agv.idle_since or 0))
            # Tolerance grows with idle time so AGVs don't camp forever
            # when overlap == 0 is unattainable in a 5-AGV fleet.
            overlap_tolerance = max(1, int(idle_seconds // 30))

            def _score(node: str) -> tuple[int, float]:
                # Dijkstra-based graph distance (and overlap with busy peers).
                # Falls back to a large sentinel if the node is unreachable.
                try:
                    path = self.routing.shortest_path(agv.current_node, node)
                except Exception:
                    path = None
                if not path:
                    return (10**6, float("inf"))
                overlap = sum(1 for n in path[1:] if n in reservations)
                # Path length in edge count is a good proxy for Dijkstra
                # weighted distance on this uniform-weight graph; if the
                # routing table exposes edge weights, prefer that.
                try:
                    dist = self.routing.distance(agv.current_node, node)
                except Exception:
                    dist = float(len(path) - 1)
                return (overlap, dist)

            depot = min(avail, key=_score)
            score = _score(depot)
            # Is THIS AGV's current node on a busy peer's planned path? If yes,
            # staying put IS the blockage — we must move even if every depot
            # has some overlap. Pick min-overlap option and go.
            on_busy_path = agv.current_node in reservations
            tolerated = score[0] <= overlap_tolerance or idle_seconds >= 60
            if score[0] > 0 and not on_busy_path and not tolerated:
                log.info(
                    "auto-park: skip %s (best option %s overlaps %d busy node(s), idle %.0fs, tol=%d) — will retry",
                    agv.agv_id, depot, score[0], idle_seconds, overlap_tolerance,
                )
                continue
            if score[0] > 0 and not on_busy_path and tolerated:
                log.info(
                    "auto-park: %s tolerating %d overlap node(s) for %s (idle %.0fs >= tol=%d or >=60s)",
                    agv.agv_id, score[0], depot, idle_seconds, overlap_tolerance,
                )
            if score[0] > 0 and on_busy_path:
                log.info(
                    "auto-park: %s is BLOCKING peer at %s — forcing move to %s "
                    "despite %d overlap node(s)",
                    agv.agv_id, agv.current_node, depot, score[0],
                )
            used.add(depot)
            trip = Trip(trip_id=f"TR-PARK-{uuid.uuid4().hex[:6]}", stops=[Stop(station_id=depot, op="move")])
            agv.submit_priority(trip)
            self._publish_recall_trip(agv, trip)
            log.info(
                "auto-park: %s -> nearest free bay %s (idle %.0fs, overlap=%d w/ busy peers)",
                agv.agv_id, depot, (time.time() - (agv.idle_since or 0)), score[0],
            )

    def _cmd_recall_low_battery(self, p: dict) -> None:
        """Recall up to N AGVs (default 3) with the lowest battery to free
        charging bays. Skips AGVs already on a bay or carrying payload.
        """
        n = int(p.get("count") or 3)
        threshold = float(p.get("threshold") if p.get("threshold") is not None else self.cfg.battery_min_dispatch)
        # Candidates: not already on a bay, not carrying payload, below threshold.
        # Match "depleted" semantics: include AGVs at/below the threshold,
        # AND any AGV whose state is already "depleted" (regardless of how
        # battery_pct rounds). Allow recall even with payload — depleted
        # AGVs cannot safely complete trips.
        candidates = [
            a for a in self.fleet
            if a.current_node not in ("H01", "H02", "H03")
            and (a.battery_pct <= threshold or a.state == "depleted")
        ]
        candidates.sort(key=lambda a: a.battery_pct)
        candidates = candidates[:n]
        if not candidates:
            self._reply(p.get("request_id"), True, {"recalled": [], "note": f"No AGVs below {threshold:.0f}% available for recall."})
            return
        # Assign each candidate a DISTINCT, currently-FREE bay. Do NOT evict —
        # eviction + recall trips run concurrently and create routing cycles
        # in this layout. If no bay is free, the candidate is skipped.
        all_bays = ["H01", "H02", "H03"]
        # Bays with someone on them are off-limits.
        occupied_bays: set[str] = {a.current_node for a in self.fleet if a.current_node in all_bays}
        recalled: list[dict] = []
        skipped: list[dict] = []
        used_bays: set[str] = set()
        for agv in candidates:
            def _dist(node: str, _agv=agv) -> float:
                if self.routing is None or not _agv.current_node:
                    return float("inf")
                try:
                    return self.routing.distance(_agv.current_node, node)
                except Exception:
                    return float("inf")
            avail = [b for b in all_bays if b not in occupied_bays and b not in used_bays]
            depot: Optional[str] = None
            evicted: Optional[str] = None
            if avail:
                # Build a reservation set covering BOTH peers' planned paths
                # AND bays already assigned in this same recall sweep, so two
                # depleted AGVs never converge on the same corridor.
                reservations: set[str] = set()
                for peer in self.fleet:
                    if peer.agv_id == agv.agv_id:
                        continue
                    try:
                        reservations.update(peer.planned_path_nodes())
                    except Exception:
                        pass
                for r in recalled:
                    try:
                        path = self.routing.shortest_path(r.get("from"), r.get("to")) or []
                        reservations.update(path)
                    except Exception:
                        pass

                def _overlap(node: str, _agv=agv) -> int:
                    try:
                        path = self.routing.shortest_path(_agv.current_node, node) or []
                    except Exception:
                        path = []
                    return sum(1 for n in path[1:] if n in reservations)

                def _score(node: str, _agv=agv) -> tuple[int, float]:
                    return (_overlap(node, _agv), _dist(node, _agv))

                home = getattr(agv, "start_node", None)
                # Take home bay only if it doesn't conflict; otherwise pick
                # the bay with smallest (overlap, distance) score.
                if home in avail and _overlap(home) == 0:
                    depot = home
                else:
                    depot = min(avail, key=_score)
                # If best charging bay still overlaps a peer's planned path,
                # consider staging nodes (W34/W38) as a conflict-free fallback.
                # Charging is preferred only when both bay and route are clear;
                # otherwise park at staging and let the next sweep retry once
                # corridors clear.
                if _overlap(depot) > 0:
                    staging_nodes = ["W34", "W38"]
                    occ_staging: set[str] = {
                        a.current_node for a in self.fleet
                        if a.current_node in staging_nodes
                    }
                    staging_avail = [
                        s for s in staging_nodes
                        if s not in occ_staging and s not in used_bays
                    ]
                    if staging_avail:
                        best_stage = min(staging_avail, key=_score)
                        if _overlap(best_stage) < _overlap(depot):
                            log.info(
                                "recall_low_battery: %s bay %s overlaps %d node(s); "
                                "diverting to staging %s (overlap %d) — will retry charge next sweep",
                                agv.agv_id, depot, _overlap(depot),
                                best_stage, _overlap(best_stage),
                            )
                            depot = best_stage
            else:
                # All bays occupied. Evict ONLY a fully-charged occupant
                # (battery >= 99%) — they no longer need the bay. We do NOT
                # dispatch the depleted AGV's recall in the same sweep
                # (concurrent evict + recall caused deadlocks before). The
                # next 5s auto-recall sweep will assign the freed bay.
                for bay in sorted(all_bays, key=_dist):
                    if bay in used_bays:
                        continue
                    occupant: Optional[AGV] = None
                    for other in self.fleet:
                        if other.agv_id == agv.agv_id:
                            continue
                        if other.current_node == bay and other.state in ("idle", "charging"):
                            occupant = other
                            break
                    if occupant is None or occupant.battery_pct < 99.0:
                        continue
                    neighbour = self._nearest_non_bay_node(occupant)
                    if neighbour is None:
                        continue
                    evict_trip = Trip(
                        trip_id=f"TR-EVICT-{uuid.uuid4().hex[:6]}",
                        stops=[Stop(station_id=neighbour, op="move")],
                    )
                    occupant.submit_priority(evict_trip)
                    log.info(
                        "auto-recall: evicting fully-charged %s (%.1f%%) from %s -> %s "
                        "(next sweep will dispatch %s at %.1f%%)",
                        occupant.agv_id, occupant.battery_pct, bay, neighbour,
                        agv.agv_id, agv.battery_pct,
                    )
                    skipped.append({
                        "agv_id": agv.agv_id,
                        "battery_pct": round(agv.battery_pct, 1),
                        "reason": f"freed {bay} by evicting fully-charged {occupant.agv_id}; will retry next sweep",
                    })
                    # Skip this candidate this round — it will be picked up
                    # next sweep when the bay is free.
                    depot = None
                    break
            if not depot:
                # If we already appended to skipped above (eviction path),
                # don't append again.
                if not (skipped and skipped[-1].get("agv_id") == agv.agv_id):
                    skipped.append({"agv_id": agv.agv_id, "battery_pct": round(agv.battery_pct, 1), "reason": "all charging bays occupied; waiting for one to free up"})
                continue
            used_bays.add(depot)
            trip = Trip(trip_id=f"TR-RECALL-{uuid.uuid4().hex[:6]}", stops=[Stop(station_id=depot, op="move")])
            agv._recall_to_charge = True  # bypass depleted-state gate
            agv.submit_priority(trip)
            self._publish_recall_trip(agv, trip)
            log.info("recall_low_battery: %s (%.1f%%) -> %s", agv.agv_id, agv.battery_pct, depot)
            entry = {"agv_id": agv.agv_id, "battery_pct": round(agv.battery_pct, 1), "bay": depot}
            if evicted:
                entry["evicted"] = evicted
            recalled.append(entry)
        self._reply(p.get("request_id"), True, {"recalled": recalled, "skipped": skipped})

    def _cmd_list_pending_tasks(self, p: dict) -> None:
        """Return the dispatcher's pending (unassigned) task queue."""
        if self.dispatcher is None:
            self._reply(p.get("request_id"), True, {"pending": []})
            return
        out = []
        for t in list(self.dispatcher.pending):
            out.append({
                "task_id": t.task_id,
                "pickup": t.pickup,
                "drop": t.drop,
                "priority": t.priority,
                "units": getattr(t, "units", 1),
                "product_id": getattr(t, "product_id", None),
                "batch_id": getattr(t, "batch_id", None),
                "created_ts": getattr(t, "created_ts", None),
            })
        self._reply(p.get("request_id"), True, {"pending": out, "count": len(out)})

    def _cmd_cancel_pending_task(self, p: dict) -> None:
        """Remove queued/unassigned tasks from the dispatcher.pending deque.

        Accepts:
          - task_id: cancel a specific pending task
          - task_ids: cancel multiple pending tasks
          - all: True → cancel every pending task
        Tasks already assigned to an AGV are NOT touched (use cancel_trip for those).
        """
        if self.dispatcher is None:
            self._reply(p.get("request_id"), False, error="dispatcher unavailable")
            return
        cancel_all = bool(p.get("all"))
        targets: set[str] = set()
        if p.get("task_id"):
            targets.add(str(p["task_id"]))
        for tid in (p.get("task_ids") or []):
            if tid:
                targets.add(str(tid))
        if not cancel_all and not targets:
            self._reply(p.get("request_id"), False, error="task_id, task_ids, or all=true required")
            return
        pending = list(self.dispatcher.pending)
        kept: list = []
        removed: list[dict] = []
        for t in pending:
            if cancel_all or t.task_id in targets:
                removed.append({
                    "task_id": t.task_id,
                    "pickup": t.pickup,
                    "drop": t.drop,
                    "units": getattr(t, "units", 1),
                    "batch_id": getattr(t, "batch_id", None),
                })
            else:
                kept.append(t)
        self.dispatcher.pending.clear()
        for t in kept:
            self.dispatcher.pending.append(t)
        if self.publisher is not None:
            for r in removed:
                try:
                    self.publisher.publish_event(
                        CHANNEL_TASK_CANCELLED,
                        {**r, "reason": "cancelled by chatbot", "ts": time.time()},
                    )
                except Exception as exc:
                    log.warning("publish task:cancelled failed: %s", exc)
        log.info("chatbot cancel_pending_task: removed %d, kept %d", len(removed), len(kept))
        self._reply(
            p.get("request_id"), True,
            {"cancelled": removed, "count": len(removed), "remaining_pending": len(kept)},
        )

    def _reply(self, request_id: Optional[str], ok: bool, data: dict | None = None, error: str | None = None) -> None:
        if not request_id:
            return
        body = {"request_id": request_id, "ok": ok, "ts": time.time()}
        if data is not None:
            body["data"] = data
        if error:
            body["error"] = error
        try:
            self.client.publish(REPLY_CHANNEL, json.dumps(body))
        except Exception as exc:
            log.warning("reply publish failed: %s", exc)
