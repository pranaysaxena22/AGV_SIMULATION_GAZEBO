"""Smart dispatcher with proximity-based task bundling and load awareness.

Instead of assigning one task per AGV, this dispatcher:
1. Groups pending tasks whose pickup/drop stations are within BUNDLE_RADIUS
2. Assigns bundled multi-stop trips to AGVs with remaining capacity
3. Prefers AGVs closest to the first pickup in the bundle
4. Respects AGV capacity — won't assign more pickups than remaining slots
5. Orders stops within a bundle by nearest-neighbor to minimize total distance
"""
from __future__ import annotations

import logging
import math
import time
import uuid
from collections import deque
from typing import Optional

import simpy

from .agv import AGV, Stop, Trip
from .config import Config
from .routing import RoutingTable
from .tasks import Task
from .telemetry import (
    CHANNEL_TASK_ASSIGNED,
    CHANNEL_TRIP_REQUESTED,
    TelemetryPublisher,
)

log = logging.getLogger("agv-simulator.dispatcher")


def _euclidean(coords: dict[str, tuple[float, float]], a: str, b: str) -> float:
    ax, ay = coords.get(a, (0, 0))
    bx, by = coords.get(b, (0, 0))
    return math.hypot(bx - ax, by - ay)


class SmartDispatcher:
    def __init__(
        self,
        env: simpy.Environment,
        publisher: TelemetryPublisher,
        fleet: list[AGV],
        coords: dict[str, tuple[float, float]],
        routing: RoutingTable,
        cfg: Config,
    ) -> None:
        self.env = env
        self.publisher = publisher
        self.fleet = fleet
        self.coords = coords
        self.routing = routing
        self.cfg = cfg
        self.bundle_radius = cfg.bundle_radius
        self.pending: deque[Task] = deque()
        self.tasks_by_trip: dict[str, list[Task]] = {}
        self.all_tasks_by_trip: dict[str, list[Task]] = {}
        # Per-station buffer fullness threshold: refuse new drops when a
        # downstream station already has >= this many in-flight inbound tasks.
        self.buffer_capacity = max(1, getattr(cfg, "buffer_capacity", 4))
        # Bottleneck roles are kept fed even under buffer pressure.
        self.bottleneck_roles = ("reflow", "ict")
        self._stations_by_role = getattr(cfg, "stations_by_role", {}) or {}

    def submit(self, task: Task) -> None:
        self.pending.append(task)
        # Pre-reserve a best-fit AGV at submit time so the pending UI row
        # surfaces the AGV badge immediately and subsequent submits can
        # exclude this AGV from their candidate set (capacity-aware queueing).
        try:
            agv = self._pick_best_agv_for_pending(task)
        except Exception:
            agv = None
        if agv is not None:
            task.assigned_ts = None  # still pending; assigned_ts set on dispatch
            try:
                setattr(task, "reserved_agv_id", agv.agv_id)
            except Exception:
                pass
            # Publish a provisional trip:requested so the UI's tripsByAgv
            # map populates and the pending card mirrors in-transit layout.
            if not getattr(task, "trip_id", None):
                task.trip_id = f"TR-PEND-{uuid.uuid4().hex[:6]}"
            try:
                self.publisher.publish_event(
                    CHANNEL_TRIP_REQUESTED,
                    {
                        "trip_id": task.trip_id,
                        "agv_id": agv.agv_id,
                        "stops": [
                            {
                                "station_id": task.pickup,
                                "x": self.coords.get(task.pickup, (0, 0))[0],
                                "y": self.coords.get(task.pickup, (0, 0))[1],
                                "op": "pickup",
                            },
                            {
                                "station_id": task.drop,
                                "x": self.coords.get(task.drop, (0, 0))[0],
                                "y": self.coords.get(task.drop, (0, 0))[1],
                                "op": "drop",
                            },
                        ],
                        "bundled_tasks": 1,
                        "ts": time.time(),
                        "provisional": True,
                    },
                )
            except Exception as exc:
                log.warning("publish provisional trip:requested failed: %s", exc)

    def _reserved_agv_ids(self) -> set[str]:
        """AGV ids already reserved by other pending tasks."""
        out: set[str] = set()
        for t in self.pending:
            rid = getattr(t, "reserved_agv_id", None)
            if rid:
                out.add(rid)
        return out

    def _pick_best_agv_for_pending(self, anchor_task: Task) -> Optional[AGV]:
        """Reserve a best-fit AGV for a pending task. Prefers AGVs not yet
        reserved by other pending tasks; falls back to least-loaded AGV (by
        reservation count) so every pending row surfaces an AGV badge even
        when there are more pending tasks than AGVs."""
        reserved_counts: dict[str, int] = {}
        for t in self.pending:
            rid = getattr(t, "reserved_agv_id", None)
            if rid:
                reserved_counts[rid] = reserved_counts.get(rid, 0) + 1
        all_eligible = [
            agv for agv in self.fleet
            if agv.state in ("idle", "charging", "moving", "loading", "unloading")
            and agv.battery_pct >= self.cfg.battery_min_dispatch
        ]
        if not all_eligible:
            return None
        bays = {"H01", "H02", "H03"}
        def score(agv: AGV) -> tuple[int, int, float]:
            return (
                reserved_counts.get(agv.agv_id, 0),
                1 if agv.current_node in bays else 0,
                self.routing.distance(agv.current_node, anchor_task.pickup),
            )
        return min(all_eligible, key=score)

    def _inbound_count(self, station_id: str) -> int:
        active_trips = {a.trip_id for a in self.fleet if a.trip_id}
        interrupted_trips: set[str] = set()
        for a in self.fleet:
            if a.interrupted_trip is not None:
                interrupted_trips.add(a.interrupted_trip.trip_id)
            for t in a.interrupted_trips:
                interrupted_trips.add(t.trip_id)
        stale = [
            tid for tid in self.tasks_by_trip
            if tid not in active_trips and tid not in interrupted_trips
        ]
        for tid in stale:
            self.tasks_by_trip.pop(tid, None)
        n = 0
        for tasks in self.tasks_by_trip.values():
            for t in tasks:
                if t.drop == station_id:
                    n += 1
        return n

    def _is_bottleneck_drop(self, task: Task) -> bool:
        if task.stage_to and task.stage_to in self.bottleneck_roles:
            return True
        for role in self.bottleneck_roles:
            if task.drop in (self._stations_by_role.get(role) or []):
                return True
        return False

    def _buffer_blocked(self, task: Task) -> bool:
        if task.priority == "high":
            return False
        if self._is_bottleneck_drop(task):
            return False
        return self._inbound_count(task.drop) >= self.buffer_capacity

    def run(self):
        # Batching window: when new tasks arrive, wait briefly to accumulate
        # more tasks for bundling before dispatching.
        batch_window = getattr(self.cfg, "batch_window_s", 3.0)
        while True:
            yield self.env.timeout(0.5)
            if not self.pending:
                continue
            # A task just appeared — wait the batch window to collect more.
            count_before = len(self.pending)
            if batch_window > 0 and count_before < 3:
                yield self.env.timeout(batch_window)
            self._dispatch_round()

    def _dispatch_round(self) -> None:
        """Try to assign all pending tasks, bundling nearby ones."""
        assigned_tasks: list[Task] = []
        # Within-round reservation cache: the trip we just submitted hasn't
        # been picked up by the AGV's run-loop yet, so planned_path_nodes()
        # returns empty. Pre-populate from the stops we just assigned so
        # subsequent _pick_best_agv calls in the SAME round see the corridor.
        self._round_reservations: set[str] = set()

        # Order pending by (priority, FIFO) so high-priority tasks go first
        # and same-priority tasks honor arrival order regardless of which AGV
        # they're reserved against.
        priority_rank = {"high": 0, "normal": 1, "low": 2}
        ordered = sorted(
            self.pending,
            key=lambda t: (
                priority_rank.get(getattr(t, "priority", "normal"), 1),
                getattr(t, "created_ts", 0.0),
            ),
        )
        self.pending = deque(ordered)

        deferred: list[Task] = []
        while self.pending:
            head = self.pending[0]
            if self._buffer_blocked(head):
                deferred.append(self.pending.popleft())
                continue
            # Forecast pickup-side contention: if pickup node is currently
            # loading/unloading by another AGV, defer rather than queueing a
            # second AGV behind it (this is the S01/S04 repeated-block path).
            if self._pickup_locked_by_peer(head.pickup):
                deferred.append(self.pending.popleft())
                continue

            agv = self._pick_best_agv(head)
            if agv is None:
                break

            # HARD-DEFER if this candidate's FULL trip path (pickup→drop)
            # crosses ANY node already reserved this round OR any peer's
            # planned path. Score is a tiebreaker only; we never knowingly
            # create a conflict at pickup, drop, OR any intermediate node.
            try:
                pickup_path = self.routing.shortest_path(agv.current_node, head.pickup) or []
                drop_path = self.routing.shortest_path(head.pickup, head.drop) or []
            except Exception:
                pickup_path, drop_path = [], []
            full_path = pickup_path + drop_path[1:]
            # Peer reservations: each busy peer's path to NEXT stop (full)
            # + every remaining stop NODE (not their connecting paths). This
            # blocks dispatch when our drop/pickup IS a peer's future drop,
            # but still allows dispatch when only mid-corridor nodes overlap.
            peer_reservations: set[str] = set(self._round_reservations)
            for peer in self.fleet:
                if peer.agv_id == agv.agv_id:
                    continue
                if peer.state in ("idle", "charging") and not peer.cmd_queue.items:
                    continue
                if peer.current_node:
                    peer_reservations.add(peer.current_node)
                try:
                    trip = getattr(peer, "current_trip", None)
                    idx = getattr(peer, "current_stop_idx", 0)
                    if trip and trip.stops:
                        # Full path to immediate next stop (corridor contention).
                        if idx < len(trip.stops):
                            seg = self.routing.shortest_path(peer.current_node, trip.stops[idx].station_id) or []
                            peer_reservations.update(seg)
                        # Stop NODES for the rest (terminal contention only).
                        for s in trip.stops[idx + 1:]:
                            peer_reservations.add(s.station_id)
                except Exception:
                    pass
            # Check our pickup + drop terminal nodes always; intermediate
            # path only against immediate-corridor reservations.
            terminal_conflict = head.pickup in peer_reservations or head.drop in peer_reservations
            mid_conflict = [n for n in full_path[1:-1] if n in self._round_reservations or n in {p.current_node for p in self.fleet if p.agv_id != agv.agv_id and p.state == "blocked"}]
            conflicting = (
                ([head.pickup] if head.pickup in peer_reservations else [])
                + ([head.drop] if head.drop in peer_reservations else [])
                + mid_conflict
            )
            if terminal_conflict or mid_conflict:
                pass  # fall through to defer log
            if conflicting:
                log.info(
                    "dispatch defer: %s -> %s would cross %d reserved node(s) %s — waiting next round",
                    agv.agv_id, head.pickup, len(conflicting), conflicting[:5],
                )
                deferred.append(self.pending.popleft())
                continue

            remaining_capacity = agv.capacity - agv.payload_count
            if remaining_capacity <= 0:
                break

            # Bundling grace: if another pending task is BUNDLE-COMPATIBLE
            # (same pickup, or within bundle_radius via _is_nearby) AND
            # arrived within the last 2 seconds, hold off this round so all
            # sibling tasks coalesce into one trip. Handles chat-agent
            # bursts where multiple create_pcb_task calls land a fraction
            # of a second apart for the same logical user request.
            now = time.time()
            head_age = now - getattr(head, "created_ts", now)
            recent_siblings = [
                t for t in self.pending
                if t is not head
                and (now - getattr(t, "created_ts", now)) < 2.0
                and (t.pickup == head.pickup or self._is_nearby(head, t))
            ]
            if recent_siblings and head_age < 2.0:
                log.info(
                    "dispatch grace: %s -> %s waiting for %d sibling task(s) (head age %.1fs)",
                    head.pickup, head.drop, len(recent_siblings), head_age,
                )
                break  # next round will retry; siblings will be in pending then

            # Take the first task as anchor
            anchor = self.pending.popleft()
            bundle = [anchor]

            # Try to bundle more nearby tasks that fit in capacity.
            # Do NOT bundle across explicit AGV reservations — if the user
            # pinned a task to a specific AGV, honor FIFO/priority ordering
            # rather than coalescing all same-AGV tasks into one trip.
            anchor_reserved = getattr(anchor, "reserved_agv_id", None)
            extras_to_remove: list[Task] = []
            bundle_units = anchor.units or 1
            for task in list(self.pending):
                if bundle_units >= remaining_capacity:
                    break
                if self._buffer_blocked(task):
                    continue
                task_reserved = getattr(task, "reserved_agv_id", None)
                if anchor_reserved or task_reserved:
                    continue
                if self._is_nearby(anchor, task):
                    task_units = task.units or 1
                    if bundle_units + task_units > remaining_capacity:
                        continue
                    bundle.append(task)
                    extras_to_remove.append(task)
                    bundle_units += task_units

            for t in extras_to_remove:
                self.pending.remove(t)

            # Order stops optimally (nearest-neighbor from AGV position)
            stops = self._build_ordered_stops(agv, bundle)
            self._assign(bundle, stops, agv)
            assigned_tasks.extend(bundle)

        # Re-queue any deferred (buffer-blocked) tasks at the back so they
        # don't head-of-line block when buffers drain on the next round.
        for t in deferred:
            self.pending.append(t)
        if deferred:
            log.info("dispatch round: %d tasks deferred (buffer full)", len(deferred))

        if assigned_tasks:
            bundled = sum(1 for _ in assigned_tasks) - len(
                [t for t in assigned_tasks if not any(
                    t2 for t2 in assigned_tasks if t2 is not t and t2.trip_id == t.trip_id
                )]
            )
            log.info(
                "dispatch round: %d tasks assigned (%d bundled into multi-stop trips)",
                len(assigned_tasks),
                len(assigned_tasks) - len(set(t.trip_id for t in assigned_tasks if t.trip_id)),
            )

    def _is_nearby(self, anchor: Task, candidate: Task) -> bool:
        """Check if candidate's stations are within bundle_radius of anchor's.
        Same pickup always bundles — one trip with multiple drops is
        strictly cheaper than separate trips that all start at the same
        station.
        """
        if anchor.pickup == candidate.pickup:
            return True
        d_pickup = _euclidean(self.coords, anchor.pickup, candidate.pickup)
        d_drop = _euclidean(self.coords, anchor.drop, candidate.drop)
        d_cross = _euclidean(self.coords, anchor.drop, candidate.pickup)
        return min(d_pickup, d_drop, d_cross) <= self.bundle_radius

    def _pick_best_agv(self, anchor_task: Task) -> Optional[AGV]:
        """Pick the idle AGV with capacity closest to the anchor pickup,
        biased AWAY from candidates whose route to the pickup would overlap
        a peer's planned corridor. This forecasts contention BEFORE dispatch
        so two AGVs don't converge on the same node (esp. S01/S04 pickups).
        """
        # Honor the reservation made at submit time so the AGV reported on
        # the pending card matches the AGV that actually executes.
        reserved_id = getattr(anchor_task, "reserved_agv_id", None)
        if reserved_id:
            for a in self.fleet:
                if a.agv_id == reserved_id and a.state in ("idle", "charging") \
                        and not a.cmd_queue.items \
                        and a.payload_count < a.capacity \
                        and a.battery_pct >= self.cfg.battery_min_dispatch:
                    return a
            # Reserved AGV no longer free — fall through to fresh pick.
        candidates = [
            agv for agv in self.fleet
            if agv.state in ("idle", "charging")
            and len(agv.cmd_queue.items) == 0
            and agv.payload_count < agv.capacity
            and agv.battery_pct >= self.cfg.battery_min_dispatch
        ]
        if not candidates:
            return None

        # Build reservation set covering every busy peer's planned path AND
        # the pickup/drop nodes they're currently holding. This lets us
        # forecast head-on contention before issuing the trip.
        reservations: set[str] = set(getattr(self, "_round_reservations", set()))
        for peer in self.fleet:
            if peer.state in ("idle", "charging") and not peer.cmd_queue.items:
                continue
            try:
                reservations.update(peer.planned_path_nodes())
            except Exception:
                pass
            if peer.current_node:
                reservations.add(peer.current_node)

        def _overlap(agv: AGV) -> int:
            try:
                path = self.routing.shortest_path(agv.current_node, anchor_task.pickup) or []
            except Exception:
                path = []
            return sum(1 for n in path[1:] if n in reservations)

        bays = {"H01", "H02", "H03"}

        def _on_bay(agv: AGV) -> int:
            # Penalty for pulling an AGV off a charging bay when an
            # equally-clear non-bay AGV (parked at W34/W38 etc.) is available.
            # Bays are scarce (3 bays for 5 AGVs); leaving them free for
            # battery-low peers reduces home-bay deadlocks on return.
            return 1 if agv.current_node in bays else 0

        def score(agv: AGV) -> tuple[int, int, float]:
            # (corridor_overlap, prefer_non_bay, distance)
            return (
                _overlap(agv),
                _on_bay(agv),
                self.routing.distance(agv.current_node, anchor_task.pickup),
            )

        return min(candidates, key=score)

    def _pickup_locked_by_peer(self, station: str) -> bool:
        """True if `station` is currently held by a peer that's mid-trip there
        (loading/unloading). Used to defer tasks whose pickup is contested.
        """
        for peer in self.fleet:
            if peer.current_node == station and peer.state in ("loading", "unloading", "blocked"):
                return True
        return False

    def _build_ordered_stops(self, agv: AGV, bundle: list[Task]) -> list[Stop]:
        """Build stops in nearest-neighbor order starting from AGV position."""
        # Separate pickups and drops
        pickups = [(t, t.pickup) for t in bundle]
        drops = [(t, t.drop) for t in bundle]

        # Order pickups by nearest-neighbor from AGV
        ordered_pickups: list[tuple[Task, str]] = []
        current = agv.current_node
        remaining = list(pickups)
        while remaining:
            nearest = min(remaining, key=lambda x: self.routing.distance(current, x[1]))
            ordered_pickups.append(nearest)
            current = nearest[1]
            remaining.remove(nearest)

        # Order drops by nearest-neighbor from last pickup
        ordered_drops: list[tuple[Task, str]] = []
        remaining = list(drops)
        while remaining:
            nearest = min(remaining, key=lambda x: self.routing.distance(current, x[1]))
            ordered_drops.append(nearest)
            current = nearest[1]
            remaining.remove(nearest)

        # Build stop list: all pickups first, then all drops
        stops: list[Stop] = []
        for task, station in ordered_pickups:
            stops.append(Stop(station_id=station, op="pickup", units=task.units or 1))
        for task, station in ordered_drops:
            stops.append(Stop(station_id=station, op="drop", units=task.units or 1))
        return stops

    def _assign(self, tasks: list[Task], stops: list[Stop], agv: AGV) -> None:
        trip_id = f"TR-{uuid.uuid4().hex[:8]}"
        trip = Trip(trip_id=trip_id, stops=stops)
        now = time.time()

        for task in tasks:
            task.assigned_ts = now
            task.trip_id = trip_id

        self.tasks_by_trip[trip_id] = tasks
        self.all_tasks_by_trip[trip_id] = list(tasks)
        agv.submit(trip)

        # Populate within-round reservations so the next _pick_best_agv call
        # in this same dispatch cycle sees this trip's corridor (the AGV's
        # run-loop hasn't promoted the trip yet, so planned_path_nodes()
        # would otherwise return empty).
        try:
            src = agv.current_node
            for stop in stops:
                p = self.routing.shortest_path(src, stop.station_id) or []
                self._round_reservations.update(p)
                src = stop.station_id
        except Exception:
            pass

        try:
            self.publisher.publish_event(
                CHANNEL_TRIP_REQUESTED,
                {
                    "trip_id": trip_id,
                    "agv_id": agv.agv_id,
                    "stops": [
                        {
                            "station_id": s.station_id,
                            "x": self.coords.get(s.station_id, (0, 0))[0],
                            "y": self.coords.get(s.station_id, (0, 0))[1],
                            "op": s.op,
                            "units": s.units,
                        }
                        for s in stops
                    ],
                    "bundled_tasks": len(tasks),
                    "ts": now,
                },
            )
            for task in tasks:
                self.publisher.publish_event(
                    CHANNEL_TASK_ASSIGNED,
                    {"task_id": task.task_id, "trip_id": trip_id, "ts": now},
                )
        except Exception as exc:
            log.warning("publish trip/task assigned failed: %s", exc)

        stations = " -> ".join(s.station_id for s in stops)
        log.info(
            "assigned %d tasks -> %s on %s [%s] (cap %d/%d)",
            len(tasks), trip_id, agv.agv_id, stations,
            agv.payload_count, agv.capacity,
        )
