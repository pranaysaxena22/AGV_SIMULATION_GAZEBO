"""Centralized Traffic Manager — node-level locking for collision avoidance.

Each graph node can be held by at most one AGV at a time. Before traversing
a segment a→b, the AGV must acquire the lock on b. After arriving at b it
releases a. This prevents two AGVs from occupying the same node.

Deadlock resolution: on timeout, detect circular waits. The lower-priority AGV
(higher numeric ID) force-releases its current node so the higher-priority AGV
can pass. It then re-acquires after the segment clears.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional

import simpy

log = logging.getLogger("agv-simulator.traffic")

PublishCb = Callable[[str, dict[str, Any]], None]


class DeadlockReroute(Exception):
    """Raised by acquire() when caller should reroute around a held node."""
    def __init__(self, blocked_node: str, is_cycle: bool = False) -> None:
        super().__init__(blocked_node)
        self.blocked_node = blocked_node
        self.is_cycle = is_cycle


class TrafficManager:
    def __init__(
        self,
        env: simpy.Environment,
        deadlock_timeout: float = 5.0,
        on_blocked: Optional[PublishCb] = None,
        on_resumed: Optional[PublishCb] = None,
        priority_fn: Optional[Callable[[str], int]] = None,
    ) -> None:
        self.env = env
        self.deadlock_timeout = deadlock_timeout
        self._locks: dict[str, str | None] = {}
        self._waiters: dict[str, list[tuple[str, simpy.Event]]] = {}
        self._waiting_for: dict[str, str] = {}
        self._agv_nodes: dict[str, str] = {}
        self._on_blocked = on_blocked
        self._on_resumed = on_resumed
        # Higher value = more important (e.g. carrying payload / on a task).
        # Used to pick the *loser* of a deadlock cycle so task-carrying AGVs
        # keep their original path and idle/parking-bound AGVs yield.
        self._priority_fn = priority_fn or (lambda _aid: 0)

    def acquire_immediate(self, agv_id: str, node_id: str) -> None:
        """Non-blocking acquire for initial placement (must be free)."""
        holder = self._locks.get(node_id)
        if holder is not None and holder != agv_id:
            raise RuntimeError(
                f"Cannot place {agv_id} on {node_id}: held by {holder}"
            )
        self._locks[node_id] = agv_id
        self._agv_nodes[agv_id] = node_id

    def _find_cycle(self, agv_id: str, target_node: str) -> list[str] | None:
        """Return the cycle [agv_id, ..., agv_id] or None."""
        holder = self._locks.get(target_node)
        if holder is None:
            return None
        chain = [agv_id]
        current = holder
        visited = {agv_id}
        while current and current not in visited:
            chain.append(current)
            visited.add(current)
            waiting_for_node = self._waiting_for.get(current)
            if waiting_for_node is None:
                return None
            current = self._locks.get(waiting_for_node)
        if current == agv_id:
            chain.append(agv_id)
            return chain
        return None

    def acquire(self, agv_id: str, node_id: str, allow_reroute: bool = False):
        """SimPy process: yields until the node is free, then locks it.

        If ``allow_reroute`` is True and a cycle is detected on timeout, the
        process raises ``DeadlockReroute`` so the caller can compute an
        alternate path (avoiding ``node_id``) instead of waiting forever.
        """
        yield_attempts = 0
        while True:
            holder = self._locks.get(node_id)
            if holder is None or holder == agv_id:
                self._locks[node_id] = agv_id
                self._agv_nodes[agv_id] = node_id
                return

            evt = self.env.event()
            waiters = self._waiters.setdefault(node_id, [])
            waiters.append((agv_id, evt))
            self._waiting_for[agv_id] = node_id

            blocked_at = self.env.now
            if self._on_blocked:
                self._on_blocked("traffic:blocked", {
                    "agv_id": agv_id,
                    "node": node_id,
                    "blocked_by": holder,
                    "ts": time.time(),
                })

            result = yield evt | self.env.timeout(self.deadlock_timeout)

            self._waiting_for.pop(agv_id, None)
            if (agv_id, evt) in waiters:
                waiters.remove((agv_id, evt))
            if not self._waiters.get(node_id):
                self._waiters.pop(node_id, None)

            if evt in result:
                self._locks[node_id] = agv_id
                self._agv_nodes[agv_id] = node_id
                waited_s = self.env.now - blocked_at
                if self._on_resumed and waited_s > 0:
                    self._on_resumed("traffic:resumed", {
                        "agv_id": agv_id,
                        "node": node_id,
                        "waited_s": round(waited_s, 3),
                        "ts": time.time(),
                    })
                return

            # Timeout path: detect cycle and let caller reroute.
            yield_attempts += 1
            if allow_reroute:
                cycle = self._find_cycle(agv_id, node_id)
                # Pick the loser of the cycle: lowest priority (e.g. idle /
                # parking-bound, no payload). Ties broken by highest numeric id
                # so the choice is deterministic. The loser is the one that
                # yields — task-carrying AGVs keep their original path.
                if cycle:
                    members = [m for m in cycle if m != agv_id] + [agv_id]
                    members = list(dict.fromkeys(members))
                    loser = min(
                        members,
                        key=lambda aid: (self._priority_fn(aid), -int(''.join(c for c in aid if c.isdigit()) or 0)),
                    )
                    if loser == agv_id:
                        log.warning(
                            "deadlock cycle %s — %s (loser by priority) yields around %s",
                            "→".join(cycle), agv_id, node_id,
                        )
                        if self._on_resumed:
                            self._on_resumed("traffic:resumed", {
                                "agv_id": agv_id, "node": node_id,
                                "waited_s": round(self.env.now - blocked_at, 3),
                                "ts": time.time(),
                            })
                        raise DeadlockReroute(node_id, is_cycle=True)
                # No cycle, but the holder is parked (not waiting on anyone).
                # After a few timeouts, the holder clearly isn't moving — give
                # up and route around it instead of waiting forever (e.g. an
                # AGV parked at H02 blocking a path through that bay).
                if yield_attempts >= 2:
                    log.warning(
                        "%s waited %.1fs on %s held by %s (parked) — rerouting",
                        agv_id, yield_attempts * self.deadlock_timeout, node_id, holder,
                    )
                    if self._on_resumed:
                        self._on_resumed("traffic:resumed", {
                            "agv_id": agv_id, "node": node_id,
                            "waited_s": round(self.env.now - blocked_at, 3),
                            "ts": time.time(),
                        })
                    raise DeadlockReroute(node_id)
            backoff = min(0.5 * yield_attempts + (hash(agv_id) % 20) * 0.05, 5.0)
            yield self.env.timeout(backoff)

    def release(self, agv_id: str, node_id: str) -> None:
        """Release the node lock, waking the next waiter if any."""
        holder = self._locks.get(node_id)
        if holder != agv_id:
            return
        self._locks[node_id] = None
        if self._agv_nodes.get(agv_id) == node_id:
            del self._agv_nodes[agv_id]

        waiters = self._waiters.get(node_id)
        if waiters:
            next_agv_id, evt = waiters.pop(0)
            if not evt.triggered:
                evt.succeed()
            if not waiters:
                del self._waiters[node_id]

    def is_held(self, node_id: str) -> bool:
        return self._locks.get(node_id) is not None

    def holder(self, node_id: str) -> str | None:
        return self._locks.get(node_id)
