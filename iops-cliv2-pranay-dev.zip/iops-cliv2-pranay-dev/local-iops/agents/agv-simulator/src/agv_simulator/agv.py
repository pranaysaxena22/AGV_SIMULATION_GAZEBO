"""SimPy AGV process with state machine.

States:
    idle -> moving -> loading -> unloading -> idle

Each AGV has a SimPy Store as a command queue. A command is a Trip:

    Trip(trip_id, stops=[Stop(station_id, op="pickup"|"drop")])

The AGV interpolates its (x, y) position along each path segment at
``cfg.tick_hz`` so telemetry can be sampled smoothly.

Day 2: every state transition fires ``on_state_change(agv)`` so
publishers can emit ``agv:state`` events without polling.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Callable, Literal, Optional

import simpy

log = logging.getLogger("agv-simulator.agv")

import networkx as nx

from .config import Config
from .routing import RoutingTable
from .traffic import DeadlockReroute, TrafficManager

State = Literal["idle", "moving", "loading", "unloading", "blocked", "charging", "depleted"]

PARKING_BAYS = frozenset({"H01", "H02", "H03"})

StateChangeCb = Callable[["AGV"], None]
StopDoneCb = Callable[["AGV", str, str, str], None]
TripCompleteCb = Callable[["AGV", str, dict, list["Stop"]], None]
TripInterruptedCb = Callable[["AGV", str, "Trip"], None]
EvictionRequestCb = Callable[["AGV", str], None]
ReservationCb = Callable[["AGV"], set[str]]


@dataclass
class Stop:
    station_id: str
    op: Literal["pickup", "drop", "move"] = "pickup"
    units: int = 0


@dataclass
class Trip:
    trip_id: str
    stops: list[Stop]


@dataclass
class AGV:
    agv_id: str
    start_node: str
    env: simpy.Environment
    cfg: Config
    routing: RoutingTable
    coords: dict[str, tuple[float, float]]
    cmd_queue: simpy.Store = field(init=False)
    _state: State = field(default="idle", repr=False)
    x: float = 0.0
    y: float = 0.0
    heading: float = 0.0
    speed: float = 0.0
    current_node: str = ""
    trip_id: str | None = None
    current_trip: Optional["Trip"] = field(default=None, repr=False)
    current_stop_idx: int = 0
    capacity: int = 3
    payload_count: int = 0
    battery_pct: float = 100.0
    origin_node: str | None = None
    dest_node: str | None = None
    traffic: Optional[TrafficManager] = field(default=None, repr=False)
    graph: Optional[nx.Graph] = field(default=None, repr=False)
    on_state_change: Optional[StateChangeCb] = field(default=None, repr=False)
    on_stop_done: Optional[StopDoneCb] = field(default=None, repr=False)
    on_trip_complete: Optional[TripCompleteCb] = field(default=None, repr=False)
    on_trip_interrupted: Optional[TripInterruptedCb] = field(default=None, repr=False)
    on_eviction_request: Optional[EvictionRequestCb] = field(default=None, repr=False)
    reservation_provider: Optional[ReservationCb] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self.cmd_queue = simpy.Store(self.env)
        self.x, self.y = self.coords[self.start_node]
        self.current_node = self.start_node
        self._run_proc: Optional[simpy.events.Process] = None
        self._move_proc: Optional[simpy.events.Process] = None
        self.interrupted_trip: Optional[Trip] = None
        self.interrupted_trips: list[Trip] = []
        self._estop_requested: bool = False
        # Set true while a recall-to-charge trip is in flight; lets a depleted
        # AGV move to a charging bay even though normal trips are gated off.
        self._recall_to_charge: bool = False
        self.idle_since: float | None = None
        if self.traffic is not None:
            self.traffic.acquire_immediate(self.agv_id, self.start_node)

    # ---- state property fires callback on transition ----
    @property
    def state(self) -> State:
        return self._state

    @state.setter
    def state(self, value: State) -> None:
        if value == self._state:
            return
        import time as _time
        if value == "idle" and self._state != "idle":
            self.idle_since = _time.time()
        elif value != "idle":
            self.idle_since = None
        self._state = value
        if self.on_state_change is not None:
            try:
                self.on_state_change(self)
            except Exception:
                pass

    def submit(self, trip: Trip) -> None:
        self._flush_stale_getters()
        self.cmd_queue.put(trip)

    def submit_priority(self, trip: Trip) -> None:
        """Put a trip at the front of the queue and interrupt current trip."""
        self._flush_stale_getters()
        existing = list(self.cmd_queue.items)
        self.cmd_queue.items.clear()
        self.cmd_queue.put(trip)
        for t in existing:
            self.cmd_queue.put(t)
        # Only interrupt if there is an in-flight trip to abort. When the AGV
        # is idle or frozen in depleted state it is already waiting on the
        # queue — interrupting blows away the queue.get() and the new trip
        # gets dropped without being picked up.
        if (
            self._run_proc is not None
            and self._run_proc.is_alive
            and self.state not in ("idle", "depleted")
            and self.trip_id is not None
        ):
            try:
                self._run_proc.interrupt("priority_override")
            except Exception:
                pass

    def _flush_stale_getters(self) -> None:
        """Remove triggered/cancelled get events from the store's get_queue
        so that put() delivers to the one live listener."""
        q = self.cmd_queue.get_queue
        self.cmd_queue.get_queue = [g for g in q if not g.triggered]

    # ---- SimPy generator ----
    def run(self):
        self._run_proc = self.env.active_process
        while True:
            if self.state != "depleted":
                self.state = "idle"
            self.speed = 0.0
            self._abort = False
            try:
                trip: Trip = yield self.env.process(self._wait_for_trip_or_yield())
            except simpy.Interrupt:
                continue
            # Battery floor: refuse non-recall trips while depleted. Only
            # recall-to-charge trips (flagged on submit) may run.
            if (
                self.battery_pct <= self.cfg.battery_depleted_threshold
                and not self._recall_to_charge
                and self.current_node not in PARKING_BAYS
            ):
                log.warning(
                    "%s refusing trip %s — battery depleted (%.1f%%); recall to charging bay first",
                    self.agv_id, trip.trip_id, self.battery_pct,
                )
                self.state = "depleted"
                continue
            log.info("%s picked up trip %s with %d stops at node %s",
                     self.agv_id, trip.trip_id, len(trip.stops), self.current_node)
            self.trip_id = trip.trip_id
            self.current_trip = trip
            trip_start = self.env.now
            trip_distance = 0.0
            stops_done = 0
            for idx, stop in enumerate(trip.stops):
                self.current_stop_idx = idx
                if self._abort:
                    break
                self.origin_node = self.current_node
                self.dest_node = stop.station_id
                try:
                    seg_distance = yield self.env.process(self._move_to(stop.station_id))
                    trip_distance += seg_distance or 0.0
                    if self._abort or self._estop_requested:
                        log.warning("%s aborting trip %s after move to %s (estop=%s abort=%s)",
                                    self.agv_id, trip.trip_id, stop.station_id,
                                    self._estop_requested, self._abort)
                        self._abort = True
                        break
                    yield self.env.process(self._service_stop(stop))
                    if self._estop_requested:
                        log.warning("%s aborting trip %s after service at %s (estop set)",
                                    self.agv_id, trip.trip_id, stop.station_id)
                        self._abort = True
                        break
                except simpy.Interrupt:
                    self._abort = True
                    break
                stops_done += 1
                if self.on_stop_done is not None:
                    try:
                        self.on_stop_done(self, trip.trip_id, stop.station_id, stop.op)
                    except Exception:
                        pass
            kpis = {
                "distance": round(trip_distance, 3),
                "duration": round(self.env.now - trip_start, 3),
                "stops": stops_done,
                "aborted": self._abort,
            }
            if self._abort:
                # current_stop_idx is the stop we were working on when
                # interrupted. If we were mid-move TO that stop, we need to
                # redo it. If the stop was a pickup and we already loaded
                # (payload > 0), convert it to a plain "move" to avoid
                # double-loading.
                remaining_stops = list(trip.stops[self.current_stop_idx:])
                if remaining_stops and remaining_stops[0].op == "pickup" and self.payload_count > 0:
                    remaining_stops[0] = Stop(
                        station_id=remaining_stops[0].station_id,
                        op="move",
                        units=0,
                    )
                if remaining_stops:
                    new_interrupted = Trip(
                        trip_id=trip.trip_id,
                        stops=remaining_stops,
                    )
                    # Distinguish chatbot-driven estop (user paused; needs
                    # explicit resume) from internal priority preempt
                    # (eviction / multi-drop / unblock). For internal preempts
                    # we re-queue the remaining stops at the FRONT of the
                    # cmd_queue so the AGV auto-resumes after the higher-
                    # priority trip finishes — no UI "interrupted" event.
                    if self._estop_requested:
                        if self.interrupted_trip is not None:
                            self.interrupted_trips.append(self.interrupted_trip)
                        self.interrupted_trip = new_interrupted
                        if self.on_trip_interrupted is not None:
                            try:
                                self.on_trip_interrupted(self, trip.trip_id, new_interrupted)
                            except Exception:
                                pass
                    else:
                        existing = list(self.cmd_queue.items)
                        self.cmd_queue.items.clear()
                        self.cmd_queue.put(new_interrupted)
                        for t in existing:
                            self.cmd_queue.put(t)
            else:
                # Clear the completed trip from interrupted state.
                if (
                    self.interrupted_trip is not None
                    and self.interrupted_trip.trip_id == trip.trip_id
                ):
                    # Promote next queued interrupted trip if any.
                    if self.interrupted_trips:
                        self.interrupted_trip = self.interrupted_trips.pop(0)
                    else:
                        self.interrupted_trip = None
                else:
                    # Also check the backlog list.
                    self.interrupted_trips = [
                        t for t in self.interrupted_trips
                        if t.trip_id != trip.trip_id
                    ]
                if self.on_trip_complete is not None:
                    try:
                        self.on_trip_complete(self, trip.trip_id, kpis, trip.stops)
                    except Exception:
                        pass
            self.trip_id = None
            self.current_trip = None
            self.current_stop_idx = 0
            self.origin_node = None
            self.dest_node = None
            self.speed = 0.0
            # Recall-to-charge fulfilled when AGV reached a bay; clear flag.
            if self._recall_to_charge and self.current_node in PARKING_BAYS:
                self._recall_to_charge = False
            # Preserve depleted state — only return to idle if battery is
            # above the depleted threshold, otherwise the AGV remains frozen.
            if (
                self.battery_pct <= self.cfg.battery_depleted_threshold
                and self.current_node not in PARKING_BAYS
            ):
                self.state = "depleted"
            else:
                self.state = "idle"
            # Clear the estop flag once the trip has aborted and the AGV is
            # parked at a node. The "paused" set in the bridge gates dispatch
            # of new work; the flag is only the trip-abort signal.
            self._estop_requested = False

    def _wait_for_trip_or_yield(self):
        """Wait for a trip; while waiting, step aside if blocking traffic.

        Uses a single Store.get() across all iterations to avoid orphaned
        getters accumulating in SimPy's get_queue (cancel() does not remove
        them, causing put() to deliver items to dead listeners).
        """
        trip_get = self.cmd_queue.get()
        while True:
            timer = self.env.timeout(0.5)
            result = yield trip_get | timer
            if trip_get in result:
                return result[trip_get]
            if self._is_blocking_someone():
                yield self.env.process(self._step_aside())

    def _is_blocking_someone(self) -> bool:
        if self.traffic is None:
            return False
        node = self.current_node
        for agv_id, target in self.traffic._waiting_for.items():
            if agv_id == self.agv_id:
                continue
            if target == node:
                return True
        return False

    def _step_aside(self):
        """Move to a free neighbor node to clear traffic.

        If all neighbours are held (e.g. we're parked on a leaf process node
        and the only corridor neighbour is held by the AGV waiting on us),
        temporarily release our node so the waiter can advance, then move
        into whichever neighbour just freed up.
        """
        yield self.env.timeout(0)  # ensure generator
        if self.graph is None or self.traffic is None:
            return
        neighbors = list(self.graph.neighbors(self.current_node))
        for nb in neighbors:
            if not self.traffic.is_held(nb):
                self.state = "moving"
                try:
                    yield self.env.process(
                        self.traffic.acquire(self.agv_id, nb, allow_reroute=False)
                    )
                except Exception:
                    self.state = "idle"
                    return
                prev = self.current_node
                yield self.env.process(self._traverse_segment(prev, nb))
                self.traffic.release(self.agv_id, prev)
                self.current_node = nb
                self.state = "idle"
                self.speed = 0.0
                return
        # No free neighbour. We must NOT release the lock without moving —
        # that lets a waiting AGV acquire our station and visually overlap
        # with us (we're still physically parked there). Hold the lock and
        # keep polling for a neighbour to free up.
        prev = self.current_node
        for _ in range(40):
            yield self.env.timeout(0.5)
            for nb in neighbors:
                if not self.traffic.is_held(nb):
                    self.state = "moving"
                    try:
                        yield self.env.process(
                            self.traffic.acquire(self.agv_id, nb, allow_reroute=False)
                        )
                    except Exception:
                        break
                    yield self.env.process(self._traverse_segment(prev, nb))
                    self.traffic.release(self.agv_id, prev)
                    self.current_node = nb
                    self.state = "idle"
                    self.speed = 0.0
                    return
        # Still nothing free — stay put. The pre-flight planner is the
        # contract that prevents another AGV from being dispatched to our
        # station, so this branch is only hit during transient corridor
        # contention which will resolve in a few ticks.

    def _backoff(self, exclude: str, max_hops: int = 3):
        """Move to a free neighbor (other than ``exclude``) to break a standoff.

        Walks up to ``max_hops`` hops away from the blocked direction so the
        deadlock partner has room to pass. Each hop picks the free neighbor
        farthest (graph-distance) from ``exclude`` — a true reverse step,
        not a sideways shuffle. If no neighbor is free at any hop, waits a
        moment and bails so the caller can retry.
        """
        yield self.env.timeout(0)
        if self.graph is None or self.traffic is None:
            return
        prev_state = self.state
        self.state = "moving"
        for _ in range(max_hops):
            neighbors = [n for n in self.graph.neighbors(self.current_node) if n != exclude]
            free = [n for n in neighbors if not self.traffic.is_held(n)]
            if not free:
                yield self.env.timeout(1.0)
                self.state = prev_state
                return
            # Prefer the neighbor that increases distance from `exclude` so
            # this acts like reverse, not a lateral hop into another lane.
            def _away(n: str) -> float:
                try:
                    nx, ny = self.graph.nodes[n]["x"], self.graph.nodes[n]["y"]
                    ex, ey = self.graph.nodes[exclude]["x"], self.graph.nodes[exclude]["y"]
                    return (nx - ex) ** 2 + (ny - ey) ** 2
                except Exception:
                    return 0.0
            free.sort(key=_away, reverse=True)
            chosen = free[0]
            try:
                yield self.env.process(
                    self.traffic.acquire(self.agv_id, chosen, allow_reroute=False)
                )
            except Exception:
                self.state = prev_state
                return
            prev = self.current_node
            yield self.env.process(self._traverse_segment(prev, chosen))
            self.traffic.release(self.agv_id, prev)
            self.current_node = chosen
            # Use this new node as the "exclude" for the next hop so we keep
            # going away from the original blocker, not back toward it.
            exclude = prev
        self.state = prev_state

    def _move_to(self, dest: str):
        self.state = "moving"
        total = 0.0
        avoid: set[str] = set()
        path = self._plan_path(self.current_node, dest, avoid)
        i = 0
        while i < len(path) - 1:
            if self._estop_requested:
                self._abort = True
                self.speed = 0.0
                return total
            a, b = path[i], path[i + 1]
            if self.traffic is not None:
                if self.traffic.is_held(b) and self.traffic.holder(b) != self.agv_id:
                    prev_speed = self.speed
                    self.speed = 0.0
                    self.state = "blocked"
                    try:
                        yield self.env.process(
                            self.traffic.acquire(self.agv_id, b, allow_reroute=True)
                        )
                    except DeadlockReroute as exc:
                        # If the holder is idle/parked/empty and just sitting
                        # in our corridor, ask the bridge to evict it sideways.
                        # This handles auto-park happening BEFORE our task was
                        # dispatched (reservations couldn't predict us).
                        if self.traffic is not None and self.on_eviction_request:
                            holder_id = self.traffic.holder(exc.blocked_node)
                            holder = None
                            if holder_id:
                                # Find peer in fleet via a hack: traffic doesn't
                                # know AGV objects, but the bridge does. Just
                                # ask the bridge to evict; it filters internally.
                                try:
                                    self.on_eviction_request(self, exc.blocked_node)
                                except Exception:
                                    pass
                                yield self.env.timeout(2.0)
                                if not self.traffic.is_held(exc.blocked_node) or \
                                        self.traffic.holder(exc.blocked_node) == self.agv_id:
                                    self.state = "moving"
                                    self.speed = prev_speed
                                    continue
                        # If the blocked node IS the final destination, no
                        # reroute can ever succeed (a path must end there).
                        # Ask the bridge to evict the parked holder off it.
                        if exc.blocked_node == dest and self.on_eviction_request:
                            try:
                                self.on_eviction_request(self, exc.blocked_node)
                            except Exception:
                                pass
                            yield self.env.timeout(3.0)
                            if not self.traffic.is_held(exc.blocked_node) or \
                                    self.traffic.holder(exc.blocked_node) == self.agv_id:
                                self.state = "moving"
                                self.speed = prev_speed
                                continue
                        # Before committing to a reroute, re-check whether the
                        # blocker has cleared. The deadlock detector raises on
                        # timeout but the holder may have just moved (e.g. an
                        # evicted bay occupant or a finishing trip). If the
                        # blocked node is now free, stay on the original path.
                        if not self.traffic.is_held(exc.blocked_node) or \
                                self.traffic.holder(exc.blocked_node) == self.agv_id:
                            self.state = "moving"
                            self.speed = prev_speed
                            continue
                        # Grace wait: the blocker may be temporarily paused
                        # (loading/unloading). Wait before rerouting.
                        yield self.env.timeout(3.0)
                        if not self.traffic.is_held(exc.blocked_node) or \
                                self.traffic.holder(exc.blocked_node) == self.agv_id:
                            self.state = "moving"
                            self.speed = prev_speed
                            continue
                        # Cycle loser detected — step aside so the winner
                        # can pass, then replan our path from new position.
                        if exc.is_cycle:
                            log.info(
                                "%s is cycle loser at %s (blocked by %s) — backing off",
                                self.agv_id, exc.blocked_node,
                                self.traffic.holder(exc.blocked_node),
                            )
                            yield self.env.process(self._backoff(exc.blocked_node))
                            # After stepping aside, replan path from current pos
                            path = self._plan_path(self.current_node, dest, avoid)
                            if not path or path[-1] != dest:
                                avoid.add(exc.blocked_node)
                                path = self._plan_path(self.current_node, dest, avoid)
                            i = 0
                            self.state = "moving"
                            self.speed = prev_speed
                            continue
                        # Non-cycle contention: wait briefly then try eviction.
                        self.state = "blocked"
                        waited = 0.0
                        max_wait = 15.0
                        cleared = False
                        while waited < max_wait:
                            yield self.env.timeout(2.0)
                            waited += 2.0
                            if not self.traffic.is_held(exc.blocked_node) or \
                                    self.traffic.holder(exc.blocked_node) == self.agv_id:
                                cleared = True
                                break
                        if cleared:
                            self.state = "moving"
                            self.speed = prev_speed
                            continue
                        if self.on_eviction_request:
                            try:
                                self.on_eviction_request(self, exc.blocked_node)
                            except Exception:
                                pass
                        yield self.env.timeout(2.0)
                        if not self.traffic.is_held(exc.blocked_node) or \
                                self.traffic.holder(exc.blocked_node) == self.agv_id:
                            self.state = "moving"
                            self.speed = prev_speed
                            continue
                        # Eviction failed — back off to let the other pass.
                        log.info(
                            "%s backing off from %s after eviction failed",
                            self.agv_id, exc.blocked_node,
                        )
                        yield self.env.process(self._backoff(exc.blocked_node))
                        path = self._plan_path(self.current_node, dest, avoid)
                        if not path or path[-1] != dest:
                            avoid.add(exc.blocked_node)
                            path = self._plan_path(self.current_node, dest, avoid)
                        i = 0
                        self.state = "moving"
                        self.speed = prev_speed
                        continue
                    self.state = "moving"
                    self.speed = prev_speed
                else:
                    yield self.env.process(self.traffic.acquire(self.agv_id, b))
            move_proc = self.env.process(self._traverse_segment(a, b))
            self._move_proc = move_proc
            try:
                d = yield move_proc
            except simpy.Interrupt:
                # Re-sync visual position with current_node (which is still
                # `a` — _move_to only sets current_node=b after the segment
                # completes). Always snap back to coords[a] to keep visual
                # and graph state consistent. Promoting to `b` mid-segment
                # can collide with peers already at b.
                try:
                    self.x, self.y = self.coords[a]
                except Exception:
                    pass
                # Release the destination lock `b` we reserved for this
                # segment. Without this, the lock lingers as "stale" until
                # a peer's eviction sweep cleans it up — meanwhile the UI
                # shows us elsewhere while traffic thinks we're at b.
                if self.traffic is not None:
                    try:
                        if self.traffic.holder(b) == self.agv_id:
                            self.traffic.release(self.agv_id, b)
                    except Exception:
                        pass
                self.speed = 0.0
                self._move_proc = None
                raise
            self._move_proc = None
            total += d or 0.0
            if self._estop_requested:
                # We've completed the segment to b smoothly — stop cleanly at
                # this waypoint. current_node is updated to b below before the
                # abort returns, so resume continues forward from b.
                if self.traffic is not None:
                    self.traffic.release(self.agv_id, a)
                self.current_node = b
                self._abort = True
                self.speed = 0.0
                return total
            if self.traffic is not None:
                self.traffic.release(self.agv_id, a)
            self.current_node = b
            i += 1
        return total

    def planned_path_nodes(self) -> list[str]:
        """All nodes this AGV currently plans to traverse, from current_node
        through every remaining stop on its active trip. Used by peers to
        bias their own path-planning AWAY from corridors this AGV needs.
        """
        out: list[str] = []
        if self.current_node:
            out.append(self.current_node)
        if self.current_trip is None:
            if self.dest_node:
                try:
                    p = self.routing.shortest_path(self.current_node or self.dest_node, self.dest_node)
                    if p:
                        out.extend(p[1:])
                except Exception:
                    pass
            return out
        src = self.current_node or self.start_node
        stops = self.current_trip.stops[self.current_stop_idx:]
        for stop in stops:
            try:
                p = self.routing.shortest_path(src, stop.station_id)
            except Exception:
                p = None
            if not p:
                continue
            out.extend(p[1:])
            src = stop.station_id
        return out

    def _plan_path(self, src: str, dst: str, avoid: set[str]) -> Optional[list[str]]:
        # Soft-avoid: prefer to stay off corridors that higher-priority peers
        # are planning to use. Falls back to ignoring reservations if no path
        # exists, so reservations never strand an AGV.
        # Skip reservation soft-avoid for empty auto-park trips so an unloaded
        # AGV always takes the shortest Dijkstra path home instead of a
        # detour. Contention is handled by the blocked-wait policy.
        reservations: set[str] = set()
        is_parking_trip = (
            self.payload_count == 0
            and self.current_trip is not None
            and all(s.op == "move" for s in self.current_trip.stops)
        )
        if self.reservation_provider is not None and not is_parking_trip:
            try:
                reservations = self.reservation_provider(self) or set()
            except Exception:
                reservations = set()
            reservations = {n for n in reservations if n not in (src, dst)}
        combined = (avoid or set()) | reservations
        if combined and self.graph is not None:
            nodes = [n for n in self.graph.nodes if n not in combined or n in (src, dst)]
            sub = self.graph.subgraph(nodes)
            try:
                return nx.shortest_path(sub, src, dst, weight="weight")
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                pass  # fall back to hard-avoid only
        if not avoid or self.graph is None:
            try:
                return self.routing.shortest_path(src, dst)
            except KeyError:
                return None
        nodes = [n for n in self.graph.nodes if n not in avoid or n in (src, dst)]
        sub = self.graph.subgraph(nodes)
        try:
            return nx.shortest_path(sub, src, dst, weight="weight")
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return None

    def _traverse_segment(self, a: str, b: str):
        # Start from the AGV's actual current pixel position rather than
        # snapping back to coords[a]. After a reroute / backoff the AGV may
        # be partway through the previous segment; resetting to coords[a]
        # produces a visible teleport.
        node_ax, node_ay = self.coords[a]
        bx, by = self.coords[b]
        ax, ay = self.x, self.y
        # Sanity guard: if we're not essentially on coords[a] (e.g. trip
        # restart with a stale self.x, or a reroute that switched paths
        # mid-segment), snap to the node so the segment draws along the
        # actual corridor instead of cutting diagonally across the floor.
        if math.hypot(ax - node_ax, ay - node_ay) > 0.5:
            ax, ay = node_ax, node_ay
            self.x, self.y = ax, ay
        dx, dy = bx - ax, by - ay
        dist = math.hypot(dx, dy)
        if dist == 0:
            return 0.0
        self.heading = math.degrees(math.atan2(dy, dx))
        self.speed = self.cfg.agv_speed
        step = self.cfg.agv_speed * self.cfg.tick_period
        traveled = 0.0
        while traveled < dist:
            # Estop: don't halt mid-corridor. Keep moving smoothly to the
            # next waypoint b; the outer _move_to loop will detect the flag
            # after the segment completes and stop the AGV there.
            traveled = min(traveled + step, dist)
            t = traveled / dist
            self.x = ax + dx * t
            self.y = ay + dy * t
            try:
                yield self.env.timeout(self.cfg.tick_period)
            except simpy.Interrupt:
                self.speed = 0.0
                raise
        self.x, self.y = bx, by
        self.speed = 0.0
        return dist

    def _service_stop(self, stop: Stop):
        if stop.op == "move":
            # Direct relocation only — no loading/unloading, no payload change.
            self.state = "idle"
            yield self.env.timeout(0)
            return
        self.state = "loading" if stop.op == "pickup" else "unloading"
        # Poll _estop_requested in tick-sized chunks so an estop during
        # loading aborts immediately instead of waiting out the full
        # load_seconds timer.
        elapsed = 0.0
        step = max(0.05, self.cfg.tick_period)
        while elapsed < self.cfg.load_seconds:
            if self._estop_requested:
                log.warning("%s estop during _service_stop at %s op=%s — aborting load",
                            self.agv_id, stop.station_id, stop.op)
                return
            yield self.env.timeout(step)
            elapsed += step
        delta = stop.units if stop.units else 1
        if stop.op == "pickup":
            self.payload_count += delta
        else:
            self.payload_count = max(0, self.payload_count - delta)

    # ---- battery ----
    def is_on_charging_bay(self) -> bool:
        return self.current_node in PARKING_BAYS and self.state in ("idle", "charging")

    # ---- snapshot for telemetry ----
    def snapshot(self) -> dict:
        blocked_by = None
        blocked_at_node = None
        if self.state == "blocked" and self.traffic is not None:
            waiting_for = self.traffic._waiting_for.get(self.agv_id)
            if waiting_for:
                blocked_at_node = waiting_for
                blocked_by = self.traffic.holder(waiting_for)
        return {
            "agv_id": self.agv_id,
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "heading": round(self.heading, 1),
            "speed": round(self.speed, 3),
            "state": self.state,
            "trip_id": self.trip_id,
            "current_node": self.current_node,
            "capacity": self.capacity,
            "payload_count": self.payload_count,
            "battery_pct": round(self.battery_pct, 1),
            "origin_node": self.origin_node,
            "dest_node": self.dest_node,
            "blocked_by": blocked_by,
            "blocked_at_node": blocked_at_node,
        }
