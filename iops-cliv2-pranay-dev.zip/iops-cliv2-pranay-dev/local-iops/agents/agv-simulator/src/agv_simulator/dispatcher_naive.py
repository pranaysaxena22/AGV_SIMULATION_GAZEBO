"""Naive 1:1 dispatcher.

Consumes task:created (via in-process callback for determinism), assigns to
the first idle AGV with empty queue, and publishes:

  trip:requested  -> {trip_id, agv_id, stops, ts}
  task:assigned   -> {task_id, trip_id, ts}

Tasks that find no idle AGV go on a pending queue and are retried each tick.
"""
from __future__ import annotations

import logging
import time
import uuid
from collections import deque
from typing import Optional

import simpy

from .agv import AGV, Stop, Trip
from .tasks import Task
from .telemetry import (
    CHANNEL_TASK_ASSIGNED,
    CHANNEL_TRIP_REQUESTED,
    TelemetryPublisher,
)

log = logging.getLogger("agv-simulator.dispatcher")


class NaiveDispatcher:
    def __init__(
        self,
        env: simpy.Environment,
        publisher: TelemetryPublisher,
        fleet: list[AGV],
        coords: dict[str, tuple[float, float]],
    ) -> None:
        self.env = env
        self.publisher = publisher
        self.fleet = fleet
        self.coords = coords
        self.pending: deque[Task] = deque()
        self.tasks_by_trip: dict[str, Task] = {}

    def submit(self, task: Task) -> None:
        self.pending.append(task)

    def run(self):
        while True:
            yield self.env.timeout(0.5)
            if not self.pending:
                continue
            assigned: list[Task] = []
            for task in list(self.pending):
                agv = self._pick_idle_agv()
                if agv is None:
                    break
                self._assign(task, agv)
                assigned.append(task)
            for t in assigned:
                self.pending.remove(t)

    def _pick_idle_agv(self) -> Optional[AGV]:
        for agv in self.fleet:
            if agv.state == "idle" and len(agv.cmd_queue.items) == 0:
                return agv
        return None

    def _assign(self, task: Task, agv: AGV) -> None:
        trip_id = f"TR-{uuid.uuid4().hex[:8]}"
        stops = [
            Stop(station_id=task.pickup, op="pickup"),
            Stop(station_id=task.drop, op="drop"),
        ]
        trip = Trip(trip_id=trip_id, stops=stops)
        task.assigned_ts = time.time()
        task.trip_id = trip_id
        self.tasks_by_trip[trip_id] = task

        agv.submit(trip)
        try:
            self.publisher.publish_event(
                CHANNEL_TRIP_REQUESTED,
                {
                    "trip_id": trip_id,
                    "agv_id": agv.agv_id,
                    "stops": [
                        {
                            "station_id": s.station_id,
                            "x": self.coords.get(s.station_id, (0, 0))[0],
                            "y": self.coords.get(s.station_id, (0, 0))[1],
                            "op": s.op,
                            "units": s.units,
                        }
                        for s in stops
                    ],
                    "ts": task.assigned_ts,
                },
            )
            self.publisher.publish_event(
                CHANNEL_TASK_ASSIGNED,
                {"task_id": task.task_id, "trip_id": trip_id, "ts": task.assigned_ts},
            )
        except Exception as exc:
            log.warning("publish trip/task assigned failed: %s", exc)

        log.info(
            "assigned %s -> %s on %s (%s -> %s)",
            task.task_id, trip_id, agv.agv_id, task.pickup, task.drop,
        )
