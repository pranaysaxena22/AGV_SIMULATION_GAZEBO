"""Product-aware task generator for the PCB factory POC.

Tasks now belong to a product batch traversing a fixed sequence of station
roles (e.g., paste_print -> smt_pnp -> reflow -> aoi_post_smt -> ict ...).
Each emitted task represents one inter-stage move (load at upstream stage,
unload at downstream stage) for a given batch.

Backward compatible: every task keeps `pickup` and `drop` station IDs so
the existing dispatcher/AGV code does not need to change.
"""
from __future__ import annotations

import logging
import random
import time
import uuid
from dataclasses import dataclass
from typing import Optional

import simpy

from .telemetry import CHANNEL_TASK_CREATED, TelemetryPublisher

log = logging.getLogger("agv-simulator.tasks")


# ---------------------------------------------------------------------------
# Product / process definitions
# ---------------------------------------------------------------------------

# Each product is an ordered list of station roles its boards traverse.
# Stations are looked up by role at task-creation time, so the same product
# routing works on any layout that contains the required role buckets.
PRODUCT_ROUTES: dict[str, list[str]] = {
    "pcb_consumer": [
        "inbound", "smt_feeder", "paste_print", "smt_pnp", "reflow",
        "aoi_post_smt", "ict", "packaging", "outbound",
    ],
    "pcb_industrial": [
        "inbound", "smt_feeder", "paste_print", "smt_pnp", "reflow",
        "aoi_post_smt", "ict", "fct", "depanel", "packaging", "outbound",
    ],
    "pcb_automotive": [
        "inbound", "smt_feeder", "paste_print", "smt_pnp", "reflow",
        "aoi_post_smt", "xray", "ict", "fct", "conformal_coat",
        "depanel", "final_assembly", "packaging", "dispatch_dock",
    ],
}

PRODUCT_WEIGHTS: list[tuple[str, float]] = [
    ("pcb_consumer", 0.5),
    ("pcb_industrial", 0.3),
    ("pcb_automotive", 0.2),
]

# Automotive boards are delivery-critical; consumer boards run normal.
PRODUCT_PRIORITY: dict[str, str] = {
    "pcb_consumer": "normal",
    "pcb_industrial": "normal",
    "pcb_automotive": "high",
}

PRIORITY_WEIGHTS: list[tuple[str, float]] = [
    ("low", 0.2),
    ("normal", 0.6),
    ("high", 0.2),
]

SLA_BY_PRIORITY = {"high": 60.0, "normal": 180.0, "low": 600.0}


@dataclass
class Task:
    task_id: str
    pickup: str           # station id
    drop: str             # station id
    priority: str
    sla: float            # absolute wall-clock deadline (epoch s)
    created_ts: float
    # PCB-aware fields (optional for back-compat with older consumers)
    product_id: Optional[str] = None
    batch_id: Optional[str] = None
    stage_from: Optional[str] = None    # role name
    stage_to: Optional[str] = None      # role name
    units: int = 1
    material_type: Optional[str] = None
    assigned_ts: Optional[float] = None
    completed_ts: Optional[float] = None
    trip_id: Optional[str] = None

    def to_event(self) -> dict:
        return {
            "task_id": self.task_id,
            "pickup": self.pickup,
            "drop": self.drop,
            "priority": self.priority,
            "sla": self.sla,
            "ts": self.created_ts,
            "product_id": self.product_id,
            "batch_id": self.batch_id,
            "stage_from": self.stage_from,
            "stage_to": self.stage_to,
            "units": self.units,
            "material_type": self.material_type,
            "trip_id": self.trip_id,
            "reserved_agv_id": getattr(self, "reserved_agv_id", None),
        }


def _weighted_choice(rng: random.Random, choices: list[tuple[str, float]]) -> str:
    return rng.choices([c[0] for c in choices], weights=[c[1] for c in choices], k=1)[0]


def _material_for_stage(stage_from: str, stage_to: str) -> str:
    if stage_from in ("inbound",):
        return "bare_pcb"
    if stage_from in ("smt_feeder",):
        return "component_reel"
    if stage_to in ("packaging", "outbound", "dispatch_dock"):
        return "finished_unit"
    if stage_to in ("rework",):
        return "defective_unit_to_rework"
    return "wip_panel"


class TaskGenerator:
    """SimPy process that emits product-aware task:created events.

    Picks a product per Poisson tick, advances one stage of a fresh batch
    through that product's route, and publishes a task whose pickup/drop
    are stations matching the corresponding stage roles.
    """

    def __init__(
        self,
        env: simpy.Environment,
        publisher: TelemetryPublisher,
        stations: list[str],
        lam: float,
        rng: random.Random,
        on_task: Optional[callable] = None,
        stations_by_role: Optional[dict[str, list[str]]] = None,
        product_mix: Optional[list[tuple[str, float]]] = None,
        failure_rate: float = 0.05,
        disabled_role: Optional[str] = None,
        starved_roles: Optional[tuple[str, ...]] = None,
    ) -> None:
        self.env = env
        self.publisher = publisher
        self.stations = stations
        self.lam = max(0.001, lam)
        self.rng = rng
        self.on_task = on_task
        self.stations_by_role = stations_by_role or {}
        self.product_mix = product_mix or PRODUCT_WEIGHTS
        self.failure_rate = max(0.0, min(1.0, failure_rate))
        self.disabled_role = disabled_role
        self.starved_roles = set(starved_roles or ())
        # batch_id -> (product, next_stage_index). When index == len(route)-1,
        # the batch is done and a new batch is created.
        self._batches: dict[str, tuple[str, int]] = {}

    # ------------------------------------------------------------------
    def _pick_station_for_role(self, role: str) -> Optional[str]:
        candidates = self.stations_by_role.get(role) or []
        if not candidates:
            return None
        return self.rng.choice(candidates)

    def _start_new_batch(self, product: str) -> str:
        batch_id = f"B-{product.split('_')[-1].upper()}-{uuid.uuid4().hex[:5]}"
        self._batches[batch_id] = (product, 0)
        return batch_id

    def _advance_batch(self) -> Optional[Task]:
        # Either continue an in-flight batch or start a new one.
        active = [b for b, (_p, i) in self._batches.items()
                  if i < len(PRODUCT_ROUTES[self._batches[b][0]]) - 1]
        if active and self.rng.random() < 0.7:
            batch_id = self.rng.choice(active)
            product, idx = self._batches[batch_id]
        else:
            product = _weighted_choice(self.rng, self.product_mix)
            batch_id = self._start_new_batch(product)
            idx = 0

        route = PRODUCT_ROUTES[product]
        stage_from = route[idx]
        stage_to = route[idx + 1]

        # Scenario hooks: skip the stage if it touches a disabled role or
        # a role currently starved of upstream material.
        if self.disabled_role and (stage_from == self.disabled_role or stage_to == self.disabled_role):
            return None
        if self.starved_roles and stage_from in self.starved_roles:
            return None

        # Quality-spike: AOI/ICT failures divert to rework instead of moving on.
        is_quality_stage = stage_to in ("aoi_post_smt", "ict", "fct")
        if is_quality_stage and self.rng.random() < self.failure_rate:
            stage_to = "rework"
        pickup = self._pick_station_for_role(stage_from)
        drop = self._pick_station_for_role(stage_to)
        if not pickup or not drop:
            log.debug("no stations for %s -> %s; skipping", stage_from, stage_to)
            return None

        # Advance pointer; drop completed batches.
        new_idx = idx + 1
        if new_idx >= len(route) - 1:
            self._batches.pop(batch_id, None)
        else:
            self._batches[batch_id] = (product, new_idx)

        priority = PRODUCT_PRIORITY.get(product, "normal")
        # Mild priority jitter so the queue isn't monotone.
        if self.rng.random() < 0.15:
            priority = _weighted_choice(self.rng, PRIORITY_WEIGHTS)

        units = self.rng.randint(20, 50)
        now = time.time()
        return Task(
            task_id=f"T-{uuid.uuid4().hex[:8]}",
            pickup=pickup,
            drop=drop,
            priority=priority,
            sla=now + SLA_BY_PRIORITY[priority],
            created_ts=now,
            product_id=product,
            batch_id=batch_id,
            stage_from=stage_from,
            stage_to=stage_to,
            units=units,
            material_type=_material_for_stage(stage_from, stage_to),
        )

    # ------------------------------------------------------------------
    # Seed definitions: 9 tasks designed for 5 AGVs so the smart dispatcher
    # can demonstrate bundling (nearby tasks combined into multi-stop trips)
    # and nearest-neighbour/Dijkstra routing.
    #
    # Bundling pairs (pickup/drop within 15m of each other):
    #   Tasks 0+1: both pick from zone-A SMT area → drop in zone-B test area
    #   Tasks 3+4+5: triple bundle from zone-B test → zone-C (demonstrates
    #     nearest-neighbour stop ordering across 3 drops)
    #
    # Remaining tasks are solo cross-zone trips that exercise Dijkstra routing.
    SEED_TASKS: list[dict] = [
        # --- Bundle pair 1: zone-A → zone-B (nearby pickups & drops) ---
        {"product": "pcb_automotive", "stage_idx": 3, "priority": "high", "units": 30},
        {"product": "pcb_industrial", "stage_idx": 3, "priority": "high", "units": 20},
        # --- Solo cross-zone trip: zone-A → zone-B (long Dijkstra path) ---
        {"product": "pcb_automotive", "stage_idx": 5, "priority": "normal", "units": 50},
        # --- Triple bundle: zone-B test area (nearest-neighbour optimization) ---
        # Pickups: fct(S13@40,37), fct(S14@26,28), xray(S15@33,28) — all within 15m
        # Drops: conformal_coat(S21@48,37), depanel(S23@57,33), ict(S11@26,37)
        # NN ordering optimizes drop sequence via greedy Dijkstra from pickup
        {"product": "pcb_automotive", "stage_idx": 8, "priority": "normal", "units": 20},
        {"product": "pcb_industrial", "stage_idx": 7, "priority": "normal", "units": 15},
        {"product": "pcb_automotive", "stage_idx": 6, "priority": "normal", "units": 15},
        # --- Solo long trips ---
        {"product": "pcb_automotive", "stage_idx": 11, "priority": "low", "units": 40},
        {"product": "pcb_industrial", "stage_idx": 0, "priority": "normal", "units": 35},
        {"product": "pcb_automotive", "stage_idx": 0, "priority": "low", "units": 48},
    ]

    def _create_seed_task(self, spec: dict) -> Optional[Task]:
        product = spec["product"]
        route = PRODUCT_ROUTES[product]
        idx = spec["stage_idx"]
        if idx >= len(route) - 1:
            return None
        stage_from = route[idx]
        stage_to = route[idx + 1]
        pickup = self._pick_station_for_role(stage_from)
        drop = self._pick_station_for_role(stage_to)
        if not pickup or not drop:
            return None
        batch_id = f"B-{product.split('_')[-1].upper()}-{uuid.uuid4().hex[:5]}"
        now = time.time()
        return Task(
            task_id=f"T-{uuid.uuid4().hex[:8]}",
            pickup=pickup,
            drop=drop,
            priority=spec["priority"],
            sla=now + SLA_BY_PRIORITY[spec["priority"]],
            created_ts=now,
            product_id=product,
            batch_id=batch_id,
            stage_from=stage_from,
            stage_to=stage_to,
            units=spec["units"],
            material_type=_material_for_stage(stage_from, stage_to),
        )

    def run(self):
        log.info("task generator: seeding %d startup tasks", len(self.SEED_TASKS))
        yield self.env.timeout(3.0)
        seed_tasks: list[Task] = []
        for spec in self.SEED_TASKS:
            task = self._create_seed_task(spec)
            if task is None:
                continue
            seed_tasks.append(task)
        # Submit FIRST so the dispatcher reserves an AGV and stamps trip_id;
        # then publish task:created so the UI's pending row carries the
        # trip_id that matches the provisional trip:requested.
        for task in seed_tasks:
            if self.on_task is not None:
                try:
                    self.on_task(task)
                except Exception as exc:
                    log.warning("on_task callback failed: %s", exc)
        for task in seed_tasks:
            try:
                self.publisher.publish_event(CHANNEL_TASK_CREATED, task.to_event())
            except Exception as exc:
                log.warning("publish task:created failed: %s", exc)
            log.info(
                "seed task %s [%s] %s -> %s (%s -> %s, %d units, %s)",
                task.task_id, task.product_id,
                task.pickup, task.drop, task.stage_from,
                task.stage_to, task.units, task.priority,
            )
        yield self.env.timeout(0.1)
        log.info("seed complete; awaiting chatbot tasks")
