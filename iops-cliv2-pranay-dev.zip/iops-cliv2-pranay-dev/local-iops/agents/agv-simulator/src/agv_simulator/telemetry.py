"""Redis publishers for agv:* / task:* / trip:* events."""
from __future__ import annotations

import json
import time
from typing import Any

import redis

from .agv import AGV
from .config import Config

CHANNEL_TELEMETRY = "agv:telemetry"
CHANNEL_STATE = "agv:state"
CHANNEL_TASK_CREATED = "task:created"
CHANNEL_TASK_ASSIGNED = "task:assigned"
CHANNEL_TASK_CANCELLED = "task:cancelled"
CHANNEL_TRIP_REQUESTED = "trip:requested"
CHANNEL_TRIP_STOP_DONE = "trip:stop_done"
CHANNEL_TRIP_COMPLETED = "trip:completed"
CHANNEL_TRIP_INTERRUPTED = "trip:interrupted"
CHANNEL_TRIP_RESUMED = "trip:resumed"
CHANNEL_TRAFFIC_BLOCKED = "traffic:blocked"
CHANNEL_TRAFFIC_RESUMED = "traffic:resumed"


class TelemetryPublisher:
    def __init__(self, cfg: Config, client: redis.Redis | None = None) -> None:
        self.cfg = cfg
        self.client = client or redis.Redis(
            host=cfg.redis_host,
            port=cfg.redis_port,
            password=cfg.redis_password or None,
            decode_responses=True,
        )

    def publish(self, agv: AGV) -> int:
        payload = agv.snapshot()
        payload["ts"] = time.time()
        return self.client.publish(CHANNEL_TELEMETRY, json.dumps(payload))

    def publish_state(self, agv: AGV) -> int:
        payload = {
            "agv_id": agv.agv_id,
            "state": agv.state,
            "payload_count": agv.payload_count,
            "current_node": agv.current_node,
            "trip_id": agv.trip_id,
            "ts": time.time(),
        }
        return self.client.publish(CHANNEL_STATE, json.dumps(payload))

    def publish_event(self, channel: str, payload: dict[str, Any]) -> int:
        body = {**payload, "ts": payload.get("ts", time.time())}
        return self.client.publish(channel, json.dumps(body))

    def close(self) -> None:
        try:
            self.client.close()
        except Exception:
            pass
