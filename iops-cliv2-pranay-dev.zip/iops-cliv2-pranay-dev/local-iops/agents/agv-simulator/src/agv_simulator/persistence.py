"""MongoDB persistence consumer.

Subscribes to the same Redis pub/sub channels the simulator publishes
on, and writes a downsampled view to MongoDB:

  - agv_telemetry_snapshots: latest snapshot per AGV at 1 Hz
  - agv_state_log: every agv:state event

The consumer runs in a daemon thread so it does not block SimPy. It is
deliberately tolerant of MongoDB being unreachable (e.g. tests with
fakeredis): a failed write is logged and dropped rather than retried.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from typing import Optional

import redis

from .config import Config
from .telemetry import (
    CHANNEL_STATE,
    CHANNEL_TASK_ASSIGNED,
    CHANNEL_TASK_CREATED,
    CHANNEL_TELEMETRY,
    CHANNEL_TRIP_COMPLETED,
    CHANNEL_TRIP_INTERRUPTED,
    CHANNEL_TRIP_REQUESTED,
    CHANNEL_TRIP_RESUMED,
)

log = logging.getLogger("agv-simulator.persistence")

DB_NAME = "agv_poc"
COL_TELEMETRY = "agv_telemetry_snapshots"
COL_STATE = "agv_state_log"
COL_TASKS = "agv_tasks"


class PersistenceWorker:
    """Background thread that mirrors Redis events into MongoDB."""

    def __init__(self, cfg: Config, redis_client: Optional[redis.Redis] = None) -> None:
        self.cfg = cfg
        self._redis = redis_client or redis.Redis(
            host=cfg.redis_host,
            port=cfg.redis_port,
            password=cfg.redis_password or None,
            decode_responses=True,
        )
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._mongo_col_telemetry = None
        self._mongo_col_state = None
        self._mongo_col_tasks = None
        self._trip_to_task: dict[str, str] = {}
        self._trip_meta: dict[str, dict] = {}
        self._latest_per_agv: dict[str, dict] = {}
        self._latest_lock = threading.Lock()

    # ---- lifecycle ----
    def start(self) -> None:
        self._connect_mongo()
        self._thread = threading.Thread(
            target=self._run, name="agv-persistence", daemon=True
        )
        self._thread.start()
        sampler = threading.Thread(
            target=self._sampler, name="agv-persistence-sampler", daemon=True
        )
        sampler.start()

    def stop(self) -> None:
        self._stop.set()

    # ---- internals ----
    def _connect_mongo(self) -> None:
        try:
            from pymongo import MongoClient
        except ImportError:
            log.warning("pymongo not installed; persistence disabled")
            return
        max_retries = 10
        for attempt in range(1, max_retries + 1):
            try:
                client = MongoClient(self.cfg.mongo_uri, serverSelectionTimeoutMS=3000)
                client.admin.command("ping")
                break
            except Exception as e:
                if attempt == max_retries:
                    log.warning("MongoDB unreachable after %d attempts (%s); persistence disabled", max_retries, e)
                    return
                log.info("MongoDB not ready (attempt %d/%d), retrying in 3s…", attempt, max_retries)
                time.sleep(3)
        db = client[DB_NAME]
        self._mongo_col_telemetry = db[COL_TELEMETRY]
        self._mongo_col_state = db[COL_STATE]
        self._mongo_col_tasks = db[COL_TASKS]
        try:
            self._mongo_col_tasks.create_index("task_id", unique=True)
            self._mongo_col_tasks.create_index("trip_id")
        except Exception as e:
            log.debug("tasks index create failed: %s", e)
        try:
            res = self._mongo_col_tasks.delete_many({})
            if res.deleted_count:
                log.info("purged %d tasks from previous run", res.deleted_count)
        except Exception as e:
            log.debug("task collection purge failed: %s", e)
        log.info("connected to MongoDB at %s", self.cfg.mongo_uri)

    def _run(self) -> None:
        try:
            pubsub = self._redis.pubsub()
            pubsub.subscribe(
                CHANNEL_TELEMETRY,
                CHANNEL_STATE,
                CHANNEL_TASK_CREATED,
                CHANNEL_TASK_ASSIGNED,
                CHANNEL_TRIP_REQUESTED,
                CHANNEL_TRIP_COMPLETED,
                CHANNEL_TRIP_INTERRUPTED,
                CHANNEL_TRIP_RESUMED,
            )
        except Exception as e:
            log.warning("redis subscribe failed (%s); persistence loop exiting", e)
            return
        for msg in pubsub.listen():
            if self._stop.is_set():
                break
            if msg.get("type") != "message":
                continue
            try:
                data = json.loads(msg["data"])
            except Exception:
                continue
            channel = msg["channel"]
            if channel == CHANNEL_TELEMETRY:
                self._on_telemetry(data)
            elif channel == CHANNEL_STATE:
                self._on_state(data)
            elif channel == CHANNEL_TASK_CREATED:
                self._on_task_created(data)
            elif channel == CHANNEL_TASK_ASSIGNED:
                self._on_task_assigned(data)
            elif channel == CHANNEL_TRIP_REQUESTED:
                self._on_trip_requested(data)
            elif channel == CHANNEL_TRIP_COMPLETED:
                self._on_trip_completed(data)
            elif channel == CHANNEL_TRIP_INTERRUPTED:
                self._on_trip_interrupted(data)
            elif channel == CHANNEL_TRIP_RESUMED:
                self._on_trip_resumed(data)

    def _on_telemetry(self, data: dict) -> None:
        agv_id = data.get("agv_id")
        if not agv_id:
            return
        with self._latest_lock:
            self._latest_per_agv[agv_id] = data

    def _on_state(self, data: dict) -> None:
        if self._mongo_col_state is None:
            return
        try:
            self._mongo_col_state.insert_one(dict(data))
        except Exception as e:
            log.debug("state insert failed: %s", e)

    def _on_task_created(self, data: dict) -> None:
        if self._mongo_col_tasks is None:
            return
        task_id = data.get("task_id")
        if not task_id:
            return
        doc = {
            "task_id": task_id,
            "pickup": data.get("pickup"),
            "drop": data.get("drop"),
            "priority": data.get("priority"),
            "sla": data.get("sla"),
            "created_ts": data.get("ts"),
            "product_id": data.get("product_id"),
            "batch_id": data.get("batch_id"),
            "stage_from": data.get("stage_from"),
            "stage_to": data.get("stage_to"),
            "units": data.get("units"),
            "material_type": data.get("material_type"),
            "status": "pending",
        }
        try:
            self._mongo_col_tasks.update_one(
                {"task_id": task_id}, {"$set": doc}, upsert=True
            )
        except Exception as e:
            log.debug("task create upsert failed: %s", e)

    def _on_trip_requested(self, data: dict) -> None:
        trip_id = data.get("trip_id")
        if not trip_id:
            return
        self._trip_meta[trip_id] = {
            "agv_id": data.get("agv_id"),
            "stops": data.get("stops") or [],
            "bundled_tasks": data.get("bundled_tasks") or 1,
            "ts": data.get("ts"),
        }

    def _on_task_assigned(self, data: dict) -> None:
        if self._mongo_col_tasks is None:
            return
        task_id = data.get("task_id")
        trip_id = data.get("trip_id")
        if not task_id or not trip_id:
            return
        self._trip_to_task[trip_id] = task_id
        meta = self._trip_meta.get(trip_id, {})
        try:
            self._mongo_col_tasks.update_one(
                {"task_id": task_id},
                {
                    "$set": {
                        "trip_id": trip_id,
                        "agv_id": meta.get("agv_id"),
                        "stops": meta.get("stops", []),
                        "bundled_tasks": meta.get("bundled_tasks", 1),
                        "assigned_ts": data.get("ts"),
                        "status": "assigned",
                    }
                },
            )
        except Exception as e:
            log.debug("task assigned update failed: %s", e)

    def _on_trip_interrupted(self, data: dict) -> None:
        if self._mongo_col_tasks is None:
            return
        trip_id = data.get("trip_id")
        if not trip_id:
            return
        try:
            self._mongo_col_tasks.update_many(
                {"trip_id": trip_id},
                {"$set": {"was_interrupted": True, "interrupted_ts": data.get("ts")}},
            )
        except Exception as e:
            log.debug("trip interrupted update failed: %s", e)

    def _on_trip_resumed(self, data: dict) -> None:
        if self._mongo_col_tasks is None:
            return
        trip_id = data.get("trip_id")
        if not trip_id:
            return
        try:
            self._mongo_col_tasks.update_many(
                {"trip_id": trip_id},
                {"$set": {"was_resumed": True, "resumed_ts": data.get("ts")}},
            )
        except Exception as e:
            log.debug("trip resumed update failed: %s", e)

    def _on_trip_completed(self, data: dict) -> None:
        if self._mongo_col_tasks is None:
            return
        trip_id = data.get("trip_id")
        # Multi-drop trips publish task_ids; single-drop trips publish task_id.
        ids: list[str] = []
        if isinstance(data.get("task_ids"), list):
            ids.extend([t for t in data["task_ids"] if t])
        if data.get("task_id"):
            ids.append(data["task_id"])
        carry = self._trip_to_task.pop(trip_id, None)
        if carry and carry not in ids:
            ids.append(carry)
        # As a final fallback, sweep any tasks still pinned to this trip_id.
        update = {
            "trip_id": trip_id,
            "completed_ts": data.get("ts"),
            "kpis": data.get("kpis", {}),
            "agv_id": data.get("agv_id"),
            "status": "completed",
        }
        try:
            if ids:
                self._mongo_col_tasks.update_many(
                    {"task_id": {"$in": ids}}, {"$set": update}
                )
            if trip_id:
                self._mongo_col_tasks.update_many(
                    {"trip_id": trip_id, "status": {"$ne": "completed"}},
                    {"$set": update},
                )
        except Exception as e:
            log.debug("task completed update failed: %s", e)

    def _sampler(self) -> None:
        """Flush latest-per-AGV snapshot to Mongo at 1 Hz."""
        while not self._stop.is_set():
            time.sleep(1.0)
            if self._mongo_col_telemetry is None:
                continue
            with self._latest_lock:
                if not self._latest_per_agv:
                    continue
                batch = list(self._latest_per_agv.values())
                self._latest_per_agv.clear()
            try:
                self._mongo_col_telemetry.insert_many(
                    [dict(b, sampled_at=time.time()) for b in batch]
                )
            except Exception as e:
                log.debug("telemetry insert_many failed: %s", e)
