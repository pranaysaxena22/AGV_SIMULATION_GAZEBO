"""Floor layout loader.

Reads a poc-floor.json layout and returns a NetworkX graph plus a
node->(x, y) coordinate map. Edge weights are Euclidean distance in
meters between endpoint nodes.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Tuple

import networkx as nx

NodeCoords = dict[str, tuple[float, float]]
StationMeta = dict[str, dict]  # station_id -> {"role": str, "name": str, "zone": str}


def load_floor(path: str | Path) -> Tuple[nx.Graph, NodeCoords]:
    """Load a floor layout JSON and return (graph, coords).

    The graph is undirected. Node attributes:
      - kind: "station" | "waypoint"
      - x, y: floor coordinates in meters
      - zone: only on station nodes
    Edge attribute:
      - weight: Euclidean distance between endpoints (meters)

    Raises ValueError if the layout fails validation (unknown node ids,
    floating nodes, or any station unreachable from S01).
    """
    layout = json.loads(Path(path).read_text())

    g: nx.Graph = nx.Graph()
    coords: NodeCoords = {}

    for s in layout["stations"]:
        g.add_node(
            s["id"], kind="station",
            x=s["x"], y=s["y"], zone=s["zone"],
            role=s.get("role"), name=s.get("name"),
        )
        coords[s["id"]] = (s["x"], s["y"])
    for w in layout["waypoints"]:
        g.add_node(w["id"], kind="waypoint", x=w["x"], y=w["y"])
        coords[w["id"]] = (w["x"], w["y"])

    for e in layout["edges"]:
        a, b = e["from"], e["to"]
        if a not in coords or b not in coords:
            raise ValueError(f"edge references unknown node: {e}")
        ax, ay = coords[a]
        bx, by = coords[b]
        weight = math.hypot(ax - bx, ay - by)
        if weight == 0:
            raise ValueError(f"zero-length edge: {e}")
        g.add_edge(a, b, weight=weight)

    _validate_reachability(g, layout)
    return g, coords


def _validate_reachability(g: nx.Graph, layout: dict) -> None:
    station_ids = [s["id"] for s in layout["stations"]]
    if "S01" not in g:
        raise ValueError("layout missing S01")
    unreachable = [s for s in station_ids if not nx.has_path(g, "S01", s)]
    if unreachable:
        raise ValueError(f"stations unreachable from S01: {unreachable}")
