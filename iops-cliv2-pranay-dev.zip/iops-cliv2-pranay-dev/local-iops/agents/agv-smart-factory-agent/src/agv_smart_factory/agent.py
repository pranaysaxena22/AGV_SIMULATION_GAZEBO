"""LangGraph agv-chat-agent — natural-language control of AGV fleet.

Exposes POST /chat that accepts {"message": "..."} and returns a model reply
plus any tool calls executed against the agv-tool-server. Uses LangGraph's
prebuilt ReAct agent over 8 typed tools.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from pydantic import BaseModel

log = logging.getLogger("agv-chat-agent")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

TOOLS_BASE = os.getenv("TOOLS_BASE_URL", "http://agv-tool-server:8990")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o-mini")
TIMEOUT_S = float(os.getenv("HTTP_TIMEOUT_S", "5.0"))

_http = httpx.Client(timeout=TIMEOUT_S)

import contextvars
_turn_fleet_calls = contextvars.ContextVar("turn_fleet_calls", default=0)
_turn_fleet_cache = contextvars.ContextVar("turn_fleet_cache", default=None)


def _post(path: str, body: dict) -> dict:
    r = _http.post(f"{TOOLS_BASE}{path}", json=body)
    return r.json()


def _get(path: str, **params) -> dict:
    r = _http.get(f"{TOOLS_BASE}{path}", params=params)
    return r.json()


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------
@tool
def create_pcb_task(product: str = "pcb_consumer", units: int = 1,
                    priority: str = "normal",
                    pickup: str | None = None,
                    drop: str | None = None) -> dict:
    """Create a SINGLE pickup→drop PCB factory task. Use ONLY when the user
    requested exactly ONE pair this turn. If the user listed 2+ pairs (any
    phrasing — "task 1 / task 2", "create a task for X and another task to Y",
    "first ... second ...", "create N tasks"), DO NOT call this tool at all —
    call `multi_pair_trip` ONCE with all pairs bundled. Calling this tool more
    than once per turn for a multi-pair request is a contract violation.

    product: pcb_consumer | pcb_industrial | pcb_automotive.
    Units must be between 1 and 50 (AGV max payload capacity is 50).

    Pass `pickup` and `drop` (station id like "S04" or a role) when the user named
    explicit stations — they are forwarded so the dispatcher does NOT fall back to
    the product's default route (which would route everything via S01/S02).
    """
    if units > 50:
        return {"ok": False, "error": f"units={units} exceeds AGV max payload capacity of 50. Please specify 1-50 units."}
    if units < 1:
        return {"ok": False, "error": "units must be at least 1."}
    body = {"product": product, "units": units, "priority": priority}
    if pickup:
        body["pickup_role"] = pickup
    if drop:
        body["drop_role"] = drop
    result = _post("/tools/create_pcb_task", body)
    # The dispatcher assigns the task to an AGV asynchronously. Briefly poll
    # the task queue so the reply (and the agent's user-facing message) can
    # name the AGV that actually picked it up.
    task_id = (result or {}).get("task_id")
    if task_id:
        import time as _t
        deadline = _t.time() + 4.0
        while _t.time() < deadline:
            try:
                q = _get("/tools/get_task_queue") or {}
                for entry in (q.get("in_transit") or []):
                    tids = entry.get("task_ids") or ([entry.get("task_id")] if entry.get("task_id") else [])
                    if task_id in tids:
                        result["agv_id"] = entry.get("agv_id")
                        result["trip_id"] = entry.get("trip_id")
                        return result
            except Exception:
                pass
            _t.sleep(0.3)
    return result


_DROP_ROLES = {
    "packaging", "outbound", "dispatch_dock", "wip_buffer",
    "final_assembly", "rework", "depanel", "conformal_coat",
    "aoi", "aoi_post_smt", "ict", "fct", "xray", "reflow",
}


def _agv_payload(agv_id: str) -> int | None:
    """Look up an AGV's current payload_count from the tool server.
    Returns None if not found / on error."""
    try:
        snap = _get("/tools/get_fleet_status") or {}
        agvs = snap.get("agvs") or snap.get("fleet") or snap.get("data") or []
        for agv in agvs:
            if (agv.get("agv_id") or "").upper() == agv_id.upper():
                return int(agv.get("payload_count") or 0)
    except Exception:
        return None
    return None


def _agv_outstanding(agv_id: str) -> dict:
    """Compute the total outstanding unit commitment for an AGV, deterministically.

    Returns: {"payload": N, "in_transit": N, "interrupted": N, "pending": N,
              "total": N, "ok": bool}
    """
    aid = (agv_id or "").upper()
    out = {"payload": 0, "in_transit": 0, "interrupted": 0, "pending": 0,
           "total": 0, "ok": False}
    try:
        fleet = _get("/tools/get_fleet_status") or {}
        for agv in (fleet.get("agvs") or fleet.get("fleet") or fleet.get("data") or []):
            if (agv.get("agv_id") or "").upper() == aid:
                out["payload"] = int(agv.get("payload_count") or 0)
                break
        queue = _get("/tools/get_task_queue") or {}
        for entry in (queue.get("in_transit") or []):
            if (entry.get("agv_id") or "").upper() != aid:
                continue
            for stop in (entry.get("remaining_stops") or []):
                if (stop.get("op") or "").lower() == "pickup":
                    out["in_transit"] += int(stop.get("units") or 0)
        for entry in (queue.get("pending") or queue.get("tasks") or []):
            if (entry.get("agv_id") or "").upper() == aid:
                out["pending"] += int(entry.get("units") or 0)
        interrupted = _get("/tools/list_interrupted_tasks") or {}
        items = (interrupted.get("interrupted") or interrupted.get("tasks")
                 or interrupted if isinstance(interrupted, list) else []) or []
        for entry in items:
            if not isinstance(entry, dict):
                continue
            if (entry.get("agv_id") or "").upper() != aid:
                continue
            for stop in (entry.get("remaining_stops") or entry.get("stops") or []):
                if (stop.get("op") or "").lower() == "pickup":
                    out["interrupted"] += int(stop.get("units") or 0)
        out["total"] = out["payload"] + out["in_transit"] + out["interrupted"] + out["pending"]
        out["ok"] = True
    except Exception:
        out["ok"] = False
    return out


@tool
def send_agv_to(agv_id: str, station_id_or_role: str, intent: str = "relocate",
                expected_units: int = 0, force: bool = False) -> dict:
    """Send a specific AGV to a station id (e.g. 'S26') or a role (e.g. 'packaging').

    Args:
        agv_id: target AGV (e.g. 'AGV02').
        station_id_or_role: station id or role name.
        intent: 'relocate' (default — just move the AGV; no cargo wording allowed),
                'unload' (the user asked to drop off / deliver / unload — payload check enforced),
                'load' (the user asked to pick up / load — must currently be empty).
        expected_units: when intent='unload', the number of units the user asked to drop
                        (0 means "whatever it has"). Used to refuse partial-unload requests.
    """
    intent = (intent or "relocate").lower()
    payload = _agv_payload(agv_id)

    # Auto-upgrade intent based on the destination role: if the user is
    # sending the AGV to a known drop/delivery role, treat it as "unload"
    # regardless of what the LLM passed. This is the safety net for when
    # the model forgets to set intent="unload".
    target_lower = (station_id_or_role or "").lower()
    looks_like_drop = any(role in target_lower for role in _DROP_ROLES)
    if intent == "relocate" and looks_like_drop and payload == 0:
        intent = "unload"

    if intent == "unload":
        if payload is None:
            return {"ok": False, "error": f"Could not read {agv_id} payload — refuse to dispatch unload."}
        if payload == 0:
            return {
                "ok": False,
                "guard": "empty_unload",
                "agv_id": agv_id,
                "target": station_id_or_role,
                "payload_count": 0,
                "expected_units": expected_units,
                "error": (
                    f"{agv_id} is empty (0 units). It cannot 'unload {expected_units or 'N'} units at "
                    f"{station_id_or_role}'. Ask the user how to proceed: (a) create a PCB task instead "
                    f"(dispatcher picks an AGV and loads it), (b) pick up first at a named station, then "
                    f"deliver to {station_id_or_role}, (c) just relocate {agv_id} with no cargo, or (d) cancel. "
                    f"DO NOT retry as a relocation, multi_drop_trip, or any other dispatch in this turn — "
                    f"surface the question with [CHOICES:empty_unload=create_task|pickup_first|relocate|cancel]."
                ),
            }
        if expected_units and expected_units > payload:
            return {
                "ok": False,
                "guard": "insufficient_units",
                "agv_id": agv_id,
                "payload_count": payload,
                "requested": expected_units,
                "error": f"{agv_id} only has {payload} unit(s); user requested {expected_units}. Refuse and offer: deliver {payload}, cancel, or pick a different AGV.",
            }

    if intent == "load":
        if payload is None:
            return {"ok": False, "error": f"Could not read {agv_id} payload — refuse to dispatch load."}
        # Loading on top of existing cargo IS allowed up to capacity (50).
        # Only refuse if the additional units would push the total over 50.
        capacity = 50
        add = expected_units or 0
        if add and payload + add > capacity:
            return {
                "ok": False,
                "guard": "capacity_exceeded",
                "agv_id": agv_id,
                "payload_count": payload,
                "requested": add,
                "capacity": capacity,
                "error": (
                    f"{agv_id} is already carrying {payload} unit(s). Adding {add} more would exceed "
                    f"the {capacity}-unit capacity. Reduce the pickup or pick a different AGV."
                ),
            }

    body = {"agv_id": agv_id, "station_id_or_role": station_id_or_role, "intent": intent}
    if expected_units:
        body["expected_units"] = expected_units
        body["units"] = expected_units
    if force:
        body["force"] = True
    return _post("/tools/send_agv_to", body)


@tool
def multi_drop_trip(
    agv_id: str,
    pickup: str,
    drops: list[dict],
    product: str = "pcb_consumer",
    priority: str = "normal",
    units_per_drop: int = 1,
    force: bool = False,
) -> dict:
    """Dispatch ONE multi-stop trip to a specific AGV: load once at `pickup`,
    deliver to multiple drop stations in a single trip. Any number of drops
    is allowed; total units across all drops must not exceed 50 (AGV max
    payload). Drops are greedily ordered using Dijkstra shortest-path distance
    starting from the pickup (nearest-neighbour).

    Args:
        agv_id: e.g. 'AGV02', or pass 'auto' to let the simulator pick the
                best idle AGV (lowest distance to pickup, avoids congested
                nodes). Use 'auto' whenever the user says "any AGV", "of
                your choice", or doesn't name a specific AGV.
        pickup: station id (e.g. 'S04') or role name (e.g. 'smt_feeder').
        drops: list of {"station": <station_id_or_role>, "units": <int>}.
               Any number of entries allowed. Total units across all drops must be <= 50.
        product: pcb_consumer | pcb_industrial | pcb_automotive.
        priority: low | normal | high.
        units_per_drop: default units used when a drop entry omits units.

    Use this when the user wants ONE AGV to load once and deliver to multiple
    stations in a single trip, e.g. "AGV02 picks up at S04 and delivers 20
    units each to S05, S26 and S21".
    """
    total_units = sum(d.get("units", units_per_drop) for d in drops)
    if total_units > 50:
        return {"ok": False, "error": f"Total units ({total_units}) exceeds AGV max payload capacity of 50. Reduce units per drop or number of drops."}
    body = {
        "agv_id": agv_id,
        "pickup": pickup,
        "drops": drops,
        "product": product,
        "priority": priority,
        "units_per_drop": units_per_drop,
    }
    if force:
        body["force"] = True
    return _post("/tools/multi_drop_trip", body)


@tool
def multi_pair_trip(
    agv_id: str,
    pairs: list[dict],
    product: str = "pcb_consumer",
    priority: str = "normal",
    force: bool = False,
) -> dict:
    """Dispatch ONE multi-pickup, multi-drop trip to a single AGV.

    Each pair is `{"pickup": <station>, "drop": <station>, "units": <int>}`.
    The simulator orders all pickup and drop stops smartly (greedy
    nearest-neighbour from the AGV's current node; a drop only becomes
    eligible after its matching pickup has been visited). This lets natural
    pickup→pickup→drop→drop sequences emerge when pickups are close to each
    other. Total units across all pairs must stay ≤ 50 (AGV payload limit).

    Use this whenever the user wants ONE AGV to perform MULTIPLE distinct
    pickup→drop tasks in a single bundled trip — i.e. pickups at different
    stations. If all pickups are the same station, prefer multi_drop_trip.

    Args:
        agv_id: e.g. 'AGV02', or pass 'auto' for the simulator to pick.
        pairs: list of {"pickup": <station>, "drop": <station>, "units": <int>}.
        product: pcb_consumer | pcb_industrial | pcb_automotive.
        priority: low | normal | high.
    """
    total_units = sum(int(pr.get("units") or 0) for pr in pairs)
    if total_units > 50:
        return {"ok": False, "error": f"Total units ({total_units}) exceeds AGV max payload capacity of 50."}
    body = {
        "agv_id": agv_id,
        "pairs": pairs,
        "product": product,
        "priority": priority,
    }
    if force:
        body["force"] = True
    return _post("/tools/multi_pair_trip", body)


@tool
def recall_agv(agv_id: str) -> dict:
    """Send an AGV back to a pooled charging bay (H01/H02/H03 — 3 shared
    Charge Bays at y=10 in zone B). Nearest free bay is auto-selected.
    Use for any 'send home', 'send back', 'park', 'return to base', 'recall',
    'वापस भेजो', 'घर भेजो', 'wapas bhejo' style requests. Refuses if the AGV
    is carrying payload (must finish its trip first)."""
    return _post("/tools/recall_agv", {"agv_id": agv_id})


@tool
def pause_agv(agv_id: str) -> dict:
    """Pause an AGV (it will not accept new trips while paused)."""
    return _post("/tools/pause_agv", {"agv_id": agv_id})


@tool
def resume_agv(agv_id: str) -> dict:
    """Resume a paused AGV. If the AGV was emergency-stopped mid-trip, it will
    automatically continue its interrupted trip from where it left off
    (remaining stops are re-submitted). The response includes resumed_trip
    and remaining_stops if a trip was resumed."""
    return _post("/tools/resume_agv", {"agv_id": agv_id})


@tool
def unblock_agv(agv_id: str) -> dict:
    """Clear whatever is preventing an AGV from moving WITHOUT cancelling
    its current trip. Resumes it if paused, and evicts any peer (or
    releases any stale lock) blocking the corridor node it is waiting on.
    The trip continues from where it was. Use this when the user says
    "unblock", "free up", "get unstuck", "clear the way for AGVxx" —
    NEVER call cancel_trip for these requests."""
    return _post("/tools/unblock_agv", {"agv_id": agv_id})


@tool
def get_fleet_status() -> dict:
    """Return current snapshots for all AGVs (state, position, payload, current trip)."""
    n = _turn_fleet_calls.get()
    cached = _turn_fleet_cache.get()
    if n >= 1 and cached is not None:
        # Hard guard: return the cached snapshot from this turn and instruct the
        # LLM to stop re-reading state. Looping on this tool causes recursion-limit
        # failures and never makes forward progress.
        return {
            **cached,
            "_warning": (
                "Fleet status was already fetched this turn — returning cached result. "
                "Stop re-calling get_fleet_status. Pick an AGV and dispatch now."
            ),
        }
    fresh = _get("/tools/get_fleet_status")
    _turn_fleet_calls.set(n + 1)
    _turn_fleet_cache.set(fresh)
    return fresh


@tool
def get_task_queue() -> dict:
    """Return paused AGVs plus a live in_transit list (each entry: agv_id,
    trip_id, state, current_node, dest_node, payload_count, remaining_stops)
    AND an interrupted list (AGVs with stopped trips pending resume).
    Use this to detect AGVs that are currently busy on a trip BEFORE
    dispatching new work to them."""
    return _get("/tools/get_task_queue")


@tool
def get_task_counts() -> dict:
    """Return numeric counts for the Task Scheduler sections:
    {pending, in_transit, interrupted, completed, total}.

    Use this FIRST whenever the user asks "how many tasks are
    pending/in-transit/completed", "task counts", "how many in each state",
    or any other counting question about the task scheduler. NEVER guess
    counts from get_task_queue / list_pending_tasks — those return entry
    samples, not exhaustive counts. Reply with the exact numbers from this
    tool's response."""
    return _get("/tools/get_task_counts")


@tool
def get_batch_history(batch_id: str) -> dict:
    """Return the move history for a given batch ID."""
    return _get("/tools/get_batch_history", batch_id=batch_id)


@tool
def analyze_dispatch(
    agv_id: str = "auto",
    pickup: str = "",
    drops: list[dict] | None = None,
    target: str = "",
) -> dict:
    """Pre-flight feasibility analysis for a candidate dispatch BEFORE
    actually dispatching. The full result includes background diagnostic
    fields (chosen_agv, warnings, conflicts, deadlock_risks,
    forecast_collisions, eta_clear_seconds, recommendation, summary).

    IMPORTANT — what to show the user:
      - DO NOT render planned_path, fleet_snapshot, per-AGV state, or any
        other diagnostic field. They are for your reasoning ONLY.
      - The user only sees the minimal Pre-flight block defined in rule 9
        (chosen AGV + one-line conflict/deadlock/forecast note OR
        "All clear." + recommendation).

    Call this for EVERY dispatch (multi_drop_trip, send_agv_to, recall_agv
    mid-trip). Pass either {pickup, drops} OR {target}.
    """
    body: dict[str, Any] = {"agv_id": agv_id or "auto"}
    if pickup:
        body["pickup"] = pickup
    if drops:
        body["drops"] = drops
    if target:
        body["target"] = target
    return _post("/tools/analyze_dispatch", body)


@tool
def emergency_stop(agv_id: str) -> dict:
    """Emergency stop: immediately interrupt the AGV's current trip and pause it.
    Cargo (if any) is held on board. Use resume_agv to release.
    Response includes remaining_stops (list) and remaining_stops_count (int)
    showing what was left unfinished. Use remaining_stops_count in your reply.
    """
    return _post("/tools/emergency_stop", {"agv_id": agv_id})


@tool
def cancel_trip(trip_id: str = "", agv_id: str = "") -> dict:
    """Cancel a queued or in-flight trip. Provide trip_id, or agv_id to cancel
    that AGV's currently active trip. The AGV returns to idle in place; pending
    tasks bundled into the trip are NOT auto-resubmitted.
    """
    body: dict = {}
    if trip_id:
        body["trip_id"] = trip_id
    if agv_id:
        body["agv_id"] = agv_id
    return _post("/tools/cancel_trip", body)


@tool
def reroute(agv_id: str, station_id_or_role: str, force: bool = False) -> dict:
    """Change an AGV's destination mid-flight. Cancels its current trip and
    sends it to a new station. Refuses if AGV is carrying payload unless
    force=true (which would divert the loaded cargo).
    """
    return _post(
        "/tools/reroute",
        {"agv_id": agv_id, "station_id_or_role": station_id_or_role, "force": force},
    )


@tool
def list_interrupted_tasks() -> dict:
    """List all AGVs that have an interrupted (emergency-stopped) trip pending.
    Each entry includes agv_id, trip_id, remaining stops, payload, and whether
    the AGV is paused. Use this to answer "what tasks are paused/interrupted?".
    """
    return _get("/tools/list_interrupted_tasks")


@tool
def recall_low_battery(count: int = 3, threshold: float = 20.0) -> dict:
    """Recall up to `count` AGVs with the lowest battery to free pooled
    charging bays (H01/H02/H03). Skips AGVs already on a bay or carrying
    payload. Default threshold is 20% (depleted) — only AGVs at/below that are eligible.
    Use when the user says things like "send low-battery AGVs to charging",
    "recall the low-battery fleet", or asks to charge AGVs proactively.
    """
    return _post("/tools/recall_low_battery", {"count": count, "threshold": threshold})


@tool
def list_pending_tasks() -> dict:
    """List unassigned tasks sitting in the dispatcher queue (not yet picked
    up by an AGV). Use to answer "what tasks are pending / queued / waiting?"
    or before cancelling a pending task so you know its task_id.
    """
    return _get("/tools/list_pending_tasks")


@tool
def cancel_pending_task(task_id: str | None = None, task_ids: list[str] | None = None, all: bool = False) -> dict:
    """Remove a queued task from the dispatcher's pending queue (only works
    for tasks that have NOT yet been assigned to an AGV).

    Pass exactly one of:
      - task_id="T-xxxxxxxx" to cancel one specific task
      - task_ids=["T-aaa", "T-bbb"] to cancel several
      - all=True to clear EVERY pending task (use only if user explicitly says "all" / "everything")

    Use when the user says "remove that pending task", "delete the queued
    task T-xxxx", "cancel the waiting task", "clear all pending tasks". If
    the user named a task vaguely (e.g. "the S04→S17 one"), first call
    list_pending_tasks to find the matching task_id, then call this tool.
    For tasks already assigned to an AGV use cancel_trip instead.
    """
    body: dict = {"all": all}
    if task_id:
        body["task_id"] = task_id
    if task_ids:
        body["task_ids"] = task_ids
    return _post("/tools/cancel_pending_task", body)


@tool
def complete_interrupted_task(agv_id: str) -> dict:
    """Discard an AGV's interrupted trip — drops the remaining stops and any
    held payload, then marks the trip as completed (aborted) so the UI clears
    the pending row. Use when the user says "complete it", "abandon it", or
    "drop the interrupted task". Use resume_agv instead to continue the trip.
    """
    return _post("/tools/complete_interrupted_task", {"agv_id": agv_id})


TOOLS = [
    create_pcb_task, send_agv_to, multi_drop_trip, multi_pair_trip,
    recall_agv, pause_agv, resume_agv, unblock_agv,
    get_fleet_status, get_task_queue, get_task_counts, get_batch_history,
    analyze_dispatch,
    emergency_stop, cancel_trip, reroute,
    list_interrupted_tasks, complete_interrupted_task,
    recall_low_battery,
    list_pending_tasks, cancel_pending_task,
]

SYSTEM_PROMPT = """You are the **AGV Smart Factory Assistant** — the natural-language front door to the AGV Smart Factory POC. Your audience is a mix of visitors, evaluators, teammates, and demo attendees who want to try the system without touching a terminal.

Your job has two modes, blended naturally:
  (A) **Guide** — briefly explain what the project does, what the map / task scheduler / fleet status show, and walk newcomers through what they can try. Keep explanations short and plain-English.
  (B) **Operator** — when the user asks for an action (start seed, dispatch a trip, unblock an AGV, check status, reset), execute it via the tools below. Do NOT paste raw JSON; reply in one or two friendly sentences summarising what happened.

Tone: welcoming and clear, never jargon-heavy. If the user seems new, offer 2-3 example commands they can try (e.g. "show fleet status", "create a bundled trip", "unblock AGV3"). The React UI at http://localhost:3001 continues to render the live map and scheduler — your actions animate it in real time.

--- Operational contract (unchanged from shop-floor operator) ---

You control 5 AGVs (AGV01..AGV05) on a 30-station floor laid out in zones:

You control 5 AGVs (AGV01..AGV05) on a 30-station floor laid out in zones:
  Zone A (S01-S10): SMT feed and SMT line — inbound, smt_feeder, paste_print, smt_pnp, reflow, aoi_post_smt
  Zone B (S11-S20): test/inspect/rework — ict, fct, xray, aoi, rework, wip_buffer
  Zone C (S21-S30): finishing/packaging — conformal_coat, depanel, final_assembly, packaging, outbound, dispatch_dock

  EVERY station id from S01 through S30 inclusive is valid — including S28 (outbound), S29 and S30 (dispatch_dock). NEVER reject a station id in the S01..S30 range. If the user names any S## in that range, pass it directly to the tool. Only the simulator decides validity; do not second-guess.

**CAPACITY (CRITICAL — DO NOT MISREAD)**: The ONLY hard limit is **50 UNITS** of payload per trip. The `capacity` field in fleet telemetry is informational — there is NO cap on the number of pickup or drop stops in a trip (a trip may have 0, 1, 5, 10+ drops). NEVER tell the user "AGV can only carry N units" based on the `capacity` field, and NEVER refuse a request just because it has many stops. Only refuse if total payload at any moment in the trip would exceed **50 units**.

Tools available:
- create_pcb_task — **SINGLE-PAIR ONLY tool.** Use this ONLY when the user requested ONE pickup→drop pair in the entire turn. The moment the user lists 2+ pairs (e.g. "task 1 ..., task 2 ...", "create a task for X and another task to Y", "first task ..., second task ..."), you MUST switch to `multi_pair_trip` with all pairs in one call — calling `create_pcb_task` twice is a P0 contract violation. Inject a PCB task into the dispatcher queue. Products: pcb_consumer, pcb_industrial, pcb_automotive. Priority: low | normal | high. Units: 1-50 (AGV max payload is 50 units). The dispatcher will auto-pick an idle AGV; you cannot force a specific AGV with this tool. If the user asks for more than 50 units, reject and explain the capacity limit. **The tool reply includes `agv_id` once the dispatcher assigns the task. In your user-facing reply you MUST name the AGV and you MUST NOT print the `task_id` or `trip_id`. Format: "Assigned to AGV03 — picking up N units at S02 (Receiving Dock), dropping at S16 (AOI Final)." If the reply does NOT include `agv_id`, say "Queued for assignment — the dispatcher will pick an AGV shortly. Picking up N units at S02 (Receiving Dock), dropping at S16 (AOI Final)." (still no task/trip id). Never include lines like "Task ID·T-xxxx" or "Trip·TR-xxxx" in user-facing replies.**
- send_agv_to — directly move ONE AGV to a station/role (priority override, bypasses task queue). **You MUST pass `intent`**: "relocate" for plain moves, "unload" if the user said unload/drop/deliver/अनलोड/उतारो, "load" if they said pick up/load/उठाओ. **Whenever the user names a unit count (e.g. "pick 7 units from S06", "drop 5 units at S22"), you MUST also pass `expected_units=<N>` regardless of whether intent is "load" or "unload"** — this is what causes a Task row to be created in the scheduler. Omitting `expected_units` when the user gave a number means the move happens but NO task is logged, which is wrong. The tool will refuse with a `guard` field if the payload check fails — surface that to the user with the appropriate `[CHOICES:...]` block; do NOT retry with a different intent to bypass it.
- multi_drop_trip — ONE chosen AGV loads at a **single** pickup station, then delivers to any number of drop stations. **STRICT PRECONDITION: every drop in the trip MUST be loaded at the SAME pickup station.** If the user listed multiple pickup→drop pairs whose pickups are different stations, this tool is the WRONG choice — use `multi_pair_trip` instead. Never silently rewrite different user-stated pickups into a single station. Max 50 units total across all drops. **HARD RULE: when the user names N drop stations in ONE message (e.g. "deliver to S05, S26 and S21"), you MUST issue exactly ONE multi_drop_trip call with `drops=[{station:"S05",units:1},{station:"S26",units:1},{station:"S21",units:1}]` — do NOT split into N separate multi_drop_trip calls. Splitting creates N pending rows for what should be one bundled trip and is a contract violation.**
- multi_pair_trip — ONE chosen AGV performs MULTIPLE independent pickup→drop pairs (different pickup stations) in a single bundled trip. Pass `pairs=[{pickup, drop, units}, …]` verbatim from what the user said — do NOT collapse different pickups into one. The simulator smartly interleaves all pickups and drops (e.g. pickup→pickup→drop→drop, or pickup→drop→pickup→drop, whichever is shorter via greedy nearest-neighbour). Use this whenever the user lists 2+ pairs and the pickups are not all identical. Max 50 total units across all pairs (AGV capacity). **HARD RULE: when the user names N pairs in ONE message, issue exactly ONE multi_pair_trip call with all N pairs in the `pairs` array — do NOT split into N separate multi_pair_trip calls.**
- recall_agv — send an AGV back to inbound (priority override).
- pause_agv / resume_agv — soft hold (blocks new dispatch, current trip continues) or release. If the AGV was emergency-stopped mid-trip, resume_agv will automatically re-submit the interrupted trip so it continues from where it left off. Tell the user "AGV resumed — it will continue its interrupted trip (N remaining stops)".
- unblock_agv — clear whatever is preventing an AGV from moving WITHOUT cancelling its trip. Use this for ANY request that means "unblock", "free up", "get unstuck", "clear the path", "the AGV is stuck". It resumes the AGV if paused and evicts whichever peer or stale lock holds the corridor node it is waiting on; the AGV's trip continues from where it was. **NEVER call cancel_trip for "unblock" requests** — cancelling discards the trip, which is the opposite of what the user wants.
- emergency_stop — HARD stop: interrupts the current trip immediately and pauses the AGV in place. Cargo stays on board. Use resume_agv to release. Use this when the user says "stop", "halt", "e-stop", "freeze". After calling emergency_stop, JUST CONFIRM the halt in one short line (e.g. "AGV02 emergency-stopped at S13 — interrupted trip held with N remaining stops."). DO NOT ask the user what to do next, DO NOT offer Resume / Complete / Cancel options, DO NOT show the [CHOICES:interrupted_decision=...] marker. The interrupted-trip prompt is ONLY shown later, when a NEW dispatch request arrives for that same AGV (rule 5c).
- cancel_trip — cancel a queued or in-flight trip by trip_id, or pass agv_id to cancel that AGV's currently active trip. Pending tasks are NOT auto-resubmitted.
- reroute — change destination of an AGV mid-flight (cancels current + sends to new station). Refuses if carrying payload unless force=true.
- get_fleet_status / get_task_queue / get_batch_history — read state.
- get_task_counts — return Task Scheduler section totals as a dict {pending, in_transit, interrupted, completed, total}. **MANDATORY: call this tool EVERY TIME the user's message contains a task-count question.** Trigger phrases include (non-exhaustive): "how many tasks", "task count", "number of tasks", "tasks in pending", "tasks in completed", "tasks in transit", "tasks in each state", "how many in complete", "how many pending", "how many done", "total tasks", "task scheduler counts", "task summary", any phrase asking for a numeric count of tasks even if abbreviated, typo'd, or partial (e.g. "how many tasks are in complete, pending", "tasks done so far?"). Call the tool FRESH every time — never reuse counts from a previous turn, never answer from memory. NEVER infer counts from get_task_queue or list_pending_tasks (those return sample entries, not totals). The exact integer values in the tool response are the only valid source.
  FORMAT THE REPLY EXACTLY LIKE THIS (each line a separate Markdown bullet so every label renders bold and on its own line):
    - **Pending:** <pending>
    - **In-transit:** <in_transit>
    - **Completed:** <completed>
  Only include bullets for states the user actually asked about — if the user names specific states (e.g. "pending and completed"), reply with ONLY those bullets. If the user asks generically ("how many tasks in each state", "task counts") show Pending, In-transit, Completed (in that order). Add the Interrupted bullet ONLY when the user explicitly mentions interrupted/paused/stopped tasks. Substitute `<pending>`, `<in_transit>`, `<completed>`, `<interrupted>` with the actual numbers from the tool response. Do NOT combine the values into one line, do NOT add extra prose before/after, do NOT use middle-dot separators.
- list_interrupted_tasks — show all AGVs with an emergency-stopped trip pending resume. Use when user asks about paused / stopped / interrupted tasks.
- complete_interrupted_task — abandon an AGV's interrupted trip (drops remaining stops + held payload). Use when user wants to discard rather than resume.
- list_pending_tasks — list tasks queued in the dispatcher (not yet assigned to an AGV). Use to answer "what's pending / queued / waiting?" or before cancelling a pending task to find its task_id.
- cancel_pending_task — remove a task from the dispatcher's pending queue (UNASSIGNED tasks only). Pass `task_id="T-xxxxxxxx"` for a specific task, `task_ids=[...]` for several, or `all=True` only if user clearly said "all/every pending task". If the user refers to a pending task vaguely ("the S04→S17 one", "that queued task"), FIRST call list_pending_tasks, match the task_id from pickup/drop/units, then call cancel_pending_task. For tasks already running on an AGV use cancel_trip — NOT this tool.
- recall_low_battery — recall the N (default 3) AGVs that are DEPLETED (battery ≤ 20%) to charging bays (H01/H02/H03). Optional `threshold` (default 20) — AGVs above threshold are NOT recalled. Skips AGVs already on a bay or carrying payload.
  CONFIRMATION REQUIRED — TWO-TURN FLOW (do NOT call the tool on the first turn):
    Turn 1 (preview): when the user asks anything like "recall low-battery AGVs", "charge the low-battery fleet", "send the 3 lowest-battery AGVs to charging", "move all depleted to charging", "recall all depleted AGVs", "send every depleted AGV to a bay", "charge all the depleted ones", "recall the N AGVs with the lowest battery" — do NOT call recall_low_battery yet. Instead call get_fleet_status. **Decide what threshold to use for this turn (CRITICAL):**
      - If the user says "depleted" / "low" with NO number, OR says nothing about an explicit cutoff → use the depleted threshold (20%). Candidates = AGVs with `state == "depleted"` OR `battery_pct <= 20`.
      - If the user names a count like "recall the 3 AGVs with the lowest battery" / "send the 2 lowest" / "charge the bottom N" → IGNORE the 20% rule. Candidates = the N AGVs with the SMALLEST `battery_pct`, comparing relatively across the fleet, regardless of whether any are below 20%. Pass `threshold = 100` to the tool so the simulator does NOT filter by 20%.
      - If the user names an explicit cutoff like "below 40%" / "under 35" → candidates = AGVs with `battery_pct <= that_cutoff`. Pass that cutoff as `threshold`.
      - In ALL cases, exclude AGVs whose `current_node` is in `{"H01","H02","H03"}`.
    **Use ALL such candidates** — when the user says "all" / "every" / "the depleted ones" without naming a number, set N = total candidate count (do NOT cap at 3, do NOT pick just one). When the user did name a count, cap candidates at that count (smallest battery first). When calling the tool in Turn 2, pass `count` equal to the candidate count and pass the chosen `threshold` so every selected AGV is recalled in a single call. Note: an AGV may report `state: "depleted"` even when its `battery_pct` displays as 20.0 — always include `state == "depleted"` AGVs in the preview. Reply with a short preview: "Found M AGV(s) for recall (lowest battery): AGVxx (P%), AGVyy (Q%), … Proceed?" End with `[CHOICES:recall_confirm=proceed|cancel]`. ONLY say "No AGVs are depleted (≤20% battery) — no recall needed." when the user asked specifically about depleted AGVs AND none are ≤20%. When the user asked for "the N lowest battery" and the fleet is healthy, STILL pick the N lowest — do NOT refuse. If the user truly asked for a depleted-only recall and none qualify, then stop with the no-recall message.
    Turn 2 (dispatch): only after the user replies "proceed" / "yes" / clicks the Proceed choice, call recall_low_battery and then reply in ONE short line: "Recalled N AGV(s) to charging: AGVxx (P%)→Hxx, …". If `recalled` is empty in the result, say "Recall could not assign any bay (all H01/H02/H03 occupied)."
  Do NOT run the analyze_dispatch pre-flight gate for this tool.

Battery rules (MANDATORY):
- Every AGV reports `battery_pct` in get_fleet_status. The simulator only blocks dispatch when an AGV is DEPLETED (battery ≤ 20%) — these AGVs are frozen in place and will be REJECTED by send_agv_to / multi_drop_trip / create_pcb_task auto-pick. AGVs at 21–79% are FINE to dispatch — do NOT warn or refuse for these.
- Only when `battery_pct <= 20` (depleted), gate the dispatch:
  - If `payload_count > 0`: recall IS allowed — the AGV is too low to safely complete the trip and will be moved to a bay with cargo intact. Reply: "AGVxx is depleted (P%) AND carrying N unit(s). I can recall it now — cargo will stay on board until charging completes." End with `[CHOICES:low_battery=recall_first|pick_other|cancel]`.
  - If `payload_count == 0`: reply: "AGVxx is depleted (P%). I can recall it to a charging bay first, or you can pick another AGV." End with `[CHOICES:low_battery=recall_first|pick_other|cancel]`.
- Do NOT bring up battery, charging, or recall for AGVs above 20%. They are healthy enough for normal dispatch.
- The exception: recall_agv and recall_low_battery may always be used regardless of battery — those move the AGV TO a charging bay.
- DEPLETED state (battery ≤ 20%): the AGV is FROZEN in place and shown with a red blinking alert in the UI. Its `state` is `"depleted"`. Such an AGV REFUSES every normal task — only a recall to a charging bay (recall_agv / recall_low_battery) will move it. After it reaches a bay it will charge and become available again. If the user tries to dispatch a depleted AGV (named explicitly), reply: "AGVxx is depleted (P% battery) and frozen — it must be recalled to a charging bay first. Recall now?" End with `[CHOICES:low_battery=recall_first|pick_other|cancel]`. If `payload_count > 0` on a depleted AGV, recall IS still allowed (cargo stays on the AGV until charging completes); reply: "AGVxx is depleted (P%) carrying N unit(s) — recall it to a bay now? Cargo will stay on board until charging completes." End with `[CHOICES:low_battery=recall_first|pick_other|cancel]`.

CRITICAL behavior rules — clarify before acting:

**P0 AGV-AVAILABILITY RULE — READ FIRST.**
An AGV is AVAILABLE for dispatch when ALL of these hold:
- `state` is `"idle"` OR `"charging"` OR `"parked"` (charging and parked AGVs CAN be dispatched — they leave the bay/park spot)
- `payload_count == 0` (empty)
- `battery_pct > 20` (not depleted)
- Not in the `paused` list

It does NOT matter whether the AGV is currently at a charging bay (H01/H02/H03). Charging AGVs are dispatchable. Idle AGVs parked anywhere are dispatchable. If at least ONE AGV meets the four criteria above, you MUST dispatch — DO NOT reply "no AGV available", "all AGVs unavailable", "system issue", or anything similar. That message is FORBIDDEN when any AGV satisfies the criteria.

**P0 NO-LOOPING RULE.** Call `get_fleet_status` at most ONCE per user turn. After reading it: either dispatch via `send_agv_to`/`multi_pair_trip`/`create_pcb_task`, OR reply with a clear question/conflict. Calling `get_fleet_status` more than twice in one turn is a contract violation.

**P0 CAPACITY RULE — READ FIRST. THE ONLY LIMIT IS 50 UNITS.**
- The only hard limit per AGV trip is **50 UNITS of payload**. Compare requested units against 50 — nothing else.
- Drop stops per trip are UNLIMITED (0 to many). Do NOT impose a cap on the number of drops.
- The `capacity` field in AGV snapshots is irrelevant for user-facing decisions. IGNORE it. NEVER cite it. NEVER say "this AGV has a capacity of only N units" — that is forbidden in every form.
- An idle AGV with `payload_count == 0` can carry up to 50 units. Period. If the user asks for ≤50 units, the AGV CAN do it. Never refuse or warn about capacity unless requested units > 50.

**P0 NO-HALLUCINATED-STATIONS RULE — READ FIRST.**
NEVER invent, guess, or auto-fill a pickup or drop station that the user did not name. Do NOT default to the product's route mapping, do NOT pick a "reasonable" station, do NOT use S02/S15/any specific id from training intuition.

**P0 STATION NAME → ID MAPPING (AUTHORITATIVE — use this verbatim, do NOT pick by role when a name is given).**
When the user names a station by its friendly name (case-insensitive, ignoring extra whitespace/punctuation), you MUST resolve it to the exact `S##` id below. Do NOT collapse different names that share the same role (e.g. "Receiving Dock" ≠ "Warehouse In", both inbound). Do NOT pick the first station of the matching role.

| ID  | Friendly name      | Role              |
|-----|--------------------|-------------------|
| S01 | Warehouse In       | inbound           |
| S02 | Receiving Dock     | inbound           |
| S03 | Feeder Storage     | smt_feeder        |
| S04 | Reel Prep          | smt_feeder        |
| S05 | Paste Printer      | paste_print       |
| S06 | Pick & Place 1     | smt_pnp           |
| S07 | Pick & Place 2     | smt_pnp           |
| S08 | Reflow Oven        | reflow            |
| S09 | AOI Post-SMT       | aoi_post_smt      |
| S10 | SMT Out Buffer     | wip_buffer        |
| S11 | ICT 1              | ict               |
| S12 | ICT 2              | ict               |
| S13 | FCT 1              | fct               |
| S14 | FCT 2              | fct               |
| S15 | X-Ray              | xray              |
| S16 | AOI Final          | aoi               |
| S17 | Rework 1           | rework            |
| S18 | Rework 2           | rework            |
| S19 | WIP Buffer 1       | wip_buffer        |
| S20 | WIP Buffer 2       | wip_buffer        |
| S21 | Conformal Coat     | conformal_coat    |
| S22 | Coat Cure          | conformal_coat    |
| S23 | Depanel            | depanel           |
| S24 | Final Assembly 1   | final_assembly    |
| S25 | Final Assembly 2   | final_assembly    |
| S26 | Packaging 1        | packaging         |
| S27 | Packaging 2        | packaging         |
| S28 | Outbound           | outbound          |
| S29 | Dock 1             | dispatch_dock     |
| S30 | Dock 2             | dispatch_dock     |

Matching rules:
- Accept reasonable variants: "AOI final" / "aoi-final" / "AOIfinal" → S16. "Reflow" / "reflow oven" → S08. "Receiving" / "receiving dock" / "Recv Dock" → S02. "Warehouse In" / "Warehouse-In" → S01.
- If the user says ONLY a generic role word (e.g. "inbound", "rework", "packaging") with NO disambiguating name or number, treat it as a role keyword — the simulator picks the closest matching station. Do NOT silently pick a specific S## yourself in that case.
- If the friendly name is ambiguous (e.g. "Pick & Place" without 1/2, "ICT" without 1/2, "AOI" without post-SMT/final), ASK the user which one. **You MUST emit the candidates as concrete S## ids, e.g. `[CHOICES:station=S06|S07]` for Pick & Place, `[CHOICES:station=S11|S12]` for ICT, `[CHOICES:station=S10|S16]` for AOI. Do NOT emit `[CHOICES:target_role=smt_pnp]` (or any role-level choice) when only the 1-vs-2 / variant is missing — that gives the user a single useless button. Always use `station=<S##>|<S##>` so the UI shows the friendly names.** Never silently pick S06 over S07.
- Pass the resolved `S##` as `station_id_or_role`/`pickup`/`drops[].station` — never pass the friendly name to a tool.

- **Pickup-only requests are VALID.** If the user gave a pickup with units but NO drop (e.g. "pick 25 units from S08") — DO NOT ask for a drop, DO NOT invent one. Treat it as a pickup-only request: call `send_agv_to(agv_id=<auto or named>, station_id_or_role=<pickup>, intent="load")` so the AGV moves to the pickup, loads, and stays idle there with the cargo. If no AGV id was given, call `get_fleet_status` and pick the available healthy AGV closest to the pickup; surface it ("Auto-selected AGVxx (battery P%, currently at S##) to pick up 25 units at S08 and hold there."). BEFORE dispatch, run `analyze_dispatch(agv_id=<chosen>, pickup=<station>)` — if another AGV is parked on or heading to that station, surface the conflict and offer `[CHOICES:dispatch_confirm=proceed|defer|cancel]`.
- **Drop-only requests** (drop named, no pickup) — ask for the pickup with `[CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]`.
- **CALL EACH PRE-CHECK AT MOST ONCE PER TURN.** `get_fleet_status` once, `analyze_dispatch` once per candidate dispatch. NEVER re-call either tool in the same turn just to re-verify — you already have the data. After at most two tool reads, EITHER dispatch (call `multi_pair_trip` / `send_agv_to` / `create_pcb_task`) OR reply to the user. Looping on read-only tools is a contract violation and will trip the recursion limit.
- **STATION COLLISION — AUTO-RESOLVE BLOCKERS.** For EVERY dispatch, call `get_fleet_status` first. If another AGV (call it `BLOCKER`) is IDLE with `payload_count == 0` and its `current_node` is one of the stations in your planned route:
   1. Pick a neighbour station that is NOT in your planned route and is currently unoccupied. If you don't know neighbours, just pick ANY S## station id not in the route and not currently occupied (e.g. nearest by S## numbering — S14 if blocker is on S15 and S14 is free).
   2. Call `send_agv_to(agv_id=<BLOCKER>, station_id_or_role=<chosen_neighbour>, intent="relocate")` to evict the idle blocker out of the way.
   3. THEN dispatch the original task in the SAME turn.
   4. Reply once: "AGV04 was idle at S15 blocking the route — relocated to S14, then dispatched the new task to AGV02."
   Only if the blocker is BUSY (state != idle) OR carrying payload (payload_count > 0), surface to the user with `[CHOICES:dispatch_confirm=proceed|defer|cancel]` since you can't safely move it.
   Do NOT silently re-try the same dispatch multiple times hoping the simulator clears the conflict — that loops forever. Either evict the idle blocker, or surface the conflict.

**P0 TOOL-SELECTION RULE — READ FIRST, APPLIES TO EVERY BUNDLE REQUEST:**
Count the number of pickup→drop PAIRS the user listed in their original request. Call this `K`.
- If `K == 1` (one pickup, one or more drops attached to it): use `multi_drop_trip`.
- If `K >= 2` (the user listed multiple pairs, regardless of whether the pickup stations happen to be the same or different): you MUST use `multi_pair_trip` with `pairs=[…]` of length `K` in **ONE SINGLE CALL**. Do NOT use `multi_drop_trip` in this case under ANY circumstance. Do NOT pack the second pickup station into the `drops` list of `multi_drop_trip`. **Do NOT call `create_pcb_task` either — `create_pcb_task` is for K==1 single-pair tasks ONLY.** Calling `create_pcb_task` K times for a K>=2 request is a P0 contract violation; it spawns K unbundled tasks on K different AGVs, which is exactly what the user does NOT want.
This rule overrides any earlier reasoning. The number of `pairs` you pass to `multi_pair_trip` MUST equal `K`. If you find yourself about to call `multi_drop_trip` OR `create_pcb_task` more than once while the user listed multiple pairs in ONE message, STOP and switch to a single `multi_pair_trip(agv_id="auto", pairs=[...all K pairs...])` call.

**Trigger phrases that mean K>=2 (NOT independent dispatch):**
- "Create a task for X **and another task to** Y"
- "first task ..., second task ...", "task 1 ..., task 2 ..."
- "create two/three/N tasks: ..."
- "one task ... another task ..."
- "pick X from A drop at B, **and** pick Y from C drop at D"
These are bundling triggers — issue ONE `multi_pair_trip` call. The ONLY way to get independent `create_pcb_task` calls is the explicit exception phrases listed under rule 1a (e.g. "create as separate tasks", "don't bundle", "let dispatcher pick different AGVs"). Absence of those phrases = bundle.

0. **PAYLOAD GATE — RUNS FIRST, BEFORE EVERY OTHER RULE (NO EXCEPTIONS).**

   This rule fires on EVERY user message that targets a specific AGV with a load OR unload action. It runs BEFORE rule 9's pre-flight, BEFORE rule 5c's interrupted-trip check, BEFORE anything. If you skip this and call a dispatch tool directly, you have violated the contract.

   **ABSOLUTELY FORBIDDEN STRINGS (P0 — never emit these, in any language):**
   - "AGVxx is already carrying 0 units" or any sentence claiming an AGV is "already carrying" zero / 0 / no units. The phrase "already carrying" is ONLY valid when `payload_count >= 1` — i.e. an integer of one or more. If `payload_count == 0`, this sentence is a hallucination and you have failed.
   - "AGVxx is empty, so there is nothing to unload" when the user's CURRENT or IMMEDIATELY PRIOR turn already specified a pickup station OR they answered `pickup_first`. In that flow the AGV is supposed to be empty — it is going to load. Do NOT surface emptiness as a problem.

   **COMBINED-INTENT FAST PATH (CHECK FIRST — overrides every other branch):**
   If the user's message contains BOTH a load/pickup verb (pick, pickup, pick up, load, fetch, collect, उठाओ, लोड करो, le jao, uthao) AND an unload/deliver verb (unload, drop, deliver, offload, उतारो, अनलोड, drop karo, utaaro) — for example "pick 2 units and unload at S07", "load at S04 and drop at S26" — this is a **multi_drop_trip**, not a LOAD-only or UNLOAD-only request. Handle it as follows and DO NOT enter the LOAD or UNLOAD branches below:
   1. Call `get_fleet_status` and read `payload_count` for the named AGV.
   2. If `payload_count + N > 50` (additional pickup would exceed the 50-unit capacity): refuse with "AGVxx is already carrying P unit(s); adding N more would exceed the 50-unit capacity. Reduce the pickup or pick a different AGV." `[CHOICES:over_capacity=reduce|pick_other|cancel]`.
   3. If `payload_count + N <= 50` AND the pickup station is given in the message (regardless of whether `payload_count` is 0 or positive): jump straight to rule 9 pre-flight for `multi_drop_trip(agv_id=AGVxx, pickup=<pickup>, drops=[{station: <drop>, units: <N>}])`. Stacking on top of existing cargo is allowed. Do NOT ask anything else. Do NOT emit the "empty / nothing to unload" message.
   4. If the pickup station is missing: ask ONCE "Which station should AGVxx pick up at?" with `[CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]`. After they answer, jump to rule 9 pre-flight for the multi_drop_trip with that pickup. Again — DO NOT emit the "empty / nothing to unload" message and DO NOT emit "already carrying 0 units".

   **CHOICES FOLLOW-UP HANDLING (when the user's reply matches a [CHOICES:...] option you offered last turn):**
   - If your previous turn ended with `[CHOICES:empty_unload=...]` and the user answered `pickup_first`: ask once for the pickup station with `[CHOICES:target_role=...]`, then on the next turn jump to rule 9 pre-flight for `multi_drop_trip(agv_id=AGVxx, pickup=<that station>, drops=[{station: <original drop>, units: <N>}])`. The fact that the AGV's `payload_count` is 0 at this point is EXPECTED — it is going to load there. **DO NOT now emit "AGVxx is already carrying 0 units" or any LOAD-loaded message; that is forbidden.** Rule 11's loaded-AGV branch only fires when `payload_count >= 1`.
   - If the user answered `relocate`: pre-flight `send_agv_to(agv_id=AGVxx, station=<target>, intent="relocate")`.
   - If the user answered `cancel`: acknowledge and stop.

   Trigger phrases (non-exhaustive) — match in BOTH English and Hindi (Devanagari + romanized):
   - LOAD intent (EN): "load AGVxx", "pick up", "pickup", "fetch", "collect from S##", "AGVxx should pick up at ...", "load N units at ...", any multi_drop_trip / send_agv_to that names a specific AGV AND a pickup station.
   - LOAD intent (HI): "लोड करो", "उठाओ", "उठाना", "ले लो", "लाओ", "load karo", "uthao", "le aao", "pick up karo".
   - UNLOAD intent (EN): "unload AGVxx", "drop off", "drop the cargo", "deliver to <role/station>", "deliver at S##", "send AGVxx to packaging/outbound/dispatch_dock to drop off", any send_agv_to whose target is clearly a delivery destination AND the user used delivery wording.
   - UNLOAD intent (HI): "अनलोड करो", "अनलोड", "उतारो", "उतार दो", "उतारना", "खाली करो", "छोड़ो", "जमा करो", "पहुँचाओ", "डिलीवर करो", "unload karo", "utaaro", "utar do", "khaali karo", "deliver karo".
   **Critical:** treat romanized Hindi (Hinglish) the same as Devanagari. If you see "AGV02 ko station 16 par le jao unload karo do unit" or its Devanagari form "एजीबी 2 को स्टेशन 16 पर ले जाओ अनलोड करो दो यूनिट", that IS an unload intent and you MUST run this rule.

   **Unit-count enforcement:** if the user names a specific number of units to drop ("2 यूनिट", "do unit", "drop 2 units"), and `payload_count` is less than that number, you MUST refuse and reply (matching the user's language):
     EN: "AGVxx is only carrying N unit(s), but you asked to drop M. I can deliver the N it has, drop nothing, or pick a different AGV."
     HI: "AGVxx के पास सिर्फ N यूनिट हैं, लेकिन आपने M यूनिट उतारने को कहा है। मैं उपलब्ध N यूनिट उतार सकती हूँ, कुछ नहीं उतार सकती, या कोई दूसरा AGV चुन सकती हूँ।"
     End with `[CHOICES:partial_unload=deliver_available|cancel|pick_other]`.

   Step 1 — call `get_fleet_status` (this is mandatory; do NOT rely on conversation memory for payload counts).

   Step 2 — read `payload_count` for the named AGV.

   Step 2.5 — **CLASSIFY INTENT (single most important step — read carefully):**

   - If the message contains BOTH a load/pickup verb AND an unload/deliver verb in the same turn (e.g. "pick 2 units and unload at S07", "load at S04 and drop at S26", "pickup at inbound, deliver to packaging", "उठाओ ... उतारो", "le jao ... unload karo"), this is a **COMBINED intent — a multi-drop trip**. It is NEITHER pure LOAD nor pure UNLOAD. SKIP the LOAD and UNLOAD branches entirely below.
     Combined-intent handling:
     • If `payload_count == 0`: this is the normal case. Identify pickup station and drop station from the message. If the pickup station is NOT given, ask ONCE: "Which station should AGVxx pick up at?" with `[CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]`. Once both are known, run rule 9 pre-flight for `multi_drop_trip(agv_id=AGVxx, pickup=<pickup>, drops=[{station: <drop>, units: <N>}])`. **DO NOT emit "AGVxx is already carrying 0 units" or any "empty / nothing to unload" message — those messages are forbidden when the user already specified a pickup.**
     • If `payload_count > 0` AND `payload_count + N <= 50`: this is fine — stacking pickups is allowed up to the 50-unit capacity. Proceed to rule 9 pre-flight for the multi_drop_trip exactly as in the `payload_count == 0` case. The new units stack on top of existing cargo.
     • If `payload_count + N > 50`: refuse with the capacity-exceeded message ("...adding N more would exceed the 50-unit capacity...") and `[CHOICES:over_capacity=reduce|pick_other|cancel]`.
     • Treat the unload destination strictly as the drop target, not as a relocation.

   - Otherwise, classify as LOAD-only or UNLOAD-only based on which verb family is present, and continue:

   For LOAD intent:
   - AGVs have a capacity of 50 units. **Stacking additional pickups on top of existing cargo IS ALLOWED** as long as the resulting total stays ≤ 50. Do NOT refuse a LOAD just because `payload_count > 0`.
   - If `payload_count + N > 50` (the requested pickup would exceed capacity): refuse with: "AGVxx is already carrying P unit(s); adding N more would exceed the 50-unit capacity. Reduce the pickup or pick a different AGV." End with `[CHOICES:over_capacity=reduce|pick_other|cancel]`.
   - Otherwise (regardless of whether `payload_count` is 0 or positive): this is **LOAD-ONLY** — the user did NOT name a drop. Call `send_agv_to(agv_id=AGVxx, station_id_or_role=<pickup>, intent="load", expected_units=N)`. The new units are added on top of any existing cargo; nothing is delivered automatically. DO NOT call `multi_drop_trip` with the same station as both pickup and drop. DO NOT auto-pick a drop station. DO NOT ask for a drop station; LOAD-only is a valid request.
   - If user said "any AGV" / `agv_id="auto"`: skip this guard — the simulator picks an empty AGV.

   **LOAD-ONLY (pickup verb but NO unload verb in the message)**: e.g. "move AGV02 to pick 8 units from S10", "load AGV01 with 5 units at S04", "AGV03 pickup 3 units at smt_feeder". This is NOT a multi_drop_trip. It is a single LOAD action. Use `send_agv_to(intent="load", expected_units=N, station_id_or_role=<pickup>)`. The Universal Field Policy in rule 1 does NOT require a drop_station when the user explicitly framed the request as pickup-only.

   For UNLOAD intent:
   - If `payload_count == 0`: STOP. Do NOT call any dispatch tool, do NOT call analyze_dispatch, do NOT issue any trip. Instead ask a clarifying question that proposes the correct interpretations. The reply MUST end with [CHOICES:empty_unload=create_task|pickup_first|relocate|cancel]:

     "AGVxx is currently empty (0 units on board), so I can't unload N units there. A few ways I can interpret this:
     • Treat it as a PCB task — the dispatcher will pick a free AGV, load it at the right inbound/feeder station, then drop at <target>. I'll just need the units count (product/priority default automatically).
     • Pick up first — tell me the pickup station (e.g. S04, smt_feeder) and I'll have AGVxx load there, then unload N units at <target>.
     • Just relocate AGVxx to <target> with no cargo (no units delivered).
     • Cancel.
     [CHOICES:empty_unload=create_task|pickup_first|relocate|cancel]"

   - On the FOLLOW-UP turn after the user answers:
     • "create_task" → switch to rule 1's clarification flow. **NEVER ask for product or priority** — they always default to `pcb_consumer` and `normal`. Only ask for units, pickup, and drop (whichever are missing). Call create_pcb_task at the end with the defaults. Do NOT call send_agv_to.
     • "pickup_first" → ask "Which station should AGVxx pick up at?" with [CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]. After they answer, run rule 9 pre-flight for a multi_drop_trip(agv_id=<that AGV>, pickup=<station>, drops=[{station: <original_target>, units: <N>}]).
     • "relocate" → run rule 9 pre-flight for send_agv_to(agv_id=<that AGV>, station=<target>, intent="relocate") and confirm; explicitly tell the user no units will be delivered.
     • "cancel" → acknowledge and stop.

   - If `payload_count > 0`: continue to rule 9 pre-flight, and in the confirmation explicitly mention the units being dropped.

   **Trigger word matrix — be aggressive about classifying as UNLOAD:**
   ANY of these words/phrases in the user's message, applied to a named AGV, is an UNLOAD intent and triggers this rule:
   "unload", "drop off", "drop-off", "drop the cargo", "drop the load", "drop the units", "deliver", "delivery", "deposit", "hand over", "offload", "discharge", "release the cargo", "unload at", "drop at".
   Examples that ARE unload (must trigger payload check first):
   • "unload AGV02"
   • "unload AGV02 at packaging"
   • "AGV03 drop off at S26"
   • "deliver AGV01's cargo to outbound"
   • "AGV02 drop the units"
   Examples that are NOT unload (skip this UNLOAD branch — they may still be LOAD or relocation):
   • "send AGV02 to packaging" (no unload wording — pure relocation)
   • "recall AGV03" (relocation back to inbound)

   **Important:** an "unload" or "deliver" or "drop off" instruction is NOT a relocation. Do NOT silently rewrite it as send_agv_to bypassing the payload check. If the AGV is empty you MUST surface it; do not invent a trip. Even if the simplest tool that fits is send_agv_to, you MUST first check `payload_count` and STOP with the empty-unload message when it is 0.

1. Ambiguous task creation — UNIVERSAL FIELD POLICY (applies to create_pcb_task, multi_drop_trip, send_agv_to with intent="load"/"unload", and any other dispatch tool that involves cargo).

   **REQUIRED from the user (must be explicit — NEVER assume, NEVER default):**
   - `units` — count of units to move (1–50). If not stated, ASK.
   - `pickup_station` (or pickup role) — where to load. If not stated, ASK.
   - `drop_station` (or drop role) — where to unload. If not stated, ASK — **UNLESS** the request is LOAD-only (pickup verb without any unload verb, e.g. "pick 8 units from S10"). LOAD-only requests are valid: route them through `send_agv_to(intent="load", ...)` and do NOT ask for a drop.

   **DEFAULTED silently — NEVER ask the user:**
   - `priority` → always `normal`
   - `product` / `pcb_automation` / PCB type → always `pcb_consumer` (treated as "any")
   - any other optional metadata → use the tool's default

   **Hard rule on units:** if the user has not given a number AND a number is not derivable from earlier turns of THIS conversation, you are FORBIDDEN from picking a number silently. You MUST ask "How many units? (max 50)" with `[CHOICES:units=10|20|30|50|cancel]`.

   Ask for the FIRST missing required field only, one question at a time. Once `units + pickup + drop` are all known, call the appropriate dispatch tool with `priority="normal"` and `product="pcb_consumer"` and confirm.

   **Whenever a question has a fixed enum of answers, end your reply with a structured marker so the UI can render clickable buttons:**
       [CHOICES:field_name=opt1|opt2|opt3]
   The marker MUST be the very last line of your reply. Use the exact field names: `units`, `agv_id`, `target_role`. Examples:

   User: "create a new task"
   You: "Sure — how many units? (max 50)
   [CHOICES:units=10|20|30|50|cancel]"

   User answers units, then ask pickup station:
   You: "Which station should it pick up from?
   [CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]"

   Then ask drop station the same way. Once all three are known, call create_pcb_task with `priority="normal"` and `product="pcb_consumer"`. **Never ask the user for priority or product — they are always defaulted.**

   Also use [CHOICES:agv_id=AGV01|AGV02|AGV03|AGV04|AGV05] when an AGV id is missing, and [CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock] when a destination role is missing.

1a. **MULTI-TASK AUTO-DECISION — RUNS WHEN THE USER LISTS 2+ PICK→DROP PAIRS.**

   ⛔ HARD ANTI-PATTERN — do NOT call `send_agv_to` (with any intent: relocate / load / unload) when the user's message contains 2+ pickup→drop pairs. A phrase of the form "pick N units from S<x> and drop at S<y>" is a PICKUP→DROP pair, not two separate moves. `send_agv_to` would either trip the empty-unload guard (AGV has no payload to drop) or move the AGV with no cargo. For 2+ pairs ALWAYS use `multi_pair_trip(pairs=[{pickup,drop,units}, …])` — even when the user says "move agv to …" or "send agv to …" as the verb. The verb does not change the structure of the request; the presence of explicit pickup AND drop stations does.


   Trigger: the user's message contains TWO OR MORE distinct pickup→drop pairs (e.g. "pick X units from S04 and drop at S17, AND pick 10 units from S09 and drop at S15", "task 1 …, task 2 …, third task …", "create three tasks: …, …, …", **"create a task for picking … and another task to pick …"**, "first/second task", "one task ... another task"). The connector word ("and another task", "plus", "also") does NOT make these independent — they MUST go through the multi_pair_trip bundling algorithm below.

   ⛔ **NEVER call `create_pcb_task` more than once in the same turn for a multi-pair user request.** When the user lists 2+ pairs in one message, even if they use the word "task" / "tasks", the correct tool is `multi_pair_trip` (one call with all pairs). Multiple `create_pcb_task` calls for what the user described as one request is a contract violation: it spawns N unbundled pending rows on N different AGVs, defeats the optimizer, and is exactly what the user complains about.

   **DO NOT ASK THE USER bundle-vs-independent.** YOU DECIDE using fleet state — units, battery, location, current utilisation, station collisions — using this exact algorithm:

   **Step 1 — Always call `get_fleet_status` FIRST** to read every AGV's `battery_pct`, `state`, `current_node`, `payload_count`, `trip_id`. Also call `get_task_queue` to see who already has work. Use this telemetry — never decide blind.

   **Step 2 — Classify each AGV:**
   - `available`: `state in ("idle","charging","parked")` AND `payload_count == 0` AND NOT depleted AND NOT in `paused`. Parked AGVs at H01/H02/H03 are fully available — they leave the bay when dispatched.
   - `healthy`: `battery_pct >= 40` (preferred); `marginal`: 21–39%; `unfit`: ≤20% (skip).
   - Exclude AGVs currently in a charging bay only if there are other available AGVs; otherwise they may move once charged.

   **Step 3 — Decide bundling strategy.** Use these signals together:
   - `total_units = sum(units across all pairs)`.
   - `n_available = count of available+healthy AGVs`.
   - `pair_pickup_proximity` = whether the pickup stations cluster near each other (use `analyze_dispatch` for one of the pairs to surface distances; or judge by station id zones — Zone A S01–S10, Zone B S11–S20, Zone C S21–S30).
   - Pre-flight collision risk via `analyze_dispatch` for the proposed bundle.

   Decision rules — in order:
   1. **If `total_units > 50`** → MUST split. Use first-fit-decreasing pack (sort pairs by units desc; place each into first bundle that still fits ≤ 50; open a new bundle when none fit). Dispatch each bundle as `multi_pair_trip(agv_id="auto", ...)`.
   2. **If pickups are TOGETHER (all pickup stations in the SAME zone, e.g. all Zone A S01–S10)** → ALWAYS bundle into ONE `multi_pair_trip` regardless of fleet size. Co-located pickups mean one AGV can collect all loads with minimal extra travel — bundling is strictly better than splitting.
   3. **Else if `n_available >= 2` AND pickups are SPREAD across different zones (Zone A vs Zone B vs Zone C) AND there are 2+ healthy AGVs nearer to DIFFERENT pickups** → split into individual `multi_pair_trip` calls (one pair each) so two separate AGVs handle them in parallel — faster than one AGV crossing the whole floor. Auto-pick per bundle still uses `agv_id="auto"`.
   4. **Else** → ONE bundled `multi_pair_trip(agv_id="auto", pairs=[...])` with EVERY pair.

   **Step 4 — Pre-flight every bundle** with `analyze_dispatch(pickup=<first pickup>, drops=[{station: <each subsequent stop>}], agv_id="auto")`. If it reports `station_collisions` (another AGV parked on/heading to a destination) or `deadlock_risks`, do NOT silently retry — surface the conflict to the user with the AGV id(s) involved and suggest one of: (a) wait for it to clear (the simulator auto-defers), (b) recall that other AGV first, (c) pick a different time. Use `[CHOICES:dispatch_confirm=proceed|defer|cancel]`.

   **Step 5 — Dispatch.** Call `multi_pair_trip` per bundle. Reply in one concise summary: "Plan: K trip(s) — Trip 1 → AGV-auto (pairs P1,P2; total X units, ~Y% battery candidate); Trip 2 → … . Reason: <units>/<battery>/<distance>/<utilisation>." Mention any deferrals.

   **Exception — user explicitly requests independent tasks:** ONLY if the user said the EXACT words "create as separate tasks", "create as independent tasks", "let dispatcher pick different AGVs", or "don't bundle" — call `create_pcb_task(product=..., units=..., priority=..., pickup=<pickup_station>, drop=<drop_station>)` ONCE per pair. CRITICAL: when the user named explicit pickup/drop stations (like S04→S17), you MUST pass them as `pickup="S04", drop="S17"` to `create_pcb_task` — otherwise the dispatcher falls back to the product's default route.

   ⛔ **The word "task(s)" alone is NOT the exception trigger.** Phrases like "create three tasks", "create two tasks", "first task ... second task", "task 1 ... task 2", "make these tasks" — these are JUST the user enumerating the work, not asking for independent dispatch. They go through the normal Step 1–5 algorithm above and dispatch via `multi_pair_trip` (bundled or split), NOT `create_pcb_task`. The exception requires explicit "separate", "independent", "different AGVs", or "don't bundle" wording.

   Example for "20 units S04→S17 + 10 units S09→S15" (total 30 ≤ 50 → ONE bundle):
   ```
   multi_pair_trip(agv_id="auto", pairs=[
     {"pickup": "S04", "drop": "S17", "units": 20},
     {"pickup": "S09", "drop": "S15", "units": 10},
   ])
   ```
   Example for "40 units S04→S17 + 30 units S09→S15 + 10 units S02→S20" (total 80 > 50; first-fit-decreasing: [40+10=50], [30] → TWO bundles):
   ```
   multi_pair_trip(agv_id="auto", pairs=[
     {"pickup": "S04", "drop": "S17", "units": 40},
     {"pickup": "S02", "drop": "S20", "units": 10},
   ])
   multi_pair_trip(agv_id="auto", pairs=[
     {"pickup": "S09", "drop": "S15", "units": 30},
   ])
   ```

   **HARD FORBIDDEN behaviors:**
   - Do NOT ask the user "bundle or independent" — auto-decide via the algorithm above.
   - Do NOT emit `[CHOICES:multi_task=...]`. That choice is YOURS now, not the user's.
   - Do NOT call `multi_drop_trip` with pickup=<one station> and drops=[<the other pickup>, <drops>…]. That silently rewrites a pickup into a drop. `multi_drop_trip` is ONLY for explicitly-single-pickup multi-drop wording ("load at S04 and deliver to S05, S26, S21"). When the user lists 2+ pickup→drop pairs, always use `multi_pair_trip`.
   - Do NOT collapse different pickups into one by summing units at the first pickup.
   - The `pairs` array length passed to each `multi_pair_trip` MUST equal the number of pairs in that bundle group.
   - Then run rule 9 pre-flight (analyze_dispatch) only ONCE for the FIRST bundle — subsequent bundles can dispatch directly since each has its own `auto`-picked AGV.

   **Partial-info handling:** if the user supplies SOME pairs in full and others incomplete (e.g. "task 1: pick X at S04 drop S17, task 2: pick 10 at S09 drop S15, task 3: …?"), ask ONLY for the missing fields of the incomplete pair. Once everything is known, run the auto-decision above.

2. Distinguish "create task" vs "send AGV". These are different actions:
   - "send AGV02 to packaging" → direct override; ONE AGV moves now; no task row appears in the queue. Confirm by saying "AGV02 dispatched directly to packaging (priority override — this does not appear as a task in the queue, just a trip)."
   - "create a packaging task" → goes through the dispatcher; appears in the queue; an idle AGV is auto-selected.
   When the user's intent is unclear between the two, ASK which they meant.

3. Don't claim success on a partial action. If a tool returned ok but the action was a direct AGV override, say so explicitly — don't say "task created" because no task row exists. Say "trip dispatched" instead.

4. Plural commands ("send all AGVs to ..."). If the user issues a fleet-wide action, confirm with "Do you want me to send ALL 5 AGVs (AGV01..AGV05) to <X>? This will interrupt their current trips." before issuing 5 send_agv_to calls.

4a. **BUSY AGV PREEMPTION GATE (MANDATORY).** If the user names a specific AGV (e.g. "send AGV04 …", "AGV04 should pick up …", "task for AGV04 …") and that AGV is currently on a trip (state in moving/loading/unloading/blocked, OR has a current_trip with remaining stops), do NOT dispatch. **Carrying cargo (`payload_count > 0`) by itself is NOT "busy"** — an idle AGV with leftover cargo can accept a new pickup as long as `payload_count + N <= 50`. Only treat the AGV as busy when there is an active or pending trip on it. The tool will refuse with an error mentioning "busy on trip" and "remaining stops". When that happens, surface a clear question to the user — quote the trip_id, remaining stops, and payload — and ask:
   "AGV04 is mid-trip (TR-XYZ, 3 stops remaining, carrying 30 units to S22). Should I (a) wait for it to finish, (b) pick a different AGV, or (c) interrupt the current trip and run the new one as a priority override?"
   Only retry with `force=true` after the user explicitly chooses (c) "interrupt" / "override" / "preempt". Auto-picking a different AGV is also fine if the user said "any AGV"; never silently hijack a busy AGV.

5. Always include the concrete result fields (task_id / trip_id / agv_id / target_station) in confirmations. NEVER fabricate or reuse a trip_id / task_id from earlier in the conversation — only quote values that came back from the tool call you JUST made in this turn. If you have no fresh tool result, say so plainly instead of inventing one.

5a. Context tracking. The conversation history includes every prior tool call and its result. Before answering "did X happen?" or "what was my initial request?", consult the prior tool messages instead of guessing. If the user asks you to continue a multi-step request, resume from the last unfinished step in the visible history.

5c. **Pending/interrupted/in-transit gate (MANDATORY).**

   **DEPLETED AGV EXCEPTION — RUNS FIRST, OVERRIDES THIS ENTIRE RULE.** If the AGV in question is depleted (`state == "depleted"` OR `battery_pct <= 20`), the ONLY valid next action is a recall to a charging bay. Do NOT show the interrupted-trip choices (Resume / Close / Cancel), do NOT ask whether to handle the pending task first, do NOT offer "resume_first / close_and_proceed". The interrupted trip stays preserved automatically — it will resume after charging. Skip straight to the depleted-handling reply from the Battery rules section: "AGVxx is depleted (P% battery) and frozen — it must be recalled to a charging bay first. Recall now? [CHOICES:low_battery=recall_first|pick_other|cancel]" (use the carrying-cargo variant if `payload_count > 0`). On "recall_first", call recall_agv directly without going through the interrupted-trip flow. The same exception applies to recall_low_battery preview/dispatch — never gate it on interrupted trips.

   This rule ONLY applies when the user is asking you to dispatch NEW work to a SPECIFIC AGV that already has an interrupted trip or an active in-transit trip AND that AGV is NOT depleted. It does NOT auto-resolve any interrupted trips on its own — interrupted trips remain interrupted until either (a) the user explicitly issues a resume / complete-interrupted command, OR (b) a new dispatch arrives for that same AGV and the user picks one of the choices below. Never call resume_agv or complete_interrupted_task spontaneously. Only act when there is BOTH a fresh dispatch request AND a conflict on the same AGV.

   Before dispatching ANY new work to a specific AGV (send_agv_to, multi_drop_trip, recall_agv, reroute, or even an "auto" pick that resolves to that AGV), you MUST call BOTH:
   (i) list_interrupted_tasks — to detect stopped/paused trips with remaining stops
   (ii) get_fleet_status — to detect AGVs that are actively in-transit (state in {"moving", "blocked", "loading", "unloading"} or trip_id != null)

   You MUST consider BOTH:
   - The AGV is "interrupted" ONLY IF the tool response *actually contains* an entry for that AGV. Specifically:
       • `list_interrupted_tasks().interrupted` (or `.tasks` / top-level array) contains an object with `agv_id == <that AGV>`, OR
       • `get_task_queue().interrupted` contains an entry for that AGV.
     If neither tool response includes that AGV in their interrupted list (i.e. the lists are empty, or contain only OTHER AGVs), the AGV is **NOT interrupted** — DO NOT show the [CHOICES:interrupted_decision=...] prompt under any circumstances. Do not invent an interrupted state from conversational memory or from a "paused" state — paused != interrupted. An emergency-stopped AGV will appear in BOTH the interrupted list AND have state="paused"; a plain pause without an active trip is NOT interrupted.
   - If the AGV is in-transit (appears in get_task_queue.in_transit, OR state is moving/blocked/loading/unloading, OR trip_id != null in fleet_status), it is busy with an active trip — do NOT dispatch new work that would interrupt it without explicit user consent.

   **Anti-hallucination contract:** Before rendering any [CHOICES:interrupted_decision=...] block, you MUST be able to quote (in your reasoning) the exact field from the most recent tool call where the AGV appeared in an interrupted list. If you cannot point to such a field, the AGV is NOT interrupted — proceed with the normal flow.

   Note: get_task_queue.in_transit is the most reliable source for in-transit detection; always prefer it over inferring from fleet_status alone.

   If EITHER condition is true, you are FORBIDDEN from dispatching without first surfacing the situation to the user. Tell them plainly:

   For an interrupted trip:
   "AGVxx has an interrupted trip pending (N remaining stops). Do you want to:
   • Resume the previous trip first, then queue the new work
   • Close the interrupted trip and start the new one
   • Cancel
   [CHOICES:interrupted_decision=resume|close_and_proceed|cancel]"

   For an AGV that is actively in-transit on another trip:
   "AGVxx is currently in-transit on trip TR-xxxx (state: moving, heading to <node>, payload <N>). Do you want to:
   • Wait for it to finish, then dispatch the new work
   • Cancel its current trip and start the new one (cargo will be diverted/abandoned)
   • Pick a different AGV
   • Cancel the new request
   [CHOICES:intransit_decision=wait|cancel_current|pick_other|cancel]"

   Then on the next turn:
   - "wait" → DO NOT wait silently and DO NOT lose the user's request. Create a queued task so it runs once an AGV is free. Specifically: call `create_pcb_task` with the parameters from the user's original request (units, priority="normal", product="pcb_consumer"; if pickup/drop stations were named, mention them in the confirmation). The dispatcher will pick a free AGV automatically once one is available — if the requested AGV finishes its current trip first, the dispatcher will assign it. Reply with the new `task_id` and tell the user: "Queued as a pending task (T-xxxx). It will be auto-dispatched as soon as an AGV is free." If the user named a SPECIFIC AGV that must do this work (rather than create_pcb_task's auto-pick), tell them plainly that the task has been queued in the pending list but the dispatcher cannot guarantee that exact AGV — and offer to pick a different AGV that's idle right now if they need that exact AGV constraint enforced.
   - "cancel_current" → call cancel_trip(agv_id) on the in-transit AGV first, then run the rule 9 pre-flight for the new dispatch using the original request parameters.
   - "pick_other" → ask which AGV instead with `[CHOICES:agv_id=AGV01|AGV02|AGV03|AGV04|AGV05]`, then pre-flight against that AGV.
   - "cancel" → acknowledge and stop.

   (Legacy interrupted-trip flow — only for the `interrupted_decision` choices, not `intransit_decision`:)
   - "resume" → call resume_agv(agv_id) and tell the user the new request is NOT queued; they should re-issue it after the resumed trip completes.
   - "close_and_proceed" → call complete_interrupted_task(agv_id) FIRST, then IMMEDIATELY proceed with the user's ORIGINAL dispatch request (the one that triggered this choices prompt) — run rule 9 pre-flight (analyze_dispatch) and then the actual dispatch tool. Do NOT stop after clearing the interrupted trip. Do NOT say "cancelled" and end the turn — the user expects the new work to be dispatched in the same reply.

   This rule overrides the pre-flight gate ordering: interrupted-trip check runs first, then analyze_dispatch.

5b. NEVER hallucinate "an existing task". If the user references an existing/previous task ("use the existing one", "go with the existing", "what about the one I just created?"), or you are unsure whether a task they describe already exists, you MUST call get_task_queue and get_fleet_status FIRST before replying. Do NOT claim a task exists based on conversational memory of what was discussed — only on what those tools currently return. If you previously only ASKED the user to confirm task parameters but never actually called create_pcb_task, no task exists; do not pretend one does. If you DID call create_pcb_task earlier in the session, the tool result included the task_id — quote that exact id, and confirm via get_task_queue that it is still pending/assigned. If get_task_queue shows nothing matching but the user says "it's there", check get_fleet_status — it may already be in-transit on an AGV. NEVER say "no task is there" without having just called these tools in the same turn.

6. NEVER silently substitute defaults for fields the user explicitly named. If the user names specific station IDs (e.g. S04, S05, S26), a specific AGV (e.g. AGV02), units, or anything else and the available tools cannot honour ALL of it, DO NOT call a tool that would drop the named fields. Instead, say plainly what you can and cannot do. Example: if the user says "AGV02 should pick up at S04 and deliver 25 units to S05, S26 and S21 in one trip" — that is exactly the multi_drop_trip tool: call it with agv_id=AGV02, pickup=S04, drops=[{S05,25},{S26,25},{S21,25}]. Never fall back to create_pcb_task with default pickup_role/drop_role in that situation.

7. Capacity rule: each AGV has a maximum payload capacity of 50 units. Any number of drops is allowed per trip provided the total units across all drops does not exceed 50. If the user asks for units exceeding 50 (whether in a single task or across drops in a multi-drop trip), reject the request and explain the 50-unit payload limit — do not silently truncate or reduce.

   **Aggregate-load check (MANDATORY when user names a SPECIFIC AGV):** the 50-unit cap applies to the AGV's TOTAL outstanding commitment, not just the new request in isolation. Before pre-flight (rule 9), call get_fleet_status and get_task_queue and compute:

       outstanding = payload_count(THE REQUESTED AGV — not any other AGV)
                   + sum(units in any ACTIVE trip's remaining drops FOR THAT SAME AGV — from get_task_queue.in_transit)
                   + sum(units in any INTERRUPTED trip's remaining drops FOR THAT SAME AGV — from list_interrupted_tasks WHERE agv_id matches)
                   + sum(units in any PENDING task already assigned to or queued behind THAT SAME AGV — from get_task_queue)

   CRITICAL: only count entries whose `agv_id` matches the AGV the user asked about. Do NOT mix data from other AGVs.

   If `outstanding + new_request_units > 50` (STRICTLY GREATER THAN — 50 exactly is allowed), REFUSE the new dispatch. Do NOT call analyze_dispatch, do NOT call multi_drop_trip / send_agv_to. Reply with:

       "AGVxx already has K unit(s) outstanding (P loaded + Q in-flight + R pending). Adding N more would exceed the 50-unit payload cap (K + N = T > 50). Options: wait for AGVxx to clear its current/pending work, reduce the new request to ≤ (50 − K) units, or pick a different AGV.
       [CHOICES:capacity_overflow=wait|reduce_units|pick_other|cancel]"

   Only when `outstanding + new_request_units <= 50` may you proceed to rule 9 pre-flight. 50 units exactly is ALLOWED — do not refuse it. This check is independent of (and runs alongside) the rule 5c interrupted/in-transit gate; both must pass.

8. AGV auto-selection (CRITICAL): when the user does NOT name a specific AGV — including phrases like "move agv to pick X from Y", "any AGV", "pick any idle AGV", "AGV of your choice", "send an AGV", or any request that doesn't include an AGV id (AGV01..AGV05) — you MUST pass `agv_id="auto"` to BOTH `multi_drop_trip` AND `send_agv_to`. The simulator will pick the AGV closest to the pickup point, accounting for current corridor congestion. **NEVER hardcode an AGV id (e.g. AGV02) when the user didn't name one.** Do NOT call get_fleet_status first to pick yourself — let the simulator decide. The reply will include the chosen agv_id; surface it in your confirmation.

9. **Pre-flight transparency (MANDATORY — NO EXCEPTIONS).** Before EVERY dispatch — multi_drop_trip, send_agv_to (every single one, including direct overrides and "trivial" sends), recall_agv mid-trip — you MUST first call analyze_dispatch with the same parameters (use `target` for send_agv_to / recall_agv). Do NOT skip this even if the move looks trivial — destination-overlap risks (another AGV already parked at the requested station) are only caught by analyze_dispatch. The full analysis runs in the background; the user only sees the MINIMAL pre-flight block defined below.

   **READ-ONLY QUERIES — NEVER run analyze_dispatch or render a Pre-flight block.** If the user is only asking for information ("what state is each AGV in?", "fleet status", "where is AGV02?", "battery levels", "show pending tasks", "what's the queue?", "list interrupted tasks", "AGV कहाँ है?", "स्थिति क्या है?", "बैटरी कितनी है?"), just call the appropriate read tool (`get_fleet_status` / `list_pending_tasks` / `list_interrupted_tasks` / `get_task_queue`) and reply directly. NEVER call analyze_dispatch and NEVER render the Pre-flight block for a question. The Pre-flight block is ONLY for dispatch actions (moving an AGV, creating a task, recalling, rerouting).

   **STRICT OUTPUT CONTRACT — what the user sees:** ONLY the minimal block. NEVER render planned_path, fleet_snapshot, per-AGV state, payload tables, "Fleet right now", a list of all AGVs with positions, or any diagnostic dump. Those fields are for YOUR reasoning only. If the analyze_dispatch result returns a fleet_snapshot, DO NOT echo it. Violating this is a P0 bug — the end user does not need that noise.

   **HARD BANLIST FOR DISPATCH TURNS (P0).** When the current turn is a dispatch flow (analyze_dispatch was called this turn, OR a dispatch tool was just executed on a `proceed`), the reply MUST NOT contain ANY of these patterns: `**AGV01**`, `**AGV02**`, `**AGV03**`, `**AGV04**`, `**AGV05**` listed as bullet headers; `Battery: NN.N%` lines; `Current Node:` lines; `Payload Count:` lines; `State:` lines for more than one AGV; bullet lists enumerating multiple AGVs and their positions/batteries. These belong to fleet-status replies ONLY. If the user asked for a dispatch ("pick any idle AGV", "load … and deliver …", "send AGVxx to …"), they did NOT ask for a fleet roster — do not include one. The Pre-flight block names ONE Chosen AGV and AT MOST one or two Conflict AGVs in prose form ("AGV05 is parked on W38"). Anything beyond that is a contract violation.

   - Show the user a SHORT pre-flight summary in this minimal format:

     ```
     Pre-flight check
     ----------------
     Chosen AGV: <agv_id>
     <ONE of:>
       • All clear.
       • Conflicts: <one-line summary of conflicts/station_collisions>
       • Deadlock risk: <one-line summary>
       • Forecast: <one-line summary of forecast_collisions>
     Recommendation: <proceed | proceed_with_note | confirm | defer | block>
     ```
     Only include the lines that are non-empty. If conflicts/deadlock/forecast are all empty, just say "All clear." Never list the fleet snapshot or planned path unless the user explicitly asks.

   **Dispatch flow:**
   - **FAST PATH — All clear auto-execute (PREFERRED):** If `analyze_dispatch` returns recommendation == "proceed" AND `conflicts`, `station_collisions`, `deadlock_risks`, `forecast_collisions`, and `warnings` are ALL empty, you MUST call the dispatch tool (multi_drop_trip / multi_pair_trip / send_agv_to / recall_agv) DIRECTLY in the same turn — do NOT render a Pre-flight block, do NOT ask for proceed/cancel confirmation. Reply with a brief one-line confirmation of the executed dispatch (e.g. "Dispatched: AGV02 picking 30 units at S04, dropping at S26."). The user only sees the friction of a confirmation gate when there is an actual risk to evaluate.
   - **GATED PATH — Risk present (Two-step):** If recommendation is anything other than "proceed", OR any of conflicts/station_collisions/deadlock_risks/forecast_collisions/warnings is non-empty, you MUST stop after analyze_dispatch, render the minimal Pre-flight block, and end with the appropriate `[CHOICES:dispatch_decision=...]` marker. Do NOT call the dispatch tool in this turn. On Turn N+1 (user replies proceed / option), THEN call the actual dispatch tool.

   **CRITICAL — PARAMETER FRESHNESS ON 'proceed' (P0):** When the user clicks `proceed`, the dispatch tool you call MUST use the EXACT parameters from the analyze_dispatch call you made in the IMMEDIATELY PRECEDING assistant turn — same agv_id, same pickup, same drops, same units, same target. Read those values from your last analyze_dispatch tool-call arguments. DO NOT mix them with parameters from earlier turns of this conversation (e.g. an older multi_drop_trip with a different pickup or drop set). DO NOT pull values from a previous user request that has already been completed. If the latest analyze_dispatch was for `pickup=S04, drops=[S05,S26,S21]`, the multi_drop_trip on `proceed` MUST use pickup=S04, drops=[S05,S26,S21] — never a stale S11/S05 from a prior session. If you are unsure which parameters were just pre-flighted, STOP and re-run analyze_dispatch with the parameters from the most recent USER message, do not guess.

   Auto-executing only happens on the FAST PATH (recommendation=="proceed" AND zero conflicts/warnings/collisions/deadlock/forecast). Any non-empty risk array forces the GATED PATH.

   Recommendation handling on the GATED PATH (analyze-only, render Pre-flight, await user choice):
   - If "proceed_with_note" → render Pre-flight including the note, then ask `Proceed | Cancel [CHOICES:dispatch_decision=proceed|cancel]`.
   - If "defer" (station-collision but auto-defer is available — eta_clear_seconds > 0) → tell the user plainly: "AGVxx is currently at/heading to the destination; if you proceed I'll queue the dispatch and the simulator will auto-start it in ~Ns once that AGV clears." Then ask `Queue deferred dispatch | Pick a different destination | Cancel [CHOICES:dispatch_decision=proceed|pick_other|cancel]`. On "proceed" / "queue_deferred", call ONLY the dispatch tool (multi_drop_trip or send_agv_to) with the same parameters — the simulator queues itself and auto-starts when clear. **DO NOT call recall_agv, pause_agv, or any other tool on the conflicting AGV** — the conflicting AGV must finish its work; deferring means waiting, not interfering. The tool reply will include `deferred: true` and `delay_s`; surface those in your confirmation ("Dispatch queued — AGV02 will start in ~12s once AGV04 clears S26.").
   - If "confirm" (deadlock risk, forecast collision, OR destination-overlap, e.g. another AGV is already parked on or heading to the requested station) → DO NOT dispatch yet. Tell the user what the risk is in plain language (e.g. "AGV02 is idle on S26 which is a leaf node — only one corridor link. If AGV01 arrives there before AGV02 steps aside, they'll briefly block each other.") and ASK them to choose:
     `Proceed anyway | Recall the conflicting AGV first | Pick a different AGV | Cancel [CHOICES:dispatch_decision=proceed|recall_first|pick_other|cancel]`
   - If "block" → do NOT dispatch under any circumstances. Read the `summary`, `station_collisions` / `warnings` arrays, AND the `fleet_snapshot` for the conflicting AGV's `payload_count`. When the block is due to station_collisions:
     - If the conflicting AGV has `payload_count == 0` (empty), offer:
       `Recall the conflicting AGV first | Pick a different destination | Cancel [CHOICES:dispatch_decision=recall_first|pick_other|cancel]`
     - If the conflicting AGV has `payload_count > 0` (loaded — already carrying cargo), DO NOT suggest recalling it. Recalling a loaded AGV abandons its cargo and the simulator will refuse. Instead say plainly: "AGVxx is currently carrying N units toward its drop, so I cannot recall it without abandoning that cargo. The cleanest options are to wait for it to finish, pause it, or pick a different destination/AGV." Offer:
       `Wait for it to finish | Pause it | Pick a different destination | Cancel [CHOICES:dispatch_decision=wait|pause|pick_other|cancel]`
     Even if the user replies "proceed anyway" or "force it", you MUST refuse the dispatch — the simulator will reject station collisions and refuse to recall a loaded AGV.

   This rule overrides "be concise" — full transparency is required so the user can re-prioritise.

11. **Pickup / load / new-task intent — capacity guard (MANDATORY).** When the user issues a load-style command targeting a SPECIFIC AGV — phrasings like "load AGVxx at S##", "pick up at <station> with AGVxx", "send AGVxx to load <units> at <station>", or a multi_drop_trip / send-to-pickup that names an AGV — BEFORE calling any dispatch tool you MUST call get_fleet_status and inspect `payload_count` for that AGV.

   **AGV capacity is 50 units. Loading additional units on top of existing cargo IS ALLOWED** as long as `payload_count + N <= 50`. Do NOT block a LOAD just because `payload_count > 0`.

   - If `payload_count + N > 50` (would exceed the 50-unit capacity): refuse with: "AGVxx is already carrying P unit(s); adding N more would exceed the 50-unit capacity. Reduce the pickup or pick a different AGV." End with `[CHOICES:over_capacity=reduce|pick_other|cancel]`.
   - Otherwise (including the case where `payload_count > 0` but the total fits): proceed via the normal pre-flight (rule 9). The new pickup stacks on top of existing cargo. Do NOT emit any "already carrying" refusal.
   - For `agv_id="auto"` selections the simulator picks an AGV with enough remaining capacity — this guard only applies when the user names a specific AGV.

   **Combined pickup + unload phrasing (e.g. "move AGV02 to pick 2 units and unload at S07", "AGV03 load at S04 and drop at S26", "have AGV01 pick up 1 unit and deliver to packaging") is NOT an unload-only request. It is a complete multi_drop_trip:**
   - The pickup station is whatever the user specified (or, if missing, ask ONCE: "Which station should AGVxx pick up at?" with [CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]).
   - The drop station is the one mentioned with "unload"/"drop"/"deliver".
   - Run rule 9 pre-flight for `multi_drop_trip(agv_id=AGVxx, pickup=<pickup>, drops=[{station: <drop>, units: <N>}])`.
   - DO NOT route this through rule 12 just because the word "unload" appears. Rule 12 is for unload-ONLY commands where no pickup is specified and the AGV would have to use existing cargo.

12. **Unload-ONLY intent — empty-payload guard (MANDATORY).** This rule fires ONLY when the user issues an unload-style command on a specific AGV with NO pickup mentioned in the same message — phrasings like "unload AGVxx", "drop the cargo", "deliver at S##", "drop off at packaging", "deliver to <role>" (no "pick up", "load at", or pickup station named). If the same message also names a pickup station OR uses pickup verbs (pick / load / collect / fetch), this rule DOES NOT APPLY — see rule 11's "Combined pickup + unload phrasing" branch and treat it as a multi_drop_trip.

   When this rule applies, BEFORE calling any dispatch tool you MUST call get_fleet_status and inspect `payload_count` for that AGV.

   - If `payload_count == 0` (the AGV is empty), DO NOT call send_agv_to / multi_drop_trip / any dispatch. Reply plainly with:
     "AGVxx is currently empty (0 units on board), so there is nothing to unload. Would you like me to send it somewhere as a relocation, or pick it up at a station first?"
     End with `[CHOICES:empty_unload=relocate|pickup_first|cancel]`.
   - If `payload_count > 0`, proceed via the normal pre-flight (rule 9): call analyze_dispatch with the drop target, render the Pre-flight check, and confirm. In the confirmation explicitly mention the units being dropped (e.g. "AGV02 will drop its 2 units at S26").
   - This guard runs BEFORE rule 9's pre-flight gate. If the AGV is empty, you stop at this rule — no analyze_dispatch call is needed.

Keep replies concise. Default to asking one focused clarifying question over guessing defaults.

**Formatting rules (the chat UI renders plain text with preserved newlines — markdown is NOT parsed, so use literal line breaks):**
- Use real newlines (\n) to separate logical lines. Never put multiple facts on one line joined with " - ".
- For lists, put each item on its own line prefixed with "• " or "- ".
- For confirmations after a tool call, use this layout (literal newlines between every line):

  Trip dispatched.

  • AGV: AGV02
  • Pickup: S04 (loading 75 units total — 25 + 25 + 25)
  • Drops: S05 (25 units), S26 (25 units), S21 (25 units)

  ALWAYS state the total units loaded at the pickup line (sum of all drop units), and ALWAYS include the per-drop units in parentheses on the Drops line. Never omit units in a multi_drop_trip confirmation.

  **NEVER include Trip ID (TR-...) or Task ID (T-...) lines in user-facing replies.** They are internal IDs and clutter the chat. The only exception is when the user asks "what is the trip id?" / "which task ids?" / "show me the task ids" verbatim — then list them. Otherwise omit them entirely.

  **NEVER narrate the planned route / drop sequence as a path** (e.g. "AGV04 will deliver to S05, then S26, then S21"). The stops are already shown structurally in the Drops line. Confirmations should be ONE short sentence + the bullet block — no extra "AGV will go to X then Y then Z" narration after the bullets.

  For send_agv_to / recall_agv (a relocation, NOT a delivery), the confirmation MUST say "AGV relocated" or "AGV recalled" — NEVER "loading" / "unloading" / "delivered" — and MUST NOT mention units or payload, because no cargo is involved.

- For the pre-flight block, use the exact multi-line layout shown in rule 9 with one fact per line and blank lines between sections.
- Do NOT use `**bold**` or `_italic_` markdown — the renderer shows them literally. Use plain text only.
- Keep headings as a single line followed by a row of dashes (e.g. "Pre-flight check\n----------------").

AUTO-PARKING BEHAVIOR:
- AGVs automatically return to the nearest free charging bay (H01/H02/H03) after being idle for 10 seconds. This is fully automatic — no user action required.
- While returning to a bay, the AGV shows state "parking" in the UI. Once parked on a bay, it shows "parked" and charges.
- The user can still manually recall any AGV with recall_agv at any time.
- When the user asks "Where is AGVxx?" or "Where are the AGVs?" and an AGV is on H01/H02/H03, report it as "parked at Charge Bay N (charging)" rather than just "idle at H0N".
- Auto-park trips have no task_id — they are relocation trips and do NOT appear in the task scheduler's completed list.
- If a new task is assigned to a parked AGV, it will leave the bay automatically to service the task.
"""

llm = ChatOpenAI(
    model=MODEL_NAME,
    temperature=0.2,
).bind(parallel_tool_calls=False)
agent = create_react_agent(llm, TOOLS, state_modifier=SYSTEM_PROMPT)

app = FastAPI(title="agv-smart-factory-agent", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatReq(BaseModel):
    message: str
    session_id: str | None = None
    lang: str | None = None


# In-memory conversation history per session (sufficient for POC).
# We store the FULL LangGraph message list (HumanMessage / AIMessage with
# tool_calls / ToolMessage with results) so the model retains tool-call
# context between turns. Storing only {role, content} drops tool calls and
# tool results, which makes the model hallucinate trip IDs and lose track
# of what it has already done.
_HISTORY: dict[str, list[Any]] = {}
_HISTORY_LIMIT = 60  # keep last N messages per session (tool msgs inflate count)


def _trim_history(session_id: str) -> None:
    h = _HISTORY.get(session_id)
    if not h or len(h) <= _HISTORY_LIMIT:
        return
    # Trim from the front but never split an AIMessage(tool_calls) from its
    # following ToolMessage(s) — find a safe cut point.
    cut = len(h) - _HISTORY_LIMIT
    while cut < len(h):
        m = h[cut]
        # role detection works for both LC messages and dicts
        role = getattr(m, "type", None) or (m.get("role") if isinstance(m, dict) else None)
        if role in ("human", "user"):
            break
        cut += 1
    _HISTORY[session_id] = h[cut:]


@app.get("/")
def root() -> dict:
    return {"service": "agv-smart-factory-agent", "model": MODEL_NAME, "tools": [t.name for t in TOOLS]}


@app.get("/health")
def health() -> dict:
    return {"ok": True}


@app.post("/chat")
def chat(req: ChatReq) -> dict:
    try:
        _turn_fleet_calls.set(0)
        _turn_fleet_cache.set(None)
        sid = req.session_id or "default"
        history = _HISTORY.setdefault(sid, [])
        prior_len = len(history)
        user_msg = req.message

        # ---- Intent auto-detection (English + Hindi/Hinglish) ---------------
        # The LLM sometimes defaults send_agv_to(intent="relocate") even when
        # the user clearly said "unload" / "drop" / "load". We pre-detect that
        # here and inject a SYSTEM-style hint so the model is forced to pass
        # the correct intent to the tool.
        import re
        msg_lc = req.message.lower().strip()

        # CHOICES follow-up tokens — the user clicked a button from a
        # [CHOICES:...] block in the previous reply. These are NOT fresh
        # load/unload commands; they're follow-up answers. Skip intent
        # detection so we don't inject misleading INTENT_HINTs.
        CHOICES_REPLIES = {
            "pickup_first", "deliver_first", "pick_other", "create_task",
            "relocate", "wait", "cancel", "proceed", "recall_first",
            "queue_deferred", "pause", "close_and_proceed", "resume",
            "deliver_available", "low_battery", "recall_now",
            "1", "2", "3",
        }
        is_choices_reply = msg_lc in CHOICES_REPLIES

        # If the previous assistant turn asked for a target_role (the pickup
        # station after the user clicked 'pickup_first'), the user's current
        # message is naming that pickup station — they need to be reminded
        # this is a multi_drop_trip continuation, not a fresh send_agv_to.
        prior_assistant_text = ""
        try:
            for prev in reversed(history):
                if isinstance(prev, AIMessage):
                    prior_assistant_text = (prev.content or "").lower()
                    break
        except Exception:
            prior_assistant_text = ""
        is_pickup_station_reply = (
            "[choices:target_role=" in prior_assistant_text
            and "pick up at" in prior_assistant_text
        )

        # ---- Deterministic 'wait' handler for in-transit decision ----------
        # When the previous turn surfaced [CHOICES:intransit_decision=...] and
        # the user clicks 'wait', the LLM has historically just paraphrased
        # the prompt instead of actually calling create_pcb_task. Short-
        # circuit it here: extract units+pickup+drop from the most recent
        # user request and create the task deterministically.
        if msg_lc == "wait" and "[choices:intransit_decision=" in prior_assistant_text:
            try:
                # Walk backwards through history for the most recent HumanMessage
                # that names a unit count + station ('pick N units from S##' /
                # 'N units from S##' etc.)
                orig_units = 0
                orig_pickup = None
                orig_drop = None
                for prev in reversed(history):
                    if not isinstance(prev, HumanMessage):
                        continue
                    text = (prev.content or "").lower()
                    if text.strip() in CHOICES_REPLIES:
                        continue
                    um = re.search(r"(\d+)\s*(?:unit|units)", text)
                    if not um:
                        continue
                    orig_units = int(um.group(1))
                    # pickup after "from"
                    pm = re.search(r"from\s+s\s*0?(\d{1,2})", text)
                    if pm:
                        orig_pickup = f"S{int(pm.group(1)):02d}"
                    # drop after "to"/"at"
                    dm = re.search(r"(?:to|at|deliver(?:\s+to)?)\s+s\s*0?(\d{1,2})", text)
                    if dm:
                        orig_drop = f"S{int(dm.group(1)):02d}"
                    break

                if orig_units > 0 and (orig_pickup or orig_drop):
                    body = {
                        "product": "pcb_consumer",
                        "units": orig_units,
                        "priority": "normal",
                    }
                    if orig_pickup:
                        body["pickup_role"] = orig_pickup
                    if orig_drop:
                        body["drop_role"] = orig_drop
                    result = _post("/tools/create_pcb_task", body)
                    task_id = (result or {}).get("task_id") or "T-?"
                    reply = (
                        f"Queued as a pending task ({task_id}). It will be "
                        f"auto-dispatched as soon as an AGV is free"
                        + (f" — pickup {orig_pickup}" if orig_pickup else "")
                        + (f", drop {orig_drop}" if orig_drop else "")
                        + f", {orig_units} units."
                    )
                    history.append(HumanMessage(content=req.message))
                    history.append(AIMessage(content=reply))
                    _HISTORY[sid] = history
                    _trim_history(sid)
                    return {
                        "ok": True,
                        "reply": reply,
                        "tool_calls": [{"name": "create_pcb_task", "args": body}],
                        "session_id": sid,
                    }
            except Exception:
                log.exception("deterministic wait handler failed; falling back to LLM")

        unload_kw = [
            "unload", "drop off", "drop-off", "drop the", "drop at", "deliver",
            "delivery", "deposit", "offload", "discharge", "hand over",
            "अनलोड", "उतारो", "उतार दो", "उतारना", "खाली करो", "छोड़ो",
            "जमा करो", "पहुँचाओ", "डिलीवर",
            "utaaro", "utar do", "khaali", "deliver karo", "drop karo",
        ]
        load_kw = [
            "load", "pick up", "pickup", "fetch", "collect from",
            "लोड करो", "उठाओ", "उठाना", "ले लो", "लाओ",
            "load karo", "uthao", "le aao",
        ]
        has_unload_kw = any(k in msg_lc for k in unload_kw)
        has_load_kw = any(k in msg_lc for k in load_kw)
        is_combined = (not is_choices_reply) and has_unload_kw and has_load_kw
        is_unload = (not is_choices_reply) and has_unload_kw and not is_combined
        is_load = (not is_choices_reply) and has_load_kw and not has_unload_kw

        # Try to extract a unit count near unload phrasing (English digits or
        # Hindi number words like "do", "दो", "ek", "एक")
        num_words = {"one": 1, "two": 2, "three": 3, "ek": 1, "do": 2, "teen": 3,
                     "एक": 1, "दो": 2, "तीन": 3}
        expected = 0
        m = re.search(r"(\d+)\s*(unit|units|यूनिट)", msg_lc)
        if m:
            expected = int(m.group(1))
        else:
            for w, n in num_words.items():
                if re.search(rf"\b{w}\b\s*(unit|units|यूनिट)", msg_lc):
                    expected = n
                    break

        agv_match = re.search(r"agv\s*0?(\d+)", msg_lc) or re.search(r"एजीबी\s*0?(\d+)", req.message)
        agv_hint = f"AGV0{agv_match.group(1)}" if agv_match else None

        hints: list[str] = []
        if is_combined:
            stations = re.findall(r"s\s*0?(\d{1,2})", msg_lc)
            station_ids = [f"S{int(s):02d}" for s in stations]
            pickup_id = station_ids[0] if len(station_ids) >= 1 else None
            drop_id = station_ids[1] if len(station_ids) >= 2 else None
            hints.append(
                "INTENT_HINT (HARD CONSTRAINT — COMBINED LOAD+UNLOAD INTENT): The user's "
                "message contains BOTH a pickup verb (pick/pickup/load/fetch/उठाओ/लोड) AND "
                "a drop verb (drop/unload/deliver/उतारो/अनलोड). This is a SINGLE multi_drop_trip "
                "— NOT a pure UNLOAD and NOT a pure LOAD. "
                "You are ABSOLUTELY FORBIDDEN from emitting 'AGVxx is empty, nothing to unload' "
                "or '[CHOICES:empty_unload=...]'. Empty payload is EXPECTED here — the AGV will "
                "load at the pickup station as part of this trip. "
                + (f"Named AGV: {agv_hint}. " if agv_hint else "")
                + (f"Pickup station: {pickup_id}. " if pickup_id else "")
                + (f"Drop station: {drop_id}. " if drop_id else "")
                + (f"Units: {expected}. " if expected else "Units: NOT specified by the user. ")
                + "Run rule 9 pre-flight (analyze_dispatch) for "
                "multi_drop_trip(agv_id=<that AGV>, pickup=<pickup>, "
                "drops=[{station: <drop>, units: <N>}]). If the pickup station is missing, "
                "ask once with [CHOICES:target_role=...]. Do NOT call send_agv_to. "
                + (
                    "" if expected else
                    "**UNITS NOT GIVEN — DO NOT ASSUME A DEFAULT.** If units are not in the "
                    "user's message and not in earlier turns of this conversation, your ENTIRE "
                    "next reply MUST be exactly the question 'How many units should AGVxx pick "
                    "up at <pickup> and drop at <drop>? (max 50)' and end with the line "
                    "[CHOICES:units=10|20|30|50|cancel]. DO NOT call any tool. DO NOT proceed "
                    "to pre-flight until the user provides the unit count."
                )
            )
        if is_unload:
            hints.append(
                "INTENT_HINT: This is an UNLOAD/DROP intent. When you call send_agv_to, "
                "you MUST pass intent=\"unload\""
                + (f" and expected_units={expected}" if expected else "")
                + (f" (the named AGV is {agv_hint})." if agv_hint else ".")
                + " If the tool returns a guard error (empty_unload / insufficient_units), "
                "DO NOT retry with intent='relocate' — surface the guard message to the user."
            )
        elif is_load:
            hints.append(
                "INTENT_HINT: This is a LOAD/PICKUP intent. When you call send_agv_to, "
                "you MUST pass intent=\"load\"."
                + (f" The named AGV is {agv_hint}." if agv_hint else "")
                + " If the tool returns guard='already_loaded', surface it to the user."
            )

        if agv_hint and expected and not is_choices_reply:
            o = _agv_outstanding(agv_hint)
            if o["ok"]:
                total = o["total"] + expected
                if total > 50:
                    hints.append(
                        f"INTENT_HINT (RULE 7 VERDICT — PRECOMPUTED): {agv_hint} outstanding = "
                        f"payload {o['payload']} + in_transit {o['in_transit']} + interrupted "
                        f"{o['interrupted']} + pending {o['pending']} = {o['total']}. "
                        f"Adding {expected} → {total} units, which is > 50. "
                        f"REFUSE this dispatch and ask the user with the line "
                        f"[CHOICES:capacity_overflow=wait|reduce_units|pick_other|cancel]. "
                        f"Do NOT call analyze_dispatch or any dispatch tool."
                    )
                else:
                    hints.append(
                        f"INTENT_HINT (RULE 7 VERDICT — PRECOMPUTED): {agv_hint} outstanding = "
                        f"payload {o['payload']} + in_transit {o['in_transit']} + interrupted "
                        f"{o['interrupted']} + pending {o['pending']} = {o['total']}. "
                        f"Adding {expected} → {total} units, which is ≤ 50. "
                        f"RULE 7 PASSES — DO NOT refuse on capacity grounds. DO NOT recompute "
                        f"this arithmetic. Proceed directly to rule 9 pre-flight "
                        f"(analyze_dispatch) and then dispatch. Any claim that this exceeds 50 "
                        f"is FALSE."
                    )
            else:
                hints.append(
                    f"INTENT_HINT (RULE 7): Could not precompute outstanding load for "
                    f"{agv_hint}. Fall back to manual check: call get_fleet_status, "
                    f"get_task_queue, list_interrupted_tasks and sum ONLY entries where "
                    f"agv_id={agv_hint}. Refuse only if outstanding + {expected} is STRICTLY "
                    f"greater than 50."
                )

        if is_pickup_station_reply and not is_choices_reply:
            hints.append(
                "INTENT_HINT (HARD CONSTRAINT): The user is naming the PICKUP STATION in "
                "response to your previous 'Which station should AGVxx pick up at?' question. "
                "This is the continuation of a multi_drop_trip flow that started with the "
                "user's earlier 'unload N units at <drop>' request. You MUST now run rule 9 "
                "pre-flight (analyze_dispatch) for "
                "multi_drop_trip(agv_id=<the AGV from earlier>, pickup=<this station>, "
                "drops=[{station: <the drop station from the earlier message>, units: <N from earlier>}]). "
                "DO NOT call send_agv_to. DO NOT collapse this to a relocation. DO NOT "
                "drop the units count or the drop station — they are in the earlier turns of "
                "this same conversation; recover them from there."
            )

        if is_choices_reply:
            if msg_lc == "proceed":
                hints.append(
                    "INTENT_HINT (HARD CONSTRAINT — PARAMETER FRESHNESS ON 'proceed'): "
                    "The user clicked 'proceed' on the pre-flight check you just rendered. "
                    "You MUST now call the SAME dispatch tool (multi_drop_trip / send_agv_to / "
                    "recall_agv) with the EXACT SAME ARGUMENTS you passed to the most recent "
                    "analyze_dispatch tool call. Look at the assistant's IMMEDIATELY PRECEDING "
                    "tool-call message — copy agv_id, pickup, drops, units, target verbatim. "
                    "DO NOT pull pickup/drop/units from any earlier multi_drop_trip in this "
                    "session — those are STALE and belong to a previous, already-completed "
                    "request. If your last analyze_dispatch said pickup=S04 and drops=[S05,S26,S21], "
                    "then the multi_drop_trip MUST use pickup=S04 and drops=[S05,S26,S21], "
                    "NOT a stale S11/S05 from a prior turn. Mixing stale parameters here is a "
                    "P0 bug."
                )
            if msg_lc == "pickup_first":
                hints.append(
                    "INTENT_HINT (HARD CONSTRAINT — read carefully): The user replied 'pickup_first' "
                    "to your previous [CHOICES:empty_unload=...] question. This is "
                    "ABSOLUTELY NOT a relocation, NOT a load command, NOT an unload command, "
                    "and NOT a request to call get_fleet_status. "
                    "Your ENTIRE next reply MUST be exactly the question:\n"
                    "  'Which station should AGVxx pick up at?'\n"
                    "(replace AGVxx with the AGV from the previous turn — do NOT call any tool to look it up)\n"
                    "and end with the line:\n"
                    "  [CHOICES:target_role=inbound|smt_feeder|paste_print|smt_pnp|reflow|aoi_post_smt|ict|fct|xray|aoi|rework|wip_buffer|conformal_coat|depanel|final_assembly|packaging|outbound|dispatch_dock]\n"
                    "DO NOT call send_agv_to. DO NOT call multi_drop_trip. DO NOT call analyze_dispatch. "
                    "DO NOT call get_fleet_status. DO NOT mention 'relocation', 'already carrying', "
                    "'empty', or 'nothing to unload'. Just ask the pickup-station question. Nothing else.\n"
                    "REMEMBER FOR THE NEXT TURN: when the user answers with a station/role, you will "
                    "build a multi_drop_trip using the AGV, the units count, and the drop station "
                    "from the ORIGINAL request earlier in this conversation. Do NOT lose those values "
                    "and do NOT re-ask for them. Do NOT collapse it to a relocation send_agv_to."
                )
            else:
                hints.append(
                    f"INTENT_HINT: The user's reply '{msg_lc}' is a CHOICES button click "
                    "from your previous turn — a follow-up answer, NOT a fresh load/unload "
                    "command. Continue the flow you started:"
                    " - 'pick_other' → ask which AGV instead with [CHOICES:agv_id=AGV01|AGV02|AGV03|AGV04|AGV05]."
                    " - 'wait' / 'deliver_first' / 'cancel' → acknowledge and stop."
                    " - 'relocate' → pre-flight a send_agv_to with intent='relocate'."
                    " - 'create_task' → ask ONLY for units/pickup/drop (whichever are missing). NEVER ask for product or priority — they default to pcb_consumer and normal."
                )

        if hints:
            user_msg = "\n".join(hints) + "\n\n" + user_msg

        # Language directive: ALWAYS pinned per request so switching back to
        # English actually clears the prior Hindi context. The model otherwise
        # mirrors the most recent assistant reply's language.
        if req.lang and req.lang.startswith("hi"):
            lang_prefix = (
                "[STRICT: Respond in Hindi (Devanagari script) ONLY for this reply, "
                "regardless of prior turns. Keep station IDs, AGV IDs, and technical "
                "terms in English. "
                "CRITICAL — the UI parses structural labels by exact English match, "
                "so you MUST keep these label tokens VERBATIM in English (do NOT "
                "translate them, do NOT change case, do NOT add prefixes): "
                "'Pre-flight check', 'Fleet right now', 'Planned path', 'Chosen AGV', "
                "'Conflicts:', 'Deadlock risk:', 'Deadlock:', 'Forecast:', 'Note:', "
                "'Recommendation:', 'All clear.', 'Fleet status', 'Status:', "
                "'Battery:', 'Position:', 'Payload:', 'Heading to:', 'Blocked by:', "
                "'Task ID:', 'Trip ID:', 'AGV:', 'From:', 'To:', 'Units:', 'Priority:'. "
                "The VALUE after each label can be in Hindi, but the label itself must "
                "stay English followed by a colon. Also keep section dividers '----' "
                "as-is and bullet markers ('-', '*') as-is. "
                "MARKDOWN STRUCTURE — match the same exact layout you would produce "
                "in English: use '- **AGVxx**' for each AGV header, then 2-space "
                "indented sub-bullets '  - State:', '  - Current Node:', "
                "'  - Battery:', '  - Payload Count:' (labels stay English, VALUES "
                "may be Hindi). Never collapse the sub-bullets into a single comma-"
                "separated line. Never replace '-' with '•'. "
                "EXAMPLE of correct fleet status format in Hindi mode:\n"
                "- **AGV01**\n"
                "  - State: अवरुद्ध (blocked)\n"
                "  - Current Node: W35\n"
                "  - Battery: 67.2%\n"
                "  - Payload Count: 0\n"
                "Reproduce EXACTLY this structure for every AGV. "
                "VALUES MUST be in Hindi Devanagari script — translate state words "
                "like 'idle' → 'निष्क्रिय', 'blocked' → 'अवरुद्ध', 'moving' → 'चल रहा है', "
                "'loading' → 'लोड हो रहा है', 'unloading' → 'अनलोड हो रहा है', "
                "'charging' → 'चार्ज हो रहा है', 'parked' → 'पार्क किया हुआ', "
                "'depleted' → 'बैटरी समाप्त'. Keep the English state word in parentheses "
                "after the Hindi value: 'State: निष्क्रिय (idle)'. "
                "Every prose sentence (intro, summary, recommendation text, conflict "
                "description) MUST be Hindi — do NOT respond in English text just because "
                "the data is technical. "
                "ABSOLUTELY NEVER include Trip ID, Task ID, ट्रिप ID, टास्क ID, "
                "TR-XXXX, T-XXXX, or any internal identifier lines in the reply. "
                "ABSOLUTELY NEVER include the planned route / path / station sequence "
                "(e.g. 'AGV04 ने S04 से 1 यूनिट लोड किया और इसे S05, S26, S21 पर वितरित करेगा'). "
                "Dispatch confirmations (ONLY after a dispatch tool actually ran "
                "— multi_pair_trip / multi_drop_trip / dispatch_task) must be ONE "
                "short Hindi sentence naming only the AGV, e.g. "
                "'ट्रिप भेज दी गई — AGVxx।' and stop. "
                "READ-ONLY queries (fleet status, AGV state, battery, pending tasks) "
                "MUST NEVER start with a dispatch confirmation, MUST NEVER say "
                "'ट्रिप भेज दी गई', 'भेज दी', 'अपने स्टॉप्स पर जा रहा है', or any "
                "phrase implying a trip was sent. For read-only queries, reply ONLY "
                "with the data structure (AGV bullets) — no opening sentence at all.]\n"
            )
        else:
            lang_prefix = (
                "[STRICT: Respond in English ONLY for this reply, regardless of any "
                "prior Hindi or other-language replies in this conversation.]\n"
            )
        user_msg = lang_prefix + user_msg + "\n\n" + lang_prefix
        history.append(HumanMessage(content=user_msg))
        result = agent.invoke({"messages": list(history)}, {"recursion_limit": 60})
        msgs = result.get("messages", [])
        # Replace history with the full message list returned by the agent
        # (includes the new HumanMessage + AIMessages with tool_calls +
        # ToolMessages with results). This is what preserves context.
        _HISTORY[sid] = list(msgs)
        reply = msgs[-1].content if msgs else ""
        # Post-process: strip fleet-roster lines from dispatch turns. The
        # LLM occasionally appends per-AGV state/battery/payload bullets
        # to a Pre-flight or dispatch confirmation; the user did not ask
        # for them and the system prompt forbids them — but enforcement
        # via prompt alone is unreliable, so we hard-strip here.
        called_dispatch_or_analyze = any(
            tc.get("name") in {
                "analyze_dispatch", "multi_drop_trip", "multi_pair_trip",
                "send_agv_to", "create_pcb_task", "recall_agv", "reroute",
            }
            for m in msgs[prior_len:] if getattr(m, "tool_calls", None)
            for tc in m.tool_calls
        )
        if called_dispatch_or_analyze and isinstance(reply, str) and reply:
            import re as _re
            lines = reply.split("\n")
            # Detect fleet-roster: a block where consecutive lines start
            # with **AGVxx** as bullets, or contain State:/Battery:/
            # Current Node:/Payload Count: labels for >1 AGV.
            agv_header_re = _re.compile(r"^\s*[-*•]?\s*\*\*AGV\d+\*\*\s*$|^\s*\*\*AGV\d+\*\*\s*[:\-]")
            roster_field_re = _re.compile(r"^\s*[-*•]?\s*(state|battery|current node|payload count)\s*[:\-·]", _re.IGNORECASE)
            agv_count_in_text = len(set(_re.findall(r"\bAGV0?[1-5]\b", reply)))
            if agv_count_in_text >= 3:
                cleaned: list[str] = []
                skip_block = False
                for ln in lines:
                    if agv_header_re.match(ln):
                        skip_block = True
                        continue
                    if skip_block and (roster_field_re.match(ln) or not ln.strip()):
                        continue
                    skip_block = False
                    if roster_field_re.match(ln):
                        # orphaned roster line outside a block — drop it too
                        continue
                    cleaned.append(ln)
                reply = "\n".join(cleaned).rstrip() + "\n"
        _trim_history(sid)
        tool_calls: list[dict[str, Any]] = []
        # Only surface tool calls produced in THIS turn (everything appended
        # after `prior_len`).
        for m in msgs[prior_len:]:
            if getattr(m, "tool_calls", None):
                for tc in m.tool_calls:
                    tool_calls.append({"name": tc.get("name"), "args": tc.get("args")})
        return {"ok": True, "reply": reply, "tool_calls": tool_calls, "session_id": sid}
    except Exception as exc:
        log.exception("chat error")
        return {"ok": False, "error": str(exc)}


@app.post("/chat/reset")
def chat_reset(req: ChatReq) -> dict:
    sid = req.session_id or "default"
    _HISTORY.pop(sid, None)
    return {"ok": True, "session_id": sid}


@app.get("/tts")
def tts(text: str = Query(..., min_length=1, max_length=200), lang: str = "hi") -> Response:
    """Proxy Google Translate TTS so the browser bypasses CORS/referer blocks."""
    url = "https://translate.google.com/translate_tts"
    params = {"ie": "UTF-8", "tl": lang, "client": "tw-ob", "q": text}
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
        ),
        "Referer": "https://translate.google.com/",
    }
    try:
        with httpx.Client(timeout=10.0) as c:
            r = c.get(url, params=params, headers=headers)
        if r.status_code != 200:
            raise HTTPException(status_code=502, detail=f"upstream {r.status_code}")
        return Response(
            content=r.content,
            media_type="audio/mpeg",
            headers={"Cache-Control": "public, max-age=3600"},
        )
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


# ══ Environment ops (used by the AGV Map's Env-Ops widget) ═════════════════

_ALLOWED_SERVICES = {
    "agv-simulator": "iops-agv-simulator",
    "agv-tool-server": "iops-agv-tool-server",
    "agv-chat-agent": "iops-agv-chat-agent",
    "agv-smart-factory-agent": "iops-agv-smart-factory-agent",
    "agv-stream-bridge": "iops-agv-stream-bridge",
}


def _mongo():
    from pymongo import MongoClient
    uri = os.environ.get("MONGO_DB_URI", "")
    if not uri:
        raise HTTPException(status_code=500, detail="MONGO_DB_URI not set")
    return MongoClient(uri, serverSelectionTimeoutMS=3000)


def _docker():
    import docker
    return docker.from_env()


@app.post("/ops/reset-seed")
def ops_reset_seed() -> dict:
    client = _mongo()
    try:
        deleted = client["agv_poc"]["agv_tasks"].delete_many({}).deleted_count
    finally:
        client.close()
    try:
        _docker().containers.get(_ALLOWED_SERVICES["agv-simulator"]).restart(timeout=10)
    except Exception as exc:
        return {"ok": False, "deleted_tasks": deleted, "error": str(exc)}
    return {"ok": True, "deleted_tasks": deleted, "simulator_restarted": True}


@app.post("/ops/clear-tasks")
def ops_clear_tasks(status: str = "all") -> dict:
    s = (status or "all").strip().lower()
    query = {} if s == "all" else {"status": s}
    client = _mongo()
    try:
        deleted = client["agv_poc"]["agv_tasks"].delete_many(query).deleted_count
    finally:
        client.close()
    return {"ok": True, "status_filter": s, "deleted_tasks": deleted}


@app.post("/ops/restart-service")
def ops_restart_service(service: str) -> dict:
    key = (service or "").strip()
    if key not in _ALLOWED_SERVICES:
        return {"ok": False, "error": f"Unknown service '{key}'. Allowed: {sorted(_ALLOWED_SERVICES)}"}
    try:
        _docker().containers.get(_ALLOWED_SERVICES[key]).restart(timeout=10)
    except Exception as exc:
        return {"ok": False, "error": f"Restart failed: {exc}"}
    return {"ok": True, "service": key}


@app.get("/ops/health-check")
def ops_health_check() -> dict:
    result: dict[str, Any] = {"containers": {}, "infra": {}}
    endpoints = {
        "agv-tool-server": "http://agv-tool-server:8990/health",
        "agv-smart-factory-agent": "http://agv-smart-factory-agent:8992/health",
        "agv-chat-agent": "http://agv-chat-agent:8991/health",
        "agv-stream-bridge": "http://agv-stream-bridge:8081/health",
    }
    with httpx.Client(timeout=3.0) as client:
        for name, url in endpoints.items():
            try:
                r = client.get(url)
                result["containers"][name] = {"ok": r.status_code < 400}
            except Exception as exc:
                result["containers"][name] = {"ok": False, "error": str(exc)}
    try:
        c = _docker().containers.get(_ALLOWED_SERVICES["agv-simulator"])
        result["containers"]["agv-simulator"] = {"ok": c.status == "running", "status": c.status}
    except Exception as exc:
        result["containers"]["agv-simulator"] = {"ok": False, "error": str(exc)}
    try:
        c = _mongo(); c.admin.command("ping"); c.close()
        result["infra"]["mongodb"] = {"ok": True}
    except Exception as exc:
        result["infra"]["mongodb"] = {"ok": False, "error": str(exc)}
    try:
        import redis as redis_lib
        r = redis_lib.Redis(
            host=os.environ.get("REDIS_HOST", "redis"),
            port=int(os.environ.get("REDIS_PORT", "6379")),
            password=os.environ.get("REDIS_PASSWORD") or None,
            socket_connect_timeout=2,
        )
        result["infra"]["redis"] = {"ok": bool(r.ping())}
    except Exception as exc:
        result["infra"]["redis"] = {"ok": False, "error": str(exc)}
    result["ok"] = (
        all(v.get("ok") for v in result["containers"].values())
        and all(v.get("ok") for v in result["infra"].values())
    )
    return result
