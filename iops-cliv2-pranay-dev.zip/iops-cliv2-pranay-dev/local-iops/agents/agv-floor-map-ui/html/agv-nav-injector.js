(function () {
  "use strict";

  var TARGET_URL = "/agv-floor-map/";
  var LABEL = "AGV Floor Map";
  var ID = "agv-floor-map-nav-item";
  var IFRAME_ID = "agv-floor-map-iframe-host";
  var STYLE_ID = "agv-nav-styles";
  var STATE = { open: false, suppressed: [] };

  function findItemByText(text) {
    var els = document.querySelectorAll('a, button, [role="link"], [role="button"], li, div');
    for (var i = 0; i < els.length; i++) {
      if ((els[i].textContent || "").trim() === text) return els[i];
    }
    return null;
  }

  function findSidebar() {
    var settings = findItemByText("Settings");
    if (!settings) return null;
    var el = settings;
    while (el && el.parentElement) {
      var w = el.offsetWidth, h = el.offsetHeight;
      if (w > 100 && w < window.innerWidth * 0.5 && h > window.innerHeight * 0.4) return el;
      el = el.parentElement;
    }
    return null;
  }

  function findBreadcrumbBar() {
    var crumb = findItemByText("IntelligentOps");
    if (!crumb) return null;
    var el = crumb;
    var sidebarRight = 0;
    var sb = findSidebar();
    if (sb) sidebarRight = sb.getBoundingClientRect().right;
    while (el && el.parentElement) {
      var r = el.getBoundingClientRect();
      if (r.left >= sidebarRight - 1 && r.width > 200 && r.height < 200 && r.top < window.innerHeight * 0.25) {
        return el;
      }
      el = el.parentElement;
    }
    return null;
  }

  function isTransparentBg(color) {
    return !color || color === "rgba(0, 0, 0, 0)" || color === "transparent";
  }

  function isActiveLooking(el) {
    var cs = getComputedStyle(el);
    var fw = parseInt(cs.fontWeight, 10) || 400;
    return !isTransparentBg(cs.backgroundColor) || fw >= 600 || el.getAttribute("aria-current");
  }

  function collectActiveDescendants(root) {
    var found = [];
    var stack = [root];
    while (stack.length) {
      var node = stack.pop();
      if (node.nodeType !== 1) continue;
      if (node.id === ID) continue;
      if (node !== root && node.tagName !== "SVG" && node.tagName !== "PATH") {
        if (isActiveLooking(node)) found.push(node);
      }
      for (var i = 0; i < node.children.length; i++) stack.push(node.children[i]);
    }
    return found;
  }

  function getNavSiblings() {
    var nav = document.getElementById(ID);
    if (!nav || !nav.parentElement) return [];
    var out = [];
    var kids = nav.parentElement.children;
    for (var i = 0; i < kids.length; i++) {
      var k = kids[i];
      if (k === nav) continue;
      var t = (k.textContent || "").trim();
      if (!t) continue;
      out.push(k);
    }
    return out;
  }

  function suppressOtherActiveStates() {
    restoreSuppressed();
    var sibs = getNavSiblings();
    for (var i = 0; i < sibs.length; i++) {
      var sib = sibs[i];
      var hits = [];
      if (isActiveLooking(sib)) hits.push(sib);
      hits = hits.concat(collectActiveDescendants(sib));
      for (var j = 0; j < hits.length; j++) {
        var el = hits[j];
        if (el.dataset.agvSuppressed) continue;
        var orig = el.getAttribute("style") || "";
        el.setAttribute("data-agv-suppressed", "1");
        el.setAttribute("data-agv-orig-style", orig);
        el.setAttribute(
          "style",
          orig +
          ";background:transparent !important;background-color:transparent !important;" +
          "font-weight:400 !important;color:inherit !important;box-shadow:none !important;"
        );
        STATE.suppressed.push(el);
      }
    }
  }

  function restoreSuppressed() {
    for (var i = 0; i < STATE.suppressed.length; i++) {
      var el = STATE.suppressed[i];
      var orig = el.getAttribute("data-agv-orig-style") || "";
      if (orig) el.setAttribute("style", orig);
      else el.removeAttribute("style");
      el.removeAttribute("data-agv-suppressed");
      el.removeAttribute("data-agv-orig-style");
    }
    STATE.suppressed = [];
  }

  function computeOverlayRect() {
    var sidebar = findSidebar();
    var left = sidebar ? Math.round(sidebar.getBoundingClientRect().right) : 0;

    var crumb = findBreadcrumbBar();
    var top = crumb ? Math.round(crumb.getBoundingClientRect().bottom) : 56;

    return {
      left: left,
      top: top,
      width: Math.round(window.innerWidth - left),
      height: Math.round(window.innerHeight - top),
    };
  }

  function ensureOverlay() {
    var host = document.getElementById(IFRAME_ID);
    if (!host) {
      host = document.createElement("div");
      host.id = IFRAME_ID;
      var iframe = document.createElement("iframe");
      iframe.src = TARGET_URL;
      iframe.title = LABEL;
      iframe.setAttribute("loading", "eager");
      iframe.style.cssText = "border:0;width:100%;height:100%;display:block;background:#fff;";
      host.appendChild(iframe);
      document.body.appendChild(host);
    }
    applyOverlayStyles(host);
    return host;
  }

  function applyOverlayStyles(host) {
    var r = computeOverlayRect();
    var visibility = STATE.open ? "block" : "none";
    host.setAttribute(
      "style",
      "position:fixed !important;" +
      "left:" + r.left + "px !important;" +
      "top:" + r.top + "px !important;" +
      "width:" + r.width + "px !important;" +
      "height:" + r.height + "px !important;" +
      "z-index:2147483000 !important;" +
      "background:#fff !important;" +
      "display:" + visibility + " !important;" +
      "overflow:hidden !important;"
    );
  }

  function markNavActive() {
    var nav = document.getElementById(ID);
    if (nav) nav.setAttribute("data-agv-active", "1");
  }

  function unmarkNavActive() {
    var nav = document.getElementById(ID);
    if (nav) nav.removeAttribute("data-agv-active");
  }

  function openOverlay() {
    STATE.open = true;
    ensureOverlay();
    suppressOtherActiveStates();
    markNavActive();
    updateBreadcrumb(true);
  }

  function closeOverlay() {
    STATE.open = false;
    var host = document.getElementById(IFRAME_ID);
    if (host) applyOverlayStyles(host);
    restoreSuppressed();
    unmarkNavActive();
    updateBreadcrumb(false);
  }

  function updateBreadcrumb(active) {
    if (!active) return;
  }

  function buildItem(template) {
    var clone = template.cloneNode(true);
    clone.id = ID;
    clone.removeAttribute("href");
    clone.querySelectorAll("[id]").forEach(function (n) { n.removeAttribute("id"); });

    var labelEl = null;
    var walker = document.createTreeWalker(clone, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = walker.nextNode())) {
      if (n.nodeValue && n.nodeValue.trim().length > 0) { labelEl = n; break; }
    }
    if (labelEl) labelEl.nodeValue = LABEL;

    var svg = clone.querySelector("svg");
    if (svg) {
      svg.innerHTML =
        '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' +
        'd="M3 5h18v14H3z M3 12h18 M12 5v14 M7 8.5h.01 M16.5 16h.01"/>';
      svg.setAttribute("viewBox", "0 0 24 24");
    }

    clone.style.cursor = "pointer";
    var handler = function (e) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation && e.stopImmediatePropagation();
      openOverlay();
    };
    clone.addEventListener("click", handler, true);
    clone.addEventListener("mousedown", function (e) { e.stopPropagation(); }, true);
    return clone;
  }

  function bindCloseHandlers() {
    var nav = document.getElementById(ID);
    if (!nav || !nav.parentElement) return;
    var siblings = nav.parentElement.querySelectorAll('a, button, [role="link"], [role="button"], li');
    siblings.forEach(function (s) {
      if (s === nav || s.dataset.agvBound) return;
      s.dataset.agvBound = "1";
      s.addEventListener("click", function () { setTimeout(closeOverlay, 0); }, true);
    });
  }

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent =
      "#" + ID + "[data-agv-active]{background:rgba(16,185,129,0.12) !important;border-radius:6px;}" +
      "#" + ID + "[data-agv-active] *{color:rgb(16,185,129) !important;font-weight:600 !important;}";
    document.head.appendChild(s);
  }

  function inject() {
    if (!document.getElementById(ID)) {
      var settingsEl = findItemByText("Settings");
      if (!settingsEl || !settingsEl.parentElement) return false;
      var item = buildItem(settingsEl);
      settingsEl.parentElement.insertBefore(item, settingsEl.nextSibling);
    }
    bindCloseHandlers();
    if (STATE.open) {
      ensureOverlay();
      suppressOtherActiveStates();
      markNavActive();
    }
    return true;
  }

  function start() {
    injectStyles();
    inject();
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      inject();
      if (tries > 240) clearInterval(iv);
    }, 500);

    var mo = new MutationObserver(function () { inject(); });
    mo.observe(document.body, { childList: true, subtree: true });

    window.addEventListener("resize", function () {
      var host = document.getElementById(IFRAME_ID);
      if (host) applyOverlayStyles(host);
    });

    window.addEventListener("popstate", closeOverlay);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
