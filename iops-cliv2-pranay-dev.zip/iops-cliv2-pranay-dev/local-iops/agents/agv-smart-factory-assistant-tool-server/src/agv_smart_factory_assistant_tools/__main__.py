"""Entry point for agv_smart_factory_assistant_tools package."""

from agv_smart_factory_assistant_tools import main

main()
