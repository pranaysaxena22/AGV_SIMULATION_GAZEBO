"""agv_smart_factory_assistant_tools package."""

from .server import serve


def main() -> None:
    try:
        serve()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
