"""AGV Smart Factory Assistant MCP tool server.

Environment-only ops: reset_seed, clear_tasks, restart_service, health_check.
Fleet/task operations are handled by agv-smart-factory-agent's chat drawer.
"""

import json
import logging
import os
import socket
from typing import Annotated, Any

import httpx
from mcp.server.fastmcp import Context, FastMCP
from pydantic import Field

logging.basicConfig(
    format="%(asctime)s %(levelname)s:%(name)s:%(funcName)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("agv-smart-factory-assistant-tool-server")

MONGO_URI = os.environ.get("MONGO_DB_URI", "")
REDIS_HOST = os.environ.get("REDIS_HOST", "redis")
REDIS_PORT = int(os.environ.get("REDIS_PORT", "6379"))
REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD", "")

ALLOWED_SERVICES = {
    "agv-simulator": "iops-agv-simulator",
    "agv-tool-server": "iops-agv-tool-server",
    "agv-chat-agent": "iops-agv-chat-agent",
    "agv-smart-factory-agent": "iops-agv-smart-factory-agent",
    "agv-stream-bridge": "iops-agv-stream-bridge",
}

server = FastMCP("agv_smart_factory_assistant_tool_server")


def _mongo_client():
    from pymongo import MongoClient
    if not MONGO_URI:
        raise RuntimeError("MONGO_DB_URI is not set")
    return MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)


def _docker_client():
    import docker
    return docker.from_env()


def _publish_event(channel: str, payload: dict) -> None:
    try:
        import redis as redis_lib
        r = redis_lib.Redis(
            host=REDIS_HOST, port=REDIS_PORT,
            password=REDIS_PASSWORD or None, socket_connect_timeout=1.5,
        )
        r.publish(channel, json.dumps(payload))
    except Exception as exc:
        log.info("publish %s failed: %s", channel, exc)


def _tcp_ping(host: str, port: int, timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _as_text(payload) -> str:
    if not isinstance(payload, dict):
        return str(payload)
    if payload.get("ok") is False:
        return f"Error: {payload.get('error') or payload}"
    parts = []
    for k in ("ok", "service", "deleted_tasks", "status_filter",
              "simulator_restarted", "message"):
        if k in payload:
            parts.append(f"{k}={payload[k]}")
    if parts:
        return "OK · " + " · ".join(parts)
    return json.dumps(payload, default=str)


@server.tool(structured_output=False)
async def reset_seed(context: Context) -> str:
    """Restart the agv-simulator container without touching agv_tasks.

    Task deletion is deliberately NOT performed here — use clear_tasks
    (e.g. status='completed') when the operator explicitly asks to
    remove tasks.
    """
    try:
        _docker_client().containers.get(ALLOWED_SERVICES["agv-simulator"]).restart(timeout=10)
    except Exception as exc:
        return _as_text({"ok": False, "error": str(exc)})
    _publish_event("scenario:reset", {"action": "reset_seed", "deleted_tasks": 0})
    return _as_text({"ok": True, "deleted_tasks": 0, "simulator_restarted": True})


@server.tool(structured_output=False)
async def clear_tasks(
    status: Annotated[str, Field(description="'all' or 'completed'. Only completed tasks may be cleared; pending/in-transit tasks are protected.")],
    context: Context,
) -> str:
    """Delete COMPLETED tasks from agv_poc.agv_tasks.

    Only 'completed' (and 'all' which is remapped to 'completed') is
    supported. Pending or in-transit tasks are managed by the fleet
    dispatcher and must not be cleared here.
    """
    s = (status or "completed").strip().lower()
    if s in ("all", "completed", "done", "finished"):
        query = {"status": "completed"}
        s = "completed"
    else:
        return _as_text({
            "ok": False,
            "error": (
                f"Cannot clear '{s}' tasks. This assistant can only "
                "clear completed tasks — pending/in-transit tasks are "
                "handled by the fleet dispatcher (AGV Map chat panel)."
            ),
        })
    client = _mongo_client()
    try:
        deleted = client["agv_poc"]["agv_tasks"].delete_many(query).deleted_count
    finally:
        client.close()
    _publish_event("task:cleared", {"status_filter": s, "deleted_tasks": deleted})
    return _as_text({"ok": True, "status_filter": s, "deleted_tasks": deleted})


FRIENDLY_SERVICE_ALIASES = {
    "": "agv-simulator",
    "all": "agv-simulator",
    "simulator": "agv-simulator",
    "sim": "agv-simulator",
    "fleet": "agv-simulator",
    "agv": "agv-simulator",
    "agvs": "agv-simulator",
    "map": "agv-stream-bridge",
    "stream": "agv-stream-bridge",
    "bridge": "agv-stream-bridge",
    "chat": "agv-chat-agent",
    "chatbot": "agv-chat-agent",
    "assistant": "agv-smart-factory-agent",
    "agent": "agv-smart-factory-agent",
    "tools": "agv-tool-server",
    "tool": "agv-tool-server",
}


@server.tool(structured_output=False)
async def restart_service(
    service: Annotated[
        str,
        Field(
            default="",
            description=(
                "Optional. Leave empty to restart the AGV simulator "
                "(the default demo service). Accepts friendly aliases "
                "like 'simulator', 'fleet', 'map', 'chat', 'tools' or "
                "the raw container name."
            ),
        ),
    ] = "",
    context: Context = None,
) -> str:
    """Restart one AGV service container. Defaults to agv-simulator."""
    raw = (service or "").strip().lower()
    key = FRIENDLY_SERVICE_ALIASES.get(raw, raw)
    if key not in ALLOWED_SERVICES:
        return _as_text({"ok": False, "error": f"Unknown service '{service}'. Try: simulator, map, chat, tools."})
    try:
        _docker_client().containers.get(ALLOWED_SERVICES[key]).restart(timeout=10)
    except Exception as exc:
        return _as_text({"ok": False, "error": f"Restart failed: {exc}"})
    _publish_event("scenario:reset", {"action": "restart_service", "service": key})
    return _as_text({"ok": True, "service": key})


@server.tool(structured_output=False)
async def health_check(context: Context) -> str:
    """Report health of AGV containers, MongoDB, and Redis."""
    result: dict[str, Any] = {"containers": {}, "infra": {}}
    endpoints = {
        "agv-tool-server": "http://agv-tool-server:8990/health",
        "agv-smart-factory-agent": "http://agv-smart-factory-agent:8992/health",
        "agv-chat-agent": "http://agv-chat-agent:8991/health",
        "agv-stream-bridge": "http://agv-stream-bridge:8081/health",
    }
    with httpx.Client(timeout=3.0) as client:
        for name, url in endpoints.items():
            try:
                r = client.get(url)
                result["containers"][name] = {"ok": r.status_code < 400, "code": r.status_code}
            except Exception as exc:
                port = int(url.split(":")[-1].split("/")[0])
                result["containers"][name] = {"ok": _tcp_ping(name, port), "port": port, "error": str(exc)}
    try:
        c = _docker_client().containers.get(ALLOWED_SERVICES["agv-simulator"])
        result["containers"]["agv-simulator"] = {"ok": c.status == "running", "status": c.status}
    except Exception as exc:
        result["containers"]["agv-simulator"] = {"ok": False, "error": str(exc)}
    try:
        c = _mongo_client(); c.admin.command("ping"); c.close()
        result["infra"]["mongodb"] = {"ok": True}
    except Exception as exc:
        result["infra"]["mongodb"] = {"ok": False, "error": str(exc)}
    try:
        import redis as redis_lib
        r = redis_lib.Redis(host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD or None, socket_connect_timeout=2)
        result["infra"]["redis"] = {"ok": bool(r.ping())}
    except Exception as exc:
        result["infra"]["redis"] = {"ok": False, "error": str(exc)}
    result["ok"] = all(v.get("ok") for v in result["containers"].values()) and all(v.get("ok") for v in result["infra"].values())
    ok = "healthy" if result["ok"] else "DEGRADED"
    lines = [f"System: {ok}"]
    for name, v in result["containers"].items():
        lines.append(f"- {name}: {'ok' if v.get('ok') else 'FAIL'}")
    for name, v in result["infra"].items():
        lines.append(f"- {name}: {'ok' if v.get('ok') else 'FAIL'}")
    return "\n".join(lines)


@server.tool(structured_output=False)
async def get_task_stats(context: Context) -> str:
    """Return task counts by status plus last-hour delta."""
    from datetime import datetime, timedelta, timezone
    client = _mongo_client()
    try:
        coll = client["agv_poc"]["agv_tasks"]
        pipeline = [{"$group": {"_id": "$status", "count": {"$sum": 1}}}]
        by_status = {r["_id"] or "unknown": r["count"] for r in coll.aggregate(pipeline)}
        cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
        last_hour = coll.count_documents({"created_at": {"$gte": cutoff}})
        total = sum(by_status.values())
    finally:
        client.close()
    lines = [f"Task stats — total {total} (last hour: {last_hour})"]
    for status in ("pending", "assigned", "in_transit", "completed", "failed"):
        if status in by_status:
            lines.append(f"- {status}: {by_status[status]}")
    for status, count in by_status.items():
        if status not in ("pending", "assigned", "in_transit", "completed", "failed"):
            lines.append(f"- {status}: {count}")
    return "\n".join(lines)


@server.tool(structured_output=False)
async def get_fleet_summary(context: Context) -> str:
    """Return AGV counts by state and average battery."""
    client = _mongo_client()
    try:
        db = client["agv_poc"]
        docs = []
        if "agv_state" in db.list_collection_names():
            docs = list(db["agv_state"].find({}, {"_id": 0, "agv_id": 1, "state": 1, "battery": 1}))
        if not docs and "agv_telemetry_snapshots" in db.list_collection_names():
            pipeline = [
                {"$sort": {"ts": -1}},
                {"$group": {
                    "_id": "$agv_id",
                    "state": {"$first": "$state"},
                    "battery": {"$first": "$battery"},
                }},
                {"$project": {"_id": 0, "agv_id": "$_id", "state": 1, "battery": 1}},
            ]
            docs = list(db["agv_telemetry_snapshots"].aggregate(pipeline))
    finally:
        client.close()
    if not docs:
        return "No AGVs found in agv_poc.agv_state."
    by_state: dict[str, int] = {}
    for d in docs:
        s = d.get("state") or "unknown"
        by_state[s] = by_state.get(s, 0) + 1
    lines = [f"Fleet: {len(docs)} AGVs"]
    for state, count in sorted(by_state.items()):
        lines.append(f"- {state}: {count}")
    return "\n".join(lines)


@server.tool(structured_output=False)
async def get_service_logs(
    service: Annotated[str, Field(description="Service name/alias (simulator, map, chat, tools, etc.)")],
    lines: Annotated[int, Field(default=50, description="How many trailing log lines to fetch (max 200)")] = 50,
    context: Context = None,
) -> str:
    """Tail the last N log lines from a service container."""
    raw = (service or "").strip().lower()
    key = FRIENDLY_SERVICE_ALIASES.get(raw, raw)
    if key not in ALLOWED_SERVICES:
        return _as_text({"ok": False, "error": f"Unknown service '{service}'. Try: simulator, map, chat, tools."})
    n = max(1, min(int(lines or 50), 200))
    try:
        c = _docker_client().containers.get(ALLOWED_SERVICES[key])
        raw_logs = c.logs(tail=n, timestamps=False).decode("utf-8", errors="replace")
    except Exception as exc:
        return _as_text({"ok": False, "error": f"Log fetch failed: {exc}"})
    return f"Last {n} log lines from {key}:\n{raw_logs}"


@server.tool(structured_output=False)
async def get_kpi_snapshot(context: Context) -> str:
    """Return recent KPIs: completions/min, avg trip duration, avg wait."""
    from datetime import datetime, timedelta, timezone
    client = _mongo_client()
    try:
        coll = client["agv_poc"]["agv_tasks"]
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=5)
        recent = list(coll.find(
            {"status": "completed", "completed_at": {"$gte": cutoff}},
            {"created_at": 1, "assigned_at": 1, "completed_at": 1, "kpis": 1},
        ))
    finally:
        client.close()
    if not recent:
        return "No completed tasks in the last 5 minutes."
    per_min = len(recent) / 5.0
    durations, waits = [], []
    for t in recent:
        c_at, a_at, done = t.get("created_at"), t.get("assigned_at"), t.get("completed_at")
        if a_at and done:
            durations.append((done - a_at).total_seconds())
        if c_at and a_at:
            waits.append((a_at - c_at).total_seconds())
    avg_dur = f"{sum(durations) / len(durations):.1f}s" if durations else "n/a"
    avg_wait = f"{sum(waits) / len(waits):.1f}s" if waits else "n/a"
    return (
        f"KPI snapshot (last 5 min)\n"
        f"- completions/min: {per_min:.1f}\n"
        f"- avg trip duration: {avg_dur}\n"
        f"- avg queue wait: {avg_wait}"
    )


@server.tool(structured_output=False)
async def ping_redis(context: Context) -> str:
    """Ping Redis and report latency."""
    import time
    try:
        import redis as redis_lib
        r = redis_lib.Redis(host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD or None, socket_connect_timeout=2)
        t0 = time.perf_counter()
        ok = bool(r.ping())
        ms = (time.perf_counter() - t0) * 1000
    except Exception as exc:
        return _as_text({"ok": False, "error": str(exc)})
    return f"Redis: {'ok' if ok else 'FAIL'} — {ms:.1f} ms"


@server.tool(structured_output=False)
async def ping_mongo(context: Context) -> str:
    """Ping MongoDB and report latency."""
    import time
    try:
        client = _mongo_client()
        t0 = time.perf_counter()
        client.admin.command("ping")
        ms = (time.perf_counter() - t0) * 1000
        client.close()
    except Exception as exc:
        return _as_text({"ok": False, "error": str(exc)})
    return f"MongoDB: ok — {ms:.1f} ms"


@server.tool(structured_output=False)
async def list_stuck_tasks(
    min_age_s: Annotated[int, Field(default=120, description="Minimum age in seconds (default 120)")] = 120,
    context: Context = None,
) -> str:
    """List tasks past SLA that are still not completed."""
    from datetime import datetime, timedelta, timezone
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=max(1, int(min_age_s)))
    client = _mongo_client()
    try:
        docs = list(client["agv_poc"]["agv_tasks"].find(
            {"status": {"$nin": ["completed", "failed"]}, "created_at": {"$lte": cutoff}},
            {"_id": 0, "task_id": 1, "status": 1, "priority": 1, "created_at": 1, "assigned_agv": 1},
        ).limit(20))
    finally:
        client.close()
    if not docs:
        return f"No stuck tasks older than {min_age_s}s."
    lines = [f"Stuck tasks (> {min_age_s}s old): {len(docs)}"]
    for d in docs:
        lines.append(f"- {d.get('task_id')} status={d.get('status')} pri={d.get('priority')} agv={d.get('assigned_agv') or '-'}")
    return "\n".join(lines)


@server.tool(structured_output=False)
async def export_tasks(
    status: Annotated[str, Field(default="completed", description="Task status filter (default 'completed')")] = "completed",
    limit: Annotated[int, Field(default=100, description="Max rows to export (max 1000)")] = 100,
    context: Context = None,
) -> str:
    """Export tasks as a downloadable CSV (Excel-compatible) with an inline preview."""
    import csv
    import io
    from datetime import datetime, timezone
    n = max(1, min(int(limit or 100), 1000))
    q = {} if (status or "").lower() == "all" else {"status": status}
    client = _mongo_client()
    try:
        docs = list(client["agv_poc"]["agv_tasks"].find(q, {"_id": 0}).limit(n))
    finally:
        client.close()

    if not docs:
        return f"No tasks matched status={status}."

    columns: list[str] = []
    seen: set[str] = set()
    preferred = [
        "task_id", "status", "priority", "created_at", "assigned_at",
        "completed_at", "assigned_agv", "pickup", "drop", "sla",
    ]
    for k in preferred:
        if any(k in d for d in docs) and k not in seen:
            columns.append(k)
            seen.add(k)
    for d in docs:
        for k in d.keys():
            if k not in seen:
                columns.append(k)
                seen.add(k)

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for d in docs:
        row = {k: ("" if d.get(k) is None else str(d.get(k))) for k in columns}
        writer.writerow(row)
    csv_text = buf.getvalue()

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    fname = f"tasks_{status}_{ts}.csv"

    exports_dir = "/app/exports"
    os.makedirs(exports_dir, exist_ok=True)
    with open(os.path.join(exports_dir, fname), "w", encoding="utf-8", newline="") as f:
        f.write(csv_text)

    href = f"http://localhost:8990/exports/{fname}"

    preview_rows = docs[:5]
    header_row = "| " + " | ".join(columns) + " |"
    sep_row = "| " + " | ".join(["---"] * len(columns)) + " |"
    body_rows = [
        "| " + " | ".join(
            ("" if d.get(k) is None else str(d.get(k))).replace("|", "\\|")[:40]
            for k in columns
        ) + " |"
        for d in preview_rows
    ]
    preview_md = "\n".join([header_row, sep_row, *body_rows])

    link = (
        f'<a href="{href}" download="{fname}" target="_blank" '
        f'rel="noopener noreferrer" '
        f'style="color:#26890D;text-decoration:underline;font-weight:600;">'
        f'Download {fname}</a>'
    )

    return (
        f"**Exported {len(docs)} tasks (status={status}) as CSV**\n"
        f"- filename: `{fname}` (opens in Excel)\n"
        f"- rows: {len(docs)} (limit {n}), columns: {len(columns)}\n"
        f"- {link}\n\n"
        f"Preview (first {len(preview_rows)} rows):\n\n{preview_md}"
    )


@server.tool(structured_output=False)
async def snapshot_state(context: Context) -> str:
    """Snapshot current fleet + task state to a timestamped MongoDB collection."""
    from datetime import datetime, timezone
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    client = _mongo_client()
    try:
        db = client["agv_poc"]
        tasks = list(db["agv_tasks"].find({}, {"_id": 0}))
        agvs = list(db["agv_state"].find({}, {"_id": 0})) if "agv_state" in db.list_collection_names() else []
        snap = db[f"snapshot_{ts}"]
        if tasks:
            snap.insert_one({"kind": "tasks", "count": len(tasks), "items": tasks})
        if agvs:
            snap.insert_one({"kind": "agvs", "count": len(agvs), "items": agvs})
    finally:
        client.close()
    return f"Snapshot saved to agv_poc.snapshot_{ts} — {len(tasks)} tasks, {len(agvs)} AGVs."


def serve() -> None:
    server.run()
