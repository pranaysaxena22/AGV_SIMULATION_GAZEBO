#!/bin/sh
set -e

HTML_DIR="/usr/share/nginx/html"
CONFIG_FILE="$HTML_DIR/config.js"

echo "Generating runtime config..."

printf 'window.__ENV__={' > "$CONFIG_FILE"

# Docker-compose sets LOCALIOPS_* env vars; map them to IOPS_* keys for the app.
# Redirect from a temp file instead of piping so variable state is preserved
# (pipes run the while-loop in a subshell where assignments don't propagate).
env | grep '^LOCALIOPS_' | sort > /tmp/_localiops_vars
sep=""
while IFS='=' read -r key value; do
  # LOCALIOPS_ISLOCAL -> IOPS_ISLOCAL
  iops_key="IOPS_${key#LOCALIOPS_}"
  escaped=$(printf '%s' "$value" | sed 's/\\/\\\\/g; s/"/\\"/g; s/</\\u003c/g')
  printf '%s"%s":"%s"' "$sep" "$iops_key" "$escaped" >> "$CONFIG_FILE"
  sep=","
done < /tmp/_localiops_vars
rm -f /tmp/_localiops_vars

printf '};\n' >> "$CONFIG_FILE"

echo "Runtime config generated."
