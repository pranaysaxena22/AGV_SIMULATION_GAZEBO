/** Non-package scopes for cross-cutting changes */
const extraScopes = ["app", "deps", "ci", "release", "config"];

/** @type {import('@commitlint/types').UserConfig} */
export default {
  extends: ["@commitlint/config-conventional"],
  rules: {
    "scope-enum": [2, "always", [...extraScopes]],
    "scope-empty": [1, "never"],
  },
};
