import { useMemo, useState } from "react";
import { Badge } from "@smaf/iops-shared-ui";
import { cn } from "@smaf/iops-theme-ui";
import {
  ArrowRight,
  ChevronDown,
  ChevronUp,
  PanelLeftClose,
  PanelLeftOpen,
} from "lucide-react";

import { FloorMap } from "../components/FloorMap.js";
import { AgvMarker } from "../components/AgvMarker.js";
import { KpiBar } from "../components/KpiBar.js";
import { TaskSchedulerPanel } from "../components/TaskSchedulerPanel.js";
import { ChatDrawer } from "../components/ChatDrawer.js";
import { useAgvWebSocket } from "../hooks/useAgvWebSocket.js";
import { useFleetState } from "../hooks/useFleetState.js";
import layoutJson from "../data/poc-floor.json" with { type: "json" };
import type { AgvTelemetry, FloorLayout } from "../types/index.js";
import "../styles/agv-map.css";

const layout = layoutJson as unknown as FloorLayout;

const PARKING_BAYS = new Set(["H01", "H02", "H03", "W34", "W38"]);
const BAY_NAMES: Record<string, string> = { H01: "Charge Bay 1", H02: "Charge Bay 2", H03: "Charge Bay 3", W34: "Staging 1", W38: "Staging 2" };

const STATE_VARIANT: Record<
  string,
  "default" | "secondary" | "outline" | "destructive"
> = {
  idle: "outline",
  moving: "default",
  loading: "secondary",
  unloading: "secondary",
  blocked: "destructive",
  charging: "secondary",
  depleted: "destructive",
  parking: "secondary",
  parked: "outline",
};

function getDisplayState(agv: AgvTelemetry): string {
  if (agv.state === "moving" && agv.dest_node && PARKING_BAYS.has(agv.dest_node)) return "parking";
  if (agv.state === "idle" && agv.current_node && PARKING_BAYS.has(agv.current_node)) return "parked";
  return agv.state;
}

function nodeLabel(id: string | null | undefined): string {
  if (!id) return "—";
  return id.replace(/^STN_/, "").replace(/^WP_/, "·");
}

function FleetRow({
  agv,
  picked,
  allShown,
  onToggleVisible,
}: {
  agv: AgvTelemetry;
  picked: boolean;
  allShown: boolean;
  onToggleVisible: (id: string) => void;
}) {
  const displayState = getDisplayState(agv);
  const variant = STATE_VARIANT[displayState] ?? "outline";
  // When user has an active selection set, dim rows that aren't part of it.
  const dimmed = !allShown && !picked;
  const isParked = displayState === "parked";
  return (
    <button
      type="button"
      onClick={() => onToggleVisible(agv.agv_id)}
      className={`flex w-full items-center gap-1.5 rounded-md border px-2 py-1.5 text-left transition-colors ${
        picked
          ? "border-primary bg-primary/10"
          : "border-border bg-card hover:bg-accent"
      } ${dimmed ? "opacity-50 hover:opacity-90" : ""}`}
    >
      <div className={`agv-chip agv-chip-${displayState}`}>
        {agv.agv_id.replace(/^AGV0?/, "")}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1 text-[10px] font-semibold text-foreground">
          {isParked ? (
            <span className="truncate text-muted-foreground">
              Parked · {BAY_NAMES[agv.current_node!] ?? agv.current_node}
            </span>
          ) : (
            <>
              <span className="truncate">{nodeLabel(agv.origin_node ?? agv.current_node)}</span>
              <ArrowRight className="h-2.5 w-2.5 shrink-0 text-muted-foreground" />
              <span className="truncate">{nodeLabel(agv.dest_node)}</span>
            </>
          )}
        </div>
        <div className="flex items-center justify-between gap-1 text-[9px] text-muted-foreground">
          <Badge variant={variant} className="capitalize text-[8px] px-1 py-0">
            {displayState}
          </Badge>
          <span className="flex items-center gap-1">
            <span>{agv.payload_count}/{agv.capacity}</span>
            {typeof agv.battery_pct === "number" && (
              <span
                className="font-bold"
                style={{
                  color:
                    agv.battery_pct < 20
                      ? "#ef4444"
                      : agv.battery_pct < 80
                      ? "#facc15"
                      : "#10b981",
                }}
              >
                {Math.round(agv.battery_pct)}%
              </span>
            )}
          </span>
        </div>
      </div>
    </button>
  );
}

export function AgvMapPage() {
  useAgvWebSocket();

  const fleet = useFleetState((s) => s.fleet);

  const visibleAgvIds = useFleetState((s) => s.visibleAgvIds);
  const toggleAgvVisible = useFleetState((s) => s.toggleAgvVisible);
  const showAllAgvs = useFleetState((s) => s.showAllAgvs);
  const agvs = useMemo(
    () =>
      Array.from(fleet.values()).sort((a, b) =>
        a.agv_id.localeCompare(b.agv_id),
      ),
    [fleet],
  );
  const isVisible = (id: string) =>
    visibleAgvIds === null ? true : visibleAgvIds.has(id);
  const isPicked = (id: string) =>
    visibleAgvIds !== null && visibleAgvIds.has(id);
  const visibleAgvs = useMemo(
    () => agvs.filter((a) => isVisible(a.agv_id)),
    [agvs, visibleAgvIds],
  );
  const allShown = visibleAgvIds === null;


  const [leftOpen, setLeftOpen] = useState(true);
  const [expandedCard, setExpandedCard] = useState<"tasks" | "fleet">("tasks");

  return (
    <div className={cn("flex h-full gap-0 p-2 overflow-hidden")}>
      {/* Left — Task Scheduler + Fleet Status */}
      {leftOpen ? (
        <div
          className="shrink-0 min-h-0 flex flex-col mr-3"
          style={{ width: 300, minWidth: 300, maxWidth: 300, flex: "0 0 300px" }}
        >
          <div className="flex items-center justify-end mb-1">
            <button
              type="button"
              onClick={() => setLeftOpen(false)}
              className="rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
              title="Collapse panel"
            >
              <PanelLeftClose className="h-4 w-4" />
            </button>
          </div>
          <div className="flex-1 min-h-0 overflow-hidden flex flex-col gap-2">
            {/* Task Scheduler — collapsible */}
            <div className={cn(
              "flex flex-col min-h-0 rounded-lg border border-border bg-card overflow-hidden transition-all",
              expandedCard === "tasks" ? "flex-1" : "shrink-0"
            )}>
              <button
                type="button"
                onClick={() => setExpandedCard(expandedCard === "tasks" ? "fleet" : "tasks")}
                className="flex items-center justify-between px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground hover:bg-accent/50 transition-colors shrink-0"
              >
                Task Scheduler
                {expandedCard === "tasks" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              </button>
              {expandedCard === "tasks" && (
                <div className="flex-1 min-h-0 overflow-hidden" style={{ scrollbarGutter: "stable" }}>
                  <TaskSchedulerPanel />
                </div>
              )}
            </div>

            {/* Fleet Status — collapsible */}
            <div className={cn(
              "flex flex-col min-h-0 rounded-lg border border-border bg-card overflow-hidden transition-all",
              expandedCard === "fleet" ? "flex-1" : "shrink-0"
            )}>
              <button
                type="button"
                onClick={() => setExpandedCard(expandedCard === "fleet" ? "tasks" : "fleet")}
                className="flex items-center justify-between px-3 py-1.5 hover:bg-accent/50 transition-colors shrink-0"
              >
                <div className="flex items-center gap-1">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Fleet Status
                  </span>
                  {expandedCard === "fleet" ? <ChevronUp className="h-3 w-3 text-muted-foreground" /> : <ChevronDown className="h-3 w-3 text-muted-foreground" />}
                </div>
                <span
                  role="button"
                  tabIndex={0}
                  onClick={(e) => { e.stopPropagation(); if (!allShown) showAllAgvs(); }}
                  onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.stopPropagation(); if (!allShown) showAllAgvs(); } }}
                  aria-disabled={allShown}
                  className={`rounded-md border px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide transition-colors ${
                    allShown
                      ? "border-primary bg-primary/10 text-primary cursor-default"
                      : "border-border text-muted-foreground hover:bg-accent hover:text-foreground cursor-pointer"
                  }`}
                  title="Show all AGVs on the map"
                >
                  {allShown ? `All (${agvs.length})` : `Show all`}
                </span>
              </button>
              {expandedCard === "fleet" && (
                <div className="flex-1 min-h-0 overflow-hidden">
                  <div className="h-full flex flex-col overflow-hidden">
                    {!allShown && visibleAgvIds && (
                      <div className="shrink-0 px-2 pb-1 text-[10px] text-muted-foreground">
                        showing {visibleAgvIds.size} of {agvs.length}
                      </div>
                    )}
                    <div
                      className="flex-1 min-h-0 px-2 pb-2 space-y-1.5"
                      style={{ overflowY: "scroll", scrollbarGutter: "stable" }}
                    >
                      {agvs.length === 0 && (
                        <div className="text-xs text-muted-foreground py-4 text-center">
                          Waiting for telemetry…
                        </div>
                      )}
                      {agvs.map((a) => (
                        <FleetRow
                          key={a.agv_id}
                          agv={a}
                          picked={isPicked(a.agv_id)}
                          allShown={allShown}
                          onToggleVisible={toggleAgvVisible}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="shrink-0 flex flex-col items-center mr-1">
          <button
            type="button"
            onClick={() => setLeftOpen(true)}
            className="rounded-md border border-border bg-card p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors shadow-sm"
            title="Expand panel"
          >
            <PanelLeftOpen className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Center — Floor Map (takes all available space) */}
      <div className="flex-1 min-w-0 min-h-0 flex flex-col gap-1">
        <div className="shrink-0 flex items-center justify-between px-2 py-1">
          <h2 className="text-sm font-semibold text-foreground">AGV Floor Map</h2>
        </div>
        <div className="flex-1 min-h-0 overflow-hidden rounded-md">
          <FloorMap layout={layout} agvs={visibleAgvs}>
            {visibleAgvs.map((a) => (
              <AgvMarker key={a.agv_id} agv={a} />
            ))}
          </FloorMap>
        </div>
        <div className="shrink-0 rounded-md border border-border bg-card px-3 py-1.5">
          <KpiBar />
        </div>
      </div>


      <ChatDrawer />
    </div>
  );
}

export default AgvMapPage;
