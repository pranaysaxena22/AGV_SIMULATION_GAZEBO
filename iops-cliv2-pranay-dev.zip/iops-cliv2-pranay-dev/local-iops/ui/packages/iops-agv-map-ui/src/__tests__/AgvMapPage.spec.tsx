// Mock the API service to avoid transitive ESM dependency issues
jest.mock("../api/agvMapService.js", () => ({
  fetchAllAgvMap: jest.fn(),
  fetchAgvMapById: jest.fn(),
}));

import { screen } from "@testing-library/react";
import { AgvMapPage } from "../pages/AgvMapPage";
import { renderWithProviders } from "./test-utils";

describe("AgvMapPage", () => {
  it("should render the page heading", () => {
    renderWithProviders(<AgvMapPage />);
    expect(screen.getByText("AGV Floor Map")).toBeTruthy();
  });

  it("should render welcome message", () => {
    renderWithProviders(<AgvMapPage />);
    expect(screen.getByText(/Welcome to AGV Floor Map/)).toBeTruthy();
  });
});
