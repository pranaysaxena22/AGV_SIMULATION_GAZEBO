/**
 * Tests for agvMapPlugin metadata
 */

// Mock the API service to avoid transitive ESM dependency issues
jest.mock("../api/agvMapService.js", () => ({
  fetchAllAgvMap: jest.fn(),
  fetchAgvMapById: jest.fn(),
}));

// Mock lazy-loaded page modules
jest.mock("../pages/AgvMapPage.js", () => ({
  default: () => null,
}));

import { agvMapPlugin } from "../plugin.js";

describe("agvMapPlugin", () => {
  it("should have correct name and display name", () => {
    expect(agvMapPlugin.name).toBe("agvMap");
    expect(agvMapPlugin.displayName).toBe("AGV Floor Map");
  });

  it("should be enabled", () => {
    expect(agvMapPlugin.enabled).toBe(true);
  });

  it("should define routes under home/agv-map", () => {
    expect(agvMapPlugin.routes).toHaveLength(1);
    expect(agvMapPlugin.routes[0].path).toBe("home/agv-map");
    expect(agvMapPlugin.routes[0].type).toBe("protected");
  });

  it("should define nav items", () => {
    expect(agvMapPlugin.navItems).toHaveLength(1);
    expect(agvMapPlugin.navItems?.[0].label).toBe("AGV Floor Map");
    expect(agvMapPlugin.navItems?.[0].path).toBe("agv-map");
  });

  it("should require feature:agv_map permission", () => {
    expect(agvMapPlugin.permissions).toEqual(["feature:agv_map"]);
  });

  describe("lazy component loaders", () => {
    it("should resolve page component", async () => {
      const mod = await agvMapPlugin.routes[0].component();
      expect(mod).toHaveProperty("default");
    });
  });

  describe("route config properties", () => {
    it("should configure route with correct properties", () => {
      const route = agvMapPlugin.routes[0];
      expect(route.allowedRole).toBe("feature:agv_map");
      expect(route.errorBoundary).toBe(true);
      expect(route.type).toBe("protected");
    });
  });

  describe("route meta objects", () => {
    it("should have meta on route with icon", () => {
      const meta = agvMapPlugin.routes[0].meta;
      expect(meta?.title).toBe("AGV Floor Map");
      expect(meta?.description).toBe("");
      expect(meta?.icon).toBeDefined();
    });
  });
});
