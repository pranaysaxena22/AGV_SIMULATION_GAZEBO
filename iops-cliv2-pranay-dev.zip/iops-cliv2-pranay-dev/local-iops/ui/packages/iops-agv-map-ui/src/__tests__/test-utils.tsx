import { render } from "@testing-library/react";
import type { RenderOptions } from "@testing-library/react";
import type { ReactElement } from "react";
import { MemoryRouter } from "react-router-dom";

// =============================================================================
// Test Fixtures
// =============================================================================

export function makeItem(
  overrides: Partial<{ id: string; name: string; description: string }> = {}
) {
  return {
    id: "test-1",
    name: "Test Item",
    description: "A test item",
    ...overrides,
  };
}

// =============================================================================
// Render Helper
// =============================================================================

interface RenderWithProvidersOptions extends Omit<RenderOptions, "wrapper"> {
  route?: string;
}

export function renderWithProviders(
  ui: ReactElement,
  { route = "/", ...renderOptions }: RenderWithProvidersOptions = {}
) {
  function Wrapper({ children }: { children: React.ReactNode }) {
    return <MemoryRouter initialEntries={[route]}>{children}</MemoryRouter>;
  }

  return { ...render(ui, { wrapper: Wrapper, ...renderOptions }) };
}
