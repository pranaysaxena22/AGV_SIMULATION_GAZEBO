import { useCallback, useRef, useState } from "react";

type Lang = "en-US" | "hi-IN";

interface UseVoiceInputOptions {
  lang?: Lang;
  onResult?: (transcript: string) => void;
  onError?: (error: string) => void;
}

interface UseVoiceInputReturn {
  listening: boolean;
  supported: boolean;
  start: () => void;
  stop: () => void;
  lang: Lang;
  setLang: (l: Lang) => void;
}

const SR =
  typeof window !== "undefined"
    ? (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition
    : null;

export function useVoiceInput(opts: UseVoiceInputOptions = {}): UseVoiceInputReturn {
  const [listening, setListening] = useState(false);
  const [lang, setLang] = useState<Lang>(opts.lang ?? "en-US");
  const recRef = useRef<any>(null);

  const stop = useCallback(() => {
    if (recRef.current) {
      recRef.current.stop();
      recRef.current = null;
    }
    setListening(false);
  }, []);

  const start = useCallback(() => {
    if (!SR) {
      opts.onError?.("Speech recognition not supported in this browser");
      return;
    }
    if (recRef.current) {
      stop();
      return;
    }
    const rec = new SR();
    rec.lang = lang;
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.continuous = false;

    rec.onresult = (e: any) => {
      const transcript = e.results[0]?.[0]?.transcript ?? "";
      if (transcript) opts.onResult?.(transcript);
      setListening(false);
      recRef.current = null;
    };
    rec.onerror = (e: any) => {
      if (e.error !== "aborted") opts.onError?.(e.error);
      setListening(false);
      recRef.current = null;
    };
    rec.onend = () => {
      setListening(false);
      recRef.current = null;
    };

    recRef.current = rec;
    setListening(true);
    rec.start();
  }, [lang, opts.onResult, opts.onError, stop]);

  return { listening, supported: !!SR, start, stop, lang, setLang };
}

let _voicesLoaded = false;
let _voices: SpeechSynthesisVoice[] = [];

function loadVoices(): SpeechSynthesisVoice[] {
  if (typeof window === "undefined" || !window.speechSynthesis) return [];
  _voices = window.speechSynthesis.getVoices();
  if (_voices.length > 0) _voicesLoaded = true;
  return _voices;
}

if (typeof window !== "undefined" && window.speechSynthesis) {
  loadVoices();
  window.speechSynthesis.onvoiceschanged = () => { loadVoices(); };
}

let _fallbackAudio: HTMLAudioElement | null = null;

function speakViaGoogleTTS(text: string, lang: Lang): void {
  if (typeof window === "undefined") return;
  try {
    if (_fallbackAudio) {
      _fallbackAudio.pause();
      _fallbackAudio = null;
    }
    const tl = lang.split("-")[0];
    // Google Translate TTS limits ~200 chars per request; split on sentences
    const chunks: string[] = [];
    const sentences = text.match(/[^.!?。!?]+[.!?。!?]?/g) ?? [text];
    let buf = "";
    for (const s of sentences) {
      if ((buf + s).length > 180) {
        if (buf) chunks.push(buf);
        buf = s;
      } else {
        buf += s;
      }
    }
    if (buf) chunks.push(buf);

    let i = 0;
    const playNext = () => {
      if (i >= chunks.length) {
        _fallbackAudio = null;
        return;
      }
      const chunk = chunks[i++].trim();
      if (!chunk) {
        playNext();
        return;
      }
      const url = `/agv-chat/tts?lang=${tl}&text=${encodeURIComponent(chunk)}`;
      const audio = new Audio(url);
      _fallbackAudio = audio;
      audio.onended = playNext;
      audio.onerror = (ev) => {
        console.warn("[TTS] Google fallback audio error", url, ev);
        _fallbackAudio = null;
      };
      audio.play().catch((e) => {
        console.warn("[TTS] play() rejected (user gesture or CORS?)", e);
        _fallbackAudio = null;
      });
    };
    playNext();
  } catch (e) {
    console.warn("[TTS] Google fallback exception", e);
  }
}

export function stopSpeaking(): void {
  if (typeof window === "undefined") return;
  if (window.speechSynthesis) window.speechSynthesis.cancel();
  if (_fallbackAudio) {
    _fallbackAudio.pause();
    _fallbackAudio = null;
  }
}

export function speak(text: string, lang: Lang = "en-US"): void {
  if (typeof window === "undefined") return;

  // Cancel any in-flight speech (native + fallback)
  if (window.speechSynthesis) window.speechSynthesis.cancel();
  if (_fallbackAudio) {
    _fallbackAudio.pause();
    _fallbackAudio = null;
  }

  setTimeout(() => {
    if (!_voicesLoaded) loadVoices();
    const allVoices = window.speechSynthesis?.getVoices() ?? [];
    const prefix = lang.split("-")[0];

    // For Hindi, exclude voices that merely alias to English (some OSes
    // report en-* voices when hi-IN is requested).
    const isHindi = lang === "hi-IN";
    const matchedVoice = isHindi
      ? allVoices.find((v) => v.lang.toLowerCase().startsWith("hi"))
      : allVoices.find((v) => v.lang === lang) ??
        allVoices.find((v) => v.lang.toLowerCase().startsWith(prefix + "-")) ??
        allVoices.find((v) => v.lang.toLowerCase().startsWith(prefix));

    if (!matchedVoice) {
      console.log(`[TTS] No ${lang} voice found — using Google Translate TTS`);
      speakViaGoogleTTS(text, lang);
      return;
    }

    console.log(`[TTS] Using native voice: ${matchedVoice.name} (${matchedVoice.lang})`);
    const utter = new SpeechSynthesisUtterance(text);
    utter.voice = matchedVoice;
    utter.lang = matchedVoice.lang;
    utter.rate = isHindi ? 0.95 : 1.05;
    utter.pitch = 1;
    utter.onerror = (e) => {
      console.warn("[TTS] Native speak error, falling back to Google", e);
      speakViaGoogleTTS(text, lang);
    };
    window.speechSynthesis.speak(utter);
  }, 50);
}
