import { create } from "zustand";
import type { TaskSource } from "../types/index.js";

export type TaskPriority = "low" | "normal" | "high";

export interface TripStop {
  station_id: string;
  x: number;
  y: number;
  op: "pickup" | "drop";
  units?: number;
}

export interface PendingTask {
  task_id: string;
  pickup: string;
  drop: string;
  priority: TaskPriority;
  sla: number;
  created_ts: number;
  product_id?: string | null;
  batch_id?: string | null;
  stage_from?: string | null;
  stage_to?: string | null;
  units?: number | null;
  material_type?: string | null;
  source?: TaskSource;
  trip_id?: string | null;
  reserved_agv_id?: string | null;
  interrupted?: boolean;
  interrupted_agv_id?: string | null;
  interrupted_trip_id?: string | null;
  remaining_stops_count?: number;
}

export interface AssignedTask extends PendingTask {
  trip_id: string;
  agv_id: string;
  stops: TripStop[];
  bundled_tasks: number;
  assigned_ts: number;
}

export interface CompletedTask {
  task_id: string | null;
  task_ids?: string[];
  trip_id: string;
  agv_id: string;
  bundled: number;
  material_type?: string | null;
  kpis: { distance: number; duration: number; stops: number };
  completed_ts: number;
  was_interrupted?: boolean;
  was_resumed?: boolean;
  pickup?: string;
  drop?: string;
  stops?: TripStop[];
  product_id?: string | null;
  batch_id?: string | null;
  units?: number | null;
  priority?: TaskPriority;
  created_ts?: number;
}

export interface PcbStats {
  boards_total: number;             // total units delivered
  boards_by_product: Record<string, number>;
  cycle_time_sum_s: number;         // sum of (completed - created)
  cycle_time_count: number;
  cycle_time_by_stage_sum_s: Record<string, number>;
  cycle_time_by_stage_count: Record<string, number>;
  reworks: number;                  // tasks routed to rework
  passes: number;                   // tasks at AOI/ICT/FCT that did NOT go to rework
  sla_hits_by_priority: Record<TaskPriority, number>;
  sla_total_by_priority: Record<TaskPriority, number>;
  wip_by_zone: Record<string, number>;   // running WIP based on assigned tasks
}

interface TaskState {
  pending: Map<string, PendingTask>;
  assigned: Map<string, AssignedTask>;
  completed: CompletedTask[];
  tripsByAgv: Map<string, AssignedTask>;
  selectedAgvId: string | null;
  selectedTripId: string | null;
  pcbStats: PcbStats;
  startedAt: number;
  _nextTaskChatbot: boolean;
  seedTasks: (tasks: PendingTask[]) => void;
  markNextTaskAsChatbot: () => void;
  onTaskCreated: (e: PendingTask) => void;
  onTripRequested: (e: {
    trip_id: string;
    agv_id: string;
    stops: TripStop[];
    bundled_tasks?: number;
    ts: number;
  }) => void;
  onTaskAssigned: (e: { task_id: string; trip_id: string; ts: number }) => void;
  onTripInterrupted: (e: {
    trip_id: string;
    agv_id: string;
    task_ids?: string[];
    remaining_stops?: Array<{ station_id: string; op: string; units?: number }>;
    payload_count?: number;
    ts: number;
  }) => void;
  onTripResumed: (e: {
    trip_id: string;
    agv_id: string;
    stops: TripStop[];
    is_active?: boolean;
    ts: number;
  }) => void;
  onTripStopDone: (e: {
    trip_id: string;
    agv_id: string;
    station_id: string;
    op: string;
    ts: number;
  }) => void;
  onTripCompleted: (e: {
    trip_id: string;
    agv_id: string;
    task_id?: string | null;
    task_ids?: string[];
    bundled?: number;
    material_type?: string | null;
    stops?: Array<{ station_id: string; op: string; units?: number }>;
    kpis: { distance: number; duration: number; stops: number };
    ts: number;
  }) => void;
  selectAgv: (id: string | null) => void;
  selectTrip: (agvId: string | null, tripId: string | null) => void;
  reset: () => void;
  hydrateFromSnapshot: (snapshot: {
    pending: PendingTask[];
    assigned: (AssignedTask & { stops?: TripStop[] })[];
    completed?: Array<{
      task_id?: string | null;
      task_ids?: string[];
      trip_id: string;
      agv_id: string;
      bundled_tasks?: number;
      bundled?: number;
      kpis?: { distance?: number; duration?: number; stops?: number };
      completed_ts?: number;
    }>;
    stats?: PcbStats | null;
  }) => void;
}

const COMPLETED_LIMIT = 200;

const QUALITY_STAGES = new Set(["aoi_post_smt", "ict", "fct"]);

// Keep a side-table of pending->assigned task snapshots so we can roll up
// product / stage / SLA stats when the trip completes (event payloads only
// carry task_ids by then).
const taskSnapshots = new Map<string, PendingTask>();

// Per-trip lifecycle markers so completed rows can show whether the
// trip was halted mid-route and what happened next.
const tripLifecycle = new Map<
  string,
  { interrupted: boolean; resumed: boolean; stops?: TripStop[]; originalStops?: TripStop[] }
>();

// Authoritative trip_id -> {agv_id, stops, bundled_tasks} index built from
// trip:requested. Unlike tripsByAgv (which is gated to protect the in-flight
// overlay), this map records every requested trip so onTaskAssigned can
// always resolve the AGV for a freshly assigned task — even when the trip
// is queued behind another active trip on the same AGV.
const tripToAgv = new Map<
  string,
  { agv_id: string; stops: TripStop[]; bundled_tasks: number }
>();

export function getTripAgvIndex(): ReadonlyMap<
  string,
  { agv_id: string; stops: TripStop[]; bundled_tasks: number }
> {
  return tripToAgv;
}

function zoneFor(stationId: string | null | undefined): string {
  if (!stationId) return "unknown";
  const m = stationId.match(/S(\d+)/);
  if (!m) return "unknown";
  const n = parseInt(m[1], 10);
  if (n <= 10) return "A";
  if (n <= 20) return "B";
  return "C";
}

function emptyStats(): PcbStats {
  return {
    boards_total: 0,
    boards_by_product: {},
    cycle_time_sum_s: 0,
    cycle_time_count: 0,
    cycle_time_by_stage_sum_s: {},
    cycle_time_by_stage_count: {},
    reworks: 0,
    passes: 0,
    sla_hits_by_priority: { low: 0, normal: 0, high: 0 },
    sla_total_by_priority: { low: 0, normal: 0, high: 0 },
    wip_by_zone: {},
  };
}

export const useTaskState = create<TaskState>((set) => ({
  pending: new Map(),
  assigned: new Map(),
  completed: [],
  tripsByAgv: new Map(),
  selectedAgvId: null,
  selectedTripId: null,
  pcbStats: emptyStats(),
  startedAt: Date.now() / 1000,
  _nextTaskChatbot: false,

  seedTasks: (tasks) =>
    set(() => {
      const pending = new Map<string, PendingTask>();
      for (const t of tasks) {
        pending.set(t.task_id, t);
      }
      return { pending };
    }),

  markNextTaskAsChatbot: () => set({ _nextTaskChatbot: true }),

  onTaskCreated: (e) =>
    set((s) => {
      const raw = e as unknown as PendingTask & { ts?: number };
      const isChatbot = s._nextTaskChatbot;
      const pending = new Map(s.pending);
      const normalized: PendingTask = {
        ...raw,
        created_ts: raw.created_ts ?? raw.ts ?? Date.now() / 1000,
        source: isChatbot ? "chatbot" : "auto",
      };
      pending.set(e.task_id, normalized);
      return { pending, _nextTaskChatbot: false };
    }),

  onTripRequested: (e) =>
    set((s) => {
      // Keep a per-AGV trip-in-flight map so we can render the overlay even
      // before the matching task:assigned event arrives.
      const tripsByAgv = new Map(s.tripsByAgv);
      const placeholder: AssignedTask = {
        task_id: `pending-${e.trip_id}`,
        pickup: e.stops[0]?.station_id ?? "",
        drop: e.stops[e.stops.length - 1]?.station_id ?? "",
        priority: "normal",
        sla: 0,
        created_ts: e.ts,
        trip_id: e.trip_id,
        agv_id: e.agv_id,
        stops: e.stops,
        bundled_tasks: e.bundled_tasks ?? 1,
        assigned_ts: e.ts,
      };
      // Record the trip->agv mapping unconditionally so onTaskAssigned can
      // resolve agv_id for queued trips too.
      tripToAgv.set(e.trip_id, {
        agv_id: e.agv_id,
        stops: e.stops,
        bundled_tasks: e.bundled_tasks ?? 1,
      });
      // Only update the live overlay if this AGV has no active trip OR the
      // event matches the AGV's current trip. A `trip:requested` for a NEW
      // queued trip (different trip_id) must NOT overwrite the in-flight
      // route — the route belongs to the running trip until it completes.
      const existing = tripsByAgv.get(e.agv_id);
      if (!existing || existing.trip_id === e.trip_id) {
        tripsByAgv.set(e.agv_id, placeholder);
      }
      return { tripsByAgv };
    }),

  onTaskAssigned: (e) =>
    set((s) => {
      const pending = new Map(s.pending);
      let task = pending.get(e.task_id);
      if (!task) {
        // Backend may assign tasks with its own IDs — consume the oldest
        // pending task, but NEVER consume interrupted placeholders (those
        // belong to a stopped trip and must stay until explicitly resumed
        // or completed).
        const oldest = Array.from(pending.entries())
          .filter(([, v]) => !v.interrupted)
          .sort((a, b) => a[1].created_ts - b[1].created_ts)[0];
        if (!oldest) return {};
        task = oldest[1];
        pending.delete(oldest[0]);
      } else if (!task.interrupted) {
        pending.delete(e.task_id);
      }
      taskSnapshots.set(e.task_id, task);

      const assigned = new Map(s.assigned);
      const tripsByAgv = new Map(s.tripsByAgv);
      // Find the trip_id->agv mapping recorded by trip:requested.
      // Prefer the unconditional tripToAgv index (covers queued trips too);
      // fall back to scanning tripsByAgv.
      const tripInfo = tripToAgv.get(e.trip_id);
      let agvId = tripInfo?.agv_id ?? "";
      let stops = tripInfo?.stops ?? [];
      let bundled = tripInfo?.bundled_tasks ?? 1;
      if (!agvId) {
        for (const t of tripsByAgv.values()) {
          if (t.trip_id === e.trip_id) {
            agvId = t.agv_id;
            stops = t.stops;
            bundled = t.bundled_tasks ?? 1;
            break;
          }
        }
      }
      const merged: AssignedTask = {
        ...task,
        trip_id: e.trip_id,
        agv_id: agvId,
        stops,
        bundled_tasks: bundled,
        assigned_ts: e.ts,
      };
      assigned.set(e.trip_id, merged);
      if (merged.agv_id) {
        // Same guard: don't replace the live overlay of an AGV already
        // executing a different trip. The queued task lives only in
        // `assigned` until its trip becomes the active one.
        const existing = tripsByAgv.get(merged.agv_id);
        if (!existing || existing.trip_id === e.trip_id) {
          tripsByAgv.set(merged.agv_id, merged);
        }
      }

      if (!tripLifecycle.has(e.trip_id)) {
        tripLifecycle.set(e.trip_id, {
          interrupted: false,
          resumed: false,
          stops: merged.stops,
          originalStops: merged.stops,
        });
      }

      const z = zoneFor(merged.drop);
      const pcbStats: PcbStats = {
        ...s.pcbStats,
        wip_by_zone: {
          ...s.pcbStats.wip_by_zone,
          [z]: (s.pcbStats.wip_by_zone[z] ?? 0) + 1,
        },
      };
      return { pending, assigned, tripsByAgv, pcbStats };
    }),

  onTripInterrupted: (e) =>
    set((s) => {
      // Move the trip's tasks back to pending with interrupted markers so
      // the UI can render Resume / Complete buttons on those rows.
      const assigned = new Map(s.assigned);
      const tripsByAgv = new Map(s.tripsByAgv);
      assigned.delete(e.trip_id);
      const cur = tripsByAgv.get(e.agv_id);
      if (cur && cur.trip_id === e.trip_id) tripsByAgv.delete(e.agv_id);

      const lc = tripLifecycle.get(e.trip_id) ?? {
        interrupted: false,
        resumed: false,
      };
      lc.interrupted = true;
      tripLifecycle.set(e.trip_id, lc);

      const pending = new Map(s.pending);
      const ids = e.task_ids ?? [];
      const remStops = e.remaining_stops ?? [];
      const remCount = remStops.length;
      const dropTarget = remStops.length
        ? remStops[remStops.length - 1].station_id
        : "";
      // Only surface interrupted entries when this trip is backed by real
      // PCB tasks. Plain relocations / recalls (no task_ids) are not user-
      // facing tasks and should not show in the Pending section.
      if (ids.length === 0) {
        // no-op: drop placeholder
      } else {
        // Show as a single pending row keyed by trip_id (not per-task).
        const firstSnap = ids.map((id) => taskSnapshots.get(id)).find(Boolean);
        const base: PendingTask = firstSnap ?? {
          task_id: e.trip_id,
          pickup: "",
          drop: dropTarget,
          priority: "normal",
          sla: 0,
          created_ts: e.ts,
        };
        pending.set(e.trip_id, {
          ...base,
          task_id: e.trip_id,
          interrupted: true,
          interrupted_agv_id: e.agv_id,
          interrupted_trip_id: e.trip_id,
          remaining_stops_count: remCount,
          units: ids.length > 1 ? ids.length : base.units,
          bundled_tasks: ids.length,
          interrupted_task_ids: ids,
          interrupted_remaining_stops: remStops,
        } as PendingTask & {
          bundled_tasks?: number;
          interrupted_task_ids?: string[];
          interrupted_remaining_stops?: typeof remStops;
        });
      }
      // Decrement WIP since these tasks are no longer assigned.
      const stats: PcbStats = {
        ...s.pcbStats,
        wip_by_zone: { ...s.pcbStats.wip_by_zone },
      };
      for (const tid of ids) {
        const snap = taskSnapshots.get(tid);
        if (!snap) continue;
        const z = zoneFor(snap.drop);
        stats.wip_by_zone[z] = Math.max(0, (stats.wip_by_zone[z] ?? 0) - 1);
      }
      return { pending, assigned, tripsByAgv, pcbStats: stats };
    }),

  onTripResumed: (e) =>
    set((s) => {
      // Pull interrupted pending rows for this trip and rebuild an
      // AssignedTask so the row reappears in the in-transit section.
      const pending = new Map(s.pending);
      const restored: PendingTask[] = [];
      for (const [k, v] of pending) {
        if (v.interrupted && v.interrupted_trip_id === e.trip_id) {
          restored.push(v);
          pending.delete(k);
        }
      }
      const base: PendingTask | undefined = restored[0];
      const merged: AssignedTask = {
        task_id: base?.task_id ?? `resumed-${e.trip_id}`,
        pickup: base?.pickup ?? (e.stops[0]?.station_id ?? ""),
        drop: base?.drop ?? (e.stops[e.stops.length - 1]?.station_id ?? ""),
        priority: base?.priority ?? "normal",
        sla: base?.sla ?? 0,
        created_ts: base?.created_ts ?? e.ts,
        product_id: base?.product_id,
        batch_id: base?.batch_id,
        stage_from: base?.stage_from,
        stage_to: base?.stage_to,
        units: base?.units,
        material_type: base?.material_type,
        source: base?.source,
        trip_id: e.trip_id,
        agv_id: e.agv_id,
        stops: e.stops,
        bundled_tasks: Math.max(
          1,
          (base as PendingTask & { bundled_tasks?: number })?.bundled_tasks ??
            restored.length,
        ),
        assigned_ts: e.ts,
      };
      const assigned = new Map(s.assigned);
      assigned.set(e.trip_id, merged);
      const tripsByAgv = new Map(s.tripsByAgv);
      // Only the actively-executing resumed trip should drive the AGV's live
      // route overlay. Queued resumed trips (is_active=false) update `assigned`
      // so the row reappears, but must NOT overwrite tripsByAgv — otherwise
      // the last-published trip's stops mask the active trip's actual route.
      const isActive = e.is_active !== false;
      const existing = tripsByAgv.get(e.agv_id);
      if (isActive || !existing) {
        tripsByAgv.set(e.agv_id, merged);
      }

      const lc = tripLifecycle.get(e.trip_id) ?? {
        interrupted: true,
        resumed: false,
      };
      lc.resumed = true;
      lc.stops = e.stops;
      tripLifecycle.set(e.trip_id, lc);

      // Bump WIP back up for restored tasks.
      const stats: PcbStats = {
        ...s.pcbStats,
        wip_by_zone: { ...s.pcbStats.wip_by_zone },
      };
      for (const t of restored) {
        const z = zoneFor(t.drop);
        stats.wip_by_zone[z] = (stats.wip_by_zone[z] ?? 0) + 1;
      }
      return { pending, assigned, tripsByAgv, pcbStats: stats };
    }),

  onTripStopDone: (_e) =>
    set(() => {
      // Intentionally a no-op for the trip overlay: the trip path/sequence
      // shown on the card must remain the FULL start→end route for the
      // duration of the trip. Stop completion is reflected by the AGV
      // marker advancing along the path, not by mutating the stops list.
      return {};
    }),

  onTripCompleted: (e) =>
    set((s) => {
      // Clear any interrupted pending rows tied to this trip (covers both
      // resume-then-complete and the abandon-interrupted flow).
      const pending = new Map(s.pending);
      for (const [k, v] of pending) {
        if (v.interrupted && v.interrupted_trip_id === e.trip_id) {
          pending.delete(k);
        }
      }
      // Grab the assigned task BEFORE deleting so we can fall back to it
      // for stops/details when taskSnapshots or tripLifecycle are empty
      // (happens when events arrive in quick succession for seed tasks).
      const assignedTask = s.assigned.get(e.trip_id);
      const assigned = new Map(s.assigned);
      assigned.delete(e.trip_id);
      tripToAgv.delete(e.trip_id);
      const tripsByAgv = new Map(s.tripsByAgv);
      const cur = tripsByAgv.get(e.agv_id);
      if (cur && cur.trip_id === e.trip_id) {
        // Promote next queued task assigned to this AGV (if any) so its
        // route overlay takes over once the completed trip clears.
        const nextQueued = Array.from(assigned.values())
          .filter((t) => t.agv_id === e.agv_id && t.trip_id !== e.trip_id)
          .sort((a, b) => (a.assigned_ts ?? 0) - (b.assigned_ts ?? 0))[0];
        if (nextQueued) {
          tripsByAgv.set(e.agv_id, nextQueued);
        } else {
          tripsByAgv.delete(e.agv_id);
        }
      }
      const lc = tripLifecycle.get(e.trip_id);
      const ids0 = e.task_ids ?? (e.task_id ? [e.task_id] : []);
      // Skip adding to completed entirely if this trip was a plain relocation
      // (no task_ids). Those are not user-facing tasks.
      if (ids0.length === 0) {
        return { pending, assigned, tripsByAgv };
      }
      const firstSnap = ids0.map((id) => taskSnapshots.get(id)).find(Boolean);
      const completed: CompletedTask = {
        task_id: e.task_id ?? null,
        task_ids: e.task_ids,
        trip_id: e.trip_id,
        agv_id: e.agv_id,
        bundled: e.bundled ?? 1,
        material_type: e.material_type ?? null,
        kpis: e.kpis,
        completed_ts: e.ts,
        was_interrupted: lc?.interrupted ?? false,
        was_resumed: lc?.resumed ?? false,
        stops: e.stops?.map((s) => ({
          station_id: s.station_id,
          x: 0,
          y: 0,
          op: s.op as "pickup" | "drop",
          units: s.units,
        })) ?? lc?.originalStops ?? lc?.stops ?? assignedTask?.stops,
        pickup: firstSnap?.pickup ?? assignedTask?.pickup,
        drop: firstSnap?.drop ?? assignedTask?.drop,
        product_id: firstSnap?.product_id ?? assignedTask?.product_id,
        batch_id: firstSnap?.batch_id ?? assignedTask?.batch_id,
        units: firstSnap?.units ?? assignedTask?.units,
        priority: firstSnap?.priority ?? assignedTask?.priority,
        created_ts: firstSnap?.created_ts ?? assignedTask?.created_ts,
      };
      tripLifecycle.delete(e.trip_id);
      const deduped = s.completed.filter((c) => c.trip_id !== e.trip_id);
      const next = [completed, ...deduped].slice(0, COMPLETED_LIMIT);

      // Roll up PCB-realistic stats from the snapshots of finished tasks.
      const stats: PcbStats = {
        ...s.pcbStats,
        boards_by_product: { ...s.pcbStats.boards_by_product },
        cycle_time_by_stage_sum_s: { ...s.pcbStats.cycle_time_by_stage_sum_s },
        cycle_time_by_stage_count: { ...s.pcbStats.cycle_time_by_stage_count },
        sla_hits_by_priority: { ...s.pcbStats.sla_hits_by_priority },
        sla_total_by_priority: { ...s.pcbStats.sla_total_by_priority },
        wip_by_zone: { ...s.pcbStats.wip_by_zone },
      };
      const ids = e.task_ids ?? (e.task_id ? [e.task_id] : []);
      for (const tid of ids) {
        const snap = taskSnapshots.get(tid);
        if (!snap) continue;
        taskSnapshots.delete(tid);

        const units = snap.units ?? 1;
        stats.boards_total += units;
        if (snap.product_id) {
          stats.boards_by_product[snap.product_id] =
            (stats.boards_by_product[snap.product_id] ?? 0) + units;
        }

        const cycle = Math.max(0, e.ts - snap.created_ts);
        stats.cycle_time_sum_s += cycle;
        stats.cycle_time_count += 1;
        const stage = snap.stage_to ?? "unknown";
        stats.cycle_time_by_stage_sum_s[stage] =
          (stats.cycle_time_by_stage_sum_s[stage] ?? 0) + cycle;
        stats.cycle_time_by_stage_count[stage] =
          (stats.cycle_time_by_stage_count[stage] ?? 0) + 1;

        if (stage === "rework") stats.reworks += 1;
        else if (QUALITY_STAGES.has(stage)) stats.passes += 1;

        const pri = snap.priority ?? "normal";
        stats.sla_total_by_priority[pri] += 1;
        if (snap.sla && e.ts <= snap.sla) stats.sla_hits_by_priority[pri] += 1;

        const z = zoneFor(snap.drop);
        stats.wip_by_zone[z] = Math.max(0, (stats.wip_by_zone[z] ?? 0) - 1);
      }

      return { pending, assigned, tripsByAgv, completed: next, pcbStats: stats };
    }),

  selectAgv: (id) =>
    set((s) => ({
      selectedAgvId: s.selectedAgvId === id ? null : id,
      selectedTripId: s.selectedAgvId === id ? null : s.selectedTripId,
    })),

  selectTrip: (agvId, tripId) =>
    set((s) => {
      const same =
        s.selectedAgvId === agvId && s.selectedTripId === tripId;
      return {
        selectedAgvId: same ? null : agvId,
        selectedTripId: same ? null : tripId,
      };
    }),

  reset: () => {
    taskSnapshots.clear();
    set({
      pending: new Map(),
      assigned: new Map(),
      completed: [],
      tripsByAgv: new Map(),
      selectedAgvId: null,
      selectedTripId: null,
      pcbStats: emptyStats(),
      startedAt: Date.now() / 1000,
    });
  },

  hydrateFromSnapshot: (snapshot) =>
    set((s) => {
      const pending = new Map(s.pending);
      for (const t of snapshot.pending ?? []) {
        if (!pending.has(t.task_id)) pending.set(t.task_id, t);
      }
      const assigned = new Map(s.assigned);
      const tripsByAgv = new Map(s.tripsByAgv);
      for (const a of snapshot.assigned ?? []) {
        if (!a.trip_id) continue;
        const merged: AssignedTask = {
          ...a,
          stops: (a.stops as TripStop[]) ?? [],
          bundled_tasks: a.bundled_tasks ?? 1,
        } as AssignedTask;
        if (!assigned.has(a.trip_id)) assigned.set(a.trip_id, merged);
        if (a.agv_id && !tripsByAgv.has(a.agv_id)) {
          tripsByAgv.set(a.agv_id, merged);
        }
      }
      const completed: CompletedTask[] = (snapshot.completed ?? [])
        .map((c) => {
          const cc = c as typeof c & {
            was_interrupted?: boolean;
            was_resumed?: boolean;
            material_type?: string | null;
            pickup?: string;
            drop?: string;
            stops?: TripStop[];
            product_id?: string | null;
            batch_id?: string | null;
            units?: number | null;
            priority?: TaskPriority;
            created_ts?: number;
          };
          return {
            task_id: cc.task_id ?? null,
            task_ids: cc.task_ids,
            trip_id: cc.trip_id,
            agv_id: cc.agv_id,
            bundled: cc.bundled ?? cc.bundled_tasks ?? 1,
            material_type: cc.material_type ?? null,
            kpis: {
              distance: cc.kpis?.distance ?? 0,
              duration: cc.kpis?.duration ?? 0,
              stops: cc.kpis?.stops ?? 0,
            },
            completed_ts: cc.completed_ts ?? 0,
            was_interrupted: cc.was_interrupted,
            was_resumed: cc.was_resumed,
            pickup: cc.pickup,
            drop: cc.drop,
            stops: cc.stops,
            product_id: cc.product_id,
            batch_id: cc.batch_id,
            units: cc.units,
            priority: cc.priority,
            created_ts: cc.created_ts,
          } as CompletedTask;
        })
        .slice(0, COMPLETED_LIMIT);
      const pcbStats = snapshot.stats
        ? { ...emptyStats(), ...snapshot.stats }
        : s.pcbStats;
      return { pending, assigned, tripsByAgv, completed, pcbStats };
    }),
}));
