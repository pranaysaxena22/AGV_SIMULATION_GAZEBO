import { useEffect, useRef } from "react";
import { useFleetState } from "./useFleetState.js";
import { useTaskState } from "./useTaskState.js";
import type { AgvTelemetry } from "../types/index.js";

function getBridgeUrl(): string {
  const host = window.location.hostname || "localhost";
  return `ws://${host}:8081/ws`;
}

function getSnapshotUrl(): string {
  const host = window.location.hostname || "localhost";
  return `http://${host}:8081/tasks/snapshot`;
}

export function useAgvWebSocket() {
  const setTelemetry = useFleetState((s) => s.setTelemetry);
  const setConnected = useFleetState((s) => s.setConnected);
  const onTaskCreated = useTaskState((s) => s.onTaskCreated);
  const onTaskAssigned = useTaskState((s) => s.onTaskAssigned);
  const onTripRequested = useTaskState((s) => s.onTripRequested);
  const onTripCompleted = useTaskState((s) => s.onTripCompleted);
  const onTripStopDone = useTaskState((s) => s.onTripStopDone);
  const onTripInterrupted = useTaskState((s) => s.onTripInterrupted);
  const onTripResumed = useTaskState((s) => s.onTripResumed);
  const hydrateFromSnapshot = useTaskState((s) => s.hydrateFromSnapshot);
  const wsRef = useRef<WebSocket | null>(null);
  const backoffRef = useRef(500);

  useEffect(() => {
    let closed = false;

    // Hydrate task queue from server snapshot before opening WS so the
    // queue panel shows existing pending/assigned tasks after a refresh.
    fetch(getSnapshotUrl())
      .then((r) => r.json())
      .then((j) => {
        if (j?.ok)
          hydrateFromSnapshot({
            pending: j.pending ?? [],
            assigned: j.assigned ?? [],
            completed: j.completed ?? [],
            stats: j.stats ?? null,
          });
      })
      .catch(() => {});

    const connect = () => {
      if (closed) return;
      const url = getBridgeUrl();
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        backoffRef.current = 500;
        setConnected(true);
      };

      ws.onmessage = (ev) => {
        try {
          const envelope = JSON.parse(ev.data) as {
            channel: string;
            data: unknown;
          };
          const ch = envelope.channel;
          const d = envelope.data as Record<string, unknown> | null;
          if (!d) return;

          if (ch === "agv:telemetry" || ch === "agv:state") {
            if (typeof d.agv_id === "string") {
              const patch = { ...(d as unknown as AgvTelemetry) };
              // Any non-"blocked" state implies the AGV is no longer stalled
              // on a peer — clear the blocked overlay even if no explicit
              // traffic:resumed event fired (e.g. reroute path).
              if (
                typeof (d as Record<string, unknown>).state === "string" &&
                (d as Record<string, unknown>).state !== "blocked"
              ) {
                (patch as Partial<AgvTelemetry>).blocked_by = null;
                (patch as Partial<AgvTelemetry>).blocked_at_node = null;
              }
              setTelemetry(patch);
            }
            return;
          }
          if (ch === "task:created") {
            onTaskCreated(d as never);
            return;
          }
          if (ch === "task:assigned") {
            onTaskAssigned(d as never);
            return;
          }
          if (ch === "trip:requested") {
            onTripRequested(d as never);
            return;
          }
          if (ch === "trip:completed") {
            onTripCompleted(d as never);
            return;
          }
          if (ch === "trip:stop_done") {
            onTripStopDone(d as never);
            return;
          }
          if (ch === "trip:interrupted") {
            onTripInterrupted(d as never);
            return;
          }
          if (ch === "trip:resumed") {
            onTripResumed(d as never);
            return;
          }
          if (ch === "traffic:blocked") {
            if (typeof d.agv_id === "string") {
              setTelemetry({
                agv_id: d.agv_id as string,
                blocked_by: (d.blocked_by as string) ?? null,
                blocked_at_node: (d.node as string) ?? null,
              });
            }
            return;
          }
          if (ch === "traffic:resumed") {
            if (typeof d.agv_id === "string") {
              setTelemetry({
                agv_id: d.agv_id as string,
                blocked_by: null,
                blocked_at_node: null,
              });
            }
            return;
          }
        } catch {
          /* ignore malformed frames */
        }
      };

      ws.onclose = () => {
        setConnected(false);
        if (closed) return;
        const delay = Math.min(backoffRef.current, 10_000);
        backoffRef.current = Math.min(backoffRef.current * 2, 10_000);
        setTimeout(connect, delay);
      };

      ws.onerror = () => ws.close();
    };

    connect();
    return () => {
      closed = true;
      wsRef.current?.close();
    };
  }, [
    setTelemetry,
    setConnected,
    onTaskCreated,
    onTaskAssigned,
    onTripRequested,
    onTripCompleted,
    onTripStopDone,
    onTripInterrupted,
    onTripResumed,
    hydrateFromSnapshot,
  ]);
}
