import { create } from "zustand";
import type { AgvTelemetry } from "../types/index.js";

interface FleetState {
  fleet: Map<string, AgvTelemetry>;
  connected: boolean;
  visibleAgvIds: Set<string> | null; // null = show all
  setTelemetry: (t: Partial<AgvTelemetry> & { agv_id: string }) => void;
  setConnected: (v: boolean) => void;
  toggleAgvVisible: (id: string) => void;
  showAllAgvs: () => void;
  showOnlyAgv: (id: string) => void;
  reset: () => void;
}

const EMPTY: AgvTelemetry = {
  agv_id: "",
  x: 0,
  y: 0,
  heading: 0,
  speed: 0,
  state: "idle",
  trip_id: null,
  current_node: null,
  capacity: 3,
  payload_count: 0,
  ts: 0,
  origin_node: null,
  dest_node: null,
  blocked_by: null,
  blocked_at_node: null,
};

export const useFleetState = create<FleetState>((set) => ({
  fleet: new Map(),
  connected: false,
  visibleAgvIds: null,
  setTelemetry: (t) =>
    set((s) => {
      const next = new Map(s.fleet);
      const prev = next.get(t.agv_id) ?? { ...EMPTY, agv_id: t.agv_id };
      next.set(t.agv_id, { ...prev, ...t });
      return { fleet: next };
    }),
  setConnected: (v) => set({ connected: v }),
  toggleAgvVisible: (id) =>
    set((s) => {
      const all = Array.from(s.fleet.keys());
      // null (all-shown) means start fresh from this single click.
      const cur = s.visibleAgvIds ?? new Set<string>();
      const next = new Set(cur);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      // Empty selection => fall back to "show all".
      if (next.size === 0) return { visibleAgvIds: null };
      // Selected everyone => also fall back to "show all".
      if (next.size === all.length) return { visibleAgvIds: null };
      return { visibleAgvIds: next };
    }),
  showAllAgvs: () => set({ visibleAgvIds: null }),
  showOnlyAgv: (id) => set({ visibleAgvIds: new Set([id]) }),
  reset: () =>
    set({ fleet: new Map(), connected: false, visibleAgvIds: null }),
}));
