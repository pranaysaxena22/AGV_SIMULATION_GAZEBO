export type AgvStateName =
  | "idle"
  | "moving"
  | "loading"
  | "unloading"
  | "blocked"
  | "charging"
  | "depleted";

export interface AgvTelemetry {
  agv_id: string;
  x: number;
  y: number;
  heading: number;
  speed: number;
  state: AgvStateName;
  trip_id: string | null;
  current_node: string | null;
  capacity: number;
  payload_count: number;
  battery_pct?: number;
  ts: number;
  origin_node?: string | null;
  dest_node?: string | null;
  blocked_by?: string | null;
  blocked_at_node?: string | null;
}

export interface AgvState {
  agv_id: string;
  state: AgvStateName;
  payload_count: number;
  current_node: string | null;
  trip_id: string | null;
  ts: number;
}

export type Zone = "A" | "B" | "C";

export type TaskSource = "auto" | "chatbot" | "manual" | "seed";

export type StationRole =
  | "inbound"
  | "smt_feeder"
  | "paste_print"
  | "smt_pnp"
  | "reflow"
  | "aoi_post_smt"
  | "ict"
  | "fct"
  | "xray"
  | "aoi"
  | "rework"
  | "wip_buffer"
  | "conformal_coat"
  | "depanel"
  | "final_assembly"
  | "packaging"
  | "outbound"
  | "dispatch_dock"
  | "parking";

export interface Station {
  id: string;
  x: number;
  y: number;
  zone: Zone;
  kind?: "station";
  label?: string;
  role?: StationRole;
  name?: string;
}

export interface Waypoint {
  id: string;
  x: number;
  y: number;
  kind?: "waypoint";
}

export interface Edge {
  from: string;
  to: string;
  type?: "aisle" | "spur";
}

export interface FloorBounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

export interface FloorLayout {
  name: string;
  units: "meters";
  bounds: FloorBounds;
  stations: Station[];
  waypoints: Waypoint[];
  edges: Edge[];
}
