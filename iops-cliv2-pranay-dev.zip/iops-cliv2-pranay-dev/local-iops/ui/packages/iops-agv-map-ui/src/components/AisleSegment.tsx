import type { Edge } from "../types/index.js";

interface Props {
  edge: Edge;
  a: { x: number; y: number };
  b: { x: number; y: number };
}

export function AisleSegment({ edge, a, b }: Props) {
  const isSpur = edge.type === "spur";
  return (
    <g className={isSpur ? "aisle aisle-spur" : "aisle aisle-main"}>
      <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} className="aisle-base" />
      {!isSpur && (
        <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} className="aisle-stripe" />
      )}
    </g>
  );
}
