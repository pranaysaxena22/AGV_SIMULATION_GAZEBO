import { useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { AgvTelemetry } from "../types/index.js";
import { useTaskState } from "../hooks/useTaskState.js";

interface Props {
  agv: AgvTelemetry;
}

const BODY = 2.0;

const PARKING_BAYS = new Set(["H01", "H02", "H03", "W34", "W38"]);

const STATE_COLORS: Record<string, string> = {
  idle: "#475569",
  moving: "#6366f1",
  loading: "#ec4899",
  unloading: "#14b8a6",
  blocked: "#dc2626",
  charging: "#facc15",
  depleted: "#ef4444",
  parking: "#f59e0b",
  parked: "#78716c",
};

function deriveDisplayState(agv: AgvTelemetry): { label: string; color: string } {
  if (agv.state === "moving" && agv.dest_node && PARKING_BAYS.has(agv.dest_node)) {
    return { label: "parking", color: STATE_COLORS.parking };
  }
  if (agv.state === "idle" && agv.current_node && PARKING_BAYS.has(agv.current_node)) {
    return { label: "parked", color: STATE_COLORS.parked };
  }
  return { label: agv.state, color: STATE_COLORS[agv.state] ?? "#94a3b8" };
}

function AgvTooltip({ agv, anchorRect }: { agv: AgvTelemetry; anchorRect: DOMRect }) {
  const { label: displayState, color } = deriveDisplayState(agv);
  const top = anchorRect.top - 8;
  const left = anchorRect.left + anchorRect.width / 2;

  return createPortal(
    <div
      style={{
        position: "fixed",
        top,
        left,
        transform: "translate(-50%, -100%)",
        zIndex: 100000,
        pointerEvents: "none",
        minWidth: 180,
      }}
    >
      <div
        style={{
          background: "rgba(15, 23, 42, 0.95)",
          border: `1px solid ${color}`,
          borderRadius: 8,
          padding: "10px 12px",
          boxShadow: `0 4px 20px rgba(0,0,0,0.5), 0 0 8px ${color}33`,
          backdropFilter: "blur(8px)",
          fontSize: 12,
          color: "#e2e8f0",
          lineHeight: 1.6,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <span style={{ fontWeight: 800, fontSize: 13 }}>{agv.agv_id}</span>
          <span
            style={{
              fontSize: 10,
              fontWeight: 700,
              textTransform: "uppercase",
              color,
              background: `${color}20`,
              padding: "2px 6px",
              borderRadius: 4,
              letterSpacing: "0.04em",
            }}
          >
            {displayState}
          </span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "2px 10px", fontSize: 11 }}>
          <span style={{ opacity: 0.6 }}>Position</span>
          <span style={{ fontWeight: 600 }}>{agv.current_node ?? "—"}</span>

          <span style={{ opacity: 0.6 }}>Payload</span>
          <span style={{ fontWeight: 600 }}>{agv.payload_count} unit{agv.payload_count === 1 ? "" : "s"}</span>

          {typeof agv.battery_pct === "number" && (
            <>
              <span style={{ opacity: 0.6 }}>Battery</span>
              <span style={{ fontWeight: 700, color: agv.battery_pct < 20 ? "#f87171" : agv.battery_pct < 80 ? "#facc15" : "#34d399" }}>
                {agv.battery_pct.toFixed(0)}%
              </span>
            </>
          )}

          {agv.dest_node && (
            <>
              <span style={{ opacity: 0.6 }}>Heading to</span>
              <span style={{ fontWeight: 600, color: "#a5b4fc" }}>{agv.dest_node}</span>
            </>
          )}

          {agv.blocked_by && (
            <>
              <span style={{ opacity: 0.6 }}>Blocked by</span>
              <span style={{ fontWeight: 600, color: "#fca5a5" }}>{agv.blocked_by}</span>
            </>
          )}
        </div>
        <div
          style={{
            position: "absolute",
            bottom: -5,
            left: "50%",
            transform: "translateX(-50%) rotate(45deg)",
            width: 10,
            height: 10,
            background: "rgba(15, 23, 42, 0.95)",
            borderRight: `1px solid ${color}`,
            borderBottom: `1px solid ${color}`,
          }}
        />
      </div>
    </div>,
    document.body,
  );
}

export function AgvMarker({ agv }: Props) {
  const selectedAgvId = useTaskState((s) => s.selectedAgvId);
  const selectAgv = useTaskState((s) => s.selectAgv);
  const half = BODY / 2;
  const { label: displayState } = deriveDisplayState(agv);
  const isMoving = agv.state === "moving";
  const isBlocked = !!agv.blocked_by;
  const isDepleted = agv.state === "depleted";
  const isParking = displayState === "parking";
  const isSelected = selectedAgvId === agv.agv_id;
  const [hovered, setHovered] = useState(false);
  const gRef = useRef<SVGGElement>(null);
  const [anchorRect, setAnchorRect] = useState<DOMRect | null>(null);

  const handleMouseEnter = () => {
    setHovered(true);
    if (gRef.current) {
      setAnchorRect(gRef.current.getBoundingClientRect());
    }
  };
  const handleMouseLeave = () => setHovered(false);

  // Wrap entire marker in a translated <g>. CSS transition on `transform`
  // animates the marker between telemetry frames so reroute / step-change
  // updates glide instead of teleporting. Children are drawn at local (0,0).
  return (
    <>
      <g
        ref={gRef}
        className={`agv-marker agv-state-${displayState}${
          isSelected ? " agv-marker-selected" : ""
        }`}
        style={{ cursor: "pointer" }}
        transform={`translate(${agv.x} ${agv.y})`}
        onClick={(e) => {
          e.stopPropagation();
          selectAgv(agv.agv_id);
        }}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {isSelected && <circle cx={0} cy={0} r={2.6} className="agv-selected-ring" />}
        {isMoving && !isBlocked && (
          <circle cx={0} cy={0} r={2.2} className="agv-pulse agv-pulse-outer" />
        )}
        {isBlocked && <circle cx={0} cy={0} r={2.4} className="agv-blocked-ring" />}
        {isParking && (
          <circle
            cx={0}
            cy={0}
            r={2.2}
            className="agv-pulse agv-pulse-outer"
            style={{ stroke: "#f59e0b" }}
          />
        )}
        {isDepleted && (
          <>
            <circle cx={0} cy={0} r={2.6} className="agv-depleted-ring" />
            <g transform="scale(1,-1)" className="agv-depleted-alert">
              <text
                x={0}
                y={-1.6}
                textAnchor="middle"
                dominantBaseline="central"
                className="agv-depleted-icon"
              >
                ⚠
              </text>
            </g>
          </>
        )}
        <g transform={`rotate(${agv.heading})`}>
          <rect
            x={-half}
            y={-half}
            width={BODY}
            height={BODY}
            rx={0.5}
            ry={0.5}
            className="agv-body"
          />
          <polygon
            points={`${half},${-0.4} ${half + 0.5},0 ${half},0.4`}
            className="agv-heading"
          />
        </g>
        <g transform="scale(1,-1)">
          <text
            x={0}
            y={0}
            textAnchor="middle"
            dominantBaseline="central"
            className="agv-label"
          >
            {agv.agv_id.replace(/^AGV0?/, "")}
          </text>
          <rect
            x={-3.0}
            y={2.4 - 0.7}
            width={6.0}
            height={1.2}
            rx={0.35}
            ry={0.35}
            className="agv-state-pill"
          />
          <text
            x={0}
            y={2.4 - 0.1}
            textAnchor="middle"
            dominantBaseline="central"
            className="agv-state-text"
          >
            {displayState}
          </text>
        </g>
      </g>
      {hovered && anchorRect && <AgvTooltip agv={agv} anchorRect={anchorRect} />}
    </>
  );
}
