import { useMemo, useState, useEffect } from "react";
import { Badge } from "@smaf/iops-shared-ui";
import {
  Inbox,
  ListChecks,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Play,
  X as XIcon,
  AlertTriangle,
  RefreshCw,
  Ban,
  Route,
  Timer,
  Package,
} from "lucide-react";
import { useTaskState, getTripAgvIndex } from "../hooks/useTaskState.js";
import type {
  AssignedTask,
  CompletedTask,
  PendingTask,
  TaskPriority,
  TripStop,
} from "../hooks/useTaskState.js";
import layoutJson from "../data/poc-floor.json" with { type: "json" };

const STATION_NAMES: Record<string, string> = Object.fromEntries(
  (layoutJson as { stations: { id: string; name: string }[] }).stations.map(
    (s) => [s.id, s.name],
  ),
);

const PRIORITY_VARIANT: Record<
  TaskPriority,
  "default" | "secondary" | "destructive"
> = {
  low: "secondary",
  normal: "default",
  high: "destructive",
};

const MATERIAL_LABELS: Record<string, string> = {
  bare_pcb: "Bare PCB Transfer",
  component_reel: "Component Reel Delivery",
  wip_panel: "WIP Panel Move",
  finished_unit: "Finished Goods Pickup",
  defective_unit_to_rework: "Rework Unit Return",
};

const PRODUCT_LABELS: Record<string, string> = {
  pcb_consumer: "Consumer Electronics PCB",
  pcb_industrial: "Industrial Control PCB",
  pcb_automotive: "Automotive Grade PCB",
};

const STAGE_LABELS: Record<string, string> = {
  inbound: "Inbound Dock",
  smt_feeder: "SMT Feeder",
  paste_print: "Solder Paste Printer",
  smt_pnp: "Pick & Place",
  reflow: "Reflow Oven",
  aoi_post_smt: "AOI Inspection",
  ict: "In-Circuit Test",
  fct: "Functional Test",
  xray: "X-Ray Inspection",
  conformal_coat: "Conformal Coating",
  depanel: "Depaneling",
  final_assembly: "Final Assembly",
  packaging: "Packaging",
  outbound: "Outbound Dock",
  dispatch_dock: "Dispatch Dock",
  rework: "Rework Station",
  wip_buffer: "WIP Buffer",
};

function productLabel(id?: string | null): string {
  if (id && PRODUCT_LABELS[id]) return PRODUCT_LABELS[id];
  return id || "Material Transport";
}

function stationName(stationId?: string | null, stage?: string | null): string {
  if (stationId && STATION_NAMES[stationId]) return STATION_NAMES[stationId];
  if (stage && STAGE_LABELS[stage]) return STAGE_LABELS[stage];
  return stationId || stage || "—";
}

function materialLabel(mat?: string | null): string {
  if (mat && MATERIAL_LABELS[mat]) return MATERIAL_LABELS[mat];
  return "Material Transport";
}

function fmtStation(s: string): string {
  return s.replace(/^STN_/, "");
}


function getToolsBaseUrl(): string {
  if (typeof window === "undefined") return "";
  const w = window as unknown as { __AGV_TOOLS_URL?: string };
  if (w.__AGV_TOOLS_URL) return w.__AGV_TOOLS_URL;
  // Same-origin nginx proxy — avoids mixed-content blocks under HTTPS.
  return "/agv-tools";
}

async function callTool(path: string, body?: unknown): Promise<void> {
  const url = `${getToolsBaseUrl()}${path}`;
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body ?? {}),
    });
    if (!r.ok) {
      console.warn("callTool failed", path, r.status, await r.text());
    }
  } catch (e) {
    console.warn("callTool error", path, e);
  }
}

function InterruptedRow({ task }: { task: PendingTask }) {
  const agvId = task.interrupted_agv_id ?? "";
  const [busy, setBusy] = useState<"resume" | "complete" | null>(null);
  return (
    <div className="flex flex-col gap-1.5 rounded-lg border border-amber-500/50 bg-amber-500/10 px-3 py-2.5 text-xs">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="font-semibold truncate">
            {materialLabel(task.material_type)} · {agvId || "?"}
          </div>
          <div className="text-[11px] text-muted-foreground">
            Interrupted · {task.remaining_stops_count ?? 0} stops remaining
          </div>
        </div>
        <Badge variant="destructive" className="text-[9px] px-1.5 py-0">
          stopped
        </Badge>
      </div>
      <div className="flex gap-1.5">
        <button
          type="button"
          disabled={busy !== null || !agvId}
          onClick={async () => {
            if (!agvId) return;
            setBusy("resume");
            await callTool("/tools/resume_agv", { agv_id: agvId });
            setBusy(null);
          }}
          className="flex flex-1 items-center justify-center gap-1 rounded border border-emerald-500/60 bg-emerald-500/15 px-2 py-1 text-[10px] font-semibold text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
        >
          <Play className="h-3 w-3" /> {busy === "resume" ? "..." : "Resume"}
        </button>
        <button
          type="button"
          disabled={busy !== null || !agvId}
          onClick={async () => {
            if (!agvId) return;
            setBusy("complete");
            await callTool("/tools/complete_interrupted_task", { agv_id: agvId });
            setBusy(null);
          }}
          className="flex flex-1 items-center justify-center gap-1 rounded border border-rose-500/60 bg-rose-500/15 px-2 py-1 text-[10px] font-semibold text-rose-300 hover:bg-rose-500/25 disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
        >
          <XIcon className="h-3 w-3" /> {busy === "complete" ? "..." : "Close"}
        </button>
      </div>
    </div>
  );
}

function PendingRow({ task }: { task: PendingTask }) {
  if (task.interrupted) return <InterruptedRow task={task} />;
  const bundle = task as PendingTask & {
    _bundle_drops?: string[];
    _bundle_agv_id?: string | null;
    _bundle_count?: number;
    _bundle_stops?: TripStop[];
  };
  const drops = bundle._bundle_drops;
  const stops = bundle._bundle_stops;
  const isBundle = Array.isArray(drops) && drops.length > 1;
  const hasRoute = Array.isArray(stops) && stops.length > 1;
  return (
    <div className="flex w-full flex-col gap-1 rounded-lg border border-border bg-card px-3 py-2.5 text-left text-xs transition-colors">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-foreground truncate">
            {productLabel(task.product_id) || task.task_id}
          </div>
          <div className="mt-0.5 text-[10px] text-muted-foreground">
            AGV: <span className="font-mono font-semibold">{bundle._bundle_agv_id || "—"}</span>
            {isBundle && ` · ${bundle._bundle_count ?? drops!.length} bundled`}
          </div>
        </div>
        <Badge
          variant={PRIORITY_VARIANT[task.priority] ?? "outline"}
          className="capitalize text-[9px] px-1.5 py-0 shrink-0"
        >
          {task.priority}
        </Badge>
      </div>
      {hasRoute ? (
        <div className="flex flex-wrap items-center gap-1 text-[11px] text-muted-foreground">
          {stops.map((s, i) => (
            <span key={`${s.station_id}-${i}`} className="flex items-center gap-1">
              {i > 0 && <span className="text-foreground">→</span>}
              <span className={`rounded px-1.5 py-0.5 font-medium ${s.op === "pickup" ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300" : "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300"}`}>
                {stationName(s.station_id)}
              </span>
            </span>
          ))}
        </div>
      ) : (
        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <span className="rounded bg-muted px-1.5 py-0.5 font-medium">
            {stationName(task.pickup, task.stage_from)}
          </span>
          <span className="text-foreground">→</span>
          <span className="rounded bg-muted px-1.5 py-0.5 font-medium">
            {isBundle ? stationName(drops![drops!.length - 1]) : stationName(task.drop, task.stage_to)}
          </span>
        </div>
      )}
    </div>
  );
}

function AssignedRow({
  task,
  selected,
  onSelect,
}: {
  task: AssignedTask;
  selected: boolean;
  onSelect: (agvId: string, tripId: string) => void;
}) {
  const isBundle = task.bundled_tasks > 1;
  const pickups = task.stops?.filter((s) => s.op === "pickup") ?? [];
  const drops = task.stops?.filter((s) => s.op === "drop") ?? [];
  const firstPickup = isBundle && pickups.length > 0
    ? stationName(pickups[0].station_id)
    : stationName(task.pickup, task.stage_from);
  const lastDrop = isBundle && drops.length > 0
    ? stationName(drops[drops.length - 1].station_id)
    : stationName(task.drop, task.stage_to);
  return (
    <button
      type="button"
      onClick={() => task.agv_id && onSelect(task.agv_id, task.trip_id)}
      className={`flex w-full flex-col gap-1 rounded-lg border px-3 py-2.5 text-left text-xs transition-colors ${
        selected
          ? "border-primary bg-primary/10"
          : "border-border bg-card hover:bg-accent"
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-foreground truncate">
            {productLabel(task.product_id) || task.task_id}
          </div>
          <div className="mt-0.5 text-[10px] text-muted-foreground">
            AGV: <span className="font-mono font-semibold">{task.agv_id || "—"}</span>
            {isBundle && ` · ${task.bundled_tasks} bundled`}
          </div>
        </div>
        <Badge
          variant={PRIORITY_VARIANT[task.priority] ?? "outline"}
          className="capitalize text-[9px] px-1.5 py-0 shrink-0"
        >
          {task.priority}
        </Badge>
      </div>
      <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        <span className="rounded bg-muted px-1.5 py-0.5 font-medium">
          {firstPickup}
        </span>
        <span className="text-foreground">→</span>
        <span className="rounded bg-muted px-1.5 py-0.5 font-medium">
          {lastDrop}
        </span>
      </div>
    </button>
  );
}

function fmtTimeOnly(ts?: number): string {
  if (!ts) return "—";
  return new Date(ts * 1000).toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function isToday(ts?: number): boolean {
  if (!ts) return false;
  const d = new Date(ts * 1000);
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
}

function lifecycleBadge(task: CompletedTask) {
  if (task.was_interrupted && task.was_resumed) {
    return (
      <Badge className="gap-0.5 bg-amber-500/15 text-amber-300 border border-amber-500/40 text-[9px] px-1.5 py-0">
        <RefreshCw className="h-2.5 w-2.5" /> Resumed
      </Badge>
    );
  }
  if (task.was_interrupted && !task.was_resumed) {
    return (
      <Badge className="gap-0.5 bg-rose-500/15 text-rose-300 border border-rose-500/40 text-[9px] px-1.5 py-0">
        <Ban className="h-2.5 w-2.5" /> Closed early
      </Badge>
    );
  }
  return (
    <Badge className="gap-0.5 bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 text-[9px] px-1.5 py-0">
      <CheckCircle2 className="h-2.5 w-2.5" /> Clean
    </Badge>
  );
}

function CompletedDetailsModal({
  task,
  onClose,
}: {
  task: CompletedTask;
  onClose: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const lifecycle =
    task.was_interrupted && task.was_resumed
      ? { text: "Halted mid-route, then resumed and completed.", tone: "amber" }
      : task.was_interrupted
        ? { text: "Halted mid-route, then closed without resuming.", tone: "rose" }
        : { text: "Ran to completion without interruption.", tone: "emerald" };
  const toneCls =
    lifecycle.tone === "amber"
      ? "border-amber-500/40 bg-amber-500/10 text-amber-200"
      : lifecycle.tone === "rose"
        ? "border-rose-500/40 bg-rose-500/10 text-rose-200"
        : "border-emerald-500/40 bg-emerald-500/10 text-emerald-200";

  const dur = task.kpis?.duration ?? 0;
  const startedTs =
    task.created_ts && task.created_ts > 0
      ? task.created_ts
      : task.completed_ts && dur > 0
        ? task.completed_ts - dur
        : undefined;

  const headerTone =
    lifecycle.tone === "amber"
      ? "from-amber-500/30 to-amber-500/5"
      : lifecycle.tone === "rose"
        ? "from-rose-500/30 to-rose-500/5"
        : "from-emerald-500/30 to-emerald-500/5";

  return (
    <div
      className="fixed inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in"
      style={{ zIndex: 9999 }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md overflow-hidden rounded-2xl border border-border bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Gradient header */}
        <div
          className={`relative bg-gradient-to-br ${headerTone} px-5 py-4 border-b border-border`}
        >
          <button
            type="button"
            onClick={onClose}
            className="absolute right-3 top-3 rounded-full p-1 text-muted-foreground hover:bg-background/80 hover:text-foreground transition-colors"
            style={{ cursor: "pointer" }}
            aria-label="Close"
          >
            <XIcon className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-2">
            <div className="rounded-full bg-card/80 p-1.5 ring-1 ring-border">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
            </div>
            <div className="min-w-0">
              <div className="text-base font-bold tracking-tight truncate">
                {materialLabel(task.material_type)}
              </div>
              <div className="text-[11px] text-muted-foreground">
                {task.agv_id} · {productLabel(task.product_id)}
              </div>
            </div>
          </div>
        </div>

        <div className="px-5 py-4 space-y-4">
          {/* Lifecycle banner */}
          <div
            className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs ${toneCls}`}
          >
            {task.was_interrupted ? (
              <AlertTriangle className="h-4 w-4 shrink-0" />
            ) : (
              <CheckCircle2 className="h-4 w-4 shrink-0" />
            )}
            <span className="leading-tight">{lifecycle.text}</span>
          </div>

          {/* Trip Summary */}
          <div className="flex items-center gap-2 flex-wrap">
            {task.bundled > 1 && (
              <Badge className="gap-0.5 bg-blue-500/15 text-blue-300 border border-blue-500/40 text-[9px] px-1.5 py-0">
                <Package className="h-2.5 w-2.5" /> Bundled ({task.bundled} tasks)
              </Badge>
            )}
            {task.priority && (
              <Badge
                variant={PRIORITY_VARIANT[task.priority] ?? "outline"}
                className="capitalize text-[10px] px-2 py-0.5"
              >
                {task.priority} priority
              </Badge>
            )}
            {(() => {
              const totalUnits = task.stops?.reduce(
                (sum, s) => sum + (s.op === "pickup" && s.units ? s.units : 0),
                0,
              ) || task.units;
              return totalUnits != null && totalUnits > 0 ? (
                <span className="inline-flex items-center gap-1 rounded-md border border-border bg-muted/40 px-2 py-0.5 text-[11px]">
                  <Package className="h-3 w-3 text-muted-foreground" />
                  <span className="font-semibold text-foreground">{totalUnits}</span>
                  <span className="text-muted-foreground">{totalUnits === 1 ? "unit" : "units"}</span>
                </span>
              ) : null;
            })()}
          </div>

          {/* Stops detail */}
          {task.stops && task.stops.length > 0 ? (
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5 flex items-center gap-1">
                <Route className="h-3 w-3" /> Route ({task.stops.length} stops)
              </div>
              <div className="space-y-1">
                {task.stops.map((stop, i) => (
                  <div key={`${stop.station_id}-${stop.op}-${i}`} className="flex items-center gap-2 text-xs">
                    <div className={`h-2 w-2 rounded-full shrink-0 ${stop.op === "pickup" ? "bg-blue-400" : "bg-emerald-400"}`} />
                    <span className="font-semibold">{STATION_NAMES[stop.station_id] || fmtStation(stop.station_id)}</span>
                    <span className="text-muted-foreground capitalize text-[10px]">{stop.op === "pickup" ? "Load" : "Unload"}</span>
                    {stop.units != null && stop.units > 0 && (
                      <span className="text-muted-foreground text-[10px]">({stop.units} units)</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (task.pickup || task.drop) && (
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5 flex items-center gap-1">
                <Route className="h-3 w-3" /> Route
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="flex-1 rounded-md bg-muted px-3 py-1.5 text-center font-semibold">
                  {fmtStation(task.pickup ?? "—")}
                </span>
                <span className="text-muted-foreground">→</span>
                <span className="flex-1 rounded-md bg-muted px-3 py-1.5 text-center font-semibold">
                  {fmtStation(task.drop ?? "—")}
                </span>
              </div>
            </div>
          )}

          {/* KPIs */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg border border-border bg-muted/30 px-2 py-3 text-center">
              <Route className="mx-auto h-4 w-4 text-primary" />
              <div className="mt-1 text-lg font-bold leading-none">
                {(task.kpis?.distance ?? 0).toFixed(0)}
                <span className="ml-0.5 text-[10px] font-medium text-muted-foreground">
                  m
                </span>
              </div>
              <div className="mt-1 text-[9px] uppercase tracking-wide text-muted-foreground">
                Distance
              </div>
            </div>
            <div className="rounded-lg border border-border bg-muted/30 px-2 py-3 text-center">
              <Timer className="mx-auto h-4 w-4 text-primary" />
              <div className="mt-1 text-lg font-bold leading-none">
                {(task.kpis?.duration ?? 0).toFixed(0)}
                <span className="ml-0.5 text-[10px] font-medium text-muted-foreground">
                  s
                </span>
              </div>
              <div className="mt-1 text-[9px] uppercase tracking-wide text-muted-foreground">
                Duration
              </div>
            </div>
            <div className="rounded-lg border border-border bg-muted/30 px-2 py-3 text-center">
              <Package className="mx-auto h-4 w-4 text-primary" />
              <div className="mt-1 text-lg font-bold leading-none">
                {task.kpis?.stops ?? 0}
              </div>
              <div className="mt-1 text-[9px] uppercase tracking-wide text-muted-foreground">
                Stops
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="rounded-lg border border-border bg-muted/20 px-3 py-2.5">
            <div className="text-[9px] uppercase tracking-wide text-muted-foreground mb-2">
              Timeline
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-primary" />
                  <span className="text-muted-foreground">Started</span>
                </div>
                <span className="font-mono font-semibold">
                  {fmtTimeOnly(startedTs)}
                </span>
              </div>
              {task.was_interrupted && (
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-rose-500" />
                    <span className="text-muted-foreground">Interrupted</span>
                  </div>
                  <span className="font-mono font-semibold text-rose-300">
                    halted mid-route
                  </span>
                </div>
              )}
              {task.was_resumed && (
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-amber-500" />
                    <span className="text-muted-foreground">Resumed</span>
                  </div>
                  <span className="font-mono font-semibold text-amber-300">
                    trip continued
                  </span>
                </div>
              )}
              {task.was_interrupted && !task.was_resumed && (
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-rose-500" />
                    <span className="text-muted-foreground">Closed</span>
                  </div>
                  <span className="font-mono font-semibold text-rose-300">
                    without resuming
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-emerald-500" />
                  <span className="text-muted-foreground">Completed</span>
                </div>
                <span className="font-mono font-semibold">
                  {fmtTimeOnly(task.completed_ts)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CompletedRow({ task }: { task: CompletedTask }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center justify-between gap-2 rounded-lg border border-border bg-card px-3 py-2 text-left text-xs hover:border-primary/40 hover:bg-accent/40 transition-colors"
        style={{ cursor: "pointer" }}
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-foreground truncate">
              {task.agv_id} · {materialLabel(task.material_type)}
            </span>
            {task.was_interrupted && (
              <AlertTriangle className="h-3 w-3 shrink-0 text-amber-500" />
            )}
          </div>
          <div className="text-[10px] text-muted-foreground">
            {(task.kpis?.distance ?? 0).toFixed(1)}m ·{" "}
            {(task.kpis?.duration ?? 0).toFixed(0)}s ·{" "}
            {task.kpis?.stops ?? 0} stops
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {task.was_interrupted && lifecycleBadge(task)}
          {task.bundled > 1 && (
            <Badge className="gap-0.5 bg-blue-500/15 text-blue-300 border border-blue-500/40 text-[9px] px-1.5 py-0">
              {task.bundled}x
            </Badge>
          )}
        </div>
      </button>
      {open && <CompletedDetailsModal task={task} onClose={() => setOpen(false)} />}
    </>
  );
}

function Section({
  icon,
  title,
  count,
  children,
  defaultOpen = true,
}: {
  icon: React.ReactNode;
  title: string;
  count: number;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="mb-2 flex w-full items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
      >
        {open ? (
          <ChevronDown className="h-3 w-3" />
        ) : (
          <ChevronRight className="h-3 w-3" />
        )}
        {icon}
        <span>{title}</span>
        <span className="ml-auto rounded-full bg-muted px-2 py-0.5 text-[10px] font-bold text-foreground">
          {count}
        </span>
      </button>
      {open && <div className="space-y-2">{children}</div>}
    </div>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="rounded-lg border border-dashed border-border px-3 py-4 text-center text-[11px] text-muted-foreground">
      {label}
    </div>
  );
}

export function TaskSchedulerPanel() {
  const pending = useTaskState((s) => s.pending);
  const assigned = useTaskState((s) => s.assigned);
  const completedAll = useTaskState((s) => s.completed);
  const completed = useMemo(
    () =>
      completedAll
        .filter((c) => isToday(c.completed_ts))
        .sort((a, b) => (b.completed_ts ?? 0) - (a.completed_ts ?? 0)),
    [completedAll],
  );
  const tripsByAgv = useTaskState((s) => s.tripsByAgv);
  const selectedAgvId = useTaskState((s) => s.selectedAgvId);
  const selectedTripId = useTaskState((s) => s.selectedTripId);
  const selectTrip = useTaskState((s) => s.selectTrip);

  const pendingList = useMemo(
    () => {
      // Roll up sibling tasks that share the same trip_id (e.g. a chatbot
      // multi_drop_trip emits N task:created events for one bundled trip).
      // Show one representative row per trip_id; if trip_id is missing fall
      // back to batch_id. Standalone tasks pass through as-is.
      const all = Array.from(pending.values());
      const groupKey = (t: PendingTask) =>
        t.trip_id || (t.batch_id ? `b:${t.batch_id}` : "");

      // Build trip_id -> agv_id index from tripsByAgv (populated by
      // trip:requested / task:assigned), so bundled pending rows that have
      // not yet been individually assigned can still surface their AGV.
      const agvByTrip = new Map<string, string>();
      for (const t of tripsByAgv.values()) {
        if (t.trip_id && t.agv_id) agvByTrip.set(t.trip_id, t.agv_id);
      }
      // Fallback: tripToAgv covers queued trips that aren't in tripsByAgv
      // (because an earlier trip on the same AGV is still active).
      for (const [tripId, info] of getTripAgvIndex()) {
        if (!agvByTrip.has(tripId) && info.agv_id) {
          agvByTrip.set(tripId, info.agv_id);
        }
      }

      const groupDrops = new Map<string, string[]>();
      const groupUnits = new Map<string, number>();
      const groupCount = new Map<string, number>();
      for (const t of all) {
        const k = groupKey(t);
        if (!k) continue;
        const arr = groupDrops.get(k) ?? [];
        if (t.drop && !arr.includes(t.drop)) arr.push(t.drop);
        groupDrops.set(k, arr);
        groupUnits.set(k, (groupUnits.get(k) ?? 0) + (t.units ?? 0));
        groupCount.set(k, (groupCount.get(k) ?? 0) + 1);
      }

      // Build trip_id -> stops index from tripsByAgv so pending bundles
      // can show the actual planned route sequence.
      const stopsByTrip = new Map<string, TripStop[]>();
      for (const t of tripsByAgv.values()) {
        if (t.trip_id && t.stops) stopsByTrip.set(t.trip_id, t.stops);
      }

      const seen = new Set<string>();
      const rolled: PendingTask[] = [];
      for (const t of all) {
        const k = groupKey(t);
        const merged = { ...t } as PendingTask & {
          _bundle_drops?: string[];
          _bundle_units?: number;
          _bundle_agv_id?: string | null;
          _bundle_count?: number;
          _bundle_stops?: TripStop[];
        };
        // Always surface the AGV (when known via trip:requested) so the
        // pending card mirrors the in-transit (AssignedRow) layout.
        // Fallback to reserved_agv_id stamped on the task itself (covers
        // the case where multiple pending tasks share one AGV).
        if (t.trip_id) {
          merged._bundle_agv_id = agvByTrip.get(t.trip_id) ?? null;
          merged._bundle_stops = stopsByTrip.get(t.trip_id);
        }
        if (!merged._bundle_agv_id && t.reserved_agv_id) {
          merged._bundle_agv_id = t.reserved_agv_id;
        }
        if (k) {
          if (seen.has(k)) continue;
          seen.add(k);
          const drops = groupDrops.get(k) ?? [];
          if (drops.length > 1) {
            merged._bundle_drops = drops;
            merged._bundle_units = groupUnits.get(k) ?? 0;
            merged._bundle_count = groupCount.get(k) ?? drops.length;
          }
        }
        rolled.push(merged);
      }

      return rolled.sort((a, b) => {
        if (a.source === "chatbot" && b.source !== "chatbot") return -1;
        if (b.source === "chatbot" && a.source !== "chatbot") return 1;
        const priOrder: Record<string, number> = { high: 0, normal: 1, low: 2 };
        const pa = priOrder[a.priority] ?? 1;
        const pb = priOrder[b.priority] ?? 1;
        if (pa !== pb) return pa - pb;
        return b.created_ts - a.created_ts;
      });
    },
    [pending, tripsByAgv],
  );

  const assignedList = useMemo(
    () =>
      Array.from(assigned.values()).sort(
        (a, b) => b.assigned_ts - a.assigned_ts,
      ),
    [assigned],
  );

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="shrink-0 px-2 pb-2 flex items-center gap-1.5">
        <Badge variant="outline" className="gap-1 text-[10px]">
          {pendingList.length} queued
        </Badge>
        <Badge variant="outline" className="gap-1 text-[10px]">
          {assignedList.length} active
        </Badge>
        <Badge variant="outline" className="gap-1 text-[10px]">
          {completed.length} done
        </Badge>
      </div>
      <div
        className="flex-1 min-h-0 px-2 pb-2 space-y-4"
        style={{ overflowY: "scroll", scrollbarGutter: "stable" }}
      >
        <Section
          icon={<Inbox className="h-3.5 w-3.5" />}
          title="Pending"
          count={pendingList.length}
        >
          {pendingList.length === 0 ? (
            <Empty label="No pending tasks" />
          ) : (
            pendingList.map((t) => <PendingRow key={t.task_id} task={t} />)
          )}
        </Section>

        <Section
          icon={<ListChecks className="h-3.5 w-3.5" />}
          title="In Transit"
          count={assignedList.length}
        >
          {assignedList.length === 0 ? (
            <Empty label="No active trips" />
          ) : (
            assignedList.map((t) => (
              <AssignedRow
                key={t.trip_id}
                task={t}
                selected={
                  selectedAgvId === t.agv_id &&
                  (selectedTripId == null || selectedTripId === t.trip_id)
                }
                onSelect={selectTrip}
              />
            ))
          )}
        </Section>

        <Section
          icon={<CheckCircle2 className="h-3.5 w-3.5" />}
          title="Completed"
          count={completed.length}
          defaultOpen={false}
        >
          {completed.length === 0 ? (
            <Empty label="No completed trips yet" />
          ) : (
            completed.map((t, i) => <CompletedRow key={`${t.trip_id}-${i}`} task={t} />)
          )}
        </Section>
      </div>
    </div>
  );
}

export default TaskSchedulerPanel;
