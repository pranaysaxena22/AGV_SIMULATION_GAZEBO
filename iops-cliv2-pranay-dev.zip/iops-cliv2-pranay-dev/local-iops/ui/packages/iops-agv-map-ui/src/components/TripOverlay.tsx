import { useTaskState } from "../hooks/useTaskState.js";
import { useFleetState } from "../hooks/useFleetState.js";

export function TripOverlay() {
  const selectedAgvId = useTaskState((s) => s.selectedAgvId);
  const selectedTripId = useTaskState((s) => s.selectedTripId);
  const tripsByAgv = useTaskState((s) => s.tripsByAgv);
  const assigned = useTaskState((s) => s.assigned);
  const fleet = useFleetState((s) => s.fleet);
  const visibleAgvIds = useFleetState((s) => s.visibleAgvIds);

  if (!selectedAgvId) return null;
  if (visibleAgvIds !== null && !visibleAgvIds.has(selectedAgvId)) return null;
  // Prefer the explicitly clicked trip (covers queued trips on an AGV that's
  // currently running a different trip); fall back to the live trip.
  const live = tripsByAgv.get(selectedAgvId);
  const trip =
    selectedTripId && selectedTripId !== live?.trip_id
      ? assigned.get(selectedTripId) ?? live
      : live;
  if (!trip || trip.stops.length === 0) return null;
  const agv = fleet.get(selectedAgvId);
  if (!agv) return null;

  const points = [
    { x: agv.x, y: agv.y },
    ...trip.stops.map((s) => ({ x: s.x, y: s.y })),
  ];
  const pts = points.map((p) => `${p.x},${p.y}`).join(" ");

  return (
    <g className="trip-overlay">
      <polyline points={pts} className="trip-overlay-line" />
      {trip.stops.map((s, i) => (
        <g key={`${s.station_id}-${i}`}>
          <circle
            cx={s.x}
            cy={s.y}
            r={1.4}
            className={`trip-overlay-stop trip-overlay-stop-${s.op}`}
          />
          <text
            x={s.x}
            y={s.y}
            textAnchor="middle"
            dominantBaseline="central"
            className="trip-overlay-badge"
            transform={`translate(0,${2 * s.y}) scale(1,-1)`}
          >
            {i + 1}
          </text>
        </g>
      ))}
    </g>
  );
}

export default TripOverlay;
