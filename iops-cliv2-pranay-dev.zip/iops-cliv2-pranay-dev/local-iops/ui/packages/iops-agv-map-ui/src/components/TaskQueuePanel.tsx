import { useMemo, useState } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Badge,
} from "@smaf/iops-shared-ui";
import { Inbox, ListChecks, CheckCircle2, Play, X as XIcon } from "lucide-react";
import { useTaskState } from "../hooks/useTaskState.js";
import type {
  AssignedTask,
  CompletedTask,
  PendingTask,
  TaskPriority,
} from "../hooks/useTaskState.js";

const PRIORITY_VARIANT: Record<TaskPriority, "default" | "secondary" | "destructive"> = {
  low: "secondary",
  normal: "default",
  high: "destructive",
};

function shortId(s: string | null | undefined, n = 6): string {
  if (!s) return "—";
  return s.length > n ? s.slice(-n) : s;
}

function fmtStage(s: string | null | undefined): string {
  if (!s) return "";
  return s.replace(/_/g, " ");
}

function shortProduct(p: string | null | undefined): string {
  if (!p) return "";
  return p.replace(/^pcb_/, "");
}

function StageChip({ task }: { task: PendingTask }) {
  if (!task.stage_from && !task.stage_to) return null;
  return (
    <div className="mt-0.5 flex items-center gap-1 text-[10px] text-muted-foreground">
      <span className="rounded-sm bg-muted px-1 py-0 font-mono">
        {fmtStage(task.stage_from) || "?"}
      </span>
      <span>→</span>
      <span className="rounded-sm bg-muted px-1 py-0 font-mono">
        {fmtStage(task.stage_to) || "?"}
      </span>
    </div>
  );
}

function ProductLine({ task }: { task: PendingTask }) {
  if (!task.product_id && !task.batch_id) return null;
  return (
    <div className="flex flex-wrap items-center gap-1 text-[10px] text-muted-foreground">
      {task.product_id && (
        <span className="rounded-sm bg-primary/10 px-1 py-0 font-semibold uppercase text-primary">
          {shortProduct(task.product_id)}
        </span>
      )}
      {task.batch_id && (
        <span className="font-mono">{shortId(task.batch_id, 8)}</span>
      )}
      {task.units != null && <span>· {task.units}u</span>}
    </div>
  );
}

function SlaBar({ task }: { task: PendingTask }) {
  if (!task.sla || task.sla <= 0) return null;
  const elapsed = Math.max(0, Date.now() / 1000 - task.created_ts);
  const pct = Math.min(100, Math.round((elapsed / task.sla) * 100));
  const tone =
    pct >= 90 ? "bg-destructive" : pct >= 60 ? "bg-amber-500" : "bg-primary";
  return (
    <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-muted">
      <div className={`h-full ${tone}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function getToolsBaseUrl(): string {
  if (typeof window === "undefined") return "";
  const w = window as unknown as { __AGV_TOOLS_URL?: string };
  if (w.__AGV_TOOLS_URL) return w.__AGV_TOOLS_URL;
  // Same-origin nginx proxy — works under HTTPS without mixed-content blocks.
  return "/agv-tools";
}

async function callTool(path: string, body?: unknown): Promise<void> {
  const url = `${getToolsBaseUrl()}${path}`;
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body ?? {}),
    });
    if (!r.ok) {
      console.warn("callTool failed", path, r.status, await r.text());
    }
  } catch (e) {
    console.warn("callTool error", path, e);
  }
}

function InterruptedRow({ task }: { task: PendingTask }) {
  const agvId = task.interrupted_agv_id ?? "";
  const [busy, setBusy] = useState<"resume" | "complete" | null>(null);
  return (
    <div className="flex flex-col gap-1 rounded-md border border-amber-500/50 bg-amber-500/10 px-2.5 py-1.5 text-[11px]">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="font-mono font-semibold truncate">
            {shortId(task.task_id)} · {agvId}
          </div>
          <ProductLine task={task} />
          <div className="text-muted-foreground">
            Interrupted · {task.remaining_stops_count ?? 0} stops remaining
          </div>
        </div>
        <Badge variant="destructive" className="text-[9px] px-1.5 py-0">
          stopped
        </Badge>
      </div>
      <div className="flex gap-1.5">
        <button
          type="button"
          disabled={busy !== null}
          onClick={async () => {
            if (!agvId) return;
            setBusy("resume");
            await callTool("/tools/resume_agv", { agv_id: agvId });
            setBusy(null);
          }}
          className="flex flex-1 items-center justify-center gap-1 rounded border border-emerald-500/60 bg-emerald-500/15 px-2 py-1 text-[10px] font-semibold text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-50"
        >
          <Play className="h-3 w-3" /> {busy === "resume" ? "..." : "Resume"}
        </button>
        <button
          type="button"
          disabled={busy !== null}
          onClick={async () => {
            if (!agvId) return;
            setBusy("complete");
            await callTool("/tools/complete_interrupted_task", { agv_id: agvId });
            setBusy(null);
          }}
          className="flex flex-1 items-center justify-center gap-1 rounded border border-rose-500/60 bg-rose-500/15 px-2 py-1 text-[10px] font-semibold text-rose-300 hover:bg-rose-500/25 disabled:opacity-50"
        >
          <XIcon className="h-3 w-3" /> {busy === "complete" ? "..." : "Complete"}
        </button>
      </div>
    </div>
  );
}

function PendingRow({ task }: { task: PendingTask }) {
  if (task.interrupted) return <InterruptedRow task={task} />;
  const ageS = Math.max(0, Math.round(Date.now() / 1000 - task.created_ts));
  const bundle = task as PendingTask & {
    _bundle_drops?: string[];
    _bundle_units?: number;
  };
  const drops = bundle._bundle_drops;
  const isBundle = Array.isArray(drops) && drops.length > 1;
  return (
    <div className="flex flex-col gap-0.5 rounded-md border border-border bg-card px-2.5 py-1.5 text-[11px]">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="font-mono font-semibold truncate">
            {shortId(task.task_id)}
            {isBundle && (
              <span className="ml-1 text-muted-foreground">
                · {drops.length} drops
              </span>
            )}
          </div>
          <ProductLine task={task} />
          <div className="text-muted-foreground">
            {task.pickup} → {isBundle ? drops.join(", ") : task.drop}
          </div>
          <StageChip task={task} />
        </div>
        <div className="flex shrink-0 flex-col items-end gap-0.5">
          <Badge
            variant={PRIORITY_VARIANT[task.priority] ?? "outline"}
            className="capitalize text-[9px] px-1.5 py-0"
          >
            {task.priority}
          </Badge>
          <span className="text-[10px] text-muted-foreground">{ageS}s</span>
        </div>
      </div>
      <SlaBar task={task} />
    </div>
  );
}

function AssignedRow({
  task,
  selected,
  onSelect,
}: {
  task: AssignedTask;
  selected: boolean;
  onSelect: (agvId: string, tripId: string) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => task.agv_id && onSelect(task.agv_id, task.trip_id)}
      className={`flex w-full items-center justify-between gap-2 rounded-md border px-2.5 py-1.5 text-left text-[11px] transition-colors ${
        selected
          ? "border-primary bg-primary/10"
          : "border-border bg-card hover:bg-accent"
      }`}
    >
      <div className="min-w-0 flex-1">
        <div className="font-mono font-semibold truncate">
          {shortId(task.task_id)} · {task.agv_id || "?"}
        </div>
        <ProductLine task={task} />
        <div className="text-muted-foreground">
          {task.stops.length} stops · {task.pickup} → {task.drop}
        </div>
        <StageChip task={task} />
      </div>
      <div className="flex shrink-0 flex-col items-end gap-0.5">
        <Badge
          variant={PRIORITY_VARIANT[task.priority] ?? "outline"}
          className="capitalize text-[9px] px-1.5 py-0"
        >
          {task.priority}
        </Badge>
        {task.bundled_tasks > 1 && (
          <Badge variant="secondary" className="text-[9px] px-1.5 py-0">
            {task.bundled_tasks} bundled
          </Badge>
        )}
      </div>
    </button>
  );
}

function CompletedRow({ task }: { task: CompletedTask }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-card px-2.5 py-1.5 text-[11px]">
      <div className="min-w-0 flex-1">
        <div className="font-mono font-semibold truncate">
          {shortId(task.task_id ?? task.trip_id)} · {task.agv_id}
        </div>
        <div className="text-muted-foreground">
          {(task.kpis?.distance ?? 0).toFixed(1)} m ·{" "}
          {(task.kpis?.duration ?? 0).toFixed(1)} s · {task.kpis?.stops ?? 0}{" "}
          stops
          {task.bundled > 1 && ` · ${task.bundled} tasks`}
        </div>
      </div>
    </div>
  );
}

export function TaskQueuePanel() {
  const pending = useTaskState((s) => s.pending);
  const assigned = useTaskState((s) => s.assigned);
  const completed = useTaskState((s) => s.completed);
  const selectedAgvId = useTaskState((s) => s.selectedAgvId);
  const selectedTripId = useTaskState((s) => s.selectedTripId);
  const selectTrip = useTaskState((s) => s.selectTrip);

  const pendingList = useMemo(
    () => {
      // Roll up sibling tasks that share the same trip_id (e.g. a chatbot
      // multi_drop_trip / multi_pair_trip emits N task:created events for
      // one bundled trip). Show one representative row per trip_id; if
      // trip_id is missing fall back to batch_id (provisional defer events
      // historically lacked trip_id). Standalone tasks pass through as-is.
      const all = Array.from(pending.values());
      // First pass: gather sibling drops + total units per trip_id / batch_id
      // so the rolled-up row can surface "S04 -> S05, S26, S21 (3 drops)"
      // instead of a single arbitrary drop.
      const groupDrops = new Map<string, string[]>();
      const groupUnits = new Map<string, number>();
      const groupKey = (t: PendingTask) =>
        t.trip_id || (t.batch_id ? `b:${t.batch_id}` : "");
      for (const t of all) {
        const k = groupKey(t);
        if (!k) continue;
        const arr = groupDrops.get(k) ?? [];
        if (t.drop && !arr.includes(t.drop)) arr.push(t.drop);
        groupDrops.set(k, arr);
        groupUnits.set(k, (groupUnits.get(k) ?? 0) + (t.units ?? 0));
      }
      const seen = new Set<string>();
      const rolled: typeof all = [];
      for (const t of all) {
        const k = groupKey(t);
        if (k) {
          if (seen.has(k)) continue;
          seen.add(k);
          const drops = groupDrops.get(k) ?? [];
          if (drops.length > 1) {
            // Inject sibling drop list + bundle size as transient view-only
            // fields; PendingRow reads them to render the rolled-up label.
            (t as PendingTask & {
              _bundle_drops?: string[];
              _bundle_units?: number;
            })._bundle_drops = drops;
            (t as PendingTask & {
              _bundle_drops?: string[];
              _bundle_units?: number;
            })._bundle_units = groupUnits.get(k) ?? 0;
          }
        }
        rolled.push(t);
      }
      return rolled.sort((a, b) => {
        if (a.interrupted && !b.interrupted) return -1;
        if (!a.interrupted && b.interrupted) return 1;
        return b.created_ts - a.created_ts;
      });
    },
    [pending],
  );
  const completedList = useMemo(
    () =>
      completed.filter((t) => {
        if (t.was_interrupted && !t.was_resumed) return false;
        const hasTask =
          !!t.task_id || (Array.isArray(t.task_ids) && t.task_ids.length > 0);
        return hasTask;
      }),
    [completed],
  );
  const assignedList = useMemo(
    () =>
      Array.from(assigned.values()).sort(
        (a, b) => b.assigned_ts - a.assigned_ts,
      ),
    [assigned],
  );

  return (
    <Card className="border-border flex-1 basis-0 min-h-0 flex flex-col">
      <CardHeader className="py-2.5 px-4 shrink-0">
        <CardTitle className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Task Queue
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 overflow-y-auto px-3 pb-3 space-y-3">
        <Section
          icon={<Inbox className="h-3 w-3" />}
          title="Pending"
          count={pendingList.length}
        >
          {pendingList.length === 0 ? (
            <Empty label="No pending tasks" />
          ) : (
            pendingList.map((t) => <PendingRow key={t.task_id} task={t} />)
          )}
        </Section>

        <Section
          icon={<ListChecks className="h-3 w-3" />}
          title="Assigned"
          count={assignedList.length}
        >
          {assignedList.length === 0 ? (
            <Empty label="No active trips" />
          ) : (
            assignedList.map((t) => (
              <AssignedRow
                key={t.trip_id}
                task={t}
                selected={
                  selectedAgvId === t.agv_id &&
                  (selectedTripId == null || selectedTripId === t.trip_id)
                }
                onSelect={selectTrip}
              />
            ))
          )}
        </Section>

        <Section
          icon={<CheckCircle2 className="h-3 w-3" />}
          title="Completed"
          count={completedList.length}
        >
          {completedList.length === 0 ? (
            <Empty label="No completed trips yet" />
          ) : (
            completedList.map((t) => <CompletedRow key={t.trip_id} task={t} />)
          )}
        </Section>
      </CardContent>
    </Card>
  );
}

function Section({
  icon,
  title,
  count,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  count: number;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {icon}
        <span>{title}</span>
        <span className="ml-auto rounded bg-muted px-1.5 py-0.5 text-foreground">
          {count}
        </span>
      </div>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="rounded-md border border-dashed border-border px-2 py-2 text-center text-[10px] text-muted-foreground">
      {label}
    </div>
  );
}

export default TaskQueuePanel;
