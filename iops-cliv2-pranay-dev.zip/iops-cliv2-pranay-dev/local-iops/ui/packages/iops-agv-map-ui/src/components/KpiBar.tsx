import { useMemo } from "react";
import { Badge } from "@smaf/iops-shared-ui";
import { Percent, Timer, Wifi, WifiOff } from "lucide-react";
import { useFleetState } from "../hooks/useFleetState.js";
import { useTaskState } from "../hooks/useTaskState.js";

export function KpiBar() {
  const connected = useFleetState((s) => s.connected);
  const completed = useTaskState((s) => s.completed);

  const k = useMemo(() => {
    const totalTrips = completed.length;
    const totalBundled = completed.reduce((s, c) => s + (c.bundled || 1), 0);
    const optimizationPct =
      totalBundled > 0
        ? ((totalBundled - totalTrips) / totalBundled) * 100
        : 0;

    let savedSeconds = 0;
    for (const c of completed) {
      if (c.bundled > 1) {
        savedSeconds += c.kpis.duration * ((c.bundled - 1) / c.bundled);
      }
    }

    const savedDisplay =
      savedSeconds >= 60
        ? `${(savedSeconds / 60).toFixed(1)}m`
        : `${savedSeconds.toFixed(0)}s`;

    return { optimizationPct, savedDisplay };
  }, [completed]);

  return (
    <div className="flex items-center gap-2 flex-wrap text-[10px] font-semibold">
      <Badge
        variant={connected ? "default" : "outline"}
        className="gap-1"
      >
        {connected ? (
          <Wifi className="h-3 w-3" />
        ) : (
          <WifiOff className="h-3 w-3" />
        )}
        {connected ? "AGV live" : "AGV offline"}
      </Badge>
      <Badge variant="outline" className="gap-1">
        <Percent className="h-3 w-3" />
        {k.optimizationPct.toFixed(1)}% bundled
      </Badge>
      <Badge variant="outline" className="gap-1">
        <Timer className="h-3 w-3" />
        {k.savedDisplay} saved
      </Badge>
    </div>
  );
}
