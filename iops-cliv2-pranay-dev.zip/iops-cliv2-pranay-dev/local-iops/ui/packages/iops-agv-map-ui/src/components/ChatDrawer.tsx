import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Bot, Home, Mic, MicOff, MessageSquare, Send, Volume2, VolumeX, X, Wrench, Globe } from "lucide-react";
import { useVoiceInput, speak, stopSpeaking } from "../hooks/useVoiceInput.js";
import floor from "../data/poc-floor.json" with { type: "json" };

const STATION_LABEL: Record<string, string> = (() => {
  const map: Record<string, string> = {};
  for (const s of (floor as any).stations || []) {
    if (s.id && s.name) map[s.id] = `${s.id} (${s.name})`;
  }
  return map;
})();

function labelForChoice(opt: string): string {
  if (STATION_LABEL[opt]) return STATION_LABEL[opt];
  return opt.replace(/_/g, " ");
}

function resolveChatUrl(): string {
  if (typeof window === "undefined") return "/agv-chat/chat";
  const override = (window as any).__AGV_CHAT_URL;
  if (override) return override;
  return "/agv-chat/chat";
}
const CHAT_URL = resolveChatUrl();

interface ToolCall { name: string; args: Record<string, unknown>; }
interface ChatTurn {
  role: "user" | "assistant";
  text: string;
  toolCalls?: ToolCall[];
  pending?: boolean;
  error?: string;
  choices?: { field: string; options: string[] };
}

const CHOICES_RE = /\[CHOICES:([a-z_]+)=([^\]]+)\]/i;

function renderInline(text: string): React.ReactNode[] {
  // Order: code (`x`), bold (**x**), italic (*x* or _x_)
  const parts: React.ReactNode[] = [];
  const re = /(`[^`]+`|\*\*[^*]+\*\*|\*[^*\n]+\*|_[^_\n]+_)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let key = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("`")) {
      parts.push(
        <code
          key={`c${key++}`}
          style={{
            fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
            background: "rgba(148,163,184,0.18)",
            padding: "1px 5px",
            borderRadius: 4,
            fontSize: "0.92em",
          }}
        >
          {tok.slice(1, -1)}
        </code>,
      );
    } else if (tok.startsWith("**")) {
      parts.push(
        <strong key={`b${key++}`} style={{ fontWeight: 600, color: "var(--color-primary, #67e8f9)" }}>
          {tok.slice(2, -2)}
        </strong>,
      );
    } else {
      parts.push(
        <em key={`i${key++}`} style={{ fontStyle: "italic", opacity: 0.9 }}>
          {tok.slice(1, -1)}
        </em>,
      );
    }
    last = m.index + tok.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

function renderListItem(raw: string): React.ReactNode {
  // Highlight "Label: value" inside list items so AGV ids, stations etc. pop.
  const kv = /^([A-Za-z0-9 _\-/]{1,28}?)\s*[:—-]\s+(.+)$/.exec(raw);
  if (kv) {
    return (
      <>
        <span style={{ fontWeight: 600, color: "var(--color-primary, #67e8f9)" }}>
          {kv[1]}
        </span>
        <span style={{ opacity: 0.6, margin: "0 6px" }}>·</span>
        <span>{renderInline(kv[2])}</span>
      </>
    );
  }
  return <>{renderInline(raw)}</>;
}

const RECOMMENDATION_TONE: Record<string, { bg: string; fg: string; border: string; label: string }> = {
  proceed: { bg: "rgba(34,197,94,0.15)", fg: "#86efac", border: "rgba(34,197,94,0.5)", label: "Proceed" },
  proceed_with_note: { bg: "rgba(234,179,8,0.15)", fg: "#fde68a", border: "rgba(234,179,8,0.5)", label: "Proceed with note" },
  confirm: { bg: "rgba(234,179,8,0.18)", fg: "#fcd34d", border: "rgba(234,179,8,0.55)", label: "Confirm" },
  defer: { bg: "rgba(59,130,246,0.18)", fg: "#93c5fd", border: "rgba(59,130,246,0.55)", label: "Defer" },
  block: { bg: "rgba(244,63,94,0.18)", fg: "#fca5a5", border: "rgba(244,63,94,0.55)", label: "Block" },
};

function PreflightCard({ body }: { body: string }) {
  const lines = body.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const fields: { label: string; value: string }[] = [];
  let recommendation: string | null = null;
  let bullet: { kind: "ok" | "conflict" | "deadlock" | "forecast" | "note"; text: string } | null = null;

  for (const ln of lines) {
    if (/^all clear\.?$/i.test(ln)) {
      bullet = { kind: "ok", text: "All clear" };
      continue;
    }
    const cf = /^conflicts?:\s*(.+)$/i.exec(ln);
    if (cf) { bullet = { kind: "conflict", text: cf[1] }; continue; }
    const dl = /^deadlock(?: risk)?:\s*(.+)$/i.exec(ln);
    if (dl) { bullet = { kind: "deadlock", text: dl[1] }; continue; }
    const fc = /^forecast:\s*(.+)$/i.exec(ln);
    if (fc) { bullet = { kind: "forecast", text: fc[1] }; continue; }
    const note = /^note:\s*(.+)$/i.exec(ln);
    if (note) { bullet = { kind: "note", text: note[1] }; continue; }
    const rec = /^recommendation:\s*(.+)$/i.exec(ln);
    if (rec) { recommendation = rec[1].trim().toLowerCase(); continue; }
    const kv = /^([A-Za-z][A-Za-z0-9 _\-/]{0,40}?):\s+(.+)$/.exec(ln);
    if (kv) { fields.push({ label: kv[1], value: kv[2] }); continue; }
  }

  const tone = recommendation ? RECOMMENDATION_TONE[recommendation] ?? null : null;
  const bulletTone =
    bullet?.kind === "ok"
      ? { bg: "rgba(34,197,94,0.12)", fg: "#86efac", border: "rgba(34,197,94,0.4)" }
      : bullet?.kind === "note"
      ? { bg: "rgba(59,130,246,0.12)", fg: "#93c5fd", border: "rgba(59,130,246,0.4)" }
      : { bg: "rgba(244,63,94,0.12)", fg: "#fca5a5", border: "rgba(244,63,94,0.4)" };

  return (
    <div
      style={{
        margin: "6px 0",
        border: "1px solid rgba(6,182,212,0.35)",
        borderRadius: 8,
        background: "linear-gradient(180deg, rgba(6,182,212,0.08), rgba(6,182,212,0.02))",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          padding: "6px 10px",
          background: "rgba(6,182,212,0.18)",
          fontSize: 10,
          fontWeight: 700,
          letterSpacing: 0.5,
          textTransform: "uppercase",
          color: "var(--color-primary, #67e8f9)",
        }}
      >
        <span>✈</span>
        <span>Pre-flight check</span>
      </div>
      <div style={{ padding: "8px 10px", display: "flex", flexDirection: "column", gap: 6 }}>
        {fields.length > 0 && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "max-content 1fr",
              gap: "3px 10px",
              fontSize: 11,
            }}
          >
            {fields.map((f, idx) => (
              <div key={idx} style={{ display: "contents" }}>
                <div
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    letterSpacing: 0.3,
                    textTransform: "uppercase",
                    color: "var(--color-primary, #67e8f9)",
                    opacity: 0.85,
                    whiteSpace: "nowrap",
                  }}
                >
                  {f.label}
                </div>
                <div>{renderInline(f.value)}</div>
              </div>
            ))}
          </div>
        )}
        {bullet && (
          <div
            style={{
              padding: "6px 8px",
              borderRadius: 6,
              background: bulletTone.bg,
              border: `1px solid ${bulletTone.border}`,
              color: bulletTone.fg,
              fontSize: 11,
              fontWeight: 500,
            }}
          >
            {bullet.kind === "ok" ? "✓ " : "⚠ "}
            {bullet.kind !== "ok" && (
              <span style={{ fontWeight: 700, marginRight: 4, textTransform: "capitalize" }}>
                {bullet.kind}:
              </span>
            )}
            {renderInline(bullet.text)}
          </div>
        )}
        {tone && (
          <div
            style={{
              alignSelf: "flex-start",
              padding: "3px 10px",
              borderRadius: 999,
              background: tone.bg,
              border: `1px solid ${tone.border}`,
              color: tone.fg,
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: 0.4,
              textTransform: "uppercase",
            }}
          >
            {tone.label}
          </div>
        )}
      </div>
    </div>
  );
}

const INTERNAL_TOOL_NAMES = [
  "multi_drop_trip",
  "send_agv_to",
  "recall_agv",
  "recall_low_battery",
  "get_fleet_status",
  "analyze_dispatch",
  "complete_interrupted_task",
  "resume_agv",
  "pause_agv",
  "emergency_stop",
  "reroute",
];

function sanitizeToolMentions(text: string): string {
  let out = text;
  // Drop lines that are essentially "Calling tool: foo" or similar plumbing.
  out = out
    .split(/\r?\n/)
    .filter((ln) => {
      const t = ln.trim().toLowerCase();
      if (!t) return true;
      if (
        /^(calling|invoking|running|using|executing)\s+(the\s+)?(tool|function)\b/.test(t) ||
        /^tool\s*(call|invocation)\s*[:：]/.test(t) ||
        /^(i'?ll|i will|let me)\s+(call|invoke|use|run|execute)\s+/.test(t)
      ) {
        return false;
      }
      return true;
    })
    .join("\n");
  // Strip inline backticked tool names: `multi_drop_trip` → "the dispatch tool".
  for (const name of INTERNAL_TOOL_NAMES) {
    const reBack = new RegExp("`" + name + "(\\([^`]*\\))?`", "g");
    out = out.replace(reBack, "");
    const reBare = new RegExp("\\b" + name + "(\\([^)]*\\))?", "g");
    out = out.replace(reBare, "");
  }
  // Tidy artefacts left behind (double spaces, "  ,").
  out = out.replace(/[ \t]{2,}/g, " ").replace(/\s+([,.;:!?])/g, "$1");
  return out;
}

function MarkdownText({ text: rawText }: { text: string }) {
  const text = sanitizeToolMentions(rawText);
  const lines = text.split(/\r?\n/);
  const blocks: React.ReactNode[] = [];
  let i = 0;
  let key = 0;
  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      blocks.push(<div key={`sp${key++}`} style={{ height: 8 }} />);
      i++;
      continue;
    }

    // Pre-flight check block: "Pre-flight check\n----..."
    if (
      /^pre-?flight check$/i.test(trimmed) &&
      i + 1 < lines.length &&
      /^[-=]{3,}$/.test(lines[i + 1].trim())
    ) {
      i += 2;
      const body: string[] = [];
      while (i < lines.length) {
        const t = lines[i].trim();
        // Stop at a blank line followed by a non-pre-flight section,
        // or at a clear question/CTA paragraph starting with capital + "?".
        if (!t) {
          // peek next non-empty line
          let j = i + 1;
          while (j < lines.length && !lines[j].trim()) j++;
          if (j >= lines.length) { i = j; break; }
          // A new pre-flight or any other heading-like line ends the block.
          break;
        }
        body.push(lines[i]);
        i++;
      }
      blocks.push(<PreflightCard key={`pf${key++}`} body={body.join("\n")} />);
      continue;
    }

    // Setext heading (line followed by === or ---)
    if (
      i + 1 < lines.length &&
      /^[-=]{3,}$/.test(lines[i + 1].trim()) &&
      !/^[-*•]\s+/.test(trimmed) &&
      !/^\d+[.)]\s+/.test(trimmed)
    ) {
      blocks.push(
        <div
          key={`sh${key++}`}
          style={{
            fontWeight: 700,
            fontSize: 13,
            margin: "10px 0 4px",
            color: "var(--color-primary, #67e8f9)",
            letterSpacing: 0.3,
          }}
        >
          {renderInline(trimmed)}
        </div>,
      );
      i += 2;
      continue;
    }

    // Headings
    const h = /^(#{1,6})\s+(.+)$/.exec(trimmed);
    if (h) {
      const level = h[1].length;
      const fontSize = level <= 2 ? 14 : level === 3 ? 13 : 12;
      blocks.push(
        <div
          key={`h${key++}`}
          style={{
            fontWeight: 700,
            fontSize,
            margin: "10px 0 4px",
            color: "var(--color-primary, #67e8f9)",
            letterSpacing: 0.2,
          }}
        >
          {renderInline(h[2])}
        </div>,
      );
      i++;
      continue;
    }

    // Horizontal rule
    if (/^[-=_]{3,}$/.test(trimmed)) {
      blocks.push(
        <hr
          key={`hr${key++}`}
          style={{
            border: "none",
            borderTop: "1px dashed rgba(148,163,184,0.3)",
            margin: "8px 0",
          }}
        />,
      );
      i++;
      continue;
    }

    // Bullet list
    if (/^[-*•]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*•]\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^[-*•]\s+/, ""));
        i++;
      }
      blocks.push(
        <ul
          key={`ul${key++}`}
          style={{
            margin: "4px 0",
            paddingLeft: 18,
            display: "flex",
            flexDirection: "column",
            gap: 2,
            listStyle: "disc",
          }}
        >
          {items.map((it, idx) => (
            <li
              key={idx}
              style={{
                lineHeight: 1.5,
                color: "var(--color-foreground, #e2e8f0)",
              }}
            >
              <span style={{ minWidth: 0 }}>{renderListItem(it)}</span>
            </li>
          ))}
        </ul>,
      );
      continue;
    }

    // Numbered list
    if (/^\d+[.)]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+[.)]\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^\d+[.)]\s+/, ""));
        i++;
      }
      blocks.push(
        <div
          key={`ol${key++}`}
          style={{ margin: "4px 0", display: "flex", flexDirection: "column", gap: 4 }}
        >
          {items.map((it, idx) => (
            <div
              key={idx}
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: 8,
                padding: "4px 8px",
                background: "rgba(148,163,184,0.06)",
                borderRadius: 4,
              }}
            >
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  minWidth: 18,
                  height: 18,
                  borderRadius: 999,
                  background: "rgba(6,182,212,0.2)",
                  color: "var(--color-primary, #67e8f9)",
                  fontSize: 10,
                  fontWeight: 700,
                  flexShrink: 0,
                }}
              >
                {idx + 1}
              </span>
              <span style={{ flex: 1, minWidth: 0 }}>{renderListItem(it)}</span>
            </div>
          ))}
        </div>,
      );
      continue;
    }

    // Paragraph (collect consecutive non-empty, non-special lines)
    const para: string[] = [line];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() &&
      !/^(#{1,6})\s+/.test(lines[i].trim()) &&
      !/^[-*•]\s+/.test(lines[i].trim()) &&
      !/^\d+[.)]\s+/.test(lines[i].trim()) &&
      !/^[-=_]{3,}$/.test(lines[i].trim())
    ) {
      para.push(lines[i]);
      i++;
    }
    const paraText = para.join("\n");
    // Single-line "Label: value" → render as a chip row
    if (para.length === 1) {
      const kv = /^([A-Za-z][A-Za-z0-9 _\-/]{0,28}?):\s+(.+)$/.exec(paraText.trim());
      if (kv && kv[2].length < 200) {
        blocks.push(
          <div
            key={`kv${key++}`}
            style={{
              display: "flex",
              alignItems: "baseline",
              gap: 8,
              margin: "3px 0",
              flexWrap: "wrap",
            }}
          >
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                letterSpacing: 0.3,
                textTransform: "uppercase",
                color: "var(--color-primary, #67e8f9)",
                opacity: 0.85,
              }}
            >
              {kv[1]}
            </span>
            <span style={{ flex: 1, minWidth: 0 }}>{renderInline(kv[2])}</span>
          </div>,
        );
        continue;
      }
    }
    blocks.push(
      <div
        key={`p${key++}`}
        style={{ margin: "3px 0", whiteSpace: "pre-wrap" }}
      >
        {renderInline(paraText)}
      </div>,
    );
  }
  return <>{blocks}</>;
}

function parseChoices(text: string): { cleanText: string; choices?: { field: string; options: string[] } } {
  const trimmed = text.trim();
  const m = trimmed.match(CHOICES_RE);
  if (!m) return { cleanText: text };
  const field = m[1];
  const options = m[2].split("|").map((s) => s.trim()).filter(Boolean);
  const cleanText = trimmed.replace(CHOICES_RE, "").trim();
  return { cleanText, choices: { field, options } };
}

const SUGGESTED_PROMPTS = [
  "Pick any idle AGV - load 1 unit each at S04 and deliver to S05, S26 and S21 in one trip",
  "What state is each AGV in right now?",
  "Recall the depleted AGVs to charging bays",
];

const PE_AUTO: React.CSSProperties = { pointerEvents: "auto" };

function getSessionId(): string {
  if (typeof window === "undefined") return "default";
  const KEY = "agv-chat-session-id";
  let sid = window.sessionStorage.getItem(KEY);
  if (!sid) {
    sid = `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    window.sessionStorage.setItem(KEY, sid);
  }
  return sid;
}

export function ChatDrawer() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [busy, setBusy] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const sessionIdRef = useRef<string>(getSessionId());

  const onVoiceResult = useCallback((transcript: string) => {
    setInput(transcript);
  }, []);
  const voice = useVoiceInput({ onResult: onVoiceResult });

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [turns, open]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || busy) return;
    setShowMenu(false);
    setBusy(true);
    setTurns((t) => [
      ...t,
      { role: "user", text: trimmed },
      { role: "assistant", text: "Thinking…", pending: true },
    ]);
    setInput("");
    try {
      const res = await fetch(CHAT_URL, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: trimmed, session_id: sessionIdRef.current, lang: voice.lang }),
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => "");
        throw new Error(`Server returned ${res.status}: ${txt.slice(0, 100)}`);
      }
      const data = await res.json();
      let reply: ChatTurn;
      if (data.ok) {
        const parsed = parseChoices(data.reply ?? "(no reply)");
        reply = {
          role: "assistant",
          text: parsed.cleanText,
          toolCalls: data.tool_calls ?? [],
          choices: parsed.choices,
        };
      } else {
        reply = { role: "assistant", text: "", error: data.error ?? "request failed" };
      }
      setTurns((t) => [...t.slice(0, -1), reply]);
      if (ttsEnabled && reply.text && !reply.error) {
        const isHindi = voice.lang === "hi-IN";
        let ttsText: string;
        if (reply.choices && reply.choices.options.length > 0) {
          const opts = reply.choices.options
            .map((o) => o.replace(/_/g, " "))
            .join(isHindi ? ", या " : ", or ");
          ttsText = isHindi ? `क्या आप ${opts} चाहेंगे?` : `Would you like to ${opts}?`;
        } else {
          // Always speak a SHORT summary — never read full structured replies.
          const lines = reply.text.split(/\n+/).map((l) => l.trim()).filter(Boolean);
          const lastQuestion = [...lines].reverse().find((l) => l.endsWith("?"));
          const looksStructured =
            /^pre-?flight check|^fleet right now|^planned path|^chosen agv|^conflicts:|^recommendation:|^----+|\*\*AGV\d+\*\*/im.test(
              reply.text,
            );

          // Fleet status: count idle/blocked/etc. into one short sentence.
          const isFleetStatus = /^fleet (right now|status)/im.test(reply.text);
          let fleetSummary: string | null = null;
          if (isFleetStatus) {
            const stateByAgv: { id: string; state: string }[] = [];
            const blockRe = /\*\*?(AGV\d+)\*\*?[\s\S]*?State\s*[:\-·]\s*([^\n()]+?)(?:\s*\([^)]+\))?\s*(?:\n|$)/gi;
            let m: RegExpExecArray | null;
            while ((m = blockRe.exec(reply.text)) !== null) {
              stateByAgv.push({ id: m[1], state: m[2].trim() });
            }
            if (stateByAgv.length > 0) {
              const counts = new Map<string, number>();
              for (const { state } of stateByAgv) {
                counts.set(state, (counts.get(state) ?? 0) + 1);
              }
              const parts = [...counts.entries()].map(([state, n]) =>
                isHindi ? `${n} ${state}` : `${n} ${state}`,
              );
              fleetSummary = isHindi
                ? `${stateByAgv.length} AGVs — ${parts.join(", ")}.`
                : `${stateByAgv.length} AGVs — ${parts.join(", ")}.`;
            }
          }

          // Hard cap: TTS never longer than ~80 chars / first sentence.
          const cap = (s: string) => {
            const t = s.replace(/\s+/g, " ").trim();
            const firstSentence = t.match(/[^.!?।]+[.!?।]/)?.[0]?.trim() ?? t;
            return firstSentence.length > 100 ? firstSentence.slice(0, 97) + "…" : firstSentence;
          };

          if (fleetSummary) {
            ttsText = fleetSummary;
          } else if (lastQuestion && lastQuestion.length <= 100) {
            ttsText = cap(lastQuestion);
          } else if (looksStructured) {
            ttsText = isHindi ? "विवरण ऊपर देखें।" : "Details are above.";
          } else {
            const meaningful =
              lines.find(
                (l) =>
                  !/^[-*•#]+\s/.test(l) &&
                  !/^\*\*?AGV\d+\*\*?$/i.test(l) &&
                  !/^[-=_]{3,}$/.test(l) &&
                  !/^(state|current node|battery|payload count)\s*[:\-·]/i.test(l),
              ) ?? lines[0] ?? reply.text;
            ttsText = cap(meaningful);
          }
        }
        speak(ttsText, voice.lang);
      }
    } catch (err) {
      setTurns((t) => [...t.slice(0, -1), { role: "assistant", text: "", error: String(err) }]);
    } finally {
      setBusy(false);
    }
  }

  if (typeof document === "undefined") return null;

  const drawerStyle: React.CSSProperties = {
    position: "fixed",
    top: 0,
    right: 0,
    height: "100%",
    width: 400,
    maxWidth: "100vw",
    background: "var(--color-background, #0b1220)",
    color: "var(--color-foreground, #e2e8f0)",
    borderLeft: "1px solid rgba(148,163,184,0.2)",
    boxShadow: "-8px 0 32px rgba(0,0,0,0.5)",
    transform: open ? "translateX(0)" : "translateX(100%)",
    transition: "transform 250ms ease",
    zIndex: 99999,
    pointerEvents: open ? "auto" : "none",
    display: "flex",
    flexDirection: "column",
  };

  const headerStyle: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "12px 16px",
    borderBottom: "1px solid rgba(148,163,184,0.2)",
    flexShrink: 0,
    pointerEvents: "auto",
  };

  const bodyStyle: React.CSSProperties = {
    flex: 1,
    minHeight: 0,
    overflowY: "auto",
    padding: "12px",
    display: "flex",
    flexDirection: "column",
    gap: 10,
    pointerEvents: "auto",
  };

  const formStyle: React.CSSProperties = {
    display: "flex",
    gap: 8,
    padding: 12,
    borderTop: "1px solid rgba(148,163,184,0.2)",
    flexShrink: 0,
    pointerEvents: "auto",
  };

  const inputStyle: React.CSSProperties = {
    flex: 1,
    minWidth: 0,
    padding: "8px 12px",
    fontSize: 12,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(148,163,184,0.3)",
    borderRadius: 6,
    color: "inherit",
    outline: "none",
    pointerEvents: "auto",
  };

  const sendBtnStyle: React.CSSProperties = {
    padding: "8px 12px",
    background: "var(--color-primary, #06b6d4)",
    color: "white",
    border: "none",
    borderRadius: 6,
    cursor: busy || !input.trim() ? "not-allowed" : "pointer",
    opacity: busy || !input.trim() ? 0.5 : 1,
    pointerEvents: "auto",
  };

  const suggestionBtnStyle: React.CSSProperties = {
    padding: "8px 12px",
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(148,163,184,0.25)",
    borderRadius: 6,
    fontSize: 12,
    color: "inherit",
    textAlign: "left",
    cursor: "pointer",
    pointerEvents: "auto",
  };

  return createPortal(
    <>
      {!open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          style={{
            position: "fixed",
            bottom: 24,
            right: 24,
            zIndex: 99997,
            display: "flex",
            alignItems: "center",
            gap: 8,
            padding: "10px 16px",
            background: "var(--color-primary, #06b6d4)",
            color: "white",
            borderRadius: 999,
            border: "none",
            fontWeight: 600,
            fontSize: 13,
            cursor: "pointer",
            boxShadow: "0 8px 24px rgba(6,182,212,0.4)",
            pointerEvents: "auto",
          }}
        >
          <MessageSquare size={16} />
          AGV Assistant
        </button>
      )}

      {open && (
        <div
          onClick={() => setOpen(false)}
          aria-hidden="true"
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.4)",
            zIndex: 99998,
            pointerEvents: "auto",
          }}
        />
      )}

      <div style={drawerStyle} role="dialog" aria-label="AGV Assistant">
        <div style={headerStyle}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Bot size={16} />
            <span style={{ fontSize: 14, fontWeight: 600 }}>AGV Fleet Assistant</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            {turns.length > 0 && (
              <button
                type="button"
                disabled={busy}
                onClick={() => {
                  if (busy) return;
                  setShowMenu(true);
                }}
                style={{
                  ...PE_AUTO,
                  background: "transparent",
                  border: "none",
                  color: "inherit",
                  cursor: busy ? "not-allowed" : "pointer",
                  opacity: busy ? 0.4 : 1,
                  padding: 6,
                  borderRadius: 4,
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                  fontSize: 11,
                }}
                title={busy ? "Wait for the current reply to finish" : "Back to menu"}
                aria-label="Back to menu"
              >
                <Home size={14} />
                Menu
              </button>
            )}
            <button
              type="button"
              onClick={() => setOpen(false)}
              style={{
                ...PE_AUTO,
                background: "transparent",
                border: "none",
                color: "inherit",
                cursor: "pointer",
                padding: 6,
                borderRadius: 4,
              }}
              title="Close"
              aria-label="Close chat"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        <div ref={scrollRef} style={bodyStyle}>
          {(turns.length === 0 || showMenu) && (
            <>
              {showMenu && turns.length > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                  <div style={{ fontSize: 11, opacity: 0.7 }}>Menu (history preserved)</div>
                  <button
                    type="button"
                    onClick={() => setShowMenu(false)}
                    style={{
                      ...PE_AUTO,
                      fontSize: 11,
                      padding: "3px 8px",
                      background: "transparent",
                      border: "1px solid rgba(148,163,184,0.3)",
                      borderRadius: 4,
                      color: "inherit",
                      cursor: "pointer",
                    }}
                  >
                    Back to chat
                  </button>
                </div>
              )}
              <div style={{ fontSize: 12, lineHeight: 1.5, opacity: 0.85, marginBottom: 4 }}>
                Hi! I can <b>create PCB tasks</b> (queued for the dispatcher),
                <b> directly dispatch an AGV</b> as a priority override, or run a
                <b> multi-drop trip</b>.
              </div>
              <div style={{ fontSize: 11, opacity: 0.65 }}>Try one of these:</div>
              {SUGGESTED_PROMPTS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => send(p)}
                  style={suggestionBtnStyle}
                >
                  {p}
                </button>
              ))}
            </>
          )}
          {!showMenu && turns.map((turn, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                justifyContent: turn.role === "user" ? "flex-end" : "flex-start",
              }}
            >
              <div
                style={{
                  maxWidth: "92%",
                  padding: turn.role === "assistant" ? "10px 14px" : "8px 12px",
                  borderRadius: turn.role === "user" ? 12 : 10,
                  fontSize: 12,
                  background: turn.role === "user"
                    ? "var(--color-primary, #06b6d4)"
                    : turn.error
                    ? "rgba(244,63,94,0.15)"
                    : "linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.03))",
                  color: turn.role === "user" ? "white" : turn.error ? "#fca5a5" : "inherit",
                  border: turn.error ? "1px solid rgba(244,63,94,0.4)" : "1px solid rgba(148,163,184,0.2)",
                  fontStyle: turn.pending ? "italic" : "normal",
                  opacity: turn.pending ? 0.7 : 1,
                  whiteSpace: turn.role === "user" || turn.pending ? "pre-wrap" : "normal",
                  lineHeight: 1.55,
                  wordBreak: "break-word",
                }}
              >
                {turn.error ? (
                  `Error: ${turn.error}`
                ) : turn.role === "assistant" && !turn.pending ? (
                  <MarkdownText text={turn.text} />
                ) : (
                  turn.text
                )}
                {(() => {
                  // Hide all internal tool-call chips from the end user.
                  const visibleCalls: ToolCall[] = [];
                  return visibleCalls.length > 0 ? (
                  <div style={{ marginTop: 6, display: "flex", flexWrap: "wrap", gap: 4 }}>
                    {visibleCalls.map((tc, j) => (
                      <span
                        key={j}
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 3,
                          fontSize: 10,
                          padding: "2px 6px",
                          background: "rgba(255,255,255,0.1)",
                          borderRadius: 4,
                        }}
                      >
                        <Wrench size={10} />
                        {tc.name}
                      </span>
                    ))}
                  </div>
                  ) : null;
                })()}
                {turn.role === "assistant" &&
                  turn.choices &&
                  i === turns.length - 1 &&
                  !busy && (
                    <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {turn.choices.options.map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => send(opt)}
                          style={{
                            ...PE_AUTO,
                            fontSize: 11,
                            padding: "4px 10px",
                            borderRadius: 999,
                            border: "1px solid rgba(6,182,212,0.5)",
                            background: "rgba(6,182,212,0.12)",
                            color: "var(--color-foreground, #e2e8f0)",
                            cursor: "pointer",
                            textTransform: "capitalize",
                          }}
                        >
                          {labelForChoice(opt)}
                        </button>
                      ))}
                    </div>
                  )}
              </div>
            </div>
          ))}
        </div>

        {/* Voice controls bar */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 12px 0", flexShrink: 0, pointerEvents: "auto" }}>
          <button
            type="button"
            onClick={() => voice.setLang(voice.lang === "en-US" ? "hi-IN" : "en-US")}
            title={`Language: ${voice.lang === "en-US" ? "English" : "Hindi"} - click to switch`}
            style={{ ...PE_AUTO, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(148,163,184,0.25)", borderRadius: 4, padding: "3px 8px", fontSize: 10, color: "inherit", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}
          >
            <Globe size={11} />
            {voice.lang === "en-US" ? "EN" : "HI"}
          </button>
          <button
            type="button"
            onClick={() => {
              const next = !ttsEnabled;
              setTtsEnabled(next);
              if (!next) stopSpeaking();
            }}
            title={ttsEnabled ? "Text-to-speech ON — click to mute" : "Text-to-speech OFF — click to enable"}
            style={{ ...PE_AUTO, background: "transparent", border: "none", color: ttsEnabled ? "var(--color-primary, #06b6d4)" : "rgba(148,163,184,0.5)", cursor: "pointer", padding: 4 }}
          >
            {ttsEnabled ? <Volume2 size={13} /> : <VolumeX size={13} />}
          </button>
          <span style={{ fontSize: 10, opacity: 0.5, marginLeft: "auto" }}>
            {voice.listening ? "Listening…" : voice.supported ? "Mic ready" : "Mic not supported"}
          </span>
        </div>

        <form
          style={formStyle}
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          {voice.supported && (
            <button
              type="button"
              onClick={voice.listening ? voice.stop : voice.start}
              disabled={busy}
              title={voice.listening ? "Stop listening" : `Speak (${voice.lang === "en-US" ? "English" : "Hindi"})`}
              style={{
                ...PE_AUTO,
                padding: "8px 10px",
                background: voice.listening ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.05)",
                border: voice.listening ? "1px solid rgba(239,68,68,0.5)" : "1px solid rgba(148,163,184,0.3)",
                borderRadius: 6,
                color: voice.listening ? "#ef4444" : "inherit",
                cursor: busy ? "not-allowed" : "pointer",
                opacity: busy ? 0.5 : 1,
                animation: voice.listening ? "pulse-mic 1.2s ease-in-out infinite" : "none",
              }}
            >
              {voice.listening ? <MicOff size={14} /> : <Mic size={14} />}
            </button>
          )}
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={busy}
            placeholder={voice.listening ? "Listening…" : "Ask about the fleet…"}
            style={inputStyle}
          />
          <button type="submit" disabled={busy || !input.trim()} style={sendBtnStyle}>
            <Send size={14} />
          </button>
        </form>
      </div>
    </>,
    document.body,
  );
}
