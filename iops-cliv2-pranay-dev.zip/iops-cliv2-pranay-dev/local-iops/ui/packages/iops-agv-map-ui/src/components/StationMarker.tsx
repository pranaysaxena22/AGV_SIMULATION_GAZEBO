import type { Station, StationRole } from "../types/index.js";

interface Props {
  station: Station;
}

const W = 2.8;
const H = 1.7;

const ROLE_GROUP: Record<StationRole, string> = {
  inbound: "logistics",
  outbound: "logistics",
  dispatch_dock: "logistics",
  smt_feeder: "smt",
  paste_print: "smt",
  smt_pnp: "smt",
  reflow: "smt",
  aoi_post_smt: "smt",
  ict: "test",
  fct: "test",
  xray: "test",
  aoi: "test",
  rework: "rework",
  wip_buffer: "buffer",
  conformal_coat: "assembly",
  depanel: "assembly",
  final_assembly: "assembly",
  packaging: "assembly",
  parking: "parking",
};

function captionFor(station: Station): string {
  // Prefer the human-friendly name (e.g. "Warehouse In") over the raw role.
  if (station.name) return station.name;
  if (!station.role) return "";
  return station.role.replace(/_/g, " ");
}

export function StationMarker({ station }: Props) {
  const group = station.role ? ROLE_GROUP[station.role] : null;
  const cls = group ? `process-${group}` : station.zone ? `zone-${station.zone}` : "";
  const halfW = W / 2;
  const halfH = H / 2;
  const tooltip = station.name
    ? `${station.id} · ${station.name}${station.role ? ` (${station.role})` : ""}`
    : station.id;
  const roleTag = captionFor(station);
  return (
    <g className="station-marker">
      <title>{tooltip}</title>
      <rect
        x={station.x - halfW}
        y={station.y - halfH}
        width={W}
        height={H}
        rx={0.35}
        ry={0.35}
        className={`station-tile ${cls}`}
      />
      <text
        x={station.x}
        y={station.y}
        textAnchor="middle"
        dominantBaseline="central"
        className="station-label"
        transform={`translate(0,${2 * station.y}) scale(1,-1)`}
      >
        {station.label ?? station.id}
      </text>
      {roleTag && (() => {
        const above = station.y <= 6;
        const labelY = above ? station.y - halfH - 0.85 : station.y + halfH + 0.85;
        return (
          <text
            x={station.x}
            y={labelY}
            textAnchor="middle"
            dominantBaseline="central"
            className="station-role-tag"
            transform={`translate(0,${2 * labelY}) scale(1,-1)`}
          >
            {roleTag}
          </text>
        );
      })()}
    </g>
  );
}
