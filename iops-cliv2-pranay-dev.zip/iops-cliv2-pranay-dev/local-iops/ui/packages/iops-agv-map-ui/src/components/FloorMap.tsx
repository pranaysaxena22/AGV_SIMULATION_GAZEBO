import { useMemo } from "react";
import { cn } from "@smaf/iops-theme-ui";
import type { AgvTelemetry, FloorLayout } from "../types/index.js";
import { AisleSegment } from "./AisleSegment.js";
import { StationMarker } from "./StationMarker.js";
import { TripOverlay } from "./TripOverlay.js";

interface Props {
  layout: FloorLayout;
  agvs?: AgvTelemetry[];
  className?: string;
  children?: React.ReactNode;
}

const ZONES: { id: "A" | "B" | "C"; minX: number; maxX: number; label: string }[] = [
  { id: "A", minX: -1, maxX: 22, label: "Material Prep" },
  { id: "B", minX: 22, maxX: 44, label: "PCB Fabrication" },
  { id: "C", minX: 44, maxX: 60, label: "Assembly & Test" },
];

export function FloorMap({ layout, agvs = [], className, children }: Props) {
  const coordsById = useMemo(() => {
    const map = new Map<string, { x: number; y: number }>();
    for (const s of layout.stations) map.set(s.id, { x: s.x, y: s.y });
    for (const w of layout.waypoints) map.set(w.id, { x: w.x, y: w.y });
    return map;
  }, [layout]);

  const stationIds = useMemo(
    () => new Set(layout.stations.map((s) => s.id)),
    [layout.stations],
  );

  const { minX, minY, maxX, maxY } = layout.bounds;
  const w = maxX - minX;
  const h = maxY - minY;

  const routes = agvs
    .filter((a) => a.state === "moving" && a.dest_node)
    .map((a) => {
      const dest = a.dest_node ? coordsById.get(a.dest_node) : null;
      if (!dest) return null;
      return { id: a.agv_id, a: { x: a.x, y: a.y }, b: dest };
    })
    .filter(
      (r): r is { id: string; a: { x: number; y: number }; b: { x: number; y: number } } => r !== null,
    );

  return (
    <svg
      className={cn("agv-map-svg rounded-md", className)}
      viewBox={`${minX - 5} ${minY - 7} ${w + 9} ${h + 9}`}
      preserveAspectRatio="xMidYMid meet"
    >
      <defs>
        <pattern
          id="agv-grid"
          width={4}
          height={4}
          patternUnits="userSpaceOnUse"
        >
          <path
            d="M 4 0 L 0 0 0 4"
            fill="none"
            stroke="rgba(125, 211, 252, 0.08)"
            strokeWidth={0.04}
          />
        </pattern>
        <marker
          id="agv-route-arrow"
          viewBox="0 0 10 10"
          refX={8}
          refY={5}
          markerWidth={4}
          markerHeight={4}
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="oklch(var(--primary) / 0.85)" />
        </marker>
        <marker
          id="flow-arrow"
          viewBox="0 0 10 10"
          refX={8}
          refY={5}
          markerWidth={3}
          markerHeight={3}
          orient="auto"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="rgba(125, 211, 252, 0.6)" />
        </marker>
      </defs>

      <rect
        x={minX}
        y={minY}
        width={w}
        height={h}
        className="floor-bg"
      />

      {/* Zone bands */}
      {ZONES.map((z) => (
        <g key={z.id}>
          <rect
            x={z.minX}
            y={minY}
            width={z.maxX - z.minX}
            height={h}
            className={`zone-band zone-band-${z.id}`}
          />
        </g>
      ))}

      {/* Process-area cells (bg tints behind clusters of stations) */}
      <g className="process-areas">
        <rect x={-0.5} y={minY + 0.5} width={22} height={h - 1} className="process-area process-area-smt" />
        <rect x={22}  y={minY + 0.5} width={22} height={h - 1} className="process-area process-area-test" />
        <rect x={44.5} y={minY + 0.5} width={15} height={h - 1} className="process-area process-area-assembly" />

        {/* Top zone headers */}
        <text x={10.5} y={minY - 2.2} className="process-area-label process-label-smt">Material Prep &amp; SMT</text>
        <text x={33}   y={minY - 2.2} className="process-area-label process-label-test">PCB Test &amp; Rework</text>
        <text x={52}   y={minY - 2.2} className="process-area-label process-label-assembly">Assembly &amp; Dispatch</text>

      </g>

      {/* Material flow ribbon */}
      <g className="material-flow">
        <text x={30} y={minY - 5.2} className="material-flow-label">PCB Production Line</text>
        <line x1={4} y1={minY - 4.2} x2={56} y2={minY - 4.2} className="material-flow-line" markerEnd="url(#flow-arrow)" />
      </g>

      <rect
        x={minX}
        y={minY}
        width={w}
        height={h}
        fill="url(#agv-grid)"
      />

      {/* Zone divider lines */}
      {ZONES.slice(1).map((z) => (
        <line
          key={`div-${z.id}`}
          x1={z.minX}
          y1={minY}
          x2={z.minX}
          y2={maxY}
          className="zone-divider"
        />
      ))}

      {/* Zone labels rendered in the top margin handled by process-areas labels */}

      <g transform={`translate(0 ${maxY}) scale(1 -1)`}>
        {layout.edges.map((e, i) => {
          const a = coordsById.get(e.from);
          const b = coordsById.get(e.to);
          if (!a || !b) return null;
          const isSpur =
            e.type === "spur" || stationIds.has(e.from) || stationIds.has(e.to);
          return (
            <AisleSegment
              key={i}
              edge={{ ...e, type: isSpur ? "spur" : "aisle" }}
              a={a}
              b={b}
            />
          );
        })}

        {layout.waypoints.map((wp) => (
          <g key={wp.id} className="waypoint">
            <circle cx={wp.x} cy={wp.y} r={0.55} className="waypoint-halo" />
            <circle cx={wp.x} cy={wp.y} r={0.3} className="waypoint-dot" />
            <text
              x={wp.x}
              y={wp.y - 1.0}
              textAnchor="middle"
              dominantBaseline="central"
              className="waypoint-label"
              transform={`translate(0,${2 * (wp.y - 1.0)}) scale(1,-1)`}
            >
              {wp.id}
            </text>
          </g>
        ))}

        {routes.map((r) => (
          <line
            key={`route-${r.id}`}
            x1={r.a.x}
            y1={r.a.y}
            x2={r.b.x}
            y2={r.b.y}
            className="agv-route"
            markerEnd="url(#agv-route-arrow)"
          />
        ))}

        {layout.stations.map((s) => (
          <StationMarker key={s.id} station={s} />
        ))}

        <TripOverlay />

        {children}
      </g>
    </svg>
  );
}
