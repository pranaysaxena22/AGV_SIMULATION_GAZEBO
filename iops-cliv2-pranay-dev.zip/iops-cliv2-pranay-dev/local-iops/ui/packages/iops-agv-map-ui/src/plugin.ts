import type { PluginMetadata } from "@smaf/iops-types-ui";
import { Map } from "lucide-react";

/** Feature permission key for the agvMap plugin */
export const FEATURE_AGV_MAP = "feature:agv_map";

export const agvMapPlugin: PluginMetadata = {
  name: "agvMap",
  version: "0.0.1",
  displayName: "AGV Floor Map",
  description: "",
  enabled: true,

  routes: [
    {
      path: "home/agv-map",
      component: () => import("./pages/AgvMapPage.js"),
      type: "protected",
      allowedRole: FEATURE_AGV_MAP,
      errorBoundary: true,
      meta: {
        title: "AGV Floor Map",
        description: "",
        icon: Map,
      },
    },
  ],

  navItems: [
    {
      label: "AGV Floor Map",
      path: "agv-map",
      icon: Map,
      order: 15,
      allowedRole: FEATURE_AGV_MAP,
      isFixed: true,
    },
  ],

  permissions: [FEATURE_AGV_MAP],
};

export default agvMapPlugin;
