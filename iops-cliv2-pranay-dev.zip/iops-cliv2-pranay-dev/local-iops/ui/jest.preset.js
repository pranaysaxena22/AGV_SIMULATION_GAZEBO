const nxPreset = require("@nx/jest/preset").default;

module.exports = {
  ...nxPreset,
  coverageReporters: ["text", "lcov", "clover", "json"],
};
