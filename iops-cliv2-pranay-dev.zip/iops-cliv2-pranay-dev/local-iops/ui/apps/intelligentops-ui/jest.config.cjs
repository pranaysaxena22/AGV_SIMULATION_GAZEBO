module.exports = {
  displayName: "@smaf/intelligentops-ui",
  preset: "../../jest.preset.js",
  setupFilesAfterEnv: ["<rootDir>/jest.setup.tsx"],
  transform: {
    "^(?!.*\\.(js|jsx|ts|tsx|css|json)$)": "@nx/react/plugins/jest",
    "^.+\\.[tj]sx?$": ["babel-jest", { presets: ["@nx/react/babel"] }],
  },
  moduleNameMapper: {
    "^@smaf/(?!iops-(?:core|redux|auth|theme|shared|layout|chat|types)-ui$)(.*)$":
      "<rootDir>/src/__mocks__/smafPluginMock.js",
  },
  moduleFileExtensions: ["ts", "tsx", "js", "jsx"],
  coverageDirectory: "test-output/jest/coverage",
  collectCoverageFrom: [
    "src/**/*.{ts,tsx}",
    "!src/**/*.test.{ts,tsx}",
    "!src/__tests__/**",
    "!src/__mocks__/**",
    "!src/main.tsx",
    "!src/_tw-safelist.ts",
  ],
  coverageReporters: ["text", "lcov", "clover"],
};
