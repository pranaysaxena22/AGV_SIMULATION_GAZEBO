/**
 * Jest Setup File
 *
 * This file runs before each test file and sets up the environment.
 * It loads environment variables from .env.test file.
 */

import * as path from "node:path";
import * as dotenv from "dotenv";

// Load test environment variables
dotenv.config({ path: path.resolve(__dirname, ".env.test") });

// ============================================================================
// Core infrastructure mocks (override the catch-all moduleNameMapper)
// ============================================================================

// Mock CSS imports
jest.mock("./styles.css", () => ({}));

// --- @smaf/iops-core-ui ---
jest.mock("@smaf/iops-core-ui", () => ({
  __esModule: true,
  AppRouter: (props: Record<string, unknown>) => (
    <div
      data-testid="app-router"
      data-not-found-redirect={props.notFoundRedirect as string}
    />
  ),
  useRenderedPluginRoutes: () => null,
  setupApiInterceptors: jest.fn(),
  setSliceInjector: jest.fn(),
  apiClient: { interceptors: { request: { use: jest.fn() } } },
  pluginManager: {
    register: jest.fn(),
    getFeatureRouteMap: jest.fn(() => new Map()),
  },
}));

// --- @smaf/iops-redux-ui ---
jest.mock("@smaf/iops-redux-ui", () => ({
  __esModule: true,
  ReduxProvider: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="redux-provider">{children}</div>
  ),
  store: {
    dispatch: jest.fn(),
    getState: jest.fn(() => ({})),
    subscribe: jest.fn(),
    replaceReducer: jest.fn(),
  },
  injectSlice: jest.fn(),
  addNotification: jest.fn((payload) => ({
    type: "notifications/add",
    payload,
  })),
}));

// --- @smaf/iops-auth-ui ---
jest.mock("@smaf/iops-auth-ui", () => ({
  __esModule: true,
  initAuth: jest.fn(),
  registerFeatureRoutes: jest.fn(),
  ProtectedRoute: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="protected-route">{children}</div>
  ),
  ROUTES: {
    LOGIN: "/login",
    LOGOUT: "/logout",
    HOME: "/home",
    UNAUTHORIZED: "/unauthorized",
    FORBIDDEN: "/forbidden",
    NOT_FOUND: "/404",
    SERVER_ERROR: "/500",
  },
}));

// --- @smaf/iops-theme-ui ---
jest.mock("@smaf/iops-theme-ui", () => ({
  __esModule: true,
  ThemeProvider: ({
    children,
    ...props
  }: {
    children: React.ReactNode;
    defaultTheme?: string;
    storageKey?: string;
  }) => (
    <div data-testid="theme-provider" data-props={JSON.stringify(props)}>
      {children}
    </div>
  ),
}));

// --- @smaf/iops-shared-ui ---
jest.mock("@smaf/iops-shared-ui", () => ({
  __esModule: true,
  Toaster: () => <div data-testid="toaster" />,
}));

// --- @smaf/iops-layout-ui ---
jest.mock("@smaf/iops-layout-ui", () => ({
  __esModule: true,
  AppLayout: () => <div data-testid="app-layout" />,
  LoadingPage: () => <div data-testid="loading-page" />,
  LoginPage: ({ appName }: { appName: string }) => (
    <div data-testid="login-page">{appName}</div>
  ),
  LogoutPage: () => <div data-testid="logout-page" />,
  UnauthorizedPage: () => <div data-testid="unauthorized-page" />,
  ForbiddenPage: () => <div data-testid="forbidden-page" />,
  NotFoundPage: () => <div data-testid="not-found-page" />,
  ServerErrorPage: () => <div data-testid="server-error-page" />,
  UserSettingsLayout: () => <div data-testid="user-settings-layout" />,
  UserSettings: () => <div data-testid="user-settings" />,
  ThemeSettings: () => <div data-testid="theme-settings" />,
}));

// --- @smaf/iops-chat-ui ---
jest.mock("@smaf/iops-chat-ui", () => ({
  __esModule: true,
  AgentSelector: () => <div data-testid="agent-selector" />,
}));

// --- @smaf/iops-types-ui ---
jest.mock("@smaf/iops-types-ui", () => ({
  __esModule: true,
}));
