// Generic mock for any @smaf/* package (catch-all)
// Handles plugin packages automatically via Proxy
module.exports = new Proxy(
  { __esModule: true },
  {
    get: (target, prop) => {
      if (prop in target) return target[prop];
      // Return a mock plugin metadata object for any named export
      return { name: String(prop), routes: [], navItems: [], permissions: {} };
    },
  }
);
