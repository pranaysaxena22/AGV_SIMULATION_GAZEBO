export { routeConfig, ROUTES } from "./routeConfig.js";
