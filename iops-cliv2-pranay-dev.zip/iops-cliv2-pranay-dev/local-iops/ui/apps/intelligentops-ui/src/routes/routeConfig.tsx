/**
 * Route Configuration for IntelligentOps UI
 *
 * Shell routes only - plugin routes are rendered dynamically by RouteRenderer
 */
import { ProtectedRoute, ROUTES } from "@smaf/iops-auth-ui";
import { AgentSelector } from "@smaf/iops-chat-ui";
import type { RouteConfig } from "@smaf/iops-core-ui";
import {
  AppLayout,
  ForbiddenPage,
  LoadingPage,
  LoginPage,
  LogoutPage,
  NotFoundPage,
  ServerErrorPage,
  ThemeSettings,
  UnauthorizedPage,
  UserSettings,
  UserSettingsLayout,
} from "@smaf/iops-layout-ui";

// Re-export ROUTES for convenience
export { ROUTES } from "@smaf/iops-auth-ui";

// ============================================================================
// Route Configuration - Shell Routes Only
// ============================================================================

export const routeConfig: RouteConfig[] = [
  // Public routes
  {
    path: ROUTES.LOGIN,
    element: <LoginPage appName="IntelligentOps" />,
    meta: {
      isPublic: true,
      title: "Login",
    },
  },
  {
    path: ROUTES.LOGOUT,
    element: <LogoutPage />,
    meta: {
      isPublic: true,
      title: "Logout",
    },
  },

  // Protected layout route - plugin pages render inside via Outlet
  // Plugin routes with path "home/agents" will match /home/agents/*
  // Wrapped in ProtectedRoute to prevent unauthenticated users from briefly
  // seeing the layout shell (sidebar + header) before child route guards redirect.
  {
    path: `${ROUTES.HOME}/*`,
    element: (
      <ProtectedRoute loadingComponent={<LoadingPage />}>
        <AppLayout
          headerProps={{
            leftActions: <AgentSelector className="ml-2" />,
          }}
        />
      </ProtectedRoute>
    ),
    meta: {
      title: "Home",
    },
    children: [
      // User Settings routes (nested)
      {
        path: "user-settings",
        element: <UserSettingsLayout />,
        meta: {
          title: "User Settings",
          permission: "feature:theme_settings",
        },
        children: [
          // User Settings index page
          {
            path: "",
            element: <UserSettings />,
            meta: {
              title: "User Settings",
            },
          },
          // Theme Settings page
          {
            path: "theme-settings",
            element: <ThemeSettings />,
            meta: {
              title: "Theme Settings",
            },
          },
        ],
      },
    ],
  },

  // Error pages
  {
    path: ROUTES.UNAUTHORIZED,
    element: <UnauthorizedPage />,
    meta: {
      isPublic: true,
      title: "Unauthorized",
    },
  },
  {
    path: ROUTES.FORBIDDEN,
    element: <ForbiddenPage />,
    meta: {
      isPublic: true,
      title: "Access Denied",
    },
  },
  {
    path: ROUTES.NOT_FOUND,
    element: <NotFoundPage />,
    meta: {
      isPublic: true,
      title: "Not Found",
    },
  },
  {
    path: ROUTES.SERVER_ERROR,
    element: <ServerErrorPage />,
    meta: {
      isPublic: true,
      title: "Server Error",
    },
  },
];

export default routeConfig;
