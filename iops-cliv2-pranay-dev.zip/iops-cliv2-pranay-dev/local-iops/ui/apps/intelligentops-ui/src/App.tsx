import { agentsPlugin } from "@smaf/iops-agents-ui";
import { agvMapPlugin } from "@smaf/iops-agv-map-ui";
import { initAuth, registerFeatureRoutes } from "@smaf/iops-auth-ui";
import {
  AppRouter,
  type RouteConfig,
  apiClient,
  pluginManager,
  setSliceInjector,
  setupApiInterceptors,
  useRenderedPluginRoutes,
} from "@smaf/iops-core-ui";
import { generalChatPlugin } from "@smaf/iops-general-chat-ui";
import { globalConfigPlugin } from "@smaf/iops-global-config-ui";
import { LoadingPage } from "@smaf/iops-layout-ui";
import {
  ReduxProvider,
  addNotification,
  injectSlice,
  store,
} from "@smaf/iops-redux-ui";
import { Toaster } from "@smaf/iops-shared-ui";
import { ThemeProvider } from "@smaf/iops-theme-ui";
import { toolsAndPromptsPlugin } from "@smaf/iops-tools-prompts-ui";
import type { ApiError } from "@smaf/iops-types-ui";
import { Navigate, Route } from "react-router-dom";
import { routeConfig } from "./routes/index.js";
import "./styles.css";

// Initialize auth module — injects authSlice and sets up API client reference
initAuth(store, apiClient, injectSlice);

// Configure slice injector before registering plugins
setSliceInjector(injectSlice);

// Register plugins (metadata only - components are lazy loaded on route visit)
// Plugins with storeSlice will have their reducers injected automatically
pluginManager.register(generalChatPlugin);
pluginManager.register(agentsPlugin);
pluginManager.register(toolsAndPromptsPlugin);
pluginManager.register(globalConfigPlugin);
pluginManager.register(agvMapPlugin);
registerFeatureRoutes(pluginManager.getFeatureRouteMap());

// Setup API interceptors with centralized error handling
setupApiInterceptors(store, (error: ApiError) => {
  // Show error notification for API errors
  store.dispatch(
    addNotification({
      title: "API Error",
      message: error.message,
      severity: "error",
      duration: 5000,
    })
  );
});

/**
 * Recursively render RouteConfig array to Route elements
 * @param configs - Route configuration array
 * @param pluginRoutes - Optional plugin routes to inject as children of the layout route
 */
export function renderRoutes(
  configs: RouteConfig[],
  pluginRoutes?: React.ReactNode
): React.ReactNode {
  return configs.map((route, index) => {
    const key = `${route.path || "index"}-${index}`;

    // Handle index routes
    if (route.index) {
      return <Route key={key} index element={route.element} />;
    }

    // Check if this is the layout route (/home/*) where we should inject plugin routes
    const isLayoutRoute = route.path?.includes("/home");

    // Handle routes with children OR layout route that needs plugin routes
    if (
      (route.children && route.children.length > 0) ||
      (isLayoutRoute && pluginRoutes)
    ) {
      return (
        <Route key={key} path={route.path} element={route.element}>
          {/* Index redirect for layout route */}
          {isLayoutRoute && (
            <Route index element={<Navigate to="chat/new" replace />} />
          )}
          {/* Render static children */}
          {route.children && renderRoutes(route.children)}
          {/* Inject plugin routes as children of the layout */}
          {isLayoutRoute && pluginRoutes}
        </Route>
      );
    }

    // Handle regular routes
    return <Route key={key} path={route.path} element={route.element} />;
  });
}

/**
 * Inner App component that uses hooks to get plugin routes
 */
function AppContent() {
  const pluginRouteElements = useRenderedPluginRoutes();

  return (
    <AppRouter
      baseRoutes={renderRoutes(routeConfig, pluginRouteElements)}
      loadingComponent={<LoadingPage />}
      notFoundRedirect="/404"
      pluginRoutes={null} // Plugin routes are already injected in baseRoutes
    />
  );
}

export function App() {
  return (
    <ReduxProvider>
      <ThemeProvider defaultTheme="system" storageKey="iops-ui-theme">
        <AppContent />
        <Toaster />
      </ThemeProvider>
    </ReduxProvider>
  );
}

export default App;
