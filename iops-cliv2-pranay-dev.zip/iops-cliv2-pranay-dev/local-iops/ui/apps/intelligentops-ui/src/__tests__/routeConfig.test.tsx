import { routeConfig } from "../routes/index.js";

describe("routeConfig", () => {
  it("is a non-empty array", () => {
    expect(Array.isArray(routeConfig)).toBe(true);
    expect(routeConfig.length).toBeGreaterThan(0);
  });

  it("contains expected top-level paths", () => {
    const paths = routeConfig.map((r) => r.path);
    expect(paths).toContain("/login");
    expect(paths).toContain("/logout");
    expect(paths).toContain("/unauthorized");
    expect(paths).toContain("/forbidden");
    expect(paths).toContain("/404");
    expect(paths).toContain("/500");
  });

  it("contains a /home/* layout route", () => {
    const homeRoute = routeConfig.find((r) => r.path === "/home/*");
    expect(homeRoute).toBeDefined();
  });

  it("/home/* route has children with user-settings", () => {
    const homeRoute = routeConfig.find((r) => r.path === "/home/*");
    expect(homeRoute?.children).toBeDefined();
    const userSettings = homeRoute?.children?.find(
      (c) => c.path === "user-settings"
    );
    expect(userSettings).toBeDefined();
  });

  it("user-settings has nested children (index + theme-settings)", () => {
    const homeRoute = routeConfig.find((r) => r.path === "/home/*");
    const userSettings = homeRoute?.children?.find(
      (c) => c.path === "user-settings"
    );
    expect(userSettings?.children).toBeDefined();
    expect(userSettings?.children?.length).toBeGreaterThanOrEqual(2);

    const paths = userSettings?.children?.map((c) => c.path);
    expect(paths).toContain("");
    expect(paths).toContain("theme-settings");
  });

  it("public routes have meta.isPublic: true", () => {
    const publicPaths = [
      "/login",
      "/logout",
      "/unauthorized",
      "/forbidden",
      "/404",
      "/500",
    ];
    for (const path of publicPaths) {
      const route = routeConfig.find((r) => r.path === path);
      expect(route?.meta?.isPublic).toBe(true);
    }
  });

  it("/home/* route does NOT have meta.isPublic", () => {
    const homeRoute = routeConfig.find((r) => r.path === "/home/*");
    expect(homeRoute?.meta?.isPublic).toBeUndefined();
  });
});
