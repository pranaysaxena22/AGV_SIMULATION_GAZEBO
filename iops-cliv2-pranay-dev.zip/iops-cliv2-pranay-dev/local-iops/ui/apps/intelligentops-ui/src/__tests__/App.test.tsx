import { render } from "@testing-library/react";

// Import mocked modules to assert on calls
const { initAuth } = jest.requireMock("@smaf/iops-auth-ui");
const { setSliceInjector, setupApiInterceptors } =
  jest.requireMock("@smaf/iops-core-ui");

// Must import App after mocks are set up (jest.setup.tsx runs first)
import { App } from "../App.js";

describe("App", () => {
  it("renders without throwing", () => {
    expect(() => {
      render(<App />);
    }).not.toThrow();
  });

  it("renders ReduxProvider", () => {
    const { getByTestId } = render(<App />);
    expect(getByTestId("redux-provider")).toBeTruthy();
  });

  it("renders ThemeProvider with correct props", () => {
    const { getByTestId } = render(<App />);
    const themeProvider = getByTestId("theme-provider");
    expect(themeProvider).toBeTruthy();

    const props = JSON.parse(themeProvider.dataset.props || "{}");
    expect(props.defaultTheme).toBe("system");
    expect(props.storageKey).toBe("iops-ui-theme");
  });

  it("renders Toaster", () => {
    const { getByTestId } = render(<App />);
    expect(getByTestId("toaster")).toBeTruthy();
  });

  it("renders AppRouter with notFoundRedirect=/404", () => {
    const { getByTestId } = render(<App />);
    const appRouter = getByTestId("app-router");
    expect(appRouter).toBeTruthy();
    expect(appRouter.dataset.notFoundRedirect).toBe("/404");
  });

  it("calls initAuth on module load", () => {
    expect(initAuth).toHaveBeenCalled();
  });

  it("calls setSliceInjector on module load", () => {
    expect(setSliceInjector).toHaveBeenCalled();
  });

  it("calls setupApiInterceptors on module load", () => {
    expect(setupApiInterceptors).toHaveBeenCalled();
  });
});
