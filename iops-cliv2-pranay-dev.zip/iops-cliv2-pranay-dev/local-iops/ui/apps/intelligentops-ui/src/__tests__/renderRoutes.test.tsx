import { render } from "@testing-library/react";
import { MemoryRouter, Outlet, Route, Routes } from "react-router-dom";
import { renderRoutes } from "../App.js";

describe("renderRoutes", () => {
  it("renders a simple route with correct path and element", () => {
    const configs = [
      { path: "/test", element: <div data-testid="test-page">Test</div> },
    ];

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/test"]}>
        <Routes>{renderRoutes(configs)}</Routes>
      </MemoryRouter>
    );

    expect(getByTestId("test-page")).toBeTruthy();
  });

  it("renders an index route", () => {
    const configs = [
      {
        path: "/parent",
        element: (
          <div data-testid="parent">
            <Outlet />
          </div>
        ),
        children: [
          {
            index: true,
            element: <div data-testid="index-child">Index</div>,
          },
        ],
      },
    ];

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/parent"]}>
        <Routes>{renderRoutes(configs)}</Routes>
      </MemoryRouter>
    );

    expect(getByTestId("index-child")).toBeTruthy();
  });

  it("renders layout route (/home) with plugin routes injected", () => {
    const pluginRoutes = (
      <Route
        path="my-plugin"
        element={<div data-testid="plugin-route">Plugin</div>}
      />
    );

    const configs = [
      {
        path: "/home/*",
        element: (
          <div data-testid="layout">
            <Outlet />
          </div>
        ),
      },
    ];

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/home/my-plugin"]}>
        <Routes>{renderRoutes(configs, pluginRoutes)}</Routes>
      </MemoryRouter>
    );

    expect(getByTestId("plugin-route")).toBeTruthy();
  });

  it("renders nested children recursively", () => {
    const configs = [
      {
        path: "/a",
        element: (
          <div data-testid="a">
            <Outlet />
          </div>
        ),
        children: [
          {
            path: "b",
            element: (
              <div data-testid="b">
                <Outlet />
              </div>
            ),
            children: [
              {
                path: "c",
                element: <div data-testid="c">C</div>,
              },
            ],
          },
        ],
      },
    ];

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/a/b/c"]}>
        <Routes>{renderRoutes(configs)}</Routes>
      </MemoryRouter>
    );

    expect(getByTestId("c")).toBeTruthy();
  });

  it("renders layout route correctly when pluginRoutes is undefined", () => {
    const configs = [
      {
        path: "/home/*",
        element: (
          <div data-testid="layout">
            <Outlet />
          </div>
        ),
        children: [
          {
            path: "settings",
            element: <div data-testid="settings">Settings</div>,
          },
        ],
      },
    ];

    const { getByTestId } = render(
      <MemoryRouter initialEntries={["/home/settings"]}>
        <Routes>{renderRoutes(configs)}</Routes>
      </MemoryRouter>
    );

    expect(getByTestId("settings")).toBeTruthy();
  });

  it("returns an empty array for empty config", () => {
    const result = renderRoutes([]);
    expect(result).toEqual([]);
  });
});
