const { NxAppRspackPlugin } = require("@nx/rspack/app-plugin");
const { NxReactRspackPlugin } = require("@nx/rspack/react-plugin");
const { DefinePlugin, HtmlRspackPlugin } = require("@rspack/core");
const path = require("node:path");
const fs = require("node:fs");
const { join } = path;

// Load environment variables from .env file
require("dotenv").config({ path: join(__dirname, ".env") });

// Auto-generate aliases for all local workspace packages → source
const packagesDir = path.resolve(__dirname, "../../packages");
const packageAliases = fs.existsSync(packagesDir)
  ? fs
      .readdirSync(packagesDir, { withFileTypes: true })
      .filter(
        (d) =>
          d.isDirectory() &&
          fs.existsSync(path.join(packagesDir, d.name, "src"))
      )
      .reduce((acc, d) => {
        acc[`@smaf/${d.name}`] = path.join(packagesDir, d.name, "src");
        return acc;
      }, {})
  : {};

// Auto-inject IOPS_* environment variables via window.__ENV__ runtime config.
// All vars use window.__ENV__ lookups to prevent dead-code elimination in production.
// Fallback values from .env are used when window.__ENV__ is not available.
const envDefines = Object.keys(process.env)
  .filter((key) => key.startsWith("IOPS_"))
  .reduce((acc, key) => {
    acc[`process.env.${key}`] = `(window.__ENV__?.["${key}"] ?? ${JSON.stringify(process.env[key])})`;
    return acc;
  }, {});

module.exports = {
  output: {
    path: join(__dirname, "dist"),
  },
  // Suppress known warnings from Monaco Editor
  ignoreWarnings: [
    // Dynamic require warning
    {
      module: /monaco-editor/,
      message: /Critical dependency/,
    },
    // Missing source map warning
    {
      module: /monaco-editor/,
      message: /Failed to parse source map/,
    },
    // Source map loader warning (function filter for flexibility)
    (warning) =>
      warning.message?.includes("monaco-editor") &&
      warning.message?.includes("source map"),
    // @x0k/json-schema-merge missing source maps
    {
      module: /@x0k[\\/]json-schema-merge/,
      message: /Failed to parse source map/,
    },
  ],
  resolve: {
    conditionNames: ["browser", "import", "require", "default"],
    // Ensure peer dependencies in aliased workspace packages resolve from
    // the app's node_modules (pnpm strict isolation otherwise blocks this).
    modules: [path.resolve(__dirname, "node_modules"), "node_modules"],
    // Alias local workspace packages to their source for hot reload.
    // Registry packages resolve normally via "import" condition → dist/.
    alias: {
      ...packageAliases,
    },
    // Exclude Node.js core modules from browser bundle
    fallback: {
      http: false,
      https: false,
      http2: false,
      util: false,
      url: false,
      stream: false,
      zlib: false,
      assert: false,
      crypto: false,
    },
  },
  // Enable persistent caching for faster subsequent builds
  cache: true,
  devServer: {
    port: 3001,
    open: true,
    historyApiFallback: {
      index: "/index.html",
      disableDotRule: true,
      htmlAcceptHeaders: ["text/html", "application/xhtml+xml"],
    },
    host: "iops.dev.deloitte.intelligentops.ai",
    client: {
      // Suppress benign ResizeObserver error triggered by Monaco Editor's automaticLayout
      // Vite (used by smaf-platform) doesn't surface these; rspack's overlay does by default
      overlay: {
        runtimeErrors: (error) => {
          if (error?.message?.includes("ResizeObserver loop")) return false;
          return true;
        },
      },
    },
    server: {
      type: "https",
      options: {
        key: path.resolve(
          __dirname,
          "../../../iops.dev.deloitte.intelligentops.ai-key.pem"
        ),
        cert: path.resolve(
          __dirname,
          "../../../iops.dev.deloitte.intelligentops.ai.pem"
        ),
      },
    },
  },
  plugins: [
    new DefinePlugin({
      "process.env.NODE_ENV": JSON.stringify(
        process.env.NODE_ENV || "development"
      ),
      ...envDefines,
    }),
    new NxAppRspackPlugin({
      tsConfig: "./tsconfig.app.json",
      main: "./src/main.tsx",
      index: "./src/index.html",
      baseHref: "/",
      assets: ["./src/assets"],
      styles: ["./src/styles.css"],
      outputHashing: process.env.NODE_ENV === "production" ? "all" : "none",
      optimization: process.env.NODE_ENV === "production",
    }),
    new NxReactRspackPlugin({
      // Disable SVGR to use plain asset imports
      svgr: false,
    }),
    // Inject OneTrust cookie consent banner as a static <script> in <head>.
    // Baked into HTML at build time so the banner loads before any JS executes.
    // Requires IOPS_COOKIE_BANNER_ID and IOPS_COOKIE_SCRIPT_SRC env vars.
    // Note: On local dev, OneTrust will error if the domain is not registered
    // in their portal — this is expected. Use the -test suffix on the banner
    // ID for non-production domains (e.g., "abc123-test").
    {
      apply(compiler) {
        const bannerId = process.env.IOPS_COOKIE_BANNER_ID;
        const scriptSrc = process.env.IOPS_COOKIE_SCRIPT_SRC;
        if (!bannerId || !scriptSrc) return;

        compiler.hooks.compilation.tap("CookieBannerPlugin", (compilation) => {
          HtmlRspackPlugin.getCompilationHooks(compilation).beforeEmit.tap(
            "CookieBannerPlugin",
            (data) => {
              // OneTrust SDK stub (charset required per OneTrust docs)
              const stubTag = `<script id="ot-sdk-stub" type="text/javascript" charset="UTF-8" src="${scriptSrc}" data-domain-script="${bannerId}"></script>`;
              // OptanonWrapper callback (required by OneTrust SDK) + iframe sandbox fix.
              // OneTrust creates sandboxed about:blank iframes that may block script
              // execution on unregistered/test domains. The MutationObserver patches
              // these iframes to include allow-scripts so the banner can render.
              const wrapperTag = `<script type="text/javascript">
      function OptanonWrapper() {}
      (function() {
        var observer = new MutationObserver(function(mutations) {
          mutations.forEach(function(m) {
            m.addedNodes.forEach(function(node) {
              if (node.nodeName === "IFRAME" && node.getAttribute("sandbox") !== null
                  && node.closest && node.closest("#onetrust-consent-sdk")) {
                var sb = node.getAttribute("sandbox") || "";
                if (sb.indexOf("allow-scripts") === -1) {
                  node.setAttribute("sandbox", sb + " allow-scripts allow-same-origin");
                }
              }
            });
          });
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
      })();
    </script>`;
              data.html = data.html.replace(
                "</head>",
                `    ${stubTag}\n    ${wrapperTag}\n  </head>`
              );
              return data;
            }
          );
        });
      },
    },
  ],
  module: {
    rules: [
      // Override default SVG handling - must come after plugins
      {
        test: /\.svg$/,
        type: "asset/resource",
        // Force this rule to take precedence
        enforce: "pre",
      },
    ],
  },
};
