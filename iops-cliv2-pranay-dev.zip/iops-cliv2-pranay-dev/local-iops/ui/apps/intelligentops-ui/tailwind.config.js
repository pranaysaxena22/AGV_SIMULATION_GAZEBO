/**
 * Tailwind CSS v4 Configuration
 *
 * Note: In Tailwind v4, most configuration is done via CSS @theme blocks.
 * Content scanning is handled by @source directives in theme.css.
 * This config file is kept minimal for compatibility.
 */

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
};
