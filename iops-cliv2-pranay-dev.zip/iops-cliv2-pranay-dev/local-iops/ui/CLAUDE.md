# CLAUDE.md

This is the `@smaf` archetype — a distributable starter for building apps with `@smaf` packages consumed from Artifactory. Teams clone this repo and can extend it with their own local packages.

## Build & Development Commands

| Command                  | Description                                                           |
| ------------------------ | --------------------------------------------------------------------- |
| `pnpm start`             | Start dev server (HTTPS at `iops.dev.deloitte.intelligentops.ai:443`) |
| `pnpm build`             | Production build of the main app                                      |
| `pnpm test`              | Run all tests with combined coverage report (Jest direct)             |
| `pnpm nx test <package>` | Run tests for a single package (e.g. `pnpm nx test iops-auth-ui`)     |
| `pnpm test:watch`        | Run app tests in watch mode                                           |
| `pnpm test:coverage`     | Run app tests with coverage                                           |
| `pnpm lint`              | Lint with Biome                                                       |
| `pnpm check`             | Lint + format check with Biome                                        |
| `pnpm check:fix`         | Auto-fix lint + format issues                                         |
| `pnpm format`            | Format all files with Biome                                           |
| `pnpm graph`             | Visualize Nx dependency graph                                         |
| `pnpm reset`             | Reset Nx cache                                                        |
| `pnpm sync`              | Sync Nx workspace                                                     |
| `pnpm generate:plugin`   | Scaffold a new plugin package (interactive)                           |
| `pnpm release`           | Version and release packages (Nx release with conventional commits)   |
| `pnpm release:preview`   | Preview release without publishing                                    |
| `pnpm release:publish`   | Publish released packages to Artifactory                              |

> **Note:** `pnpm start` and `pnpm build` both auto-run `extract-tw-classes.js` first, which extracts Tailwind class names from `@smaf` package dist files into `src/_tw-safelist.ts`. This works around a Tailwind CSS v4 limitation where `@source` cannot scan `node_modules`.

## Architecture Overview

This is an Nx monorepo (`@smaf` scope) with **pnpm workspaces**. The app (`intelligentops-ui`) consumes 12 `@smaf` packages from the Artifactory registry. Teams can also create their own local packages under `packages/`.

### Package Resolution

The Rspack config (`rspack.config.js`) auto-detects a `packages/` directory at the repo root. When it exists, local packages are aliased to their `src/` directories for hot-reload without pre-building. When `packages/` is absent, all `@smaf/*` packages resolve from `node_modules` (Artifactory registry).

The `tsconfig.base.json` has empty `paths: {}` — resolution is handled entirely by Rspack aliases (dev) or standard `node_modules` lookup (prod/registry).

### Plugin System

The app uses a plugin architecture defined in `@smaf/iops-core-ui`. Each feature (agents, chat, library, data-sources, etc.) is a plugin that exports a `PluginMetadata` object containing:

- **Routes** (lazy-loaded components)
- **Nav items** (sidebar entries)
- **Store slice** (Redux slice injected at runtime)
- **Permissions** (feature-level access control)

Plugins are registered in `apps/intelligentops-ui/src/App.tsx` via `PluginManager.register()`. Plugin routes are injected under the `/home/*` layout route.

### Available @smaf Packages

These packages are consumed from Artifactory (versions in `apps/intelligentops-ui/package.json`):

| Package                | Role                                                                  |
| ---------------------- | --------------------------------------------------------------------- |
| `@smaf/iops-types-ui`  | Shared TypeScript types (PluginMetadata, RouteConfig, ApiError, etc.) |
| `@smaf/iops-redux-ui`  | Redux store with `combineSlices` for dynamic slice injection          |
| `@smaf/iops-auth-ui`   | Better-auth client, Microsoft SSO, permission guards, policy authz    |
| `@smaf/iops-theme-ui`  | ThemeProvider (dark/light/system), `cn()` utility, OKLch color themes |
| `@smaf/iops-core-ui`   | Plugin system (PluginManager), Axios API client, route rendering      |
| `@smaf/iops-shared-ui` | shadcn/ui components (Radix primitives), common components, hooks     |
| `@smaf/iops-layout-ui` | App shell (header, sidebar, main content area)                        |
| `@smaf/iops-chat-ui`   | Chat interface components                                             |

| `@smaf/iops-general-chat-ui`  | General Chat feature plugin                                           |
| `@smaf/iops-agents-ui`        | Agents feature plugin                                                 |
| `@smaf/iops-tools-prompts-ui` | Tools & Prompts feature plugin                                        |
| `@smaf/iops-global-config-ui` | Global Config feature plugin                                          |

### Dependency Flow

These are registry packages; the dependency flow is managed within the published packages:

```text
iops-types-ui (leaf)
  -> iops-redux-ui, iops-auth-ui, iops-theme-ui (leaf)
    -> iops-core-ui, iops-shared-ui
      -> iops-layout-ui, iops-chat-ui
        -> feature plugins (agents, library, general-chat, etc.)
          -> intelligentops-ui (app, consumes all)
```

### SVG Handling

Rspack is configured with `asset/resource` for SVGs (SVGR is disabled). Import SVGs as URLs, not as React components:

```tsx
import logo from "./logo.svg"; // string URL
<img src={logo} alt="Logo" />;
```

## Code Style & Conventions

- **Formatter/Linter:** Biome (not ESLint/Prettier). Double quotes, semicolons, 2-space indent, LF line endings, 80-char line width.
- **Import style:** Use `import type` for type-only imports (`useImportType: error` in Biome).
- **Commits:** Conventional Commits enforced by commitlint + husky. Format: `<type>(<scope>): <description>`. Scopes auto-derive from `packages/` directory names (if it exists) plus extra scopes: `app`, `deps`, `ci`, `release`, `config`.
- **Package manager:** pnpm (never use npm or yarn).

## Environment Setup

- `.npmrc` configures the `@smaf` scope to resolve from Artifactory. Requires `NPM_AUTH_TOKEN` and `NPM_EMAIL` environment variables (or replace placeholders in `.npmrc` directly).
- Copy `apps/intelligentops-ui/.env.example` to `.env` in the app directory.
- All app env vars are prefixed with `IOPS_` (auto-injected by Rspack DefinePlugin as `process.env.IOPS_*`).

## Local Development Auth Bypass (`IOPS_ISLOCAL`)

When `IOPS_ISLOCAL=true` is set in the app `.env` file, the `AppRouter` (in `@smaf/iops-core-ui`) skips Microsoft SSO entirely and injects a fake local user into Redux. This lets developers run the app without an auth server or valid SSO credentials.

**How it works:**

1. `AppRouter.validateUser()` checks `process.env.IOPS_ISLOCAL` at the top of the auth flow.
2. If `"true"`, it dispatches `setAuthState` with a `LOCAL_USER` object (defined in `@smaf/iops-auth-ui` constants) and a `"local-dev-token"` access token.
3. It sets `isAuthenticated: true` via `setAuthentication`.
4. Permissions are resolved locally via `getLocalPermissions()`, which reads the `IOPS_PERMISSION_OVERRIDES` env var — no API call is made.
5. `registerFeatureRoutes(pluginManager.getFeatureRouteMap())` must be called after plugin registration to enable permission-based fallback redirects in `ProtectedRoute`.
6. All downstream guards (`ProtectedRoute`, `PublicRoute`, `RootRedirect`) work unchanged since they read from Redux state.

**Permission env var:** `IOPS_PERMISSION_OVERRIDES` is a single comma-separated string of `feature:name=level` pairs. Valid levels: `"write"`, `"read"`, or `"not_allowed"`.

| Feature key                 | Feature         |
| --------------------------- | --------------- |
| `feature:general_chat`      | General Chat    |
| `feature:agents`            | Agents          |
| `feature:data_sources`      | Data Sources    |
| `feature:library`           | Library         |
| `feature:tools_and_prompts` | Tools & Prompts |
| `feature:settings`          | Settings        |

**Example `.env` for local dev with full access:**

```env
IOPS_ISLOCAL=true
IOPS_PERMISSION_OVERRIDES=feature:general_chat=write,feature:agents=write,feature:data_sources=write,feature:library=write,feature:tools_and_prompts=write,feature:settings=write
```

> **Note:** `IOPS_PERMISSION_OVERRIDES` must be a static string literal because Rspack `DefinePlugin` replaces it at compile time. Do not use dynamic expressions.

**API Key:** When `IOPS_ISLOCAL=true`, the API client (from `@smaf/iops-core-ui@0.1.14+`) injects an `X-API-Key` header from the `IOPS_API_KEY` env var and skips Bearer auth token injection.

## Creating New Packages

Teams can add their own local packages under `packages/`:

1. Run `pnpm generate:plugin` from the repo root (runs `nx g @smaf/plugin-generator:plugin`). The interactive wizard prompts for:
   - **name** — kebab-case plugin name (e.g. `my-feature`), auto-prefixed as `iops-<name>-ui`
   - **displayName** — human-readable name (e.g. `My Feature`)
   - **featurePermission** — snake_case permission key (e.g. `my_feature`)
   - Optional: **icon** (Lucide icon name), **navSection**, **navOrder**, **withStore** (Redux slice)

   To skip prompts, pass all required options inline:

   ```bash
   pnpm generate:plugin --name=my-feature --displayName="My Feature" --featurePermission=my_feature --icon=<any-preferred-icon-from-luicide-icons-library>
   ```

2. The generator scaffolds a complete plugin under `packages/iops-<name>-ui/` with routes, store, services, permissions, and auto-registers it in `apps/intelligentops-ui/src/App.tsx`.
3. Packages in `packages/` are auto-detected by Rspack for local source resolution (hot reload without building).
4. Commit scopes auto-expand when `packages/` exists — each subdirectory becomes a valid scope.
5. Version and publish local packages with `pnpm release` (Nx release using conventional commits).

## Testing

- **Framework:** Jest 30 with `@testing-library/react`
- **Test location:** Co-located in `src/__tests__/` directories within each package
- **Run single test file:** `pnpm nx test <package> -- --testPathPattern=<pattern>`
- Tests depend on built dependencies (`"test": { "dependsOn": ["^build"] }` in nx.json), but local dev uses source resolution so this mainly matters in CI

## API Client

The centralized API client is imported from `@smaf/iops-core-ui`. It provides an Axios instance with:

- Base URL from `IOPS_API_BASE_URL` env var
- Auth token injection via interceptors
- Centralized error handling via `setupApiInterceptors()`
- Named endpoint constants for 8 backend services (agents, rag, connectors, authz, assets, dashboard, tools, llm)
