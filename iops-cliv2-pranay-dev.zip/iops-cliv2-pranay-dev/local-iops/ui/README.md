# IntelligentOps UI

## Prerequisites

- Node.js 20+
- pnpm 9+
- Access to the Deloitte Artifactory registry for `@smaf` packages

## Setup

```bash
pnpm install
cp apps/intelligentops-ui/.env.example apps/intelligentops-ui/.env
```

## Development

```bash
pnpm start
```

## Scripts

| Command                | Description                   |
| ---------------------- | ----------------------------- |
| `pnpm start`           | Start dev server              |
| `pnpm build`           | Production build              |
| `pnpm test`            | Run all tests                 |
| `pnpm lint`            | Lint with Biome               |
| `pnpm check`           | Lint + format check           |
| `pnpm check:fix`       | Auto-fix lint + format        |
| `pnpm generate:plugin` | Scaffold a new plugin package |

## Creating Plugins

```bash
pnpm generate:plugin
```

Or pass options inline:

```bash
pnpm generate:plugin --name=my-feature --displayName="My Feature" --featurePermission=my_feature
```
