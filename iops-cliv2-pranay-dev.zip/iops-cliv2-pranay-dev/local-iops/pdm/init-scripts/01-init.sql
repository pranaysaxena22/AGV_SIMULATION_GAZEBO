-- Combined Database Initialization Script
-- This script includes both sample data and PDM table structures
-- Updated to match the final schema from combined_database_init.sql

-- =============================================================================
-- PDM Database Schema (Final state after all migrations V1.0.0 - V1.0.2)
-- =============================================================================

CREATE TABLE IF NOT EXISTS pdm_anomalies
(
    detected_time timestamp with time zone NOT NULL,
    risk_score double precision NOT NULL,
    risk_threshold double precision NOT NULL,
    entity_hierarchy character varying(255) COLLATE pg_catalog."default" NOT NULL,
    contributing_factor json,
    is_anomaly boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT pdm_anomalies_pkey PRIMARY KEY (detected_time, entity_hierarchy)
);

CREATE TABLE IF NOT EXISTS pdm_avg_anomalies
(
    detected_time date NOT NULL,
    entity_hierarchy character varying(255) COLLATE pg_catalog."default" NOT NULL,
    calculation_mode character varying(255) COLLATE pg_catalog."default" NOT NULL,
    avg_risk_score double precision NOT NULL,
    avg_risk_threshold double precision NOT NULL,
    event_count integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT pdm_avg_anomalies_pkey PRIMARY KEY (detected_time, entity_hierarchy, calculation_mode)
);

CREATE TABLE IF NOT EXISTS pdm_tag_configurations
(
    "plantName" character varying(255) NOT NULL,
    "entityHierarchy" character varying(255) NOT NULL,
    "tag" character varying(255) NOT NULL,
    "uom" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    CONSTRAINT pdm_tag_configuration_pkey PRIMARY KEY ("plantName", "entityHierarchy", "tag")
);

CREATE TABLE IF NOT EXISTS pdm_batch_lookup_tables
(
    "jobId" SERIAL PRIMARY KEY,
    "plantName" character varying(255) NOT NULL,
    "cronExpression" character varying(255) COLLATE pg_catalog."default",
    "isActive" boolean NOT NULL,
    "jobStatus" character varying(255) COLLATE pg_catalog."default" NOT NULL,
    "timeRangeMs" INT NOT NULL DEFAULT 3600000,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "Batch" character varying(255)
);

CREATE TABLE IF NOT EXISTS pdm_actions
(
    "actionId" INTEGER GENERATED ALWAYS AS IDENTITY (START WITH 1) PRIMARY KEY,
    "asset" character varying NOT NULL,
    "category" character varying,
    "workOrderId" character varying NOT NULL,
    "description" text,
    "actionPlan" text,
    "startDate" timestamp with time zone,
    "dueDate" timestamp with time zone,
    "priority" character varying,
    "createdByEmail" character varying,
    "assignedToEmail" character varying,
    "createdByName" character varying,
    "assignedToName" character varying,
    "status" character varying NOT NULL,
    "comments" boolean,
    "entityHierarchy" character varying
);

-- Add helpful comments
COMMENT ON TABLE pdm_anomalies IS 'Stores anomaly detection results with risk scores and contributing factors';
COMMENT ON TABLE pdm_avg_anomalies IS 'Stores averaged anomaly data grouped by calculation mode and time period';
COMMENT ON TABLE pdm_tag_configurations IS 'Configuration settings for sensor tags by plant and entity hierarchy';
COMMENT ON TABLE pdm_batch_lookup_tables IS 'Batch job configuration and scheduling information';
COMMENT ON TABLE pdm_actions IS 'Action items and work orders generated from anomaly detections';

-- =============================================================================
-- Sample Data for Testing
-- =============================================================================

-- Create a sample users table for testing
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert some sample data
INSERT INTO users (username, email) VALUES
    ('john_doe', 'john@example.com'),
    ('jane_smith', 'jane@example.com'),
    ('bob_wilson', 'bob@example.com')
ON CONFLICT (username) DO NOTHING;

-- Create an index
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- -- Insert some sample PDM data for testing
-- INSERT INTO pdm_batch_lookup_tables ("plantName", "cronExpression", "isActive", "jobStatus", "Batch", created_at, updated_at) VALUES
--     ('PLANT_001', '0 0 */6 * * *', true, 'SCHEDULED', 'BATCH_A', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
--     ('PLANT_002', '0 0 */12 * * *', true, 'RUNNING', 'BATCH_B', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
-- ON CONFLICT ("jobId") DO NOTHING;

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO postgres;

-- =============================================================================
-- Sample PDM Batch Lookup Data for Garud Plant
-- =============================================================================

-- Insert batch job configuration for Garud plant
INSERT INTO pdm_batch_lookup_tables ("plantName", "cronExpression", "isActive", "jobStatus", "timeRangeMs", "createdAt", "updatedAt", "Batch") VALUES
('GARUD', '*/1 * * * *', true, 'Running', 3600000, '2025-10-01 22:27:17.676+05:30', '2025-10-02 14:04:15.785+05:30', 'canary')
ON CONFLICT ("jobId") DO NOTHING;

-- =============================================================================
-- Sample PDM Tag Configuration Data for Garud Plant
-- =============================================================================

-- Insert vibration sensor tag configurations for Garud plant
INSERT INTO pdm_tag_configurations ("plantName", "entityHierarchy", "tag", "uom", "createdAt", "updatedAt") VALUES
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Acceleration Peak', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Acceleration RMS', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Band A', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Band B', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Band C', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Band D', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Band E', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Band F', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Deg C', 'C', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Velocity Peak', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.X Axis.Velocity RMS', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Acceleration Peak', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Acceleration RMS', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Band A', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Band B', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Band C', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Band D', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Band E', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Band F', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Deg C', 'C', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Velocity Peak', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Y Axis.Velocity RMS', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Acceleration Peak', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Acceleration RMS', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Band A', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Band B', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Band C', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Band D', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Band E', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Band F', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Deg C', 'C', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Velocity Peak', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z0|C002|A017', 'Vibration.Z Axis.Velocity RMS', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Acceleration Peak', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Acceleration RMS', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Band A', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Band B', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Band C', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Band D', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Band E', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Band F', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Deg C', 'C', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Velocity Peak', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.X Axis.Velocity RMS', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Acceleration Peak', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Acceleration RMS', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Band A', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Band B', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Band C', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Band D', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Band E', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Band F', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Deg C', 'C', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Velocity Peak', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Y Axis.Velocity RMS', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Acceleration Peak', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Acceleration RMS', 'mm/s^2', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Band A', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Band B', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Band C', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Band D', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Band E', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Band F', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Deg C', 'C', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Velocity Peak', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30'),
('GARUD', 'Deloitte|GARUDBU|GARUD|AR1|L1|Z1|C101|A006', 'Vibration.Z Axis.Velocity RMS', 'mm/s', '2025-08-18 17:23:50.465+05:30', '2025-08-18 17:23:50.465+05:30')
ON CONFLICT ("plantName", "entityHierarchy", "tag") DO NOTHING;
