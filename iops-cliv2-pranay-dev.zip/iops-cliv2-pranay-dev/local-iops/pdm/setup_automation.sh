#!/bin/sh

echo "🚀 Starting automated setup process..."

echo "📝 Step 1: Deleting existing mappings..."
curl -X DELETE 'http://simulator:8080/__admin/mappings' || echo 'No mappings to delete'

echo "📝 Step 2: Uploading CSV file..."
curl -f --location 'http://simulator:8080/__admin/csv?overwrite=true&filename=pdm_canary_data.csv' --form 'file=@./sensor_data.csv'

echo "📝 Step 3: Creating mapping..."
curl -f --location 'http://simulator:8080/__admin/mapping' \
--header 'Content-Type: application/json' \
--data '{
    "path": "/canary2",
    "method": "POST",
    "dataSource": "pdm_canary_data.csv",
    "transformers": [
        "canary",
        "mulesoft"
    ],
    "responseStructure": "groupedDataMap = new('\''java.util.HashMap'\'');for (row : dataset) {        tag = row.get('\''tag'\'');     if (tag == null) {        continue;     }    if(groupedDataMap.get(tag) != null) {        tagDataList = groupedDataMap.get(tag);        dataToAdd = new('\''java.util.HashMap'\'');        dataToAdd.put('\''q'\'', row.get('\''q'\'')*1);        dataToAdd.put('\''t'\'', row.get('\''t'\''));        dataToAdd.put('\''v'\'', row.get('\''v'\'')*1);        tagDataList.add(dataToAdd);    } else {        tagDataList = new('\''java.util.ArrayList'\'');        dataToAdd = new('\''java.util.HashMap'\'');        dataToAdd.put('\''q'\'', row.get('\''q'\'')*1);        dataToAdd.put('\''t'\'', row.get('\''t'\''));        dataToAdd.put('\''v'\'', row.get('\''v'\'')*1);        tagDataList.add(dataToAdd);        groupedDataMap.put(tag, tagDataList);    }}resultMap = new('\''java.util.HashMap'\'');resultMap.put('\''data'\'', groupedDataMap);resultMap.put('\''statusCode'\'', '\''Good'\'');resultMap.put('\''continuation'\'', null);resultMap.put('\''errors'\'', []);return resultMap;"
}'

echo "📝 Step 4: Testing the mapping..."
curl -f --location 'http://simulator:8080/canary2' \
--header 'Content-Type: application/json' \
--data '{"tags":["SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Acceleration Peak","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Acceleration RMS","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Band A","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Band B","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Band C","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Band D","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Band E","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Band F","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Deg C","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Velocity Peak","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.X Axis.Velocity RMS","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Acceleration Peak","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Acceleration RMS","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Band A","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Band B","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Band C","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Band D","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Band E","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Band F","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Deg C","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Velocity Peak","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Y Axis.Velocity RMS","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Acceleration Peak","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Acceleration RMS","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Band A","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Band B","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Band C","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Band D","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Band E","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Band F","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Deg C","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Velocity Peak","SF-Canary01.Test.AR1.L1.Z0.C002.A017.Vibration.Z Axis.Velocity RMS"],"startTime":"2025-10-03T00:15:00.019Z","endTime":"2025-10-03T11:15:00.018Z","includeQuality":false,"aggregateName":"TimeAverage2","aggregateInterval":"01:00:00"}'

echo "📝 Step 5: Restarting GARUD job..."
sleep 5
curl -f --location --request POST 'http://pdm-ms-api:9000/pdm-api/batch/triggerJob?action=restart&plantName=GARUD'

echo "✅ Automated setup completed successfully! All 5 steps executed."
echo "🎯 Simulator is configured and GARUD job is restarted. System ready for PDM operations."
